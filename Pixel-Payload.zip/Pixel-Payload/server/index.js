'use strict';
// Sunucu bağlama: Express (public/ statik) + Socket.io olayları -> oda yöneticisi.
// GÜVENLİK: istemciye yalnızca viewFor(room, playerId, sim, chat) çıktısı, her oyuncuya ayrı ayrı gider (oda yayını YOK).

const path = require('path');
const http = require('http');
const os = require('os');
const express = require('express');
const { Server } = require('socket.io');

const { createRoomManager } = require('./rooms');
const { viewFor } = require('./filter');
const { GameError, msg, hasMessage, isLang, normLang, DEFAULT_LANG } = require('./constants');

// --- Bağımlı modüller (sim, chat): yoksa anlaşılır hata ------------------------
function loadModule(rel, what) {
  try {
    return require(rel);
  } catch (err) {
    if (err && err.code === 'MODULE_NOT_FOUND' && String(err.message).includes(rel.replace('./', ''))) {
      const msg = `Pixel Payload: ${what} modülü bulunamadı (server/${rel.replace('./', '')}). `
        + 'Sunucu bu modül olmadan başlayamaz.';
      if (require.main === module) {
        console.error(msg);
        process.exit(1);
      }
      throw new Error(msg);
    }
    throw err;
  }
}

const TICK_MS = 250;
const RATE = { count: 40, perMs: 5000 }; // socket başına olay sınırı

// --- Ortam değişkenleri ------------------------------------------------------
function envNum(name) {
  const raw = process.env[name];
  if (raw === undefined || String(raw).trim() === '') return undefined;
  const n = Number(raw);
  if (Number.isFinite(n) && n >= 0) return n;
  console.warn(`[config] ${name}="${raw}" geçersiz, yok sayıldı.`);
  return undefined;
}

const config = {};
if (envNum('PP_PHASE_MS') !== undefined) config.phaseMs = envNum('PP_PHASE_MS');
if (envNum('PP_GRACE_MS') !== undefined) config.reconnectGraceMs = envNum('PP_GRACE_MS');

const { createSim } = loadModule('./sim', 'Simülasyon');
const { createChat } = loadModule('./chat', 'Sohbet');
const sim = createSim({ dataDir: path.join(__dirname, '..', 'data') });
const chat = createChat({ now: Date.now });
const manager = createRoomManager({ sim, chat, now: Date.now, config });
const PHASE_MS = manager.config.phaseMs;

// --- HTTP ----------------------------------------------------------------------
const app = express();
app.use(express.static(path.join(__dirname, '..', 'public')));

// Yerel kütüphaneler (CDN yok). node_modules'un yalnız bu klasörleri açılır.
const NM = path.join(__dirname, '..', 'node_modules');
const vendorOpts = { index: false, fallthrough: true, dotfiles: 'ignore', maxAge: '1h' };
app.use('/vendor/fonts/jetbrains-mono', express.static(path.join(NM, '@fontsource', 'jetbrains-mono'), vendorOpts));
app.use('/vendor/fonts/rajdhani', express.static(path.join(NM, '@fontsource', 'rajdhani'), vendorOpts));

// JSON dosyası oku (yoksa/bozuksa null)
function readJson(file) {
  try { return JSON.parse(require('fs').readFileSync(file, 'utf8').replace(/^﻿/, '')); } catch (e) { return null; }
}

// Bilimsel kaynak listesi (UÇUŞ VERİLERİ sayfası, debrief). ?lang=en|tr (varsayılan en):
// en'de data/i18n/en/sources.json başlık bindirmesi uygulanır. Dosya yoksa/bozuksa boş dizi.
app.get('/api/sources', (req, res) => {
  const lang = normLang(typeof req.query.lang === 'string' ? req.query.lang : DEFAULT_LANG);
  const parsed = readJson(path.join(__dirname, '..', 'data', 'science', 'sources.json'));
  let list = Array.isArray(parsed) ? parsed : [];
  if (lang !== 'tr') {
    const over = readJson(path.join(__dirname, '..', 'data', 'i18n', lang, 'sources.json'));
    if (over && typeof over === 'object') {
      list = list.map((src) => {
        const o = src && over[src.id];
        return o && typeof o.title === 'string' ? { ...src, title: o.title } : src;
      });
    }
  }
  res.json(list);
});

function lanAddresses() {
  const out = [];
  for (const list of Object.values(os.networkInterfaces())) {
    for (const a of list || []) {
      if ((a.family === 'IPv4' || a.family === 4) && !a.internal) out.push(a.address);
    }
  }
  return out;
}

let listenPort = Number(process.env.PORT) || 3000;
app.get('/api/info', (req, res) => {
  res.json({ lanUrls: lanAddresses().map((ip) => `http://${ip}:${listenPort}`) });
});

const server = http.createServer(app);
const io = new Server(server);

// --- Yardımcılar ---------------------------------------------------------------

function socketOf(player) {
  return player && player.connected && player.socketId ? io.sockets.sockets.get(player.socketId) : undefined;
}

// Belirtilen (yoksa tüm) oyunculara kendi filtrelenmiş görünümünü gönder
function sendStates(code, onlyIds) {
  const room = manager.getRoom(code);
  if (!room) return;
  for (const p of room.players.values()) {
    if (onlyIds && !onlyIds.has(p.id)) continue;
    const s = socketOf(p);
    if (!s) continue;
    const view = viewFor(room, p.id, sim, chat, { phaseMs: PHASE_MS });
    if (view) s.emit('state', view);
  }
}

// Bu koda bağlı ama odada artık olmayan socket'lere room:closed (neden alıcının dilinde)
function notifyClosed(code, key) {
  for (const s of io.sockets.sockets.values()) {
    if (s.data && s.data.code === code && !manager.getRoom(code)) {
      const lang = normLang(s.data.lang);
      s.data = { lang };
      s.emit('room:closed', { reason: msg(lang, key) });
    }
  }
}

function attach(socket, code, playerId) {
  socket.data = { ...socket.data, code, playerId, lang: manager.langOf(code, playerId) };
}

// Socket'in dili: geçerli payload.lang > odadaki oyuncunun dili > son bilinen > en
function socketLang(socket, payload) {
  if (payload && typeof payload === 'object' && isLang(payload.lang)) return payload.lang;
  const { code, playerId, lang } = socket.data || {};
  const p = code && playerId ? manager.getPlayer(code, playerId) : undefined;
  if (p && isLang(p.lang)) return p.lang;
  return normLang(lang);
}

// Socket'i şu anki odasından çıkar (leave ya da başka odaya geçiş)
function leaveCurrent(socket) {
  const { code, playerId } = socket.data || {};
  socket.data = { rate: socket.data && socket.data.rate, lang: socket.data && socket.data.lang };
  if (!code || !playerId) return;
  const p = manager.getPlayer(code, playerId);
  if (!p || p.socketId !== socket.id) return; // başka socket devraldıysa dokunma
  manager.leave(code, playerId);
  sendStates(code);
}

function requireRoom(socket) {
  const { code, playerId } = socket.data || {};
  const p = code && playerId ? manager.getPlayer(code, playerId) : undefined;
  if (!p || p.socketId !== socket.id) throw new GameError('NOT_IN_ROOM', 'err.notInAnyRoom');
  return { code, playerId };
}

// Payload doğrulama yardımcıları (key = mesaj kataloğu anahtarı)
function bad(key) { return new GameError('BAD_REQUEST', key); }
function needStr(v, key, max = 200) {
  if (typeof v !== 'string' || v.length === 0 || v.length > max) throw bad(key);
  return v;
}
// İsteğe bağlı lang: yoksa undefined, geçersizse BAD_REQUEST
function optLang(p) {
  if (p.lang === undefined || p.lang === null) return undefined;
  if (!isLang(p.lang)) throw bad('err.badLang');
  return p.lang;
}

// Socket başına basit hız sınırı (kayan pencere sayacı)
function rateOk(socket) {
  const now = Date.now();
  const r = socket.data.rate || (socket.data.rate = { start: now, n: 0 });
  if (now - r.start >= RATE.perMs) { r.start = now; r.n = 0; }
  r.n++;
  return r.n <= RATE.count;
}

// Olay sarmalayıcı: payload tipi, hız sınırı, hatalar, ack, sonrasında state.
// handler(payload) -> { ack, touched?: code, only?: Set<playerId> }
function on(socket, event, handler) {
  socket.on(event, (payload, ack) => {
    if (typeof payload === 'function' && ack === undefined) { ack = payload; payload = undefined; }
    const reply = typeof ack === 'function' ? ack : () => {};
    let res;
    let out = null;
    try {
      if (!rateOk(socket)) throw new GameError('RATE_LIMITED', 'err.rate');
      if (payload !== undefined && payload !== null && (typeof payload !== 'object' || Array.isArray(payload))) {
        throw bad('err.badFormat');
      }
      out = handler(payload || {}) || {};
      res = out.ack || { ok: true };
    } catch (err) {
      out = null;
      // ack mesajı oyuncunun dilinde
      const lang = socketLang(socket, payload);
      if (err instanceof GameError || (err && typeof err.code === 'string' && err.name === 'GameError')) {
        if (typeof err.localize === 'function') err.localize(lang);
        res = { ok: false, error: err.code, message: err.message };
      } else {
        console.error(`[${event}] beklenmeyen hata:`, err);
        res = { ok: false, error: 'BAD_REQUEST', message: msg(lang, 'err.failed') };
      }
    }
    try { reply(res); } catch (e) { console.error(`[${event}] ack hatası:`, e); }
    if (out && out.touched) {
      try { sendStates(out.touched, out.only); } catch (e) { console.error(`[${event}] state hatası:`, e); }
    }
  });
}

// --- Socket olayları -----------------------------------------------------------

io.on('connection', (socket) => {
  socket.data = {};

  on(socket, 'room:create', (p) => {
    needStr(p.name, 'req.name', 64);
    const lang = optLang(p);
    leaveCurrent(socket);
    const { room, player } = manager.createRoom(p.name, socket.id, lang);
    attach(socket, room.code, player.id);
    return { ack: { ok: true, code: room.code, playerId: player.id }, touched: room.code };
  });

  on(socket, 'room:join', (p) => {
    needStr(p.code, 'req.code', 16);
    needStr(p.name, 'req.name', 64);
    const lang = optLang(p);
    if (!manager.getRoom(p.code)) throw new GameError('ROOM_NOT_FOUND', 'err.roomNotFound');
    leaveCurrent(socket);
    const { room, player } = manager.joinRoom(p.code, p.name, socket.id, lang);
    attach(socket, room.code, player.id);
    return { ack: { ok: true, code: room.code, playerId: player.id }, touched: room.code };
  });

  on(socket, 'room:rejoin', (p) => {
    needStr(p.code, 'req.code', 16);
    needStr(p.playerId, 'req.playerId', 64);
    const lang = optLang(p);
    const room = manager.getRoom(p.code);
    if (!room) throw new GameError('ROOM_NOT_FOUND', 'err.roomNotFound');
    const player = manager.getPlayer(room.code, p.playerId);
    if (!player) throw new GameError('NOT_IN_ROOM', 'err.notInRoom');
    if (socket.data.playerId && socket.data.playerId !== p.playerId) leaveCurrent(socket);
    // Aynı oyuncu başka bir socket'teyse eskisini düşür (yeni olan geçerli)
    if (player.socketId && player.socketId !== socket.id) {
      const old = io.sockets.sockets.get(player.socketId);
      if (old) {
        const oldLang = normLang(player.lang);
        old.data = { lang: oldLang };
        old.emit('room:closed', { reason: msg(oldLang, 'msg.otherLogin') });
        old.disconnect(true);
      }
    }
    manager.rejoin(room.code, p.playerId, socket.id, lang);
    attach(socket, room.code, p.playerId);
    return { ack: { ok: true, code: room.code, playerId: p.playerId }, touched: room.code };
  });

  // Oyuncu dili (her fazda). Yalnız o oyuncuya yeni state gider.
  on(socket, 'player:lang', (p) => {
    if (!isLang(p.lang)) throw bad('err.badLang');
    const { code, playerId } = requireRoom(socket);
    manager.setLang(code, playerId, p.lang);
    socket.data.lang = p.lang;
    return { touched: code, only: new Set([playerId]) };
  });

  on(socket, 'room:leave', () => {
    leaveCurrent(socket);
    return { ack: { ok: true } };
  });

  on(socket, 'role:select', (p) => {
    const { code, playerId } = requireRoom(socket);
    if (!('role' in p) || (p.role !== null && typeof p.role !== 'string')) throw bad('req.role');
    manager.selectRole(code, playerId, p.role);
    return { touched: code };
  });

  on(socket, 'player:ready', (p) => {
    const { code, playerId } = requireRoom(socket);
    if (typeof p.ready !== 'boolean') throw bad('err.readyBool');
    manager.setReady(code, playerId, p.ready);
    return { touched: code };
  });

  on(socket, 'host:start', () => {
    const { code, playerId } = requireRoom(socket);
    manager.startGame(code, playerId);
    return { touched: code };
  });

  on(socket, 'host:kick', (p) => {
    const { code, playerId } = requireRoom(socket);
    if (!Number.isInteger(p.seat)) throw bad('req.seat');
    const { kicked } = manager.kick(code, playerId, p.seat);
    const s = kicked.socketId ? io.sockets.sockets.get(kicked.socketId) : undefined;
    if (s) {
      const kLang = normLang(kicked.lang);
      s.data = { rate: s.data && s.data.rate, lang: kLang };
      s.emit('kicked', { reason: msg(kLang, 'msg.kicked') });
    }
    return { touched: code };
  });

  on(socket, 'host:transfer', (p) => {
    const { code, playerId } = requireRoom(socket);
    if (!Number.isInteger(p.seat)) throw bad('req.seat');
    manager.transferHost(code, playerId, p.seat);
    return { touched: code };
  });

  on(socket, 'mission:select', (p) => {
    const { code, playerId } = requireRoom(socket);
    needStr(p.missionId, 'req.missionId', 64);
    manager.selectMission(code, playerId, p.missionId);
    return { touched: code };
  });

  on(socket, 'briefing:ack', () => {
    const { code, playerId } = requireRoom(socket);
    manager.ackBriefing(code, playerId);
    return { touched: code };
  });

  on(socket, 'briefing:skip', () => {
    const { code, playerId } = requireRoom(socket);
    manager.skipBriefing(code, playerId);
    return { touched: code };
  });

  on(socket, 'equip:add', (p) => {
    const { code, playerId } = requireRoom(socket);
    needStr(p.itemId, 'req.itemId', 100);
    needStr(p.moduleId, 'req.moduleId', 100);
    const { uid } = manager.addItem(code, playerId, p.itemId, p.moduleId);
    return { ack: { ok: true, uid }, touched: code };
  });

  on(socket, 'equip:remove', (p) => {
    const { code, playerId } = requireRoom(socket);
    needStr(p.uid, 'req.uid', 64);
    manager.removeItem(code, playerId, p.uid);
    return { touched: code };
  });

  on(socket, 'setting:set', (p) => {
    const { code, playerId } = requireRoom(socket);
    needStr(p.key, 'req.settingKey', 64);
    if (!['number', 'string', 'boolean'].includes(typeof p.value)) throw bad('req.settingValue');
    manager.setSetting(code, playerId, p.key, p.value);
    return { touched: code };
  });

  on(socket, 'review:open', () => {
    const { code, playerId } = requireRoom(socket);
    manager.openReview(code, playerId);
    return { touched: code };
  });

  on(socket, 'review:signoff', (p) => {
    const { code, playerId } = requireRoom(socket);
    needStr(p.decision, 'req.decision', 8);
    manager.signoff(code, playerId, p.decision);
    return { touched: code };
  });

  on(socket, 'review:back', () => {
    const { code, playerId } = requireRoom(socket);
    manager.backToDesign(code, playerId);
    return { touched: code };
  });

  // { confirm?: boolean } — READY olmayan tasarım için confirm:true gerekir (yoksa LAUNCH_CONFIRM)
  on(socket, 'mission:launch', (p) => {
    const { code, playerId } = requireRoom(socket);
    if ('confirm' in p && p.confirm !== undefined && typeof p.confirm !== 'boolean') throw bad('req.confirm');
    manager.launch(code, playerId, { confirm: p.confirm === true });
    return { touched: code };
  });

  on(socket, 'phase:back', () => {
    const { code, playerId } = requireRoom(socket);
    manager.goBack(code, playerId);
    return { touched: code };
  });

  on(socket, 'game:again', (p) => {
    const { code, playerId } = requireRoom(socket);
    needStr(p.mode, 'req.mode', 8);
    manager.playAgain(code, playerId, p.mode);
    return { touched: code };
  });

  on(socket, 'chat:send', (p) => {
    const { code, playerId } = requireRoom(socket);
    needStr(p.to, 'req.to', 32);
    if (typeof p.text !== 'string' || p.text.length > 2000) throw bad('req.text');
    const room = manager.getRoom(code);
    const res = chat.send(room, playerId, { to: p.to, text: p.text });
    if (!res || !res.ok) {
      const errCode = (res && res.error) || 'BAD_REQUEST';
      throw new GameError(errCode, hasMessage(`chat.${errCode}`) ? `chat.${errCode}` : 'chat.failed');
    }
    // Mesaj yalnız alıcılara + gönderene
    const ids = new Set([...(Array.isArray(res.recipients) ? res.recipients : []), playerId]);
    for (const id of ids) {
      const s = socketOf(room.players.get(id));
      if (s) s.emit('chat:message', res.message);
    }
    return { ack: { ok: true, message: res.message }, touched: code, only: ids };
  });

  socket.on('disconnect', () => {
    try {
      const { code, playerId } = socket.data || {};
      if (!code || !playerId) return;
      manager.setConnected(code, playerId, false, socket.id);
      sendStates(code);
    } catch (e) {
      console.error('[disconnect] hata:', e);
    }
  });
});

// --- Tick döngüsü (simülasyon aşamaları, süre aşımları, boş oda) ----------------
const tickTimer = setInterval(() => {
  let codes;
  try { codes = manager.roomCodes(); } catch (e) { console.error('[tick] roomCodes hatası:', e); return; }
  for (const code of codes) {
    try {
      if (!manager.tick(code)) continue;
      if (manager.getRoom(code)) sendStates(code);
      else notifyClosed(code, 'msg.roomClosed');
    } catch (e) {
      console.error(`[tick] ${code} hatası:`, e);
    }
  }
}, TICK_MS);
if (tickTimer.unref) tickTimer.unref();

// --- Başlatma ------------------------------------------------------------------
if (require.main === module) {
  listenPort = Number(process.env.PORT) || 3000;
  server.listen(listenPort, '0.0.0.0', () => {
    console.log('Pixel Payload sunucusu çalışıyor:');
    console.log(`  http://localhost:${listenPort}`);
    for (const ip of lanAddresses()) console.log(`  http://${ip}:${listenPort}   (aynı Wi-Fi'deki oyuncular için)`);
  });
}

module.exports = { app, server, io, manager, sim, chat };
