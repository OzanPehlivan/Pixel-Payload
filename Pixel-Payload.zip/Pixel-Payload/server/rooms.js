'use strict';
// Oda / oyuncu / akış mantığı (Aşama 7 + 8.3 + 9.3: oyuncu dili). Socket bilmez; hatalarda GameError fırlatır
// (mesaj, işlemi yapan oyuncunun dilinde). Değerlendirme/simülasyon/debrief temel dilde (en) tutulur;
// başka dil gerekince evalFor/simResultFor/debriefFor ile aynı girdilerle (aynı tohum) hesaplanıp önbelleğe alınır.
// Zamanlayıcı KURMAZ: zaman now() ile okunur, ilerleme tick(code) ile olur.
// Simülasyon ve sohbet dışarıdan verilir (sim: server/sim, chat: server/chat).

const crypto = require('crypto');
const {
  ROLES, ENGINEER_ROLES, PHASES, MAX_PLAYERS, SIGNOFF_DECISIONS, PLAY_AGAIN_MODES,
  DEFAULTS, GameError, LEDGER_MAX, launchStatusOf, DEFAULT_LANG, isLang, normLang, msg, hasMessage,
} = require('./constants');

// Odanın temel dili: room.evaluation / room.sim.result / room.debrief bu dilde
const BASE_LANG = DEFAULT_LANG;

// Oda kodu alfabesi: A–Z, I ve O hariç
const CODE_ALPHABET = 'ABCDEFGHJKLMNPQRSTUVWXYZ';
const CODE_LENGTH = 4;
const NAME_MAX = 16;
const LOG_MAX = 200;

const nonNeg = (v) => typeof v === 'number' && Number.isFinite(v) && v >= 0;
const isStr = (v) => typeof v === 'string' && v.length > 0 && v.length <= 200;

function cleanName(name) {
  const n = typeof name === 'string' ? name.replace(/[\u0000-\u001f\u007f]/g, '').trim() : '';
  if (n.length < 1 || n.length > NAME_MAX) {
    throw new GameError('NAME_REQUIRED', 'err.name', { max: NAME_MAX });
  }
  return n;
}

function normalizeCode(code) {
  if (typeof code !== 'string') throw new GameError('BAD_REQUEST', 'err.badCode');
  return code.trim().toUpperCase();
}

const emptySignoff = () => ({ rocket: null, spacecraft: null, payload: null });
const emptyChat = () => ({ threads: { rocket: [], spacecraft: [], payload: [], broadcast: [] }, rate: {} });
const clone = (v) => (v === undefined ? undefined : structuredClone(v));

// --- Dil başına değerlendirme / simülasyon / debrief (filter.js de kullanır) -------

// Oyuncu dilindeki değerlendirme. Temel dil → room.evaluation; diğer dil → aynı build/ayarla
// sim.evaluate(..., { lang }) (room.evaluation değişince önbellek kendiliğinden geçersizleşir).
function evalFor(room, sim, lang) {
  const base = room ? room.evaluation || null : null;
  const l = normLang(lang);
  if (!base || l === BASE_LANG || !room.missionId || !sim || typeof sim.evaluate !== 'function') return base;
  let c = room.evalByLang;
  if (!c || c.base !== base) c = room.evalByLang = { base, [BASE_LANG]: base };
  if (!c[l]) {
    try { c[l] = sim.evaluate(room.missionId, clone(room.build), clone(room.settings), { lang: l }) || base; } catch { c[l] = base; }
  }
  return c[l];
}

// Oyuncu dilindeki simülasyon sonucu: AYNI tohum + fırlatma anındaki build/ayar
function simResultFor(room, sim, lang) {
  const rs = room && room.sim;
  if (!rs) return null;
  const l = normLang(lang);
  if (l === BASE_LANG || !rs.build || !sim || typeof sim.simulate !== 'function') return rs.result;
  if (!rs.byLang) rs.byLang = {};
  if (!rs.byLang[l]) {
    try { rs.byLang[l] = sim.simulate(room.missionId, clone(rs.build), clone(rs.settings), rs.seed, { lang: l }) || rs.result; } catch { rs.byLang[l] = rs.result; }
  }
  return rs.byLang[l];
}

// Oyuncu dilindeki debrief (aynı ekip istatistikleriyle)
function debriefFor(room, sim, lang) {
  const base = room ? room.debrief || null : null;
  const l = normLang(lang);
  if (!base || l === BASE_LANG || !room.sim || !room.sim.team || !sim || typeof sim.debrief !== 'function') return base;
  let c = room.debriefByLang;
  if (!c || c.base !== base) c = room.debriefByLang = { base, [BASE_LANG]: base };
  if (!c[l]) {
    try {
      c[l] = sim.debrief(room.missionId, clone(evalFor(room, sim, l)), clone(simResultFor(room, sim, l)), clone(room.sim.team), { lang: l }) || base;
    } catch { c[l] = base; }
  }
  return c[l];
}

function createRoomManager({ sim, chat, now = Date.now, rng = Math.random, config = {} } = {}) {
  if (!sim || typeof sim.canAdd !== 'function' || typeof sim.evaluate !== 'function'
    || typeof sim.simulate !== 'function' || typeof sim.debrief !== 'function') {
    throw new TypeError('createRoomManager: sim zorunlu (server/sim createSim çıktısı).');
  }
  const cfg = config && typeof config === 'object' ? config : {};
  const PHASE_MS = nonNeg(cfg.phaseMs) ? cfg.phaseMs : DEFAULTS.phaseMs;
  const GRACE_MS = nonNeg(cfg.reconnectGraceMs) ? cfg.reconnectGraceMs : DEFAULTS.reconnectGraceMs;
  const EMPTY_MS = nonNeg(cfg.emptyRoomMs) ? cfg.emptyRoomMs : DEFAULTS.emptyRoomMs;

  const rooms = new Map(); // code -> room

  // Sağlam saat: now() bozuk değer dönerse gerçek saate düş
  const clock = () => {
    const t = Number(typeof now === 'function' ? now() : NaN);
    return Number.isFinite(t) ? t : Date.now();
  };

  // Günlük kaydı: key/params saklanır (her dile çevrilebilir), text temel dilde
  function pushLog(room, kind, role, key, params) {
    room.log.push({ ts: clock(), kind, role: role || null, key, params: params || null, text: msg(BASE_LANG, key, params) });
    if (room.log.length > LOG_MAX) room.log.splice(0, room.log.length - LOG_MAX);
  }

  // --- Oda / oyuncu erişimi ------------------------------------------------

  function newCode() {
    for (let tries = 0; tries < 1000; tries++) {
      let code = '';
      for (let i = 0; i < CODE_LENGTH; i++) {
        code += CODE_ALPHABET[Math.floor(rng() * CODE_ALPHABET.length) % CODE_ALPHABET.length];
      }
      if (!rooms.has(code)) return code;
    }
    throw new GameError('BAD_REQUEST', 'err.noFreeCode');
  }

  function mustRoom(code) {
    const room = rooms.get(normalizeCode(code));
    if (!room) throw new GameError('ROOM_NOT_FOUND', 'err.roomNotFound');
    return room;
  }

  function mustPlayer(room, playerId) {
    const player = typeof playerId === 'string' ? room.players.get(playerId) : undefined;
    if (!player) throw new GameError('NOT_IN_ROOM', 'err.notInRoom');
    return player;
  }

  function freeSeat(room) {
    const used = new Set([...room.players.values()].map((p) => p.seat));
    let s = 1;
    while (used.has(s)) s++;
    return s;
  }

  function newPlayer(room, name, socketId, lang) {
    return {
      id: crypto.randomUUID(), seat: freeSeat(room), name, role: null, ready: false, lang: normLang(lang),
      connected: true, socketId: typeof socketId === 'string' ? socketId : null, lastSeen: clock(),
    };
  }

  const roleHolder = (room, role) => [...room.players.values()].find((p) => p.role === role);
  const bySeat = (room) => [...room.players.values()].sort((a, b) => a.seat - b.seat);

  function playerBySeat(room, seat) {
    if (!Number.isInteger(seat)) throw new GameError('BAD_REQUEST', 'err.badSeat');
    const p = [...room.players.values()].find((x) => x.seat === seat);
    if (!p) throw new GameError('INVALID_TARGET', 'err.noSeatPlayer');
    return p;
  }

  // Host gittiyse/koptuysa bağlı ilk oyuncuya (koltuk sırası) devret
  function ensureHost(room) {
    const host = room.players.get(room.hostId);
    if (host && host.connected) return;
    const next = bySeat(room).find((p) => p.connected && p.id !== room.hostId);
    if (next) {
      room.hostId = next.id;
      pushLog(room, 'system', next.role, 'log.hostNow', { name: next.name });
    } else if (!host) {
      const any = bySeat(room)[0];
      room.hostId = any ? any.id : null;
    }
  }

  // Oyuncuyu sil (rol boşalır); oda boşaldıysa odayı da sil. Kalan oda veya undefined.
  function dropPlayer(room, playerId) {
    const p = room.players.get(playerId);
    if (!p) return room;
    room.players.delete(playerId);
    if (room.players.size === 0) {
      rooms.delete(room.code);
      return undefined;
    }
    if (p.role && room.briefingAck) room.briefingAck.delete(p.role);
    if (room.hostId === playerId) ensureHost(room);
    pushLog(room, 'system', p.role, 'log.left', { name: p.name });
    // Brifingde bekleyen tek kişi ayrıldıysa akış takılmasın
    if (room.phase === PHASES.BRIEFING && briefingDone(room)) enterDesign(room);
    return room;
  }

  // --- Yetki yardımcıları --------------------------------------------------

  function ctx(code, playerId) {
    const room = mustRoom(code);
    const player = mustPlayer(room, playerId);
    return { room, player };
  }

  function needPhase(room, phases, key) {
    const list = Array.isArray(phases) ? phases : [phases];
    if (!list.includes(room.phase)) throw new GameError('WRONG_PHASE', key || 'err.wrongPhase');
  }

  function needHost(room, player) {
    if (room.hostId !== player.id) throw new GameError('NOT_HOST', 'err.notHost');
  }

  function needDirector(player) {
    if (player.role !== 'director') throw new GameError('NOT_ALLOWED', 'err.directorOnly');
  }

  function needEngineer(player) {
    if (!ENGINEER_ROLES.includes(player.role)) {
      throw new GameError('NOT_ALLOWED', 'err.engineersOnly');
    }
  }

  // --- Görev / değerlendirme ----------------------------------------------

  function missionIds() {
    const list = typeof sim.listMissions === 'function' ? sim.listMissions() : [];
    return (Array.isArray(list) ? list : []).map((m) => m && m.id).filter(Boolean);
  }

  // Değerlendirmeyi temel dilde hesapla (odayı değiştirmez). Diğer diller evalFor ile gerektiğinde.
  function evaluateWith(room, build, settings) {
    if (!room.missionId) return null;
    return sim.evaluate(room.missionId, structuredClone(build), structuredClone(settings), { lang: BASE_LANG });
  }

  function refreshEvaluation(room) {
    room.evaluation = evaluateWith(room, room.build, room.settings);
  }

  function itemName(itemId, lang = BASE_LANG) {
    const it = typeof sim.getItem === 'function' ? sim.getItem(itemId, lang) : null;
    return it && typeof it.name === 'string' ? it.name : String(itemId);
  }

  // Parçanın şu anki maliyeti (build girişine takma anında yazılır)
  function itemCost(itemId) {
    const it = typeof sim.getItem === 'function' ? sim.getItem(itemId) : null;
    return it && Number.isFinite(it.cost) ? it.cost : 0;
  }

  // Build girişinin maliyeti: kayıtlı cost (yoksa eski giriş → katalog maliyeti)
  const entryCost = (entry) => (Number.isFinite(entry.cost) ? entry.cost : itemCost(entry.itemId));

  // --- Harcama defteri (yalnız geçmiş; harcanan = build maliyetleri toplamı) ----

  function pushLedger(room, { role, playerName, action, itemId, moduleId, cost }) {
    if (!Array.isArray(room.ledger)) room.ledger = [];
    room.ledgerSeq = (room.ledgerSeq || 0) + 1;
    room.ledger.push({
      id: room.ledgerSeq, ts: clock(), role: role || null, playerName: playerName || '', action,
      itemId, itemName: itemName(itemId), moduleId, cost,
    });
    if (room.ledger.length > LEDGER_MAX) room.ledger.splice(0, room.ledger.length - LEDGER_MAX);
  }

  // --- Standart donanım (sim.autoItems; yoksa atlanır) ----------------------

  // Eksik standart parçaları build'e ekler (aynı itemId+moduleId varsa eklemez). Eklenen sayı.
  function ensureAutoItems(room) {
    if (!room.missionId || typeof sim.autoItems !== 'function') return 0;
    let list;
    try { list = sim.autoItems(room.missionId); } catch { list = []; }
    if (!Array.isArray(list)) return 0;
    let added = 0;
    for (const a of list) {
      if (!a || !isStr(a.itemId) || !isStr(a.moduleId)) continue;
      if (room.build.some((b) => b.itemId === a.itemId && b.moduleId === a.moduleId)) continue;
      const it = typeof sim.getItem === 'function' ? sim.getItem(a.itemId) : null;
      const role = ENGINEER_ROLES.includes(a.role) ? a.role : (it && it.role);
      if (!ENGINEER_ROLES.includes(role)) continue;
      const entry = { uid: newUid(room), itemId: a.itemId, moduleId: a.moduleId, role, auto: true, cost: itemCost(a.itemId) };
      room.build.push(entry);
      pushLedger(room, { role, playerName: msg(BASE_LANG, 'ledger.standard'), action: 'auto', itemId: entry.itemId, moduleId: entry.moduleId, cost: entry.cost });
      added++;
    }
    return added;
  }

  function newUid(room) {
    const used = new Set(room.build.map((it) => it.uid));
    let uid;
    do uid = crypto.randomBytes(4).toString('hex'); while (used.has(uid));
    return uid;
  }

  // --- Faz geçişleri -------------------------------------------------------

  function enterMissionSelect(room) {
    room.phase = PHASES.MISSION_SELECT;
    room.missionId = null;
    room.build = [];
    room.settings = {};
    room.evaluation = null;
    room.briefingAck = new Set();
    room.signoff = emptySignoff();
    room.reviewRounds = 0;
    room.signoffCount = 0;
    room.designMs = 0;
    room.designStartedAt = null;
    room.sim = null;
    room.debrief = null;
    room.ledger = [];
    room.ledgerSeq = 0; // yeni görev: defter numarası baştan
  }

  function enterDesign(room) {
    room.phase = PHASES.DESIGN;
    room.signoff = emptySignoff();
    room.designStartedAt = clock();
    // standart donanım: yalnız eksikler eklenir ('same' tekrarında build zaten tam)
    if (ensureAutoItems(room) > 0) refreshEvaluation(room);
  }

  // design fazından çıkarken geçen süreyi biriktir
  function closeDesignTimer(room) {
    if (typeof room.designStartedAt === 'number') {
      room.designMs += Math.max(0, clock() - room.designStartedAt);
    }
    room.designStartedAt = null;
  }

  // review → design (operatör ya da DÜZELT diyen mühendis)
  function reviewToDesign(room) {
    room.reviewRounds++;
    enterDesign(room);
  }

  function briefingDone(room) {
    const held = ROLES.filter((r) => roleHolder(room, r));
    return held.length > 0 && held.every((r) => room.briefingAck.has(r));
  }

  // Fırlatma engeli (Aşama 8): YALNIZ 3 mühendis onayı. Kritik FAIL / bütçe engel değil.
  function launchBlockers(room) {
    return ENGINEER_ROLES.filter((r) => room.signoff[r] !== 'ok'); // onay bekleyen roller
  }

  // READY olmayan tasarımın öne çıkan kalemleri (kritik FAIL > FAIL > WARN), en çok 4 sistem adı
  function launchConcerns(ev) {
    const rank = (r) => (r.status === 'FAIL' ? (r.critical ? 0 : 1) : 2);
    const items = (ev && Array.isArray(ev.readiness) ? ev.readiness : [])
      .filter((r) => r && (r.status === 'FAIL' || r.status === 'WARN'))
      .sort((a, b) => rank(a) - rank(b));
    const names = [];
    for (const r of items) {
      const n = String(r.system || r.id || '').trim();
      if (n && !names.includes(n)) names.push(n);
      if (names.length >= 4) break;
    }
    return names;
  }

  function teamStats(room) {
    const threads = room.chat && room.chat.threads ? room.chat.threads : {};
    const chatCounts = {};
    for (const r of ENGINEER_ROLES) chatCounts[r] = Array.isArray(threads[r]) ? threads[r].length : 0;
    return {
      designSec: Math.round(room.designMs / 1000),
      reviewRounds: room.reviewRounds,
      chat: chatCounts,
      signoffs: room.signoffCount,
    };
  }

  function finishSimulation(room) {
    room.sim.team = teamStats(room); // diğer dillerdeki debrief aynı istatistikle üretilir
    room.debrief = sim.debrief(room.missionId, structuredClone(room.evaluation),
      structuredClone(room.sim.result), structuredClone(room.sim.team), { lang: BASE_LANG });
    room.phase = PHASES.DEBRIEF;
    pushLog(room, 'system', null, 'log.simDone');
  }

  // --- Dışa açık API ------------------------------------------------------

  const api = {
    createRoom(name, socketId, lang) {
      const n = cleanName(name);
      const code = newCode();
      const room = {
        code,
        hostId: null,
        players: new Map(),
        phase: PHASES.LOBBY,
        createdAt: clock(),
        missionId: null,
        build: [],
        settings: {},
        evaluation: null,
        briefingAck: new Set(),
        signoff: emptySignoff(),
        reviewRounds: 0,
        signoffCount: 0,
        designMs: 0,
        designStartedAt: null,
        sim: null,
        debrief: null,
        chat: emptyChat(),
        ledger: [],
        ledgerSeq: 0,
        log: [],
        emptySince: null,
      };
      const player = newPlayer(room, n, socketId, lang);
      room.players.set(player.id, player);
      room.hostId = player.id;
      rooms.set(code, room);
      return { room, player };
    },

    // Lobide rolsüz katılır; lobi dışında boş rolü alır, yoksa ROOM_FULL
    joinRoom(code, name, socketId, lang) {
      const room = mustRoom(code);
      const n = cleanName(name);
      let role = null;
      if (room.phase === PHASES.LOBBY) {
        if (room.players.size >= MAX_PLAYERS) throw new GameError('ROOM_FULL', 'err.roomFull');
      } else {
        role = ROLES.find((r) => !roleHolder(room, r)) || null;
        if (!role || room.players.size >= MAX_PLAYERS) {
          throw new GameError('ROOM_FULL', 'err.gameFull');
        }
      }
      const player = newPlayer(room, n, socketId, lang);
      player.role = role;
      player.ready = !!role;
      room.players.set(player.id, player);
      room.emptySince = null;
      ensureHost(room);
      pushLog(room, 'system', role, role ? 'log.joinedRole' : 'log.joined', { name: n, role });
      return { room, player };
    },

    // Kopan oyuncu geri döner (rol korunur)
    rejoin(code, playerId, socketId, lang) {
      const { room, player } = ctx(code, playerId);
      if (isLang(lang)) player.lang = lang; // geçerli lang verilirse oyuncunun dili güncellenir
      player.connected = true;
      player.socketId = typeof socketId === 'string' ? socketId : null;
      player.lastSeen = clock();
      room.emptySince = null;
      ensureHost(room);
      return { room, player };
    },

    // Oyuncunun dili ('en' | 'tr'); geçersiz → BAD_REQUEST. { room, player, changed }
    setLang(code, playerId, lang) {
      const { room, player } = ctx(code, playerId);
      if (!isLang(lang)) throw new GameError('BAD_REQUEST', 'err.badLang');
      const changed = player.lang !== lang;
      player.lang = lang;
      return { room, player, changed };
    },

    getRoom(code) {
      if (typeof code !== 'string') return undefined;
      return rooms.get(code.trim().toUpperCase());
    },

    getPlayer(code, playerId) {
      const room = this.getRoom(code);
      if (!room || typeof playerId !== 'string') return undefined;
      return room.players.get(playerId);
    },

    selectRole(code, playerId, role) {
      const { room, player } = ctx(code, playerId);
      needPhase(room, PHASES.LOBBY, 'err.phase.roleLocked');
      if (role === null || role === undefined) {
        player.role = null;
        player.ready = false;
        return room;
      }
      if (!ROLES.includes(role)) throw new GameError('INVALID_ROLE', 'err.invalidRole');
      const holder = roleHolder(room, role);
      if (holder && holder.id !== player.id) throw new GameError('ROLE_TAKEN', 'err.roleTaken');
      if (player.role !== role) player.ready = false;
      player.role = role;
      return room;
    },

    setReady(code, playerId, ready) {
      const { room, player } = ctx(code, playerId);
      needPhase(room, PHASES.LOBBY, 'err.phase.readyLobby');
      if (typeof ready !== 'boolean') throw new GameError('BAD_REQUEST', 'err.readyBool');
      if (ready && !player.role) throw new GameError('NO_ROLE', 'err.pickRole');
      player.ready = ready;
      return room;
    },

    kick(code, hostId, seat) {
      const { room, player } = ctx(code, hostId);
      needHost(room, player);
      const target = playerBySeat(room, seat);
      if (target.id === player.id) throw new GameError('INVALID_TARGET', 'err.kickSelf');
      dropPlayer(room, target.id);
      pushLog(room, 'system', null, 'log.kicked', { name: target.name });
      return { room, kicked: target };
    },

    transferHost(code, hostId, seat) {
      const { room, player } = ctx(code, hostId);
      needHost(room, player);
      const target = playerBySeat(room, seat);
      if (target.id === player.id) throw new GameError('INVALID_TARGET', 'err.alreadyHost');
      if (!target.connected) throw new GameError('INVALID_TARGET', 'err.hostOffline');
      room.hostId = target.id;
      pushLog(room, 'system', target.role, 'log.hostNow', { name: target.name });
      return room;
    },

    startGame(code, playerId) {
      const { room, player } = ctx(code, playerId);
      needHost(room, player);
      needPhase(room, PHASES.LOBBY, 'err.phase.started');
      const ps = [...room.players.values()];
      const missingRoles = ROLES.filter((r) => !ps.some((p) => p.role === r));
      if (missingRoles.length) {
        throw new GameError('NOT_READY', 'err.emptyRoles', { roles: missingRoles });
      }
      const notReady = ps.filter((p) => !p.ready || !p.connected);
      if (notReady.length) {
        throw new GameError('NOT_READY', 'err.notReadyPlayers', { names: notReady.map((p) => p.name) });
      }
      enterMissionSelect(room);
      pushLog(room, 'system', null, 'log.started');
      return room;
    },

    selectMission(code, playerId, missionId) {
      const { room, player } = ctx(code, playerId);
      needDirector(player);
      needPhase(room, PHASES.MISSION_SELECT, 'err.phase.missionSelect');
      if (typeof missionId !== 'string' || !missionIds().includes(missionId)) {
        throw new GameError('INVALID_MISSION', 'err.noMission');
      }
      room.missionId = missionId;
      room.build = [];
      room.settings = typeof sim.defaultSettings === 'function' ? (sim.defaultSettings(missionId) || {}) : {};
      room.briefingAck = new Set();
      room.signoff = emptySignoff();
      room.ledger = [];
      room.ledgerSeq = 0;
      ensureAutoItems(room); // standart donanım brifingde de değerlendirmeye girsin
      refreshEvaluation(room);
      room.phase = PHASES.BRIEFING;
      pushLog(room, 'system', 'director', 'log.mission', { mission: missionId });
      return room;
    },

    ackBriefing(code, playerId) {
      const { room, player } = ctx(code, playerId);
      needPhase(room, PHASES.BRIEFING, 'err.phase.noBriefing');
      if (!player.role) throw new GameError('NO_ROLE', 'err.noRole');
      room.briefingAck.add(player.role);
      if (briefingDone(room)) enterDesign(room);
      return room;
    },

    skipBriefing(code, playerId) {
      const { room, player } = ctx(code, playerId);
      needDirector(player);
      needPhase(room, PHASES.BRIEFING, 'err.phase.noBriefing');
      enterDesign(room);
      pushLog(room, 'system', 'director', 'log.skip');
      return room;
    },

    addItem(code, playerId, itemId, moduleId) {
      const { room, player } = ctx(code, playerId);
      needEngineer(player);
      needPhase(room, PHASES.DESIGN, 'err.phase.equip');
      if (!isStr(itemId) || !isStr(moduleId)) throw new GameError('BAD_REQUEST', 'err.itemModule');
      // gerekçe (reason) sim'den oyuncunun dilinde gelir; yoksa katalog varsayılanı
      const res = sim.canAdd(structuredClone(room.build), room.missionId, player.role, itemId, moduleId, player.lang);
      if (!res || !res.ok) {
        const err = (res && typeof res.error === 'string' && res.error) || 'INVALID_ITEM';
        if (res && typeof res.reason === 'string' && res.reason) throw new GameError(err, res.reason);
        throw new GameError(err, hasMessage(err) ? err : 'err.cantAdd');
      }
      const entry = { uid: newUid(room), itemId, moduleId, role: player.role, cost: itemCost(itemId) };
      const build = [...room.build, entry];
      const evaluation = evaluateWith(room, build, room.settings); // önce hesapla, sonra işle
      room.build = build;
      room.evaluation = evaluation;
      pushLedger(room, { role: player.role, playerName: player.name, action: 'add', itemId, moduleId, cost: entry.cost });
      pushLog(room, 'item', player.role, 'log.added', { role: player.role, item: itemName(itemId) });
      return { room, uid: entry.uid };
    },

    removeItem(code, playerId, uid) {
      const { room, player } = ctx(code, playerId);
      needEngineer(player);
      needPhase(room, PHASES.DESIGN, 'err.phase.equip');
      if (!isStr(uid)) throw new GameError('BAD_REQUEST', 'err.uid');
      const entry = room.build.find((it) => it.uid === uid);
      if (!entry) throw new GameError('ITEM_NOT_FOUND', 'err.notInstalled');
      if (entry.auto) throw new GameError('LOCKED', 'LOCKED');
      if (entry.role !== player.role) throw new GameError('NOT_ALLOWED', 'err.otherEngineer');
      const build = room.build.filter((it) => it.uid !== uid);
      const evaluation = evaluateWith(room, build, room.settings);
      room.build = build;
      room.evaluation = evaluation;
      // iade: takma anındaki tutar (çift ücret yok)
      pushLedger(room, { role: player.role, playerName: player.name, action: 'remove', itemId: entry.itemId, moduleId: entry.moduleId, cost: -entryCost(entry) });
      pushLog(room, 'item', player.role, 'log.removed', { role: player.role, item: itemName(entry.itemId) });
      return room;
    },

    setSetting(code, playerId, key, value) {
      const { room, player } = ctx(code, playerId);
      needEngineer(player);
      needPhase(room, PHASES.DESIGN, 'err.phase.settings');
      if (!isStr(key)) throw new GameError('BAD_REQUEST', 'err.settingKey');
      const res = typeof sim.validateSetting === 'function'
        ? sim.validateSetting(room.missionId, player.role, key, value) : null;
      if (!res || !res.ok) throw new GameError('BAD_SETTING', 'err.badSetting');
      const settings = { ...room.settings, [key]: res.value };
      const evaluation = evaluateWith(room, room.build, settings);
      room.settings = settings;
      room.evaluation = evaluation;
      return room;
    },

    openReview(code, playerId) {
      const { room, player } = ctx(code, playerId);
      needDirector(player);
      needPhase(room, PHASES.DESIGN, 'err.phase.reviewOpen');
      closeDesignTimer(room);
      room.signoff = emptySignoff();
      room.phase = PHASES.REVIEW;
      pushLog(room, 'system', 'director', 'log.review');
      return room;
    },

    signoff(code, playerId, decision) {
      const { room, player } = ctx(code, playerId);
      if (!ENGINEER_ROLES.includes(player.role)) throw new GameError('NOT_ALLOWED', 'err.signoffEngineers');
      needPhase(room, PHASES.REVIEW, 'err.phase.noReview');
      if (!SIGNOFF_DECISIONS.includes(decision)) throw new GameError('BAD_REQUEST', 'err.decision');
      room.signoffCount++;
      if (decision === 'fix') {
        pushLog(room, 'signoff', player.role, 'log.fix', { role: player.role });
        reviewToDesign(room);
      } else {
        room.signoff[player.role] = 'ok';
        pushLog(room, 'signoff', player.role, 'log.ok', { role: player.role });
      }
      return room;
    },

    backToDesign(code, playerId) {
      const { room, player } = ctx(code, playerId);
      needDirector(player);
      needPhase(room, PHASES.REVIEW, 'err.phase.noReview');
      reviewToDesign(room);
      return room;
    },

    // opts.confirm === true: READY olmayan tasarımı bilerek fırlat (yoksa LAUNCH_CONFIRM)
    launch(code, playerId, opts = {}) {
      const { room, player } = ctx(code, playerId);
      needDirector(player);
      needPhase(room, PHASES.REVIEW, 'err.phase.launch');
      const waiting = launchBlockers(room);
      if (waiting.length) throw new GameError('LAUNCH_BLOCKED', 'err.launchBlocked', { roles: waiting });
      if (!room.evaluation) refreshEvaluation(room);
      const status = launchStatusOf(room.evaluation) || 'INSUFFICIENT';
      const confirm = !!opts && typeof opts === 'object' && opts.confirm === true;
      if (status !== 'READY' && !confirm) {
        // sistem adları operatörün dilindeki değerlendirmeden
        const items = launchConcerns(evalFor(room, sim, player.lang));
        throw new GameError('LAUNCH_CONFIRM', items.length ? 'err.launchConfirm' : 'err.launchConfirmBare', { status, items });
      }
      const seed = Math.floor(rng() * 2147483647);
      // build/ayar kopyası saklanır: diğer dillerdeki sonuç aynı tohum ve girdilerle üretilir
      const build = structuredClone(room.build);
      const settings = structuredClone(room.settings);
      const result = sim.simulate(room.missionId, structuredClone(build), structuredClone(settings), seed, { lang: BASE_LANG });
      room.sim = { result, shownPhases: 0, nextAt: clock() + PHASE_MS, seed, build, settings, byLang: {} };
      room.phase = PHASES.SIMULATION;
      pushLog(room, 'system', 'director', status === 'READY' ? 'log.launch' : 'log.launchConfirmed', { status });
      return room;
    },

    // GERİ: briefing→mission-select (operatör), review→design (operatör), debrief→mission-select (host/operatör)
    goBack(code, playerId) {
      const { room, player } = ctx(code, playerId);
      if (room.phase === PHASES.BRIEFING) {
        needDirector(player);
        enterMissionSelect(room);
      } else if (room.phase === PHASES.REVIEW) {
        needDirector(player);
        reviewToDesign(room);
      } else if (room.phase === PHASES.DEBRIEF) {
        if (player.role !== 'director' && room.hostId !== player.id) {
          throw new GameError('NOT_ALLOWED', 'err.hostOrDirector');
        }
        enterMissionSelect(room);
      } else {
        throw new GameError('WRONG_PHASE', 'err.phase.back');
      }
      return room;
    },

    // TEKRAR OYNA: 'new' → görev seçimi (her şey sıfır), 'same' → aynı görev, tasarım korunur
    playAgain(code, playerId, mode) {
      const { room, player } = ctx(code, playerId);
      needPhase(room, PHASES.DEBRIEF, 'err.phase.again');
      if (player.role !== 'director' && room.hostId !== player.id) {
        throw new GameError('NOT_ALLOWED', 'err.hostOrDirector');
      }
      if (!PLAY_AGAIN_MODES.includes(mode)) throw new GameError('BAD_REQUEST', 'err.mode');
      if (mode === 'new') {
        enterMissionSelect(room);
      } else {
        room.sim = null;
        room.debrief = null;
        room.reviewRounds = 0;
        room.signoffCount = 0;
        room.designMs = 0;
        refreshEvaluation(room);
        enterDesign(room);
      }
      pushLog(room, 'system', player.role, mode === 'new' ? 'log.new' : 'log.same');
      return room;
    },

    // Kendi isteğiyle ayrılma: oyuncu silinir, rolü boşalır
    leave(code, playerId) {
      const room = this.getRoom(code);
      if (!room || !room.players.has(playerId)) return room;
      return dropPlayer(room, playerId);
    },

    // Bağlantı durumu. socketId verilirse yalnız oyuncunun güncel socket'iyse uygulanır.
    setConnected(code, playerId, connected, socketId) {
      const room = this.getRoom(code);
      if (!room) return undefined;
      const player = room.players.get(playerId);
      if (!player) return room;
      if (!connected && typeof socketId === 'string' && player.socketId && player.socketId !== socketId) return room;
      player.connected = !!connected;
      player.lastSeen = clock();
      if (!connected) player.socketId = null;
      else if (typeof socketId === 'string') player.socketId = socketId;
      ensureHost(room);
      return room;
    },

    // Zamanı ilerlet: simülasyon aşamaları, bağlantı süresi aşımı, boş oda. Değişiklik olduysa true.
    // Oda silindiyse de true döner (getRoom artık undefined).
    tick(code) {
      const room = this.getRoom(code);
      if (!room) return false;
      const t = clock();
      let changed = false;

      // 1) Süresi dolan kopuk oyuncular düşer (rol boşalır)
      for (const p of [...room.players.values()]) {
        if (!p.connected && t - p.lastSeen >= GRACE_MS) {
          changed = true;
          if (!dropPlayer(room, p.id)) return true; // oda silindi
        }
      }
      // 2) Boş oda temizliği
      const anyConnected = [...room.players.values()].some((p) => p.connected);
      if (!anyConnected) {
        if (room.emptySince === null) room.emptySince = t;
        if (t - room.emptySince >= EMPTY_MS) {
          rooms.delete(room.code);
          return true;
        }
      } else {
        room.emptySince = null;
      }
      // 3) Simülasyon aşamaları (son aşamadan bir aralık sonra debrief)
      if (room.phase === PHASES.SIMULATION && room.sim) {
        const phases = room.sim.result && Array.isArray(room.sim.result.phases) ? room.sim.result.phases : [];
        while (room.phase === PHASES.SIMULATION && t >= room.sim.nextAt) {
          if (room.sim.shownPhases < phases.length) {
            room.sim.shownPhases++;
            room.sim.nextAt += PHASE_MS;
          } else {
            finishSimulation(room);
          }
          changed = true;
        }
      }
      return changed;
    },

    roomCodes() {
      return [...rooms.keys()];
    },

    deleteRoom(code) {
      if (typeof code !== 'string') return;
      rooms.delete(code.trim().toUpperCase());
    },

    playerIds(code) {
      const room = this.getRoom(code);
      return room ? [...room.players.keys()] : [];
    },

    config: { phaseMs: PHASE_MS, reconnectGraceMs: GRACE_MS, emptyRoomMs: EMPTY_MS },

    // Oyuncunun dili (bilinmiyorsa varsayılan)
    langOf(code, playerId) {
      const p = this.getPlayer(code, playerId);
      return p ? normLang(p.lang) : DEFAULT_LANG;
    },
  };

  // Hata mesajlarını işlemi yapanın diline çevir: açık lang argümanı (create/join/rejoin) > oyuncunun dili > en
  const LANG_ARG = { createRoom: 2, joinRoom: 3, rejoin: 3 };
  function errLang(name, args) {
    const i = LANG_ARG[name];
    if (i !== undefined && isLang(args[i])) return args[i];
    if (name === 'createRoom') return DEFAULT_LANG;
    try {
      const room = typeof args[0] === 'string' ? rooms.get(args[0].trim().toUpperCase()) : undefined;
      const p = room && typeof args[1] === 'string' ? room.players.get(args[1]) : undefined;
      return p ? normLang(p.lang) : DEFAULT_LANG;
    } catch { return DEFAULT_LANG; }
  }
  for (const name of Object.keys(api)) {
    const fn = api[name];
    if (typeof fn !== 'function' || name === 'langOf') continue;
    api[name] = function wrapped(...args) {
      try {
        return fn.apply(this, args);
      } catch (e) {
        if (e instanceof GameError) e.localize(errLang(name, args));
        throw e;
      }
    };
  }
  return api;
}

module.exports = { createRoomManager, cleanName, evalFor, simResultFor, debriefFor, BASE_LANG };
