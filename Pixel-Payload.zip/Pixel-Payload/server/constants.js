'use strict';
// Ortak sabitler, iki dilli mesaj kataloğu ve hata sınıfı (PLAN.md Aşama 7, 8.3, 9.3).

const ROLES = ['director', 'rocket', 'spacecraft', 'payload'];
const ENGINEER_ROLES = ['rocket', 'spacecraft', 'payload'];
const WORKER_ROLES = ENGINEER_ROLES; // eski ad (geri uyumluluk)

// Akış: lobby → mission-select → briefing → design → review → simulation → debrief
const PHASES = {
  LOBBY: 'lobby',
  MISSION_SELECT: 'mission-select',
  BRIEFING: 'briefing',
  DESIGN: 'design',
  REVIEW: 'review',
  SIMULATION: 'simulation',
  DEBRIEF: 'debrief',
};
const PHASE_LIST = Object.values(PHASES);
const MAX_PLAYERS = 4;

// --- Dil (Aşama 9) -------------------------------------------------------------
const LANGS = ['en', 'tr'];
const DEFAULT_LANG = 'en';
const isLang = (v) => typeof v === 'string' && LANGS.includes(v);
const normLang = (v) => (isLang(v) ? v : DEFAULT_LANG);

// Görünen rol adları (ROLE_NAMES = Türkçe, geri uyum)
const ROLE_NAMES = {
  director: 'Operatör',
  rocket: 'İtki Mühendisi',
  spacecraft: 'Uzay Aracı Mühendisi',
  payload: 'Bilim & Faydalı Yük Mühendisi',
};
const ROLE_NAMES_I18N = {
  en: {
    director: 'Operator',
    rocket: 'Propulsion Engineer',
    spacecraft: 'Spacecraft Engineer',
    payload: 'Science & Payload Engineer',
  },
  tr: ROLE_NAMES,
};
const roleName = (lang, role) => ROLE_NAMES_I18N[normLang(lang)][role] || String(role || '');

const SIGNOFF_DECISIONS = ['ok', 'fix'];
const PLAY_AGAIN_MODES = ['new', 'same'];

// Varsayılan zamanlar (ms)
const DEFAULTS = {
  phaseMs: 3500,              // simülasyon aşaması başına
  reconnectGraceMs: 120000,   // kopan oyuncunun rolü bu süre korunur
  emptyRoomMs: 5 * 60 * 1000, // bağlı oyuncusu kalmayan oda bu süre sonra silinir
};

// Hata kodları (GameError.code). Sim/sohbet hata kodları da aynen ack'e geçer.
const ERRORS = {
  BAD_REQUEST: 'BAD_REQUEST',
  NAME_REQUIRED: 'NAME_REQUIRED',
  ROOM_NOT_FOUND: 'ROOM_NOT_FOUND',
  NOT_IN_ROOM: 'NOT_IN_ROOM',
  ROOM_FULL: 'ROOM_FULL',
  INVALID_ROLE: 'INVALID_ROLE',
  ROLE_TAKEN: 'ROLE_TAKEN',
  NO_ROLE: 'NO_ROLE',
  GAME_STARTED: 'GAME_STARTED',
  WRONG_PHASE: 'WRONG_PHASE',
  NOT_ALLOWED: 'NOT_ALLOWED',
  NOT_HOST: 'NOT_HOST',
  NOT_READY: 'NOT_READY',
  INVALID_TARGET: 'INVALID_TARGET',
  INVALID_MISSION: 'INVALID_MISSION',
  ITEM_NOT_FOUND: 'ITEM_NOT_FOUND',
  BAD_SETTING: 'BAD_SETTING',
  LAUNCH_BLOCKED: 'LAUNCH_BLOCKED',
  RATE_LIMITED: 'RATE_LIMITED',
  NO_SPACE: 'NO_SPACE',             // sim.canAdd: modülde yer yok (Aşama 8)
  LOCKED: 'LOCKED',                 // standart donanım çıkarılamaz
  LAUNCH_CONFIRM: 'LAUNCH_CONFIRM', // tasarım READY değil, fırlatma için confirm:true gerekli
};

// Fırlatma durumu (sim evaluation.launchStatus) ve adları
const LAUNCH_STATUSES = ['READY', 'RISKY', 'MISSING', 'INSUFFICIENT'];
const LAUNCH_STATUS_TR = { READY: 'Hazır', RISKY: 'Riskli', MISSING: 'Eksik', INSUFFICIENT: 'Fiziksel yetersiz' };
const LAUNCH_STATUS_I18N = {
  en: { READY: 'Ready', RISKY: 'Risky', MISSING: 'Missing', INSUFFICIENT: 'Physically insufficient' },
  tr: LAUNCH_STATUS_TR,
};

// --- Mesaj kataloğu: { en: { key: 'metin {param}' }, tr: {...} } -------------------
// Hata kodu anahtarları (NO_SPACE, LOCKED, LAUNCH_CONFIRM) varsayılan mesajdır.
const MESSAGES = {
  en: {
    NO_SPACE: 'No space left in the module.',
    LOCKED: 'Standard hardware cannot be removed.',
    LAUNCH_CONFIRM: 'The design is not ready. Confirm to launch anyway.',
    // oda / oyuncu
    'err.name': 'Name must be 1–{max} characters.',
    'err.badCode': 'Invalid room code.',
    'err.noFreeCode': 'Could not find a free room code, please try again.',
    'err.roomNotFound': 'Room not found.',
    'err.notInRoom': 'You are not in this room.',
    'err.notInAnyRoom': 'You are not in a room.',
    'err.roomFull': 'The room is full (max 4 players).',
    'err.gameFull': 'The game is in progress and no role is free.',
    'err.badSeat': 'Invalid seat number.',
    'err.noSeatPlayer': 'No player in this seat.',
    'err.notHost': 'Only the host can do this.',
    'err.directorOnly': 'Only the Operator can do this.',
    'err.engineersOnly': 'Only engineers can change equipment and settings.',
    'err.signoffEngineers': 'Only engineers give sign-off.',
    'err.hostOrDirector': 'Only the host or the Operator can do this.',
    'err.wrongPhase': 'This cannot be done right now.',
    'err.phase.roleLocked': 'Roles cannot change after the game starts.',
    'err.phase.readyLobby': 'Ready status only changes in the lobby.',
    'err.phase.started': 'The game has already started.',
    'err.phase.missionSelect': 'A mission cannot be selected right now.',
    'err.phase.noBriefing': 'There is no briefing right now.',
    'err.phase.equip': 'Equipment only changes during the design phase.',
    'err.phase.settings': 'Settings only change during the design phase.',
    'err.phase.reviewOpen': 'Review can only be opened from the design phase.',
    'err.phase.noReview': 'There is no review right now.',
    'err.phase.launch': 'Launch is only possible during review.',
    'err.phase.back': 'You cannot go back from this phase.',
    'err.phase.again': 'Play again is only available on the results screen.',
    'err.invalidRole': 'Invalid role.',
    'err.roleTaken': 'This role belongs to another player.',
    'err.readyBool': 'Ready value must be true/false.',
    'err.pickRole': 'Pick a role first.',
    'err.noRole': 'You have no role.',
    'err.kickSelf': 'You cannot kick yourself.',
    'err.alreadyHost': 'You are already the host.',
    'err.hostOffline': 'Host cannot be transferred to a disconnected player.',
    'err.emptyRoles': 'Empty roles: {roles}.',
    'err.notReadyPlayers': 'Players not ready: {names}.',
    'err.noMission': 'No such mission.',
    'err.itemModule': 'Item and module id are required.',
    'err.cantAdd': 'This item cannot be installed.',
    'err.uid': 'Item uid is required.',
    'err.notInstalled': 'This item is not installed.',
    'err.otherEngineer': 'This item belongs to another engineer.',
    'err.settingKey': 'Setting key is required.',
    'err.badSetting': 'This setting or value is invalid.',
    'err.decision': "Decision must be 'ok' or 'fix'.",
    'err.mode': "Mode must be 'new' or 'same'.",
    'err.launchBlocked': 'Launch blocked. Waiting for sign-off: {roles}.',
    'err.launchConfirm': 'The design is not ready ({status}): {items}. Confirm to launch anyway.',
    'err.launchConfirmBare': 'The design is not ready ({status}). Confirm to launch anyway.',
    // socket isteği
    'err.rate': 'You are sending requests too fast, please wait.',
    'err.badFormat': 'Invalid request format.',
    'err.failed': 'The request could not be processed.',
    'err.badLang': "Language must be 'en' or 'tr'.",
    'req.name': 'Name is required.',
    'req.code': 'Room code is required.',
    'req.playerId': 'Player id is required.',
    'req.role': 'A role must be given.',
    'req.seat': 'Seat number is required.',
    'req.missionId': 'Mission id is required.',
    'req.itemId': 'Item id is required.',
    'req.moduleId': 'Module id is required.',
    'req.uid': 'Item uid is required.',
    'req.settingKey': 'Setting key is required.',
    'req.settingValue': 'Invalid setting value.',
    'req.decision': "Decision is required ('ok' | 'fix').",
    'req.confirm': 'confirm must be true/false.',
    'req.mode': "Mode is required ('new' | 'same').",
    'req.to': 'Recipient is required.',
    'req.text': 'Message text is required.',
    // sohbet (chat.send hata kodları)
    'chat.NOT_IN_ROOM': 'You are not in this room.',
    'chat.NO_ROLE': 'You need a role to send messages.',
    'chat.FORBIDDEN': 'You cannot message this person (engineers can only write to the Operator).',
    'chat.BAD_TARGET': 'Invalid recipient.',
    'chat.EMPTY': 'Message cannot be empty.',
    'chat.TOO_LONG': 'Message is too long.',
    'chat.RATE_LIMIT': 'You are sending messages too fast, please wait.',
    'chat.TARGET_EMPTY': 'Nobody holds this role right now.',
    'chat.failed': 'Message could not be sent.',
    // bildirimler
    'msg.kicked': 'The host removed you from the room.',
    'msg.otherLogin': 'Signed in from another connection.',
    'msg.roomClosed': 'The room was closed.',
    'ledger.standard': 'Standard hardware',
    // oda günlüğü
    'log.hostNow': 'Host is now {name}',
    'log.left': '{name} left the room',
    'log.joined': '{name} joined',
    'log.joinedRole': '{name} joined ({role})',
    'log.kicked': '{name} was removed by the host',
    'log.started': 'Game started',
    'log.mission': 'Mission selected: {mission}',
    'log.skip': 'Operator skipped the briefing',
    'log.added': '{role}: {item} installed',
    'log.removed': '{role}: {item} removed',
    'log.review': 'Readiness review opened',
    'log.fix': '{role} asked for a FIX',
    'log.ok': '{role} gave SIGN-OFF',
    'log.launch': 'LAUNCH',
    'log.launchConfirmed': 'LAUNCH (confirmed, status: {status})',
    'log.new': 'New mission',
    'log.same': 'Same mission again',
    'log.simDone': 'Simulation finished',
  },
  tr: {
    NO_SPACE: 'Modülde yer yok.',
    LOCKED: 'Standart donanım çıkarılamaz.',
    LAUNCH_CONFIRM: 'Tasarım hazır değil. Yine de fırlatmak için onayla.',
    'err.name': 'İsim 1–{max} karakter olmalı.',
    'err.badCode': 'Oda kodu geçersiz.',
    'err.noFreeCode': 'Boş oda kodu bulunamadı, tekrar deneyin.',
    'err.roomNotFound': 'Oda bulunamadı.',
    'err.notInRoom': 'Bu odada değilsin.',
    'err.notInAnyRoom': 'Bir odada değilsin.',
    'err.roomFull': 'Oda dolu (en fazla 4 oyuncu).',
    'err.gameFull': 'Oyun sürüyor ve boş rol yok.',
    'err.badSeat': 'Koltuk numarası geçersiz.',
    'err.noSeatPlayer': 'Bu koltukta oyuncu yok.',
    'err.notHost': 'Bunu yalnız host yapabilir.',
    'err.directorOnly': 'Bunu yalnız Operatör yapabilir.',
    'err.engineersOnly': 'Ekipmana ve ayarlara yalnız mühendisler dokunabilir.',
    'err.signoffEngineers': 'Yalnız mühendisler onay verir.',
    'err.hostOrDirector': 'Bunu yalnız host ya da Operatör yapabilir.',
    'err.wrongPhase': 'Bu işlem şu an yapılamaz.',
    'err.phase.roleLocked': 'Oyun başladıktan sonra rol değişmez.',
    'err.phase.readyLobby': 'Hazır durumu yalnız lobide değişir.',
    'err.phase.started': 'Oyun zaten başladı.',
    'err.phase.missionSelect': 'Görev şu an seçilemez.',
    'err.phase.noBriefing': 'Şu an brifing yok.',
    'err.phase.equip': 'Ekipman yalnız tasarım aşamasında değişir.',
    'err.phase.settings': 'Ayarlar yalnız tasarım aşamasında değişir.',
    'err.phase.reviewOpen': 'İnceleme yalnız tasarım aşamasından açılır.',
    'err.phase.noReview': 'Şu an inceleme yok.',
    'err.phase.launch': 'Fırlatma yalnız inceleme aşamasında yapılır.',
    'err.phase.back': 'Bu aşamadan geri dönülemez.',
    'err.phase.again': 'Tekrar oyna yalnız sonuç ekranında.',
    'err.invalidRole': 'Geçersiz rol.',
    'err.roleTaken': 'Bu rol başka bir oyuncuda.',
    'err.readyBool': 'Hazır değeri true/false olmalı.',
    'err.pickRole': 'Önce bir rol seç.',
    'err.noRole': 'Rolün yok.',
    'err.kickSelf': 'Kendini çıkaramazsın.',
    'err.alreadyHost': 'Zaten hostsun.',
    'err.hostOffline': 'Bağlı olmayan oyuncuya host devredilemez.',
    'err.emptyRoles': 'Boş roller var: {roles}.',
    'err.notReadyPlayers': 'Hazır olmayan oyuncular: {names}.',
    'err.noMission': 'Böyle bir görev yok.',
    'err.itemModule': 'Parça ve modül kimliği gerekli.',
    'err.cantAdd': 'Bu parça takılamaz.',
    'err.uid': 'Parça uid gerekli.',
    'err.notInstalled': 'Bu parça takılı değil.',
    'err.otherEngineer': 'Bu parça başka bir mühendise ait.',
    'err.settingKey': 'Ayar anahtarı gerekli.',
    'err.badSetting': 'Bu ayar ya da değer geçersiz.',
    'err.decision': "Karar 'ok' ya da 'fix' olmalı.",
    'err.mode': "Mod 'new' ya da 'same' olmalı.",
    'err.launchBlocked': 'Fırlatma engellendi. Onay bekleniyor: {roles}.',
    'err.launchConfirm': 'Tasarım hazır değil ({status}): {items}. Yine de fırlatmak için onayla.',
    'err.launchConfirmBare': 'Tasarım hazır değil ({status}). Yine de fırlatmak için onayla.',
    'err.rate': 'Çok hızlı istek gönderiyorsun, biraz bekle.',
    'err.badFormat': 'Geçersiz istek biçimi.',
    'err.failed': 'İstek işlenemedi.',
    'err.badLang': "Dil 'en' ya da 'tr' olmalı.",
    'req.name': 'İsim gerekli.',
    'req.code': 'Oda kodu gerekli.',
    'req.playerId': 'Oyuncu kimliği gerekli.',
    'req.role': 'Rol belirtilmeli.',
    'req.seat': 'Koltuk numarası gerekli.',
    'req.missionId': 'Görev kimliği gerekli.',
    'req.itemId': 'Parça kimliği gerekli.',
    'req.moduleId': 'Modül kimliği gerekli.',
    'req.uid': 'Parça uid gerekli.',
    'req.settingKey': 'Ayar anahtarı gerekli.',
    'req.settingValue': 'Ayar değeri geçersiz.',
    'req.decision': "Karar gerekli ('ok' | 'fix').",
    'req.confirm': 'confirm true/false olmalı.',
    'req.mode': "Mod gerekli ('new' | 'same').",
    'req.to': 'Alıcı gerekli.',
    'req.text': 'Mesaj metni gerekli.',
    'chat.NOT_IN_ROOM': 'Bu odada değilsin.',
    'chat.NO_ROLE': 'Mesaj göndermek için bir rolün olmalı.',
    'chat.FORBIDDEN': 'Bu kişiye mesaj gönderemezsin (mühendisler yalnız Operatöre yazabilir).',
    'chat.BAD_TARGET': 'Geçersiz alıcı.',
    'chat.EMPTY': 'Mesaj boş olamaz.',
    'chat.TOO_LONG': 'Mesaj çok uzun.',
    'chat.RATE_LIMIT': 'Çok hızlı mesaj gönderiyorsun, biraz bekle.',
    'chat.TARGET_EMPTY': 'Bu rolde şu an kimse yok.',
    'chat.failed': 'Mesaj gönderilemedi.',
    'msg.kicked': 'Host seni odadan çıkardı.',
    'msg.otherLogin': 'Başka bir bağlantıdan giriş yapıldı.',
    'msg.roomClosed': 'Oda kapandı.',
    'ledger.standard': 'Standart donanım',
    'log.hostNow': 'Host artık {name}',
    'log.left': '{name} odadan ayrıldı',
    'log.joined': '{name} katıldı',
    'log.joinedRole': '{name} katıldı ({role})',
    'log.kicked': '{name} host tarafından çıkarıldı',
    'log.started': 'Oyun başladı',
    'log.mission': 'Görev seçildi: {mission}',
    'log.skip': 'Operatör brifingi atlattı',
    'log.added': '{role}: {item} takıldı',
    'log.removed': '{role}: {item} çıkarıldı',
    'log.review': 'Hazırlık incelemesi açıldı',
    'log.fix': '{role} DÜZELT dedi',
    'log.ok': '{role} ONAY verdi',
    'log.launch': 'FIRLATMA',
    'log.launchConfirmed': 'FIRLATMA (onaylı, durum: {status})',
    'log.new': 'Yeni görev',
    'log.same': 'Aynı görev tekrar',
    'log.simDone': 'Simülasyon bitti',
  },
};

const hasMessage = (key) => typeof key === 'string' && Object.prototype.hasOwnProperty.call(MESSAGES.en, key);

// Parametre değeri: role/roles → rol adı, status → durum adı, dizi → virgüllü liste
function paramText(lang, name, v) {
  if (name === 'role') return roleName(lang, v);
  if (name === 'roles') return (Array.isArray(v) ? v : [v]).map((r) => roleName(lang, r)).join(', ');
  if (name === 'status') return LAUNCH_STATUS_I18N[lang][v] || String(v);
  if (Array.isArray(v)) return v.join(', ');
  return v === undefined || v === null ? '' : String(v);
}

// msg(lang, key, params): katalog metni, {param} yerleştirilmiş. Anahtar yoksa anahtarın kendisi.
function msg(lang, key, params) {
  const l = normLang(lang);
  const tpl = (MESSAGES[l] && MESSAGES[l][key]) || MESSAGES.en[key];
  if (typeof tpl !== 'string') return String(key);
  const p = params && typeof params === 'object' ? params : {};
  return tpl.replace(/\{(\w+)\}/g, (m, k) => (k in p ? paramText(l, k, p[k]) : m));
}

// Geri uyum: iki dilli varsayılan hata mesajları ({ en: {NO_SPACE,...}, tr: {...} })
const ERROR_MESSAGES = MESSAGES;
// Sohbet modülü hata kodları -> mesaj, dil başına (chat.send yalnız kod döndürür)
const CHAT_ERROR_MESSAGES = Object.fromEntries(LANGS.map((l) => [l, Object.fromEntries(
  Object.entries(MESSAGES[l]).filter(([k]) => k.startsWith('chat.') && k !== 'chat.failed').map(([k, v]) => [k.slice(5), v]),
)]));

// Harcama defteri en çok bu kadar kayıt tutar (eskiler atılır)
const LEDGER_MAX = 300;

// evaluation.launchStatus; yoksa (eski sim) overall + kritik kalem türünden türet. ev yoksa null.
function launchStatusOf(ev) {
  if (!ev || typeof ev !== 'object') return null;
  if (LAUNCH_STATUSES.includes(ev.launchStatus)) return ev.launchStatus;
  const items = Array.isArray(ev.readiness) ? ev.readiness.filter((r) => r && typeof r === 'object') : [];
  const critFail = items.filter((r) => r.status === 'FAIL' && r.critical);
  if (critFail.some((r) => r.kind === 'physical')) return 'INSUFFICIENT';
  if (critFail.some((r) => r.kind === 'missing')) return 'MISSING';
  if (ev.overall === 'FAIL' || critFail.length) return 'INSUFFICIENT';
  if (ev.overall === 'WARN' || items.some((r) => r.status === 'WARN' || r.status === 'FAIL')) return 'RISKY';
  return 'READY';
}

// Oyun kuralı hatası: .code = hata kodu, .key/.params = katalog anahtarı (dile çevrilebilir),
// .message = varsayılan dilde (en) metin. key katalogda yoksa düz metin kabul edilir (ör. sim gerekçesi).
class GameError extends Error {
  constructor(code, key, params) {
    const known = hasMessage(key);
    super(known ? msg(DEFAULT_LANG, key, params) : String(key === undefined || key === null ? code : key));
    this.name = 'GameError';
    this.code = code;
    this.key = known ? key : null;
    this.params = params && typeof params === 'object' ? params : null;
  }

  // Mesajı verilen dile çevirir (düz metinse olduğu gibi kalır)
  localize(lang) {
    if (this.key) this.message = msg(lang, this.key, this.params);
    return this.message;
  }
}

module.exports = {
  ROLES, ENGINEER_ROLES, WORKER_ROLES, PHASES, PHASE_LIST, MAX_PLAYERS, ROLE_NAMES,
  SIGNOFF_DECISIONS, PLAY_AGAIN_MODES, DEFAULTS, ERRORS, CHAT_ERROR_MESSAGES, GameError,
  ERROR_MESSAGES, LEDGER_MAX, LAUNCH_STATUSES, LAUNCH_STATUS_TR, launchStatusOf,
  // Aşama 9
  LANGS, DEFAULT_LANG, isLang, normLang, ROLE_NAMES_I18N, roleName, LAUNCH_STATUS_I18N, MESSAGES, msg, hasMessage,
};
