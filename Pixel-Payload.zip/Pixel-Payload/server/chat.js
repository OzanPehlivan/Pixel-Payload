'use strict';
// Sohbet yetkileri (PLAN.md Aşama 7 "Sohbet"). Saf modül: durum yalnız room.chat içinde.
// Gönderen rolü ve oda üyeliği SUNUCU durumundan (room.players) alınır; istemciden gelen rol/oda yok sayılır.

const ENGINEER_ROLES = ['rocket', 'spacecraft', 'payload'];
const DIRECTOR = 'director';
// Bilinen tüm hedef adları: izin dışı ama bilinen → FORBIDDEN, bilinmeyen → BAD_TARGET
const KNOWN_TARGETS = new Set(['director', 'rocket', 'spacecraft', 'payload', 'engineers', 'all', 'everyone', 'broadcast']);
const DIRECTOR_TARGETS = new Set(['rocket', 'spacecraft', 'payload', 'engineers']);

// Kontrol karakterleri: C0, DEL, çift yönlü metin kontrolleri (U+202A–202E, U+2066–2069)
const STRIP_RE = /[\u0000-\u0008\u000B\u000C\u000E-\u001F\u007F‪-‮⁦-⁩]/g;
const SPACE_RE = /[\t\n\r]/g; // satır sonu/sekme boşluğa çevrilir (kelimeler yapışmasın)

function emptyChat() {
  return { threads: { rocket: [], spacecraft: [], payload: [], broadcast: [] }, rate: {} };
}

function ensureChat(room) {
  if (!room.chat || !room.chat.threads) room.chat = emptyChat();
  if (!room.chat.rate) room.chat.rate = {};
  for (const t of [...ENGINEER_ROLES, 'broadcast']) {
    if (!Array.isArray(room.chat.threads[t])) room.chat.threads[t] = [];
  }
  return room.chat;
}

function getPlayer(room, playerId) {
  if (!room || !room.players || typeof room.players.get !== 'function') return undefined;
  return room.players.get(playerId);
}

// Belirli roldeki oyuncuların playerId listesi (bağlı olmayanlar dahil)
function idsWithRole(room, role) {
  const out = [];
  for (const [pid, p] of room.players) if (p && p.role === role) out.push(pid);
  return out;
}

function cleanText(text) {
  return text.replace(SPACE_RE, ' ').replace(STRIP_RE, '').trim();
}

function copyMsg(m) {
  return { ...m };
}

function createChat({ now = Date.now, maxLen = 300, rate = { count: 5, perMs: 5000 }, historyLimit = 200 } = {}) {
  let seq = 0;

  function send(room, senderPlayerId, payload) {
    const sender = getPlayer(room, senderPlayerId);
    if (!sender) return { ok: false, error: 'NOT_IN_ROOM' };
    const role = sender.role;
    if (role !== DIRECTOR && !ENGINEER_ROLES.includes(role)) return { ok: false, error: 'NO_ROLE' };

    if (!payload || typeof payload !== 'object' || Array.isArray(payload)) return { ok: false, error: 'BAD_TARGET' };
    const { to, text } = payload;
    if (typeof to !== 'string') return { ok: false, error: 'BAD_TARGET' };

    // İzin tablosu
    let thread;
    let targetIds;
    if (role === DIRECTOR) {
      if (!DIRECTOR_TARGETS.has(to)) return { ok: false, error: KNOWN_TARGETS.has(to) ? 'FORBIDDEN' : 'BAD_TARGET' };
      if (to === 'engineers') {
        thread = 'broadcast';
        targetIds = ENGINEER_ROLES.flatMap((r) => idsWithRole(room, r));
      } else {
        thread = to;
        targetIds = idsWithRole(room, to);
      }
    } else {
      if (to !== DIRECTOR) return { ok: false, error: KNOWN_TARGETS.has(to) ? 'FORBIDDEN' : 'BAD_TARGET' };
      thread = role; // mühendis↔operatör thread'i mühendisin rolüdür
      targetIds = idsWithRole(room, DIRECTOR);
    }

    // Metin doğrulama (kesme yok)
    if (typeof text !== 'string') return { ok: false, error: 'EMPTY' };
    const clean = cleanText(text);
    if (clean.length === 0) return { ok: false, error: 'EMPTY' };
    if ([...clean].length > maxLen) return { ok: false, error: 'TOO_LONG' };

    if (targetIds.length === 0) return { ok: false, error: 'TARGET_EMPTY' };

    // Hız sınırı: playerId başına kayan pencere (yalnız kabul edilen mesajlar sayılır)
    const chat = ensureChat(room);
    const t = now();
    const recent = (chat.rate[senderPlayerId] || []).filter((ts) => t - ts < rate.perMs);
    if (recent.length >= rate.count) {
      chat.rate[senderPlayerId] = recent;
      return { ok: false, error: 'RATE_LIMIT' };
    }
    recent.push(t);
    chat.rate[senderPlayerId] = recent;

    const message = { id: ++seq, ts: t, thread, from: role, fromName: String(sender.name || ''), text: clean };
    const list = chat.threads[thread];
    list.push(message);
    if (list.length > historyLimit) list.splice(0, list.length - historyLimit);

    // Alıcılar: thread'in tarafları (gönderen dahil, ekran yankısı için), tekrarsız
    const recipients = new Set(idsWithRole(room, DIRECTOR));
    if (thread === 'broadcast') ENGINEER_ROLES.forEach((r) => idsWithRole(room, r).forEach((id) => recipients.add(id)));
    else idsWithRole(room, thread).forEach((id) => recipients.add(id));
    recipients.add(senderPlayerId);

    return { ok: true, message: copyMsg(message), recipients: [...recipients] };
  }

  function viewFor(room, playerId) {
    const p = getPlayer(room, playerId);
    if (!p) return null;
    const chat = ensureChat(room);
    const copy = (name) => chat.threads[name].map(copyMsg);
    if (p.role === DIRECTOR) {
      return { threads: { rocket: copy('rocket'), spacecraft: copy('spacecraft'), payload: copy('payload'), broadcast: copy('broadcast') } };
    }
    if (ENGINEER_ROLES.includes(p.role)) {
      return { threads: { mine: copy(p.role), broadcast: copy('broadcast') } };
    }
    return null;
  }

  function reset(room) {
    room.chat = emptyChat();
  }

  return { send, viewFor, reset };
}

module.exports = { createChat };
