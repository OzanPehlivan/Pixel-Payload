'use strict';
// Veri yükleyici: data/equipment/*.json, data/missions/*.json, data/physics/constants.json,
// data/science/sources.json. Eksik/bozuk dosyalar atlanır (istisna atmaz).

const fs = require('fs');
const path = require('path');
const { arr, obj, clone } = require('./util');
const { msg, normLang } = require('./i18n');

// Sabit ayar anahtarları (PLAN). Görev verisi aynı anahtarı tanımlarsa onunkiler öncelikli.
const BUILTIN_SETTINGS = [
  { key: 'propellantLoad', role: 'rocket', label: 'Yakıt doluluk oranı', type: 'number', min: 0.6, max: 1, step: 0.05, default: 1, unit: '' },
  { key: 'consumableMarginDays', role: 'spacecraft', label: 'Sarf malzemesi yedeği', type: 'number', min: 0, max: 10, step: 1, default: 3, unit: 'gün', crewOnly: true },
  { key: 'powerMode', role: 'spacecraft', label: 'Güç modu', type: 'enum', options: ['eco', 'normal', 'max'], default: 'normal', unit: '' },
  { key: 'instrumentMode', role: 'payload', label: 'Alet çalışma modu', type: 'enum', options: ['survey', 'balanced', 'intensive'], default: 'balanced', unit: '' },
];

function readJson(file) {
  try {
    return JSON.parse(fs.readFileSync(file, 'utf8'));
  } catch (_) {
    return undefined;
  }
}

function jsonFiles(dir) {
  try {
    return fs.readdirSync(dir).filter((f) => f.toLowerCase().endsWith('.json')).sort().map((f) => path.join(dir, f));
  } catch (_) {
    return [];
  }
}

// Görevi eksik alanlara dayanıklı hale getirir ve ayar tanımlarını birleştirir.
function normalizeMission(m) {
  const out = clone(m);
  out.modules = arr(out.modules).map((mod) => Object.assign({}, mod, { categories: arr(mod.categories) }));
  out.phases = arr(out.phases).map((p) => Object.assign({}, p, { checks: arr(p.checks) }));
  out.objectives = arr(out.objectives);
  out.limits = obj(out.limits);
  out.briefing = obj(out.briefing);
  const own = new Map(arr(out.settings).filter((s) => s && s.key).map((s) => [s.key, s]));
  const merged = [];
  for (const b of BUILTIN_SETTINGS) {
    if (b.crewOnly && !(out.crew > 0) && !own.has(b.key)) continue; // yaşam desteği yalnız mürettebatlı görevde
    const def = Object.assign({}, b, own.get(b.key) || {});
    delete def.crewOnly;
    merged.push(def);
    own.delete(b.key);
  }
  for (const s of own.values()) merged.push(Object.assign({}, s));
  out.settings = merged;
  return out;
}

// Ham veri → { items, missions, constants, sources }
function normalizeData({ equipment, missions, constants, sources }) {
  const items = [];
  const seen = new Set();
  const eqList = Array.isArray(equipment) ? equipment : arr(obj(equipment).items);
  for (const it of eqList) {
    if (!it || typeof it.id !== 'string' || seen.has(it.id)) continue;
    seen.add(it.id);
    items.push(clone(it));
  }
  const ms = [];
  for (const m of arr(missions)) if (m && typeof m.id === 'string') ms.push(normalizeMission(m));
  return { items, missions: ms, constants: obj(constants), sources: arr(sources).filter((s) => s && s.id) };
}

// --- Aşama 9: dil bindirmesi -------------------------------------------------------------------
// data/i18n/<lang>/equipment-*.json → { items: { id: { name, desc, incompatible, refs } } }
// data/i18n/<lang>/missions-<ad>.json → data/missions/<ad>.json'daki görev(ler)e (ya da kendi `id`'sine) eşlenir.
// data/i18n/<lang>/sources.json → { sourceId: { title } }. Dosya yoksa/bozuksa boş bindirme.
// Dönüş: { en: { items: {}, missions: { missionId: ov }, sources: {} } }
function loadOverlays(dataDir) {
  const out = {};
  for (const lang of ['en']) {
    const dir = path.join(dataDir, 'i18n', lang);
    const ov = { items: {}, missions: {}, sources: {} };
    for (const f of jsonFiles(dir)) {
      const base = path.basename(f, '.json');
      const j = obj(readJson(f));
      if (base.startsWith('equipment')) Object.assign(ov.items, obj(j.items));
      else if (base === 'sources') Object.assign(ov.sources, obj(j.sources && typeof j.sources === 'object' && !Array.isArray(j.sources) ? j.sources : j));
      else if (base.startsWith('missions')) {
        const tail = base.replace(/^missions-?/, '');
        const trFile = readJson(path.join(dataDir, 'missions', `${tail}.json`));
        const ids = Array.isArray(trFile) ? trFile.map((m) => m && m.id) : trFile && trFile.id ? [trFile.id] : [];
        if (typeof j.id === 'string') ids.push(j.id);
        if (!ids.length && tail) ids.push(tail);
        for (const id of ids) if (typeof id === 'string') ov.missions[id] = j;
      }
    }
    out[lang] = ov;
  }
  return out;
}

const str = (x) => typeof x === 'string' && x.trim() !== '';
const BUILTIN_TR_LABEL = new Map(BUILTIN_SETTINGS.map((b) => [b.key, b.label]));

// Normalize edilmiş görevin metin alanlarını bindirmeyle değiştirir (sayılar aynen kalır).
function localizeMission(m, ov, lang) {
  const out = clone(m);
  const o = obj(ov);
  for (const [k, v] of Object.entries(o)) if (str(v) && typeof out[k] === 'string' && k !== 'id') out[k] = v;
  const mods = obj(o.modules), phs = obj(o.phases), objs = obj(o.objectives), cats = obj(o.categories);
  for (const mod of out.modules) {
    if (str(mods[mod.id])) mod.name = mods[mod.id];
    for (const c of mod.categories) if (c && str(cats[c.category])) c.name = cats[c.category];
  }
  for (const p of out.phases) if (str(phs[p.id])) p.name = phs[p.id];
  for (const x of out.objectives) if (x && str(objs[x.id])) x.name = objs[x.id];
  for (const [role, lines] of Object.entries(obj(o.briefing))) {
    if (Array.isArray(lines) && lines.length && lines.every((l) => typeof l === 'string')) out.briefing[role] = lines.slice();
  }
  const sets = obj(o.settings);
  for (const def of out.settings) {
    const so = obj(sets[def.key]);
    if (str(so.label)) def.label = so.label;
    else if (lang === 'en' && def.label === BUILTIN_TR_LABEL.get(def.key)) def.label = msg(lang, `setting.${def.key}`);
    if (str(so.help)) def.help = so.help;
    if (typeof so.unit === 'string') def.unit = so.unit;
    else if (lang === 'en' && def.unit === 'gün') def.unit = msg(lang, 'unit.gün');
    const oi = obj(so.optionInfo);
    if (def.optionInfo && typeof def.optionInfo === 'object') {
      for (const [opt, info] of Object.entries(def.optionInfo)) {
        const t = obj(oi[opt]);
        if (!info || typeof info !== 'object') continue;
        for (const f of ['label', 'desc', 'note', 'text', 'help']) if (str(t[f])) info[f] = t[f];
      }
    }
  }
  const goals = obj(o.scienceGoals);
  for (const g of arr(out.scienceGoals)) {
    const t = obj(g && goals[g.id]);
    if (str(t.name)) g.name = t.name;
    if (str(t.desc)) g.desc = t.desc;
  }
  // refs: { "phases.launch.dvMs": "note" } → out.refs ağacındaki ilgili düğümün note'u
  for (const [p, note] of Object.entries(obj(o.refs))) {
    if (!str(note)) continue;
    let cur = out.refs && out.refs[p]; // TR'de anahtar düz ("phases.launch.dvMs") ya da iç içe olabilir
    if (!cur) { cur = out.refs; for (const k of p.split('.')) cur = cur && typeof cur === 'object' ? cur[k] : undefined; }
    if (cur && typeof cur === 'object' && !Array.isArray(cur)) cur.note = note;
  }
  for (const k of ['tagNames', 'scienceTags']) {
    if (!out[k] || typeof out[k] !== 'object') continue;
    for (const [tag, name] of Object.entries(obj(o[k]))) if (str(name)) out[k][tag] = name;
  }
  return out;
}

function localizeItem(it, ov) {
  const out = clone(it);
  const o = obj(ov);
  if (str(o.name)) out.name = o.name;
  if (str(o.desc)) out.desc = o.desc;
  const inc = obj(o.incompatible);
  for (const x of arr(out.incompatibleWith)) if (x && str(inc[x.tag])) x.reason = inc[x.tag];
  const refs = obj(o.refs);
  for (const [f, note] of Object.entries(refs)) if (str(note) && out.refs && out.refs[f] && typeof out.refs[f] === 'object') out.refs[f].note = note;
  return out;
}

// Normalize edilmiş veriyi (normalizeData çıktısı) dile çevirir. lang 'tr' → aynen.
function localizeData(raw, overlays, lang) {
  const l = normLang(lang);
  if (l === 'tr') return raw;
  const ov = obj(obj(overlays)[l]);
  const items = obj(ov.items), ms = obj(ov.missions), src = obj(ov.sources);
  return {
    items: raw.items.map((it) => localizeItem(it, items[it.id])),
    missions: raw.missions.map((m) => localizeMission(m, ms[m.id], l)),
    constants: raw.constants,
    sources: raw.sources.map((s) => (src[s.id] && str(obj(src[s.id]).title) ? Object.assign({}, s, { title: src[s.id].title }) : s)),
  };
}

function loadFromDir(dataDir) {
  const equipment = [];
  for (const f of jsonFiles(path.join(dataDir, 'equipment'))) {
    const j = readJson(f);
    equipment.push(...arr(Array.isArray(j) ? j : obj(j).items));
  }
  const missions = [];
  for (const f of jsonFiles(path.join(dataDir, 'missions'))) {
    const j = readJson(f);
    if (Array.isArray(j)) missions.push(...j);
    else if (j && typeof j === 'object') missions.push(j);
  }
  const constants = readJson(path.join(dataDir, 'physics', 'constants.json')) || {};
  const srcJson = readJson(path.join(dataDir, 'science', 'sources.json'));
  const sources = Array.isArray(srcJson) ? srcJson : arr(obj(srcJson).sources);
  return normalizeData({ equipment, missions, constants, sources });
}

module.exports = { loadFromDir, normalizeData, normalizeMission, BUILTIN_SETTINGS, loadOverlays, localizeData, localizeMission, localizeItem };
