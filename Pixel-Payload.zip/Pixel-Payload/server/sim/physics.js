'use strict';
// Fizik yardımcıları — BASİTLEŞTİRİLMİŞ EĞİTSEL MODEL.
// Gerçek bir NASA uçuş modeli değildir; sınıf arkadaşına anlatılabilecek düzeyde
// klasik denklemler (Tsiolkovsky, TWR, üstel atmosfer, Allen-Eggers + Sutton-Graves).
// Tüm birimler SI.

const { num } = require('./util');

const EDUCATIONAL_LABEL = 'Basitleştirilmiş eğitsel model; gerçek uçuş modeli değildir.';

// Tsiolkovsky: Δv = Isp·g0·ln(m0/mf)
function deltaV(ispS, g0, m0, mf) {
  if (!(ispS > 0) || !(m0 > 0) || !(mf > 0) || mf >= m0) return 0;
  return ispS * g0 * Math.log(m0 / mf);
}

// Verilen Δv için gereken yakıt kütlesi: mp = m0·(1 − e^(−Δv/(Isp·g0)))
function propellantFor(dv, ispS, g0, m0) {
  if (!(dv > 0)) return 0;
  if (!(ispS > 0) || !(m0 > 0)) return Infinity;
  return m0 * (1 - Math.exp(-dv / (ispS * g0)));
}

// Birden çok motorun etkin Isp'si (itki ağırlıklı harmonik): F / Σ(Fi/Ispi)
function effectiveIsp(engines) {
  let f = 0, flow = 0;
  for (const e of engines) {
    const F = num(e.thrustN), I = num(e.ispS);
    if (F > 0 && I > 0) { f += F; flow += F / I; }
  }
  return flow > 0 ? f / flow : 0;
}

// İtki/ağırlık oranı
function twr(thrustN, massKg, gravity) {
  if (!(massKg > 0) || !(gravity > 0)) return 0;
  return num(thrustN) / (massKg * gravity);
}

// Yüzey yerçekimi g = μ/r²
function surfaceGravity(mu, radius) {
  return radius > 0 ? mu / (radius * radius) : 0;
}

// Dairesel yörünge hızı v = √(μ/r), kaçış hızı v = √(2μ/r)
function orbitalVelocity(mu, r) {
  return r > 0 ? Math.sqrt(mu / r) : 0;
}
function escapeVelocity(mu, r) {
  return r > 0 ? Math.sqrt((2 * mu) / r) : 0;
}

// Tek yön ışık gecikmesi (s)
function lightDelay(distanceM, c) {
  return c > 0 ? distanceM / c : 0;
}

// Üstel atmosfer ρ(h) = ρ0·e^(−h/H)
function atmosphereDensity(rho0, scaleH, h) {
  if (!(scaleH > 0)) return 0;
  return rho0 * Math.exp(-h / scaleH);
}

// Allen-Eggers balistik giriş: tepe ısınmanın olduğu yoğunluk ve hız.
//   β = m/(Cd·A); ρ* = β·sinγ/(3H)… v* = v_e·e^(−1/6)
// Sutton-Graves tipi taşınım ısı akısı: q = k·√(ρ/rn)·v³ (W/m²) → W/cm² için /1e4
function entryPeakHeat({ massKg, dragAreaM2, entryMs, gammaDeg, scaleH, rho0, noseRadiusM, k }) {
  if (!(massKg > 0) || !(dragAreaM2 > 0) || !(entryMs > 0)) {
    return { ballisticCoef: 0, peakRho: 0, peakV: 0, peakHeatWcm2: 0 };
  }
  const beta = massKg / dragAreaM2;
  const sinG = Math.sin((Math.abs(num(gammaDeg, 15)) * Math.PI) / 180) || 0.25;
  let rho = (beta * sinG) / (3 * scaleH);
  if (rho0 > 0) rho = Math.min(rho, rho0); // atmosfer yüzeyden yoğun olamaz
  const v = entryMs * Math.exp(-1 / 6);
  const q = k * Math.sqrt(rho / Math.max(noseRadiusM, 0.1)) * v * v * v;
  return { ballisticCoef: beta, peakRho: rho, peakV: v, peakHeatWcm2: q / 1e4 };
}

// Sürükleme dengesinde (terminal) hız: v = √(2·m·g/(ρ·CdA))
function terminalVelocity(massKg, gravity, rho, dragAreaM2) {
  if (!(rho > 0) || !(dragAreaM2 > 0)) return Infinity;
  return Math.sqrt((2 * massKg * gravity) / (rho * dragAreaM2));
}

// Güç/enerji dengesi: marj ve bataryanın açığı kaç saat karşılayacağı.
function energyBalance(genW, useW, batteryWh) {
  const marginW = genW - useW;
  const hours = marginW >= 0 ? Infinity : batteryWh / -marginW;
  return { marginW, batteryHours: hours, ratio: useW > 0 ? Math.min(1, genW / useW) : 1 };
}

module.exports = {
  EDUCATIONAL_LABEL,
  deltaV, propellantFor, effectiveIsp, twr, surfaceGravity, orbitalVelocity, escapeVelocity,
  lightDelay, atmosphereDensity, entryPeakHeat, terminalVelocity, energyBalance,
};
