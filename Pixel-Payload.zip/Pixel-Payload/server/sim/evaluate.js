'use strict';
// evaluate(): telemetri + hazırlık kontrol listesi + ihtiyaçlar.
// BASİTLEŞTİRİLMİŞ EĞİTSEL MODEL — katsayılar veriden okunur; eksikse DEF'teki belgeli varsayılan kullanılır.
//
// Veri kuralları (docs/VERI_KAYNAKLARI.md): massKg yakıt HARİÇ (sarflar dahil); `stage` seri kademe;
// aşamada `carries` (itilen modüller) + `excludeTags` (atılan parçalar, kalıcı); `dutyCycle` ortalama güç;
// `linkSecPerSol` bağlantı penceresi; `heatRejectW`/`heatW` ısı dengesi.

const P = require('./physics');
const { num, arr, obj, clamp, round, get, tagSet, hasWord, fmt } = require('./util');
const { msg } = require('./i18n');

const ENGINEERS = ['rocket', 'spacecraft', 'payload'];
const ROLE_TR = { director: 'Operatör', rocket: 'İtki', spacecraft: 'Uzay aracı', payload: 'Bilim & faydalı yük' };

// Mod çarpanları: görev ayarındaki `optionInfo` öncelikli; yoksa bu varsayılanlar (class: game).
const DEFAULT_MODES = {
  powerMode: { eco: { use: 0.85, comms: 0.7 }, normal: { use: 1, comms: 1 }, max: { use: 1.2, comms: 1.3 } },
  instrumentMode: {
    survey: { power: 0.7, data: 0.7, science: 0.75 },
    balanced: { power: 1, data: 1, science: 1 },
    intensive: { power: 1.5, data: 1.5, science: 1.3 },
  },
};

// Belgeli varsayılanlar (veri vermezse). Hepsi "estimated/game".
const DEF = {
  minTWR: 1.2,
  minLandingTWR: 1.2,          // Ay/Mars yerel yerçekiminde iniş/çıkış TWR alt sınırı
  dvMarginPct: 0.03,           // Δv marjı bunun altındaysa WARN
  crewMassKg: 0,               // mürettebat kütlesi kapsül kütlesine dahil sayılır
  o2KgPerPersonDay: 0.84,      // NASA BVAD esinli
  waterKgPerPersonDay: 2.5,
  minBatteryHours: 12,         // güç açığını batarya en az bu kadar karşılamalı (yoksa FAIL)
  thermalBatteryFactor: 0.7,   // ısı sorunu → batarya kapasitesi çarpanı
  thermalInstrumentFactor: 0.5,
  controlledTempC: [0, 30],    // ısı kontrolü varken iç ortam
  envTempC: { moon: [-170, 120], mars: [-90, 20] },
  landingMaxVms: 2,
  terrainHazard: 0.15,         // sensörsüz arazi tehlikesi
  sensorHazardFactor: 0.3,     // iniş radarı tehlikeyi bu oranda düşürür
  trnHazardFactor: 0.5,        // arazi-göreli navigasyon / tehlike algılama ek çarpanı
  entrySpeedMs: 5400,
  entryAngleDeg: 15.5,
  noseRadiusM: 1.1,
  suttonGravesK: 1.9027e-4,    // Mars CO2 atmosferi, SI
  chuteDeployAltM: 11000,
  backshellSepAltM: 2000,
  hoverTimeS: 15,
  speedOfSoundMs: 240,
  linkSecPerSol: { mars: { relay: 600, direct: 7200 }, moon: { relay: 43200, direct: 43200 } },
  scienceTargetPct: 0.25,
  budgetWarnPct: 0.97,
  solarFactor: 1,
};

// Veri farklı adlar kullanabilir: ilk bulunan anahtar okunur.
const ALIASES = {
  minLandingTWR: ['minLandingTWR', 'minLanderTWR', 'minDescentTWR'],
  dvMarginPct: ['dvMarginPct'],
  o2KgPerPersonDay: ['o2KgPerPersonDay', 'o2PerCrewDayKg'],
  waterKgPerPersonDay: ['waterKgPerPersonDay', 'waterPerCrewDayKg'],
  entrySpeedMs: ['entrySpeedMs', 'entryVelocityMs'],
  entryAngleDeg: ['entryAngleDeg', 'entryFlightPathDeg'],
  solarFactor: ['solarFactor', 'solarDustFactor'],
  minScience: ['minScience', 'scienceTarget'],
};

function bodyOf(mission) {
  if (mission.body) return mission.body;
  return /mars/i.test(mission.id) ? 'mars' : 'moon';
}

// --- Aşama türleri ---------------------------------------------------------------------------
const KIND_RX = {
  entry: /entry|edl|giris|atmosfer|parachute|chute/i,
  landing: /landing|descent|inis|touchdown|powered/i,
  ascent: /ascent|cikis/i,
  surface: /surface|yuzey|eva|explor|kesif|deploy|rover|gezgin/i,
  science: /science|bilim|ops|operation/i,
  comms: /data|transmit|iletim|comm|downlink/i,
  cruise: /cruise|seyir|transfer|coast|tli|tmi|loi|orbit|approach|tcm|correction|return|donus|departure/i,
  recovery: /recovery|kurtarma|splash/i,
};

function launchIndex(phases) {
  const byId = phases.findIndex((p) => /^launch$|kalkis/i.test(String(p.id)));
  if (byId >= 0) return byId;
  return phases.findIndex((p) => num(p.dvMs) > 0);
}

// Her aşama için tür kümesi. Veri `kind` (metin/dizi) verirse önceliklidir.
function kindsFor(mission) {
  const li = launchIndex(mission.phases);
  return mission.phases.map((p, i) => {
    const k = new Set();
    const given = Array.isArray(p.kind) ? p.kind : p.kind ? [p.kind] : [];
    for (const g of given) k.add(String(g));
    if (!given.length) for (const [kind, rx] of Object.entries(KIND_RX)) if (rx.test(String(p.id))) k.add(kind);
    if (i === li) { k.add('launch'); k.delete('cruise'); }
    if (k.has('landing')) k.delete('ascent');
    return k;
  });
}

// --- Ayarlar ---------------------------------------------------------------------------------
function resolveSettings(mission, settings) {
  const out = {};
  const s = obj(settings);
  for (const def of arr(mission.settings)) out[def.key] = s[def.key] === undefined ? def.default : s[def.key];
  return out;
}

function modeOf(mission, key, value) {
  const def = DEFAULT_MODES[key];
  const base = Object.assign({}, def[value] || def[Object.keys(def)[1]]);
  const sdef = arr(mission.settings).find((s) => s.key === key);
  const info = obj(obj(sdef && sdef.optionInfo)[value]);
  if (key === 'powerMode' && info.useFactor !== undefined) base.use = num(info.useFactor, base.use);
  if (key === 'instrumentMode') {
    if (info.dutyFactor !== undefined) base.power = num(info.dutyFactor, base.power);
    if (info.scienceFactor !== undefined) base.science = num(info.scienceFactor, base.science);
    if (info.dataFactor !== undefined) base.data = num(info.dataFactor, base.data);
  }
  return Object.assign(base, obj(obj(obj(mission.modes)[key])[value]));
}

// Aşama 8 ayarları: seçeneğin optionInfo'daki sayısal çarpanı (ayar yoksa nötr varsayılan).
const OPTION_DEFAULTS = {
  ascentProfile: { lofted: { dvFactor: 1.04, riskFactor: 0.6 }, standard: { dvFactor: 1, riskFactor: 1 }, depressed: { dvFactor: 0.96, riskFactor: 1.6 } },
  commsPlan: { minimal: { linkFactor: 0.5, powerFactor: 0.6 }, standard: { linkFactor: 1, powerFactor: 1 }, continuous: { linkFactor: 1.6, powerFactor: 1.8 } },
  samplePriority: { goals: { scienceFactor: 0.85 }, balanced: { scienceFactor: 1 }, explore: { scienceFactor: 1.15 } },
};
function optionNum(mission, key, value, field, d) {
  const sdef = arr(mission.settings).find((s) => s.key === key);
  const info = obj(obj(sdef && sdef.optionInfo)[value]);
  if (typeof info[field] === 'number' && Number.isFinite(info[field])) return info[field];
  const def = obj(obj(OPTION_DEFAULTS[key])[value]);
  return num(def[field], d);
}

// Hazırlık kalemi türü (Aşama 8): ok | missing | physical | risky | budget
const PHYSICAL_RX = /^(dv-|twr|mass-launch$|mass-lander$|landing$|edl-|instrument-capacity$|capacity-|reentry-shield$|power($|-)|life-|crew-vehicle$)/;
function kindOf(r) {
  if (r.status === 'PASS') return 'ok';
  const id = String(r.id);
  if (id === 'budget') return 'budget';
  if (r.kind) return r.kind;
  if (id.startsWith('cat-') || id.startsWith('req-')) return 'missing';
  if (r.status === 'FAIL' && PHYSICAL_RX.test(id) && !r.cascadeFrom) return 'physical';
  return 'risky';
}
// Fırlatma durumu: INSUFFICIENT > MISSING > RISKY > READY (bütçe kalemi durumu değiştirmez)
function launchStatusOf(readiness) {
  const crit = readiness.filter((r) => r.status === 'FAIL' && r.critical);
  if (crit.some((r) => r.kind === 'physical')) return 'INSUFFICIENT';
  if (crit.some((r) => r.kind === 'missing')) return 'MISSING';
  if (readiness.some((r) => r.status !== 'PASS' && r.kind !== 'budget')) return 'RISKY';
  return 'READY';
}

// ------------------------------------------------------------------------------------------
function evaluateInternal(ctx, missionId, build, settings, lang = 'tr') {
  const mission = ctx.missions.get(missionId);
  if (!mission) return null;
  const T = (k, p) => msg(lang, k, p);
  const F = (v, d) => fmt(v, d, lang);
  const C = ctx.constants;
  const L = mission.limits;
  // Sınır okuma: veri (takma adlarla) → belgeli varsayılan
  const lim = (k) => {
    for (const a of ALIASES[k] || [k]) {
      const v = L[a];
      if (v !== undefined && v !== null) return Math.abs(num(v && typeof v === 'object' && 'v' in v ? v.v : v, DEF[k]));
    }
    return DEF[k];
  };
  const g0 = get(C, 'g0', 9.80665);
  const body = bodyOf(mission);
  const gBody = get(C, `${body}.surfaceGravity`, body === 'mars' ? 3.73 : 1.62);
  const S = resolveSettings(mission, settings);
  const load = clamp(num(S.propellantLoad, 1), 0, 1);
  const pMode = modeOf(mission, 'powerMode', S.powerMode);
  const iMode = modeOf(mission, 'instrumentMode', S.instrumentMode);
  // Aşama 8 ayarları (görevde tanımlı değilse nötr)
  const reservePct = clamp(num(S.landingReservePct, 0), 0, 50) / 100;
  const ascentDv = optionNum(mission, 'ascentProfile', S.ascentProfile, 'dvFactor', 1);
  const ascentRisk = optionNum(mission, 'ascentProfile', S.ascentProfile, 'riskFactor', 1);
  const linkF = optionNum(mission, 'commsPlan', S.commsPlan, 'linkFactor', 1);
  const commsPowerF = optionNum(mission, 'commsPlan', S.commsPlan, 'powerFactor', 1);
  const priorityF = optionNum(mission, 'samplePriority', S.samplePriority, 'scienceFactor', 1);
  const priority = S.samplePriority || 'balanced';
  const phases = mission.phases;
  const kinds = kindsFor(mission);
  const li = launchIndex(phases);

  const readiness = [];
  const add = (o) => { readiness.push(Object.assign({ critical: false }, o)); return o; };
  const unmet = [];

  // --- 1. Kurulu parçalar --------------------------------------------------------------------
  const moduleById = new Map(mission.modules.map((m) => [m.id, m]));
  const installed = [];
  for (const b of arr(build)) {
    const it = b && ctx.items.get(b.itemId);
    const moduleId = b && (b.moduleId || (it && it.module));
    if (!it || !moduleById.has(moduleId) || (b.role && b.role !== it.role)
      || (Array.isArray(it.missions) && !it.missions.includes(missionId))) {
      add({ id: `invalid-${b && b.uid}`, system: T('sys.config'), role: it ? it.role : 'director', status: 'WARN',
        text: T('ev.invalid') });
      continue;
    }
    installed.push({ uid: b.uid, item: it, moduleId, role: it.role, active: true, gone: false });
  }

  // Gereksinim: `requires` etiketini başka parça sağlamıyorsa parça çalışmaz (kütle/maliyet kalır).
  // Etiket → Türkçe ad: görev sözlüğü (tagNames / scienceTags) → onu sağlayan katalog parçasının adı → ham etiket
  const tagTr = (t) => {
    const d = obj(mission.tagNames)[t] || obj(mission.scienceTags)[t];
    if (d) return d;
    const it = ctx.itemList.find((i) => arr(i.provides).includes(t) && (!Array.isArray(i.missions) || i.missions.includes(missionId)));
    return it ? it.name : t;
  };
  const provided = new Set();
  for (const x of installed) for (const t of tagSet(x.item)) provided.add(t);
  const seenReq = new Set();
  for (const x of installed) {
    const missing = arr(x.item.requires).filter((r) => !provided.has(r));
    if (!missing.length) continue;
    x.active = false;
    if (seenReq.has(x.item.id)) continue;
    seenReq.add(x.item.id);
    const text = T('ev.req', { name: x.item.name, list: missing.map(tagTr).join(', ') });
    unmet.push({ itemId: x.item.id, requires: missing, requiresNames: missing.map(tagTr), text });
    add({ id: `req-${x.item.id}`, system: T('sys.req'), role: x.role, status: 'FAIL', text });
  }
  const act = installed.filter((x) => x.active);

  // Kategori alt sınırları
  const catalogRole = (modId, cat) => {
    const it = ctx.itemList.find((i) => i.module === modId && i.category === cat
      && (!Array.isArray(i.missions) || i.missions.includes(missionId)));
    return it ? it.role : null;
  };
  for (const mod of mission.modules) {
    for (const c of mod.categories) {
      const have = installed.filter((x) => x.moduleId === mod.id && x.item.category === c.category).length;
      if (num(c.min) > have) {
        const role = c.role || catalogRole(mod.id, c.category) || mod.role || 'director';
        add({ id: `cat-${mod.id}-${c.category}`, system: mod.name || mod.id, role, status: 'FAIL', critical: true,
          text: T('ev.cat', { mod: mod.name || mod.id, min: c.min, cat: c.name || c.label || c.category, have }),
          value: have, limit: c.min, unit: T('unit.adet') });
      }
    }
  }

  // --- 2. Kütle ve kademeler -----------------------------------------------------------------
  const crew = num(mission.crew);
  const days = num(mission.durationDays);
  const marginDays = crew > 0 ? clamp(num(S.consumableMarginDays, 0), 0, 30) : 0;
  const crewKg = crew * lim('crewMassKg');
  let crewModule = null;
  if (crew > 0) {
    const hab = installed.find((x) => hasWord(x.item, ['crew-habitat', 'capsule', 'eclss']));
    crewModule = L.crewModule || (hab && hab.moduleId) || (mission.modules.find((m) => m.role === 'spacecraft') || {}).id || null;
  }

  const propOf = (x) => num(x.item.propellantKg) * (x.role === 'rocket' ? load : 1); // doluluk yalnız itki parçalarına
  const stageOf = (it) => (num(it.stage) > 0 ? num(it.stage) : 1);
  const mods = {};
  for (const mod of mission.modules) mods[mod.id] = { id: mod.id, extra: 0, stages: {}, dropped: false };
  if (crewModule && mods[crewModule]) mods[crewModule].extra = crewKg;
  const massByRole = { rocket: 0, spacecraft: 0, payload: 0 };
  const massByModule = {};
  let propellantTotal = 0;
  for (const x of installed) {
    const m = mods[x.moduleId];
    const s = stageOf(x.item);
    const st = m.stages[s] || (m.stages[s] = { no: s, items: [], prop: 0, engines: [], dropped: false, roles: new Set() });
    st.items.push(x);
    st.prop += propOf(x);
    propellantTotal += propOf(x);
    if (x.active && num(x.item.thrustN) > 0 && num(x.item.ispS) > 0) { st.engines.push(x.item); st.roles.add(x.role); }
    const kg = num(x.item.massKg) + propOf(x);
    massByRole[x.role] = (massByRole[x.role] || 0) + kg;
    massByModule[x.moduleId] = (massByModule[x.moduleId] || 0) + kg;
  }
  if (crewKg && crewModule) { massByModule[crewModule] = (massByModule[crewModule] || 0) + crewKg; massByRole.spacecraft += crewKg; }
  const totalMass = Object.values(massByModule).reduce((a, b) => a + b, 0);

  const sortedStages = (m) => Object.values(m.stages).sort((a, b) => a.no - b.no);
  const stageDry = (s) => s.items.reduce((a, x) => a + (x.gone ? 0 : num(x.item.massKg)), 0);
  const moduleMass = (m) => m.extra + sortedStages(m).filter((s) => !s.dropped).reduce((a, s) => a + stageDry(s) + s.prop, 0);
  const stackMass = (ids) => ids.reduce((a, id) => a + moduleMass(mods[id]), 0);

  // Modülün kalan yakıtıyla yanma (seri kademe). commit=false → yalnız hesap; onlyStage → yalnız o kademe.
  function burn(modId, need, stackIds, commit, onStage, onlyStage) {
    const m = mods[modId];
    if (!m) return 0;
    const snap = sortedStages(m).map((s) => [s.prop, s.dropped]);
    let got = 0;
    let remaining = need;
    const stages = sortedStages(m).filter((s) => !s.dropped && (!onlyStage || s.no === onlyStage));
    for (let i = 0; i < stages.length && remaining > 1e-9; i++) {
      const s = stages[i];
      const isp = P.effectiveIsp(s.engines);
      const m0 = stackMass(stackIds);
      if (onStage) onStage(s, isp, m0);
      if (isp > 0 && s.prop > 0) {
        const full = P.deltaV(isp, g0, m0, m0 - s.prop);
        if (full >= remaining) {
          s.prop -= P.propellantFor(remaining, isp, g0, m0);
          got += remaining; remaining = 0;
          break;
        }
        got += full; remaining -= full; s.prop = 0;
      }
      if (i < stages.length - 1) s.dropped = true; // boşalan kademe ayrılır
    }
    if (!commit) sortedStages(m).forEach((s, i) => { s.prop = snap[i][0]; s.dropped = snap[i][1]; });
    return got;
  }

  // Aşama döngüsü
  const lastDvIndex = {};
  phases.forEach((p, i) => { if (p.dvFrom) lastDvIndex[p.dvFrom] = i; });
  const stackOf = (p) => arr(p.carries).concat(arr(p.stack));
  const laterStack = (id, i) => phases.slice(i + 1).some((p) => stackOf(p).includes(id));
  const dv = {};
  const stagesDv = {};
  const phaseInfo = {};
  let launchTwr = 0;
  let launchKg = 0;
  let edl = null;
  let landing = null;
  const hasAtmosphere = body === 'mars';
  const atmo = {
    rho0: get(C, 'mars.atmosphere.surfaceDensityKgM3', 0.016),
    H: get(C, 'mars.atmosphere.scaleHeightM', 11000),
    a: get(C, 'mars.atmosphere.speedOfSoundMs', DEF.speedOfSoundMs),
  };
  const isLandingEngine = (it) => hasWord(it, ['descent', 'lander-propulsion', 'skycrane', 'inis', 'retro']);
  const sensorItem = act.find((x) => x.role !== 'payload' && hasWord(x.item, ['radar', 'altimeter', 'landing-sensor']));
  const trnItem = act.find((x) => x.role !== 'payload' && hasWord(x.item, ['terrain-relative', 'hazard-detection', 'trn', 'lidar']));
  const firstLanding = kinds.findIndex((k) => k.has('landing'));

  function computeEdl(stackIds) {
    const m = stackMass(stackIds);
    let shieldMax = 0, aeroArea = 0, chuteArea = 0, chuteMaxMach = 0, maxEntryMass = 0;
    for (const x of act) {
      if (!stackIds.includes(x.moduleId) || x.gone) continue;
      const e = obj(x.item.edl);
      if (num(e.maxHeatFluxWcm2) > shieldMax) shieldMax = num(e.maxHeatFluxWcm2);
      if (num(e.maxMach) > 0) { chuteArea += num(e.dragArea); chuteMaxMach = Math.max(chuteMaxMach, num(e.maxMach)); } else aeroArea += num(e.dragArea);
      if (num(x.item.maxEntryMassKg) > 0) maxEntryMass = maxEntryMass ? Math.min(maxEntryMass, num(x.item.maxEntryMassKg)) : num(x.item.maxEntryMassKg);
    }
    if (num(L.maxChuteMach) > 0 && chuteMaxMach > 0) chuteMaxMach = Math.min(chuteMaxMach, num(L.maxChuteMach));
    const entryMs = lim('entrySpeedMs');
    const heat = P.entryPeakHeat({ massKg: m, dragAreaM2: aeroArea, entryMs, gammaDeg: lim('entryAngleDeg'),
      scaleH: atmo.H, rho0: atmo.rho0, noseRadiusM: lim('noseRadiusM'), k: lim('suttonGravesK') });
    const rhoDeploy = P.atmosphereDensity(atmo.rho0, atmo.H, lim('chuteDeployAltM'));
    const vTerm = P.terminalVelocity(m, gBody, rhoDeploy, aeroArea);
    // Veri sabit açılış Mach'ı verirse (ör. 1,75) onu kullan; yoksa sürükleme dengesinden hesapla
    const chuteMach = num(L.chuteDeployMach) > 0 && aeroArea > 0 ? num(L.chuteDeployMach)
      : (Number.isFinite(vTerm) ? Math.min(entryMs, vTerm) / atmo.a : 99);
    const rhoSep = P.atmosphereDensity(atmo.rho0, atmo.H, lim('backshellSepAltM'));
    const vChute = chuteArea > 0 ? P.terminalVelocity(m, gBody, rhoSep, chuteArea + aeroArea) : chuteMach * atmo.a;
    return { massKg: m, shieldMax, aeroArea, chuteArea, chuteMaxMach, maxEntryMass, entryMs, peakHeat: heat.peakHeatWcm2,
      chuteMach, vChute: Number.isFinite(vChute) ? vChute : entryMs };
  }

  phases.forEach((p, i) => {
    const ks = kinds[i];
    // Atılan parçalar (kalıcı)
    const ex = arr(p.excludeTags);
    if (ex.length) for (const x of installed) if (arr(x.item.tags).some((t) => ex.includes(t))) x.gone = true;
    let stack = stackOf(p).filter((id) => mods[id]);
    if (!stack.length) stack = mission.modules.map((m) => m.id).filter((id) => !mods[id].dropped);
    if (p.dvFrom && mods[p.dvFrom] && !stack.includes(p.dvFrom)) stack = stack.concat(p.dvFrom);
    const only = num(p.stage) > 0 ? num(p.stage) : 0;
    if (p.dvFrom && only && mods[p.dvFrom]) for (const s of sortedStages(mods[p.dvFrom])) if (s.no < only) s.dropped = true;
    const stackKg = stackMass(stack);
    const info = { id: p.id, kinds: ks, stack, stackKg, dvRequired: 0, dvAvailable: 0, twr: null, dvRole: null, dvFrom: null };
    phaseInfo[p.id] = info;
    if (i === li) launchKg = stackKg;

    if (hasAtmosphere && !edl && (ks.has('entry') || i === firstLanding)) edl = computeEdl(stack);

    let required = num(p.dvMs);
    let dvFrom = p.dvFrom;
    if (i === firstLanding) {
      if (!dvFrom) {
        const eng = act.find((x) => stack.includes(x.moduleId) && num(x.item.thrustN) > 0 && isLandingEngine(x.item));
        dvFrom = eng ? eng.moduleId : null;
      }
      if (hasAtmosphere && edl) required = Math.max(required, edl.vChute + gBody * lim('hoverTimeS'));
      required *= 1 + reservePct; // iniş yakıt rezervi: ek havada kalma payı
    }
    if (i === li) required *= ascentDv; // kalkış profili: yerçekimi kaybı ↔ dinamik basınç
    if (!(required > 0)) return finish(i);
    const m = dvFrom && mods[dvFrom];
    const firstStage = m && sortedStages(m).find((s) => !s.dropped && (!only || s.no === only));
    info.dvFrom = dvFrom;
    info.dvRole = (firstStage && [...firstStage.roles][0]) || (moduleById.get(dvFrom) || {}).role || 'rocket';
    // TWR: kalkışta deniz seviyesi itkisi (kademe ≤ 2, yani yan itici + çekirdek) / (yığın × g0);
    // iniş/çıkışta yanmanın başındaki kütle × yerel yerçekimi.
    if (i === li && m) {
      const lowest = sortedStages(m)[0] ? sortedStages(m)[0].no : 1;
      const thr = sortedStages(m).filter((s) => s.no <= Math.max(2, lowest))
        .reduce((a, s) => a + s.engines.reduce((b, e) => b + num(e.thrustSlN, num(e.thrustN)), 0), 0);
      info.twr = P.twr(thr, stackKg, g0);
      info.twrBody = 'earth';
      launchTwr = info.twr;
    } else if (ks.has('landing') || ks.has('ascent')) {
      const thr = firstStage ? firstStage.engines.reduce((a, e) => a + num(e.thrustN), 0) : 0;
      info.twr = P.twr(thr, stackKg, gBody);
      info.twrBody = body;
    }
    const available = m ? burn(dvFrom, Infinity, stack, false, (s, isp, m0) => {
      const key = Object.keys(m.stages).length > 1 ? `${dvFrom}:${s.no}` : dvFrom;
      if (stagesDv[key] === undefined) stagesDv[key] = round(P.deltaV(isp, g0, m0, m0 - s.prop), 0);
    }, only) : 0;
    if (m) burn(dvFrom, required, stack, true, null, only);
    info.dvRequired = required;
    info.dvAvailable = available;
    dv[p.id] = { available: round(available, 0), required: round(required, 0) };
    if (i === firstLanding) landing = { short: Math.max(0, required - available), phaseId: p.id };
    finish(i);
  });
  function finish(i) {
    // Son yanmasından sonra ve ileride taşınmıyorsa modül ayrılır
    for (const id of Object.keys(lastDvIndex)) if (lastDvIndex[id] === i && mods[id] && !laterStack(id, i)) mods[id].dropped = true;
  }
  for (const m of Object.values(mods)) {
    const list = sortedStages(m);
    for (const s of list) {
      const key = list.length > 1 ? `${m.id}:${s.no}` : m.id;
      if (stagesDv[key] === undefined && s.engines.length) {
        const m0 = Math.max(moduleMass(m), stageDry(s) + s.prop);
        stagesDv[key] = round(P.deltaV(P.effectiveIsp(s.engines), g0, m0, m0 - s.prop), 0);
      }
    }
  }
  const remainingProp = Object.values(mods).reduce((a, m) => a + sortedStages(m).reduce((b, s) => b + (s.dropped ? 0 : s.prop), 0), 0);

  // İniş hızı: kusursuz temas + Δv açığı (atmosfersiz/atmosferli aynı basit model)
  const legLimit = act.reduce((a, x) => (num(x.item.maxLandingVms) > 0 ? Math.min(a, num(x.item.maxLandingVms)) : a), Infinity);
  const landingMax = Math.min(lim('landingMaxVms'), legLimit);
  const touchdown = num(L.touchdownVms) || landingMax * 0.5;
  let landingVms = 0;
  if (firstLanding >= 0) {
    if (landing) landingVms = touchdown + landing.short;
    else landingVms = hasAtmosphere && edl ? edl.vChute : touchdown;
  }

  // --- 3. Güç baraları -----------------------------------------------------------------------
  // Bara: güç ÜRETEN kategorisi olan modül; diğer modüller listede kendinden önceki baraya bağlanır.
  const powerCapable = (modId) => ctx.itemList.some((it) => it.module === modId && num(it.powerGenW) > 0
    && (!Array.isArray(it.missions) || it.missions.includes(missionId)));
  const busOf = {};
  let lastBus = null;
  for (const mod of mission.modules) {
    if (arr(L.powerBuses).length) break;
    if (powerCapable(mod.id)) lastBus = mod.id;
    if (lastBus) busOf[mod.id] = lastBus;
  }
  for (const group of arr(L.powerBuses)) for (const id of arr(group)) busOf[id] = arr(group)[0];
  const buses = {};
  for (const id of new Set(Object.values(busOf))) buses[id] = { id, genW: 0, useOther: 0, usePayload: 0, batteryWh: 0, rejectW: 0, heatW: 0, mods: Object.keys(busOf).filter((k) => busOf[k] === id) };
  const busIds = Object.keys(buses);
  // Birincil bara: bilim aletlerinin bağlı olduğu bara
  const payloadItem = installed.find((x) => x.role === 'payload' && busOf[x.moduleId]);
  const primary = payloadItem ? busOf[payloadItem.moduleId] : busIds[busIds.length - 1];
  const solarF = lim('solarFactor');
  for (const x of act) {
    const b = buses[busOf[x.moduleId]];
    if (!b) continue;
    const solar = hasWord(x.item, ['solar', 'gunes']);
    b.genW += num(x.item.powerGenW) * (solar ? solarF : 1);
    b.batteryWh += num(x.item.batteryWh);
    b.rejectW += num(x.item.heatRejectW);
    let avg = num(x.item.powerW) * (x.item.dutyCycle === undefined ? 1 : num(x.item.dutyCycle, 1));
    if (x.role !== 'rocket' && num(x.item.dataRateBps) > 0 && busOf[x.moduleId] === primary) avg *= commsPowerF; // iletişim planı → verici gücü
    if (x.role === 'payload') b.usePayload += avg * iMode.power * pMode.use;
    else b.useOther += avg * pMode.use;
  }
  // Atık ısı (RTG) en büyük ısı atma kapasiteli baraya yüklenir (seyirde taşıyıcı ısıyı atar)
  const heatSink = busIds.slice().sort((a, b) => buses[b].rejectW - buses[a].rejectW)[0];
  for (const x of act) if (num(x.item.heatW) > 0 && buses[heatSink]) buses[heatSink].heatW += num(x.item.heatW);

  // --- 4. Isı (bataryayı etkiler) ------------------------------------------------------------
  const thermalCtl = act.some((x) => x.role !== 'rocket' && hasWord(x.item, ['thermal', 'heat-rejection', 'heater', 'radiator', 'rhu']));
  const envC = Array.isArray(L.envTempC) ? L.envTempC : (DEF.envTempC[body] || DEF.envTempC.moon);
  const effC = thermalCtl ? (Array.isArray(L.controlledTempC) ? L.controlledTempC : DEF.controlledTempC) : envC;
  const outOfRange = installed.filter((x) => x.role !== 'rocket' && Array.isArray(x.item.tempRangeC) && x.item.tempRangeC.length === 2
    && (num(x.item.tempRangeC[0]) > effC[0] || num(x.item.tempRangeC[1]) < effC[1]));
  const outIds = new Set(outOfRange.map((x) => x.uid));
  const overheated = busIds.filter((id) => buses[id].rejectW > 0 && buses[id].useOther + buses[id].usePayload + buses[id].heatW > buses[id].rejectW);
  const thermalIssue = outOfRange.length > 0 || overheated.length > 0;
  if (thermalIssue) for (const id of busIds) buses[id].batteryWh *= lim('thermalBatteryFactor');

  for (const id of busIds) {
    const b = buses[id];
    b.useW = b.useOther + b.usePayload;
    const bal = P.energyBalance(b.genW, b.useW, b.batteryWh);
    b.marginW = bal.marginW;
    b.hours = bal.batteryHours;
    b.deficit = bal.marginW < 0;
    b.ratio = b.deficit ? clamp((b.genW + b.batteryWh / 24) / b.useW, 0, 1) : 1;
    b.source = b.deficit && b.usePayload >= -b.marginW ? ['payload'] : ['spacecraft'];
  }
  const pb = buses[primary] || { genW: 0, useW: 0, useOther: 0, usePayload: 0, batteryWh: 0, marginW: 0, deficit: false, ratio: 1, mods: [] };
  const powerRatio = pb.ratio;

  // --- 5. İletişim (birincil bara: yüzey/gezgin bağlantısı) -----------------------------------
  let relayBps = 0, directBps = 0, downlinkMb = 0;
  const win = obj(DEF.linkSecPerSol[body]);
  for (const x of act) {
    if (x.role === 'rocket' || !(num(x.item.dataRateBps) > 0) || busOf[x.moduleId] !== primary) continue;
    const relay = hasWord(x.item, ['relay', 'uhf']);
    const rate = num(x.item.dataRateBps) * pMode.comms * (pb.deficit ? powerRatio : 1);
    const secs = Math.min(86400, (num(x.item.linkSecPerSol) || num(relay ? win.relay : win.direct, 3600)) * linkF); // iletişim planı → pencere
    if (relay) relayBps += rate; else directBps += rate;
    downlinkMb += (rate * secs) / 1e6;
  }
  const c = get(C, 'lightSpeedMs', 299792458);
  const dist = num(L.commsDistanceM) || (body === 'mars'
    ? (get(C, 'distances.earthMarsMinM', 5.46e10) + get(C, 'distances.earthMarsMaxM', 4.014e11)) / 2
    : get(C, 'distances.earthMoonM', 3.844e8));
  const delayS = P.lightDelay(dist, c);
  let dataMb = 0;
  for (const x of act) {
    if (x.role !== 'payload') continue;
    dataMb += num(x.item.dataGenMbPerSol) * iMode.data * powerRatio * (outIds.has(x.uid) ? lim('thermalInstrumentFactor') : 1);
  }
  const commsRatio = dataMb > 0 ? clamp(downlinkMb / dataMb, 0, 1) : 1;

  // --- 6. Bilim / EVA ------------------------------------------------------------------------
  const suit = act.find((x) => x.role === 'payload' && (num(x.item.evaHours) > 0 || hasWord(x.item, ['eva-capability', 'eva-suit'])));
  const evaHours = suit ? num(suit.item.evaHours) + act.reduce((a, x) => a + num(x.item.evaHoursBonus), 0) : 0;
  const minEva = num(L.minEvaHours);
  const instruments = act.filter((x) => x.role === 'payload' && num(x.item.scienceValue) > 0);
  let catalogMax = 0;
  for (const it of ctx.itemList) if (it.role === 'payload' && (!Array.isArray(it.missions) || it.missions.includes(missionId))) catalogMax += num(it.scienceValue);
  const scienceMax = num(L.scienceMax) || catalogMax;
  let scienceValue = 0;
  for (const x of instruments) scienceValue += num(x.item.scienceValue) * (outIds.has(x.uid) ? lim('thermalInstrumentFactor') : 1);
  scienceValue *= iMode.science * priorityF * powerRatio * (0.5 + 0.5 * commsRatio);
  scienceValue = Math.min(scienceValue, scienceMax || scienceValue);
  const scienceTarget = lim('minScience') || scienceMax * DEF.scienceTargetPct;
  // Gezgin alet yuvası
  const capItem = act.find((x) => num(x.item.instrumentCapacityKg) > 0);
  const instrMassOnCap = capItem ? installed.filter((x) => x.role === 'payload' && x.moduleId === capItem.moduleId).reduce((a, x) => a + num(x.item.massKg), 0) : 0;

  // --- 7. Yaşam desteği ----------------------------------------------------------------------
  let lifeSupport = null;
  const lsCap = { o2: 0, water: 0, co2: 0 };
  if (crew > 0) {
    for (const x of act) {
      if (x.moduleId !== crewModule) continue; // EVA giysisi sarfı kabin kapasitesine sayılmaz
      const ls = obj(x.item.lifeSupport);
      lsCap.o2 += num(ls.o2Kg); lsCap.water += num(ls.waterKg); lsCap.co2 += num(ls.co2ScrubPersonDays);
    }
    const cb = buses[busOf[crewModule]];
    const co2F = cb && cb.deficit ? cb.ratio : 1;
    lifeSupport = { crew, days, o2Days: round(lsCap.o2 / (crew * lim('o2KgPerPersonDay')), 1),
      waterDays: round(lsCap.water / (crew * lim('waterKgPerPersonDay')), 1), co2Days: round((lsCap.co2 / crew) * co2F, 1) };
  }

  // --- 8. Hazırlık kalemleri -----------------------------------------------------------------
  const cost = installed.reduce((a, x) => a + num(x.item.cost), 0);
  const costByRole = { rocket: 0, spacecraft: 0, payload: 0 };
  for (const x of installed) costByRole[x.role] = round((costByRole[x.role] || 0) + num(x.item.cost), 2);
  const budget = num(mission.budget);
  if (budget > 0) {
    // Aşama 8: bütçe aşımı KRİTİK DEĞİL — fırlatmayı engellemez, debrief'te puan düşürür.
    const st = cost > budget ? 'FAIL' : cost > budget * DEF.budgetWarnPct ? 'WARN' : 'PASS';
    add({ id: 'budget', system: T('sys.budget'), role: 'director', status: st, critical: false, kind: 'budget',
      text: T(st === 'FAIL' ? 'ev.budgetFail' : st === 'WARN' ? 'ev.budgetWarn' : 'ev.budgetOk', { cost: F(cost, 1), budget }),
      value: round(cost, 1), limit: budget, unit: T('unit.birim') });
  }
  // Modül kapasitesi (U): sert sınır; canAdd engeller, burada yalnız tutarsız/eski build yakalanır.
  const capacity = {};
  for (const mod of mission.modules) {
    const byRole = { rocket: 0, spacecraft: 0, payload: 0 };
    for (const x of installed) if (x.moduleId === mod.id) byRole[x.role] = (byRole[x.role] || 0) + Math.max(0, num(x.item.volumeU));
    const usedU = byRole.rocket + byRole.spacecraft + byRole.payload;
    const capU = num(mod.capacityU) > 0 ? num(mod.capacityU) : null;
    capacity[mod.id] = { name: mod.name || mod.id, usedU, capacityU: capU, freeU: capU === null ? null : capU - usedU, byRole };
    if (capU !== null && usedU > capU) {
      add({ id: `capacity-${mod.id}`, system: T('sys.capacity', { mod: mod.name || mod.id }), role: mod.role || 'director', status: 'FAIL', critical: true, kind: 'physical',
        text: T('ev.capacity', { mod: mod.name || mod.id, used: usedU, cap: capU }), value: usedU, limit: capU, unit: 'U' });
    }
  }
  if (num(L.maxLaunchMassKg) > 0) {
    const over = launchKg > num(L.maxLaunchMassKg);
    add({ id: 'mass-launch', system: T('sys.massLaunch'), role: 'rocket', status: over ? 'FAIL' : 'PASS', critical: over,
      text: T(over ? 'ev.massLaunchFail' : 'ev.massLaunchOk', { kg: F(launchKg / 1000, 1), max: F(num(L.maxLaunchMassKg) / 1000, 1) }),
      value: round(launchKg), limit: num(L.maxLaunchMassKg), unit: 'kg' });
  }
  if (num(L.maxLanderMassKg) > 0 && firstLanding >= 0) {
    const kg = phaseInfo[phases[firstLanding].id].stackKg;
    const over = kg > num(L.maxLanderMassKg);
    add({ id: 'mass-lander', system: T('sys.massLander'), role: 'rocket', status: over ? 'FAIL' : 'PASS', critical: over,
      text: T(over ? 'ev.massLanderFail' : 'ev.massLanderOk', { kg: F(kg / 1000, 1), max: F(num(L.maxLanderMassKg) / 1000, 1) }),
      value: round(kg), limit: num(L.maxLanderMassKg), unit: 'kg' });
  }
  const allot = obj(L.massAllotmentKg);
  const overRoles = [];
  for (const r of ['spacecraft', 'payload']) {
    const cap = num(allot[r]) || num(L[`${r}MassKg`]);
    if (!(cap > 0)) continue;
    const over = massByRole[r] > cap;
    if (over) overRoles.push(r);
    add({ id: `mass-${r}`, system: T('sys.massRole'), role: r, status: over ? 'WARN' : 'PASS',
      text: T(over ? 'ev.massRoleFail' : 'ev.massRoleOk', { role: T(`role.${r}`), kg: F(massByRole[r]), cap }),
      value: round(massByRole[r]), limit: cap, unit: 'kg' });
  }

  // TWR ve Δv
  const dvMarginPct = L.minDvMarginPct !== undefined && num(L.minDvMarginPct) > 0 ? num(L.minDvMarginPct) / (num(L.minDvMarginPct) > 1 ? 100 : 1) : lim('dvMarginPct');
  let worstDv = 'PASS';
  const shortRoles = new Set();
  phases.forEach((p, i) => {
    const info = phaseInfo[p.id];
    if (info.twr !== null) {
      const isLaunch = i === li;
      const minT = isLaunch ? lim('minTWR') : lim('minLandingTWR');
      const st = info.twr < minT ? 'FAIL' : info.twr < minT * 1.05 ? 'WARN' : 'PASS';
      const where = T(info.twrBody === 'earth' ? 'where.earth' : info.twrBody === 'mars' ? 'where.mars' : 'where.moon');
      add({ id: isLaunch ? 'twr' : `twr-${p.id}`, system: T('sys.twr', { phase: p.name || p.id }), role: info.dvRole || 'rocket', status: st, critical: st === 'FAIL',
        text: T(st === 'FAIL' ? 'ev.twrFail' : 'ev.twrOk', { where, twr: F(info.twr, 2), min: minT }),
        value: round(info.twr, 2), limit: minT, unit: '' });
    }
    if (info.dvRequired > 0) {
      const a = info.dvAvailable, r = info.dvRequired;
      const st = a < r ? 'FAIL' : a < r * (1 + dvMarginPct) ? 'WARN' : 'PASS';
      if (st === 'FAIL' || (st === 'WARN' && worstDv === 'PASS')) worstDv = st;
      if (st !== 'PASS') shortRoles.add(info.dvRole);
      add({ id: `dv-${p.id}`, system: T('sys.dv', { phase: p.name || p.id }), role: info.dvRole || 'rocket', status: st, critical: st === 'FAIL',
        text: T(st === 'FAIL' ? 'ev.dvFail' : st === 'WARN' ? 'ev.dvWarn' : 'ev.dvOk', { a: F(a), r: F(r) }),
        value: round(a), limit: round(r), unit: 'm/s' });
    }
  });
  // Zincir: üst modül kütlesi → itki Δv (etkilenen rol: rocket; SAYISIZ metin)
  if (worstDv !== 'PASS' && shortRoles.has('rocket')) {
    const hasAllot = Object.keys(allot).length > 0 || num(L.spacecraftMassKg) > 0 || num(L.payloadMassKg) > 0;
    const from = hasAllot ? overRoles : ['spacecraft', 'payload'].filter((r) => massByRole[r] > 0);
    if (from.length) {
      add({ id: 'mass-dv', system: T('sys.massDv'), role: 'rocket', status: 'WARN', cascadeFrom: from,
        text: T('ev.massDv', { roles: from.map((r) => T(`role.${r}`)).join(T('join.and')) }) });
    }
  }
  add({ id: 'fuel', system: T('sys.fuel'), role: 'rocket', status: worstDv === 'PASS' ? 'PASS' : 'WARN',
    text: T('ev.fuel', { t: F(propellantTotal / 1000, 1), pct: F(load * 100), kg: F(remainingProp) }),
    value: round(remainingProp), limit: 0, unit: 'kg' });

  // Güç (bara başına) + zincirler
  for (const id of busIds) {
    const b = buses[id];
    if (!b.genW && !b.useW && !b.batteryWh) continue;
    let st, text, critical = false;
    if (!b.deficit) {
      st = b.marginW < Math.max(num(L.minPowerMarginW), 0) || b.marginW < b.useW * 0.05 ? 'WARN' : 'PASS';
      text = T('ev.powerOk', { warn: st === 'WARN', gen: F(b.genW), use: F(b.useW, 1) });
    } else if (b.hours >= lim('minBatteryHours')) {
      st = 'WARN';
      text = T('ev.powerWarn', { w: F(-b.marginW, 1), h: F(b.hours, 1) });
    } else {
      st = 'FAIL'; critical = true;
      text = T('ev.powerFail', { w: F(-b.marginW, 1), h: F(b.hours, 1) });
    }
    const modName = (moduleById.get(id) || {}).name || id;
    add({ id: id === primary ? 'power' : `power-${id}`, system: id === primary && body === 'mars' ? T('sys.powerRover') : T('sys.power', { mod: modName }),
      role: 'spacecraft', status: st, critical, text, value: round(b.marginW, 1), limit: 0, unit: 'W' });
  }
  if (pb.deficit) {
    add({ id: 'power-science', system: T('sys.powerScience'), role: 'payload', status: 'WARN', cascadeFrom: ['spacecraft'],
      text: T('ev.powerScience') });
    add({ id: 'power-comms', system: T('sys.powerComms'), role: 'spacecraft', status: 'WARN', cascadeFrom: pb.source,
      text: T('ev.powerComms') });
    if (crew > 0 && suit) {
      add({ id: 'power-eva', system: T('sys.powerEva'), role: 'payload', status: 'WARN', cascadeFrom: ['spacecraft'],
        text: T('ev.powerEva') });
    }
  }
  // Mars gecesi: yalnız güneşle beslenen gezgin, geceyi (≈12 saat) bataryayla geçirmeli
  if (body === 'mars' && pb.genW > 0 && pb.useW > 0) {
    const gens = act.filter((x) => busOf[x.moduleId] === primary && num(x.item.powerGenW) > 0);
    if (gens.length && gens.every((x) => hasWord(x.item, ['solar', 'gunes']))) {
      const nightWh = pb.useW * num(L.marsNightHours, 12);
      const ok = pb.batteryWh >= nightWh;
      add({ id: 'power-night', system: T('sys.powerNight'), role: 'spacecraft', status: ok ? 'PASS' : 'WARN',
        text: T(ok ? 'ev.nightOk' : 'ev.nightWarn', { have: F(pb.batteryWh), need: F(nightWh) }),
        value: round(pb.batteryWh), limit: round(nightWh), unit: 'Wh' });
    }
  }
  const crewBus = crew > 0 ? buses[busOf[crewModule]] : null;
  if (crewBus && crewBus.deficit) {
    add({ id: 'power-life', system: T('sys.powerLife'), role: 'spacecraft', status: 'WARN', cascadeFrom: crewBus.source,
      text: T('ev.powerLife') });
  }

  // Isı
  {
    const parts = [];
    if (outOfRange.length) parts.push(T('ev.thermalOut', { n: outOfRange.length, lo: effC[0], hi: effC[1], ctl: thermalCtl, names: outOfRange.map((x) => x.item.name).join(', ') }));
    for (const id of overheated) {
      const b = buses[id];
      parts.push(T('ev.thermalOver', { mod: (moduleById.get(id) || {}).name || id, load: F(b.useW + b.heatW), rej: F(b.rejectW) }));
    }
    const maxLoad = busIds.reduce((a, id) => Math.max(a, buses[id].rejectW > 0 ? (buses[id].useW + buses[id].heatW) / buses[id].rejectW : 0), 0);
    add({ id: 'thermal', system: T('sys.thermal'), role: 'spacecraft', status: thermalIssue ? 'WARN' : 'PASS',
      text: thermalIssue ? `${parts.join('. ')}.` : T('ev.thermalOk', { lo: effC[0], hi: effC[1] }),
      value: round(maxLoad * 100), limit: 100, unit: T('unit.heatLoad') });
    if (thermalIssue && busIds.some((id) => buses[id].batteryWh > 0)) {
      add({ id: 'thermal-battery', system: T('sys.thermalBattery'), role: 'spacecraft', status: 'WARN', cascadeFrom: ['spacecraft'],
        text: T('ev.thermalBattery') });
    }
    if (outOfRange.some((x) => x.role === 'payload') || (overheated.includes(primary) && instruments.length)) {
      add({ id: 'thermal-science', system: T('sys.thermalScience'), role: 'payload', status: 'WARN', cascadeFrom: ['spacecraft'],
        text: T('ev.thermalScience') });
    }
  }

  // İletişim
  {
    const none = relayBps + directBps <= 0;
    add({ id: 'comms-link', system: T('sys.commsLink'), role: 'spacecraft', status: none ? 'FAIL' : 'PASS', critical: none, kind: none ? 'missing' : undefined,
      text: none ? T('ev.commsNone')
        : T('ev.commsOk', { relay: F(relayBps), direct: F(directBps), delay: F(delayS, 1) }),
      value: round(delayS, 1), unit: 's' });
    if (!none && downlinkMb < dataMb) {
      add({ id: 'comms-capacity', system: T('sys.commsCapacity'), role: 'spacecraft', status: 'WARN',
        text: T('ev.commsCapacity', { down: F(downlinkMb, 1), data: F(dataMb, 1) }),
        value: round(downlinkMb, 1), limit: round(dataMb, 1), unit: T('unit.mbDay') });
      add({ id: 'comms-science', system: T('sys.commsScience'), role: 'payload', status: 'WARN', cascadeFrom: ['spacecraft'],
        text: T('ev.commsScience') });
    }
  }

  // Navigasyon
  const navOk = act.some((x) => x.role !== 'payload' && hasWord(x.item, ['nav', 'star-tracker', 'imu', 'gnc', 'guidance']));
  add({ id: 'nav', system: T('sys.nav'), role: 'spacecraft', status: navOk ? 'PASS' : 'WARN',
    text: T(navOk ? 'ev.navOk' : 'ev.navNone') });

  // İniş
  let hazard = 0;
  if (firstLanding >= 0) {
    hazard = clamp(num(L.terrainHazard, DEF.terrainHazard) * (sensorItem ? lim('sensorHazardFactor') : 1)
      * (trnItem ? lim('trnHazardFactor') : 1) * (navOk ? 1 : 1.5) * Math.max(0.4, 1 - 3 * reservePct), 0, 1); // rezerv → kaçınma manevrası
    add({ id: 'landing-sensor', system: T('sys.landingSensor'), role: 'spacecraft', status: sensorItem ? 'PASS' : 'WARN',
      text: T('ev.landingSensor', { sensor: !!sensorItem, trn: !!trnItem, hazard: F(hazard * 100, 1) }),
      value: round(hazard * 100, 1), unit: '%' });
    if (!sensorItem) {
      add({ id: 'landing-sensor-rocket', system: T('sys.landingSensorRocket'), role: 'rocket', status: 'WARN', cascadeFrom: ['spacecraft'],
        text: T('ev.landingSensorRocket') });
    }
    const st = landingVms > landingMax ? 'FAIL' : landingVms > landingMax * 0.85 ? 'WARN' : 'PASS';
    add({ id: 'landing', system: T('sys.landing'), role: 'rocket', status: st, critical: st === 'FAIL',
      text: T(st === 'FAIL' ? 'ev.landingFail' : 'ev.landingOk', { v: F(landingVms, 2), max: landingMax }),
      value: round(landingVms, 2), limit: landingMax, unit: 'm/s' });
  }

  // EDL (Mars)
  if (hasAtmosphere && edl) {
    if (!(edl.aeroArea > 0)) add({ id: 'edl-aeroshell', system: T('sys.aeroshell'), role: 'spacecraft', status: 'FAIL', critical: true, text: T('ev.aeroshell') });
    if (!(edl.shieldMax > 0)) {
      add({ id: 'edl-shield', system: T('sys.shield'), role: 'spacecraft', status: 'FAIL', critical: true, text: T('ev.shieldNone') });
    } else {
      const st = edl.peakHeat > edl.shieldMax ? 'FAIL' : edl.peakHeat > edl.shieldMax * 0.8 ? 'WARN' : 'PASS';
      add({ id: 'edl-shield', system: T('sys.shield'), role: 'spacecraft', status: st, critical: st === 'FAIL',
        text: T('ev.shield', { heat: F(edl.peakHeat, 1), max: edl.shieldMax }),
        value: round(edl.peakHeat, 1), limit: edl.shieldMax, unit: 'W/cm²' });
    }
    if (edl.maxEntryMass > 0) {
      const over = edl.massKg > edl.maxEntryMass;
      add({ id: 'edl-mass', system: T('sys.entryMass'), role: 'spacecraft', status: over ? 'FAIL' : edl.massKg > edl.maxEntryMass * 0.95 ? 'WARN' : 'PASS', critical: over,
        text: T('ev.entryMass', { kg: F(edl.massKg), max: edl.maxEntryMass }),
        value: round(edl.massKg), limit: edl.maxEntryMass, unit: 'kg' });
    }
    if (!(edl.chuteMaxMach > 0)) {
      add({ id: 'edl-chute', system: T('sys.chute'), role: 'spacecraft', status: 'FAIL', critical: true, text: T('ev.chuteNone') });
    } else {
      const st = edl.chuteMach > edl.chuteMaxMach ? 'FAIL' : edl.chuteMach > edl.chuteMaxMach * 0.95 ? 'WARN' : 'PASS';
      add({ id: 'edl-chute', system: T('sys.chute'), role: 'spacecraft', status: st, critical: st === 'FAIL',
        text: T('ev.chute', { mach: F(edl.chuteMach, 2), max: edl.chuteMaxMach }),
        value: round(edl.chuteMach, 2), limit: edl.chuteMaxMach, unit: 'Mach' });
    }
  }
  // İndirme mekanizması taşıma sınırı (gök vinci / platform)
  const lowering = act.find((x) => num(x.item.maxPayloadKg) > 0);
  if (lowering) {
    const target = mission.modules.find((m) => /rover|gezgin/i.test(m.id));
    const kg = target ? moduleMass(mods[target.id]) : 0;
    const over = kg > num(lowering.item.maxPayloadKg);
    add({ id: 'edl-lowering', system: T('sys.lowering'), role: 'spacecraft', status: over ? 'FAIL' : 'PASS', critical: over,
      text: T('ev.lowering', { name: lowering.item.name, kg: F(kg), max: num(lowering.item.maxPayloadKg) }),
      value: round(kg), limit: num(lowering.item.maxPayloadKg), unit: 'kg' });
  }
  if (capItem) {
    const over = instrMassOnCap > num(capItem.item.instrumentCapacityKg);
    add({ id: 'instrument-capacity', system: T('sys.instrCap'), role: 'payload', status: over ? 'FAIL' : 'PASS', critical: over,
      text: T(over ? 'ev.instrCapFail' : 'ev.instrCapOk', { kg: F(instrMassOnCap, 1), max: num(capItem.item.instrumentCapacityKg) }),
      value: round(instrMassOnCap, 1), limit: num(capItem.item.instrumentCapacityKg), unit: 'kg' });
  }

  // Yaşam desteği (insanlı)
  if (lifeSupport) {
    for (const [id, label, d] of [['life-o2', T('life.o2'), lifeSupport.o2Days], ['life-water', T('life.water'), lifeSupport.waterDays], ['life-co2', T('life.co2'), lifeSupport.co2Days]]) {
      const st = d < days ? 'FAIL' : d < days + marginDays ? 'WARN' : 'PASS';
      add({ id, system: T('sys.life', { label }), role: 'spacecraft', status: st, critical: st === 'FAIL',
        text: T(st === 'FAIL' ? 'ev.lifeFail' : st === 'WARN' ? 'ev.lifeWarn' : 'ev.lifeOk', { label, d, days, margin: marginDays }),
        value: d, limit: days + marginDays, unit: T('unit.gün') });
    }
    const cap = installed.find((x) => x.moduleId === crewModule && (num(x.item.crewCapacity) > 0 || num(x.item.maxMissionDays) > 0));
    if (cap) {
      const seats = num(cap.item.crewCapacity);
      const endurance = num(cap.item.maxMissionDays);
      const failSeats = seats > 0 && seats < crew;
      const st = failSeats || (endurance > 0 && endurance < days) ? 'FAIL' : endurance > 0 && endurance < days + marginDays ? 'WARN' : 'PASS';
      add({ id: 'crew-vehicle', system: T('sys.crewVehicle'), role: 'spacecraft', status: st, critical: st === 'FAIL',
        text: T('ev.crewVehicle', { name: cap.item.name, seats: seats || '?', crew, endurance: endurance || '?', days, margin: marginDays }),
        value: endurance, limit: days + marginDays, unit: T('unit.gün') });
    }
    const evaSt = !suit ? 'WARN' : minEva > 0 && evaHours < minEva ? 'FAIL' : 'PASS';
    add({ id: 'eva', system: T('sys.eva'), role: 'payload', status: evaSt,
      text: !suit ? T('ev.evaNone') : T('ev.eva', { h: F(evaHours, 1), min: minEva }),
      value: round(evaHours, 1), limit: minEva || undefined, unit: T('unit.saat') });
    const shield = act.some((x) => x.moduleId === crewModule && (num(obj(x.item.edl).maxHeatFluxWcm2) > 0 || hasWord(x.item, ['heat-shield'])));
    add({ id: 'reentry-shield', system: T('sys.reentry'), role: 'spacecraft', status: shield ? 'PASS' : 'FAIL', critical: !shield,
      text: T(shield ? 'ev.reentryOk' : 'ev.reentryNone') });
  }

  // Bilim
  {
    const st = instruments.length === 0 ? 'FAIL' : scienceValue < scienceTarget ? 'WARN' : 'PASS';
    add({ id: 'science', system: T('sys.science'), role: 'payload', status: st,
      text: st === 'FAIL' ? T('ev.scienceNone')
        : T('ev.science', { v: F(scienceValue, 1), max: F(scienceMax, 1), target: F(scienceTarget, 1) }),
      value: round(scienceValue, 1), limit: round(scienceTarget, 1), unit: T('unit.puan') });
  }

  // --- 8b. Bilim hedefleri (opsiyonel; etiket + güç/ısı/iletişim/öncelik etkileşimi) -----------
  const tagNames = obj(mission.scienceTags);
  const activeTags = new Set();
  for (const x of act) for (const t of tagSet(x.item)) activeTags.add(t);
  const scienceGoals = arr(mission.scienceGoals).filter((g) => g && g.id).map((g) => {
    const req = arr(g.requiresTags).map(String);
    const missingTags = req.filter((t) => !activeTags.has(t));
    const providers = act.filter((x) => x.role === 'payload' && arr(x.item.provides).some((t) => req.includes(t)));
    const limitedBy = [];
    if (providers.length) {
      if (providers.some((x) => outIds.has(x.uid))) limitedBy.push('thermal');
      if (pb.deficit) limitedBy.push('power');
      if (commsRatio < 0.5 && providers.some((x) => num(x.item.dataGenMbPerSol) > 0)) limitedBy.push('comms');
    }
    if (priority === 'explore') limitedBy.push('priority');
    const status = req.length && missingTags.length === req.length ? 'missing' : missingTags.length || limitedBy.length ? 'partial' : 'ready';
    const missingNames = missingTags.map((t) => tagNames[t] || t);
    const note = status === 'ready' ? T('goal.ready')
      : [missingNames.length ? T('goal.missing', { list: missingNames.join(', ') }) : '', limitedBy.length ? T('goal.limited', { list: limitedBy.map((k) => T(`limit.${k}`)).join(', ') }) : ''].filter(Boolean).join('. ') + '.';
    return { id: g.id, name: g.name || g.id, desc: g.desc || '', value: num(g.value), status, missingTags, missingNames, limitedBy,
      providers: [...new Set(providers.map((x) => x.item.id))], note };
  });

  // --- 9. Genel durum, ihtiyaçlar, telemetri ------------------------------------------------
  for (const r of readiness) r.kind = kindOf(r);
  const launchStatus = launchStatusOf(readiness);
  // Durum açıklaması (Türkçe): READY garanti değildir, kalan risk parça güvenilirliğinden gelir
  const LAUNCH_NOTE = {
    READY: 'Hazır: tasarım tüm kurallara uyuyor. Kalan risk parça güvenilirliğinden gelir; yedeksiz bir parça arızası yine de görevi bitirebilir (düşük olasılık).',
    RISKY: 'Riskli: dar marj veya eksik koruma var; simülasyonda arıza olasılığı artar.',
    MISSING: 'Eksik: zorunlu bir sistem takılı değil; ilgili aşamada hasar ya da kayıp olasılığı yüksek.',
    INSUFFICIENT: 'Fiziksel yetersiz: itki, yakıt, kütle veya alan sınırı aşılıyor; ilgili aşama kesin başarısız olur.',
  };
  const overall = readiness.some((r) => r.status === 'FAIL' && r.critical) ? 'FAIL'
    : readiness.some((r) => r.status !== 'PASS') ? 'WARN' : 'PASS';

  const lp = firstLanding >= 0 ? phases[firstLanding] : null;
  const lpFrom = lp ? phaseInfo[lp.id].dvFrom : null;
  const landingThrust = lp ? act.filter((x) => num(x.item.thrustN) > 0 && (x.moduleId === lpFrom || isLandingEngine(x.item)))
    .reduce((a, x) => a + num(x.item.thrustN), 0) : 0;
  const instrPowerW = instruments.reduce((a, x) => a + num(x.item.powerW) * (x.item.dutyCycle === undefined ? 1 : num(x.item.dutyCycle, 1)), 0) * iMode.power * pMode.use;
  const needs = {
    rocket: [
      { id: 'upper-mass-spacecraft', label: T('need.upperMassSpacecraft'), value: round(massByRole.spacecraft), unit: 'kg', fromRole: 'spacecraft' },
      { id: 'upper-mass-payload', label: T('need.upperMassPayload'), value: round(massByRole.payload), unit: 'kg', fromRole: 'payload' },
    ],
    spacecraft: [
      { id: 'payload-power', label: T('need.payloadPower'), value: round(instrPowerW, 1), unit: 'W', fromRole: 'payload' },
      { id: 'payload-data', label: T('need.payloadData'), value: round(dataMb, 1), unit: T('unit.mbDay'), fromRole: 'payload' },
    ],
    payload: [
      { id: 'available-power', label: T('need.availablePower'), value: round(pb.genW - pb.useOther, 1), unit: 'W', fromRole: 'spacecraft' },
      { id: 'downlink-capacity', label: T('need.downlink'), value: round(downlinkMb, 1), unit: T('unit.mbDay'), fromRole: 'spacecraft' },
    ],
  };
  if (lp) needs.spacecraft.push({ id: 'landing-thrust', label: T('need.landingThrust'), value: round(landingThrust), unit: 'N', fromRole: 'rocket' });

  const byModule = {};
  for (const [k, v] of Object.entries(massByModule)) byModule[k] = round(v);
  const telemetry = {
    massKg: { total: round(totalMass), byModule, byRole: { rocket: round(massByRole.rocket), spacecraft: round(massByRole.spacecraft), payload: round(massByRole.payload) }, launch: round(launchKg) },
    cost: round(cost, 2), budget,
    twr: round(launchTwr, 2),
    stages: Object.entries(stagesDv).map(([id, dvMs]) => ({ id, dvMs })),
    dv,
    power: { genW: round(pb.genW, 1), useW: round(pb.useW, 1), batteryWh: round(pb.batteryWh), marginW: round(pb.marginW, 1),
      buses: busIds.map((id) => ({ id, genW: round(buses[id].genW, 1), useW: round(buses[id].useW, 1), batteryWh: round(buses[id].batteryWh), marginW: round(buses[id].marginW, 1) })) },
    thermal: { status: thermalIssue ? 'WARN' : 'PASS', label: T(thermalIssue ? 'thermal.warnLabel' : 'thermal.okLabel'), note: T(thermalIssue ? 'thermal.warnNote' : 'thermal.okNote') },
    comms: { relayBps: round(relayBps), directBps: round(directBps), delayS: round(delayS, 1), dataMbPerSol: round(dataMb, 1), downlinkMbPerSol: round(downlinkMb, 1) },
    lifeSupport,
    edl: hasAtmosphere && edl ? { entryMs: round(edl.entryMs), peakHeatWcm2: round(edl.peakHeat, 1), shieldMaxWcm2: edl.shieldMax,
      chuteMach: round(edl.chuteMach, 2), landingVms: round(landingVms, 2), hazard: round(hazard, 3) } : null,
    science: { value: round(scienceValue, 1), max: round(scienceMax, 1), instruments: instruments.length },
    // İsteğe bağlı ekler (PLAN dışı, geriye uyumlu)
    landing: lp ? { vms: round(landingVms, 2), maxVms: landingMax, hazard: round(hazard, 3), sensor: !!sensorItem } : null,
    propellant: { loadedKg: round(propellantTotal), remainingKg: round(remainingProp), load },
    eva: crew > 0 ? { hours: round(evaHours, 1), min: minEva } : null,
    model: T('model.label'),
    // Aşama 8
    capacity,
    scienceGoals,
    budget: { budget, spent: round(cost, 2), remaining: round(budget - cost, 2), byRole: costByRole },
  };

  const evaluation = { telemetry, readiness, overall, launchStatus, launchNote: T(`launch.${launchStatus}`), needs, unmetRequirements: unmet };
  const internal = {
    mission, kinds, phaseInfo, installed, act, hazard, scienceValue, scienceMax, scienceTarget, commsRatio, powerRatio,
    crew, marginDays, sensor: !!sensorItem, navOk, settings: S, budget, cost, remainingProp, propellantTotal,
    ascentRisk, priority, scienceGoals,
  };
  return { evaluation, internal };
}

module.exports = { evaluateInternal, kindsFor, launchIndex, resolveSettings, kindOf, launchStatusOf, DEFAULT_MODES, OPTION_DEFAULTS, DEF, ROLE_TR, ENGINEERS };
