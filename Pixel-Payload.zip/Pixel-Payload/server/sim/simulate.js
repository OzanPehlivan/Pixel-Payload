'use strict';
// simulate(): görev aşamalarını sırayla oynatır — BASİTLEŞTİRİLMİŞ EĞİTSEL MODEL.
// Rastgelelik yalnız parça güvenilirliği ve dar marjlardan gelir; tohumlu PRNG (mulberry32) ile deterministiktir.

const { num, arr, clamp, round, mulberry32, seedToInt, hasWord, obj } = require('./util');
const { msg } = require('./i18n');

// Varsayılan risk katsayıları (oyun değeri; görev `limits` ile ezilebilir)
const RISK = {
  reliabilityScale: 0.5, // 1−Π(güvenilirlik) bu oranla ölçeklenir
  warnRisk: 0.04,        // aşamaya bağlı WARN kalemi başına ek anomali olasılığı
  failRisk: 0.12,        // kritik olmayan FAIL başına
  severeShare: 0.35,     // yedeksiz anomalinin kritik olma payı
  crewRisk: 0.08,        // yaşam desteği uyarısı başına mürettebat riski (yedek gün azaltır)
};

// Hazırlık kalemi → tercih edilen aşama türleri
const ITEM_KIND = [
  [/^mass-launch$|^fuel$|^mass-dv$|^capacity-/, ['launch']],
  [/^power-night$/, ['surface', 'science']],
  [/^mass-lander$|^landing|^edl-lowering$/, ['landing']],
  [/^edl-|^reentry-shield$/, ['entry']],
  [/^(eva|power-eva|instrument-capacity)$/, ['surface', 'science']],
  [/^(science|power-science|thermal-science|comms-science)$/, ['science', 'surface']],
  [/^(comms-|power-comms)/, ['comms', 'surface', 'cruise']],
  [/^(life-|power-life|crew-vehicle)/, ['cruise']],
  [/^power$|^thermal-battery$/, ['surface', 'science']],
  [/^power-|^thermal$|^nav$/, ['cruise']],
];

// Herkese gösterilen olay metinleri (SAYISIZ)
const EVENT_TEXT = {
  twr: 'Motor itkisi aracı kaldırmaya yetmedi.',
  'mass-launch': 'Araç fırlatma aracının taşıma sınırını aştı.',
  'mass-lander': 'İniş aracı taşıyabileceğinden ağır.',
  dv: 'Yakıt bitti; gereken hız değişimi sağlanamadı.',
  fuel: 'Yakıt marjı dar; ekip motor ateşlemelerini kısaltmak zorunda kaldı.',
  'edl-shield': 'Isı kalkanı giriş ısısında zorlandı.',
  'edl-mass': 'Giriş kütlesi kalkanın sınırında.',
  'edl-chute': 'Süpersonik paraşüt sınırında açıldı.',
  'edl-aeroshell': 'Aerodinamik kabuk olmadan atmosferde yavaşlanamadı.',
  'edl-lowering': 'İndirme mekanizması gezgin ağırlığını taşıyamadı.',
  'reentry-shield': 'Dönüş kapsülünün ısı kalkanı yetersiz kaldı.',
  landing: 'İniş motorları aracı yeterince yavaşlatamadı; sert temas.',
  'landing-sensor': 'İniş sensörü olmadan engellerden kaçınmak zorlaştı.',
  power: 'Güç sistemi ihtiyacı karşılamakta zorlandı.',
  thermal: 'Isı kontrolü sınırda; bazı sistemler zorlandı.',
  'comms-link': 'Dünya ile veri bağlantısı kurulamadı.',
  'comms-capacity': 'Veri iletimi yavaş; veriler birikti.',
  nav: 'Navigasyon belirsizliği yörünge düzeltmesini zorlaştırdı.',
  life: 'Yaşam desteği kaynakları sınırda.',
  'crew-vehicle': 'Mürettebat aracının dayanımı sınırda.',
  eva: 'Yüzey yürüyüşü EVA ekipmanı yetersizliği yüzünden kısaldı.',
  science: 'Bilim operasyonu beklenenden zayıf kaldı.',
  'instrument-capacity': 'Aletler şasiye sığmadı.',
  cat: 'Zorunlu bir alt sistem eksik.',
  req: 'Bir parça gereksinimi karşılanmadığı için çalışmadı.',
  mass: 'Fazla kütle itki marjını eritti.',
  capacity: 'Parçalar modüle sığmadı; araç entegre edilemedi.',
  'power-night': 'Mars gecesinde batarya yetmedi; sistemler kısıldı.',
};
// Eksik olduğunda mürettebat için yaşamsal sayılan sistemler (Ay'da ölümcül olabilir)
const VITAL_RX = /eclss|oxygen|water|capsule|abort|crew-access|emergency|life|reentry|thermal/;
const MISSING_FAIL = { vital: 0.6, other: 0.3 }; // eksik sistemin aşamayı bitirme olasılığı (oyun değeri)
const MISSING_DAMAGE = 0.15;                     // eksik sistem hasarının bilim kaybı payı

function eventText(item, lang) {
  const id = String(item.id);
  if (item.cascadeFrom && item.cascadeFrom.length) return item.text; // zincir metinleri zaten sayısız
  if (EVENT_TEXT[id]) return msg(lang, `evt.${id}`);
  const pre = Object.keys(EVENT_TEXT).filter((k) => id.startsWith(`${k}-`)).sort((a, b) => b.length - a.length)[0];
  return pre ? msg(lang, `evt.${pre}`) : msg(lang, 'evt.generic', { system: item.system });
}

// Her hazırlık kalemini tek bir aşamaya atar (indeks; -2 = aşamasız).
function assignItems(mission, evaluation, internal) {
  const phases = mission.phases;
  const kinds = internal.kinds;
  const findKind = (k) => kinds.findIndex((ks) => ks.has(k));
  const map = new Map();
  evaluation.readiness.forEach((r, idx) => {
    const id = String(r.id);
    let pi = -1;
    if (id === 'budget' || id.startsWith('invalid-')) return;
    if (id.startsWith('dv-') || id.startsWith('twr-')) pi = phases.findIndex((p) => id === `dv-${p.id}` || id === `twr-${p.id}`);
    if (id === 'twr') pi = findKind('launch');
    if (pi < 0 && id === 'mass-dv') pi = phases.findIndex((p) => evaluation.readiness.some((x) => x.id === `dv-${p.id}` && x.status !== 'PASS'));
    if (pi < 0) {
      const rule = ITEM_KIND.find(([rx]) => rx.test(id));
      if (rule) for (const k of rule[1]) { pi = findKind(k); if (pi >= 0) break; }
    }
    if (pi < 0) pi = phases.findIndex((p) => arr(p.checks).some((c) => id === c || id.startsWith(`${c}-`)));
    if (pi < 0 && (id.startsWith('cat-') || id.startsWith('req-'))) {
      const it = internal.installed.find((x) => id === `req-${x.item.id}`);
      const mod = it ? it.moduleId : (mission.modules.find((m) => id.startsWith(`cat-${m.id}-`)) || {}).id;
      if (/edl/.test(mod)) pi = findKind('entry');
      else if (/lander/.test(mod)) pi = findKind('landing');
      else if (/rover|surface/.test(mod)) pi = findKind('surface');
      if (pi < 0) pi = phases.findIndex((p) => p.dvFrom === mod);
      if (pi < 0) pi = findKind('launch');
    }
    if (pi < 0) pi = phases.length - 1;
    map.set(idx, pi);
  });
  return map;
}

// Aşamada çalışan parçalar (güvenilirlik zarına girenler)
function involvedItems(internal, p, ks, info) {
  const act = internal.act;
  const list = [];
  if (info.dvFrom && num(info.dvRequired) > 0) {
    for (const x of act) if (x.moduleId === info.dvFrom && num(x.item.thrustN) > 0 && (!num(p.stage) || num(x.item.stage || 1) === num(p.stage))) list.push(x);
  }
  if (ks.has('entry')) for (const x of act) if (num(obj(x.item.edl).maxHeatFluxWcm2) > 0 || num(obj(x.item.edl).maxMach) > 0) list.push(x);
  if (ks.has('landing')) for (const x of act) if (x.role !== 'payload' && hasWord(x.item, ['radar', 'hazard', 'lidar', 'terrain', 'landing-gear', 'lowering'])) list.push(x);
  if (ks.has('science')) for (const x of act) if (x.role === 'payload' && num(x.item.scienceValue) > 0) list.push(x);
  if (ks.has('comms')) for (const x of act) if (x.role !== 'rocket' && num(x.item.dataRateBps) > 0) list.push(x);
  if (ks.has('surface') && !ks.has('science')) for (const x of act) if (num(x.item.powerGenW) > 0 || num(x.item.batteryWh) > 0) list.push(x);
  return [...new Set(list)];
}

function simulate(ctx, evaluateInternal, missionId, build, settings, seed, lang = 'tr') {
  const T = (k, p) => msg(lang, k, p);
  const res = evaluateInternal(ctx, missionId, build, settings, lang);
  if (!res) return { ok: false, error: 'INVALID_MISSION', phases: [], outcome: 'failure', reason: T('sim.unknownMission'), objectives: [] };
  const { evaluation, internal } = res;
  const mission = internal.mission;
  const L = mission.limits;
  const risk = (k) => num(L[k], RISK[k]);
  const rng = mulberry32(seedToInt(seed));
  // Aşama 8 zarları ayrı akıştan: ana akış (güvenilirlik/marj/arazi) eski sürümle aynı kalır
  const rng2 = mulberry32((seedToInt(seed) ^ 0x5bd1e995) >>> 0);
  const lostIds = new Set();
  let commsDown = false;
  const map = assignItems(mission, evaluation, internal);
  const kinds = internal.kinds;
  const isMars = /mars/i.test(mission.body || mission.id);
  const crewed = internal.crew > 0;
  const lifeWarns = evaluation.readiness.filter((r) => /^(life-|power-life|crew-vehicle)/.test(r.id) && r.status !== 'PASS').length;
  const crewRisk = risk('crewRisk') / (1 + num(internal.marginDays) / 3); // yedek gün riski azaltır
  const totalSci = internal.act.filter((x) => x.role === 'payload').reduce((a, x) => a + num(x.item.scienceValue), 0);

  const out = [];
  const whys = [];
  let failedAt = -1;
  let scienceLoss = 0;
  let crewSafe = true;

  for (let i = 0; i < mission.phases.length; i++) {
    const p = mission.phases[i];
    const ks = kinds[i];
    const info = internal.phaseInfo[p.id] || {};
    const events = [];
    let status = 'ok';
    let failReason = null;
    const ev = (severity, text, roles) => events.push({ id: `${p.id}-${events.length + 1}`, severity, text, roles: [...new Set(roles)] });
    const failWith = (text, roles) => { status = 'fail'; failReason = failReason || text; ev('critical', text, roles); };
    const warnWith = (text, roles) => { if (status === 'ok') status = 'warn'; ev('warn', text, roles); };

    // 1) Bu aşamaya bağlı hazırlık kalemleri: kritik FAIL kesin başarısızlık, diğerleri risk
    let marginRisk = 0;
    const roleSet = new Set();
    const missingCrit = [];
    const riskMul = ks.has('launch') ? num(internal.ascentRisk, 1) : 1; // kalkış profili
    evaluation.readiness.forEach((r, idx) => {
      if (map.get(idx) !== i || r.status === 'PASS' || r.kind === 'budget') return;
      const roles = [r.role].concat(arr(r.cascadeFrom)).filter((x) => x && x !== 'director');
      // Türe göre kademeli: fiziksel yetersizlik kesin başarısızlık; eksik koruma/destek olasılıklı hasar
      if (r.status === 'FAIL' && r.critical && r.kind === 'missing') missingCrit.push([r, roles]);
      else if (r.status === 'FAIL' && r.critical) failWith(eventText(r, lang), roles);
      else {
        marginRisk += r.status === 'FAIL' ? risk('failRisk') : risk('warnRisk');
        roles.forEach((x) => roleSet.add(x));
        warnWith(eventText(r, lang), roles);
      }
    });

    for (const [r, roles] of missingCrit) {
      const roll = rng2();
      if (status === 'fail') continue;
      if (r.id === 'comms-link') { commsDown = true; warnWith(eventText(r, lang), roles); continue; }
      const vital = crewed && VITAL_RX.test(String(r.id));
      if (roll < (vital ? MISSING_FAIL.vital : MISSING_FAIL.other)) {
        failWith(`${eventText(r, lang)} ${T(vital ? 'sim.vitalFail' : 'sim.otherFail')}`, roles);
      } else {
        scienceLoss += MISSING_DAMAGE;
        warnWith(`${eventText(r, lang)} ${T(vital ? 'sim.vitalOk' : 'sim.otherOk')}`, roles);
      }
    }

    // 2) Parça güvenilirliği (rng çağrı sayısı her aşamada sabit → determinizm kolay izlenir)
    const r1 = rng(), r2 = rng(), r3 = rng(), r4 = rng(), r5 = rng(), r6 = rng();
    if (status !== 'fail') {
      const involved = involvedItems(internal, p, ks, info);
      const prod = involved.reduce((a, x) => a * clamp(x.item.reliability === undefined ? 1 : num(x.item.reliability, 1), 0, 1), 1);
      if (involved.length && r1 < (1 - prod) * risk('reliabilityScale') * riskMul) {
        const victim = involved[Math.floor(r2 * involved.length)];
        const redundant = internal.act.some((x) => x !== victim && x.item.category === victim.item.category);
        const isInstrument = victim.role === 'payload';
        if (isInstrument) { scienceLoss += totalSci > 0 ? num(victim.item.scienceValue) / totalSci : 0; lostIds.add(victim.item.id); }
        if (!redundant && !isInstrument && r3 < risk('severeShare')) failWith(T('sim.partFail', { name: victim.item.name }), [victim.role]);
        else warnWith(T('sim.partWarn', { name: victim.item.name, redundant, instrument: isInstrument }), [victim.role]);
      }
    }
    // 3) Dar marjlar
    marginRisk *= riskMul;
    if (status !== 'fail' && marginRisk > 0) {
      if (r4 < marginRisk * 0.25) failWith(T('sim.marginFail'), [...roleSet]);
      else if (r4 < marginRisk) ev('warn', T('sim.marginWarn'), [...roleSet]);
    }
    // 4) Arazi tehlikesi (ilk iniş aşaması)
    if (status !== 'fail' && ks.has('landing') && i === kinds.findIndex((k) => k.has('landing'))) {
      const hz = num(internal.hazard);
      if (r5 < hz * 0.4) failWith(T('sim.terrainFail'), ['rocket', 'spacecraft']);
      else if (r5 < hz) warnWith(T('sim.terrainWarn'), ['rocket', 'spacecraft']);
    }
    // 5) Mürettebat güvenliği (yaşam desteği uyarıları)
    if (status !== 'fail' && crewed && lifeWarns > 0 && (ks.has('surface') || ks.has('cruise'))) {
      if (r6 < crewRisk * lifeWarns * 0.25) { crewSafe = false; failWith(T('sim.lifeFail'), ['spacecraft']); }
      else if (r6 < crewRisk * lifeWarns) warnWith(T('sim.lifeWarn'), ['spacecraft']);
    }

    if (!events.length) ev('info', T('sim.phaseOk'), []);
    const note = status === 'ok' ? T('sim.noteOk') : status === 'warn' ? T('sim.noteWarn') : T('sim.noteFail', { why: failReason });
    out.push({ id: p.id, name: p.name || p.id, status, events, note });
    whys.push(failReason);
    if (status === 'fail') {
      failedAt = i;
      if (crewed) crewSafe = false; // insanlı görevde kritik arıza = mürettebat güvenliği bozuldu
      break;
    }
  }

  // Aşama durum özetleri
  const reachedOk = (pred) => {
    const idx = kinds.map((k, i) => (pred(k, i) ? i : -1)).filter((i) => i >= 0);
    if (!idx.length) return null;
    return idx.every((i) => out[i] && out[i].status !== 'fail');
  };
  const landingOk = reachedOk((k) => k.has('landing'));
  const sciencePhaseOk = reachedOk((k) => k.has('science') || k.has('surface'));
  let commsPhaseOk = reachedOk((k) => k.has('comms'));
  if (commsDown && commsPhaseOk !== null) commsPhaseOk = false; // bağlantı yok: veri Dünya'ya ulaşmaz

  // Bilim çıktısı
  const rf = 0.9 + rng() * 0.2;
  let achieved = internal.scienceValue * (1 - clamp(scienceLoss, 0, 1)) * rf;
  if (sciencePhaseOk === false || (sciencePhaseOk === null && failedAt >= 0)) achieved = 0;
  if (commsPhaseOk === false) achieved *= 0.3; // veri Dünya'ya ulaşmadı
  const scienceScore = round(100 * clamp(achieved / (internal.scienceMax || 1), 0, 1));
  const scienceDone = achieved > 0 && achieved >= internal.scienceTarget;

  const st = { mission, out, failedAt, landingOk, scienceDone, commsPhaseOk, sciencePhaseOk, crewSafe, evaluation };
  const objectives = mission.objectives.map((o) => ({ id: o.id, name: o.name || o.id, done: objectiveDone(o, st) }));

  let outcome, reason;
  if (failedAt >= 0) {
    const ph = out[failedAt];
    const why = whys[failedAt];
    if (isMars && landingOk) { outcome = 'partial'; reason = T('out.partialLanded', { phase: ph.name, why }); }
    else { outcome = 'failure'; reason = T('out.lost', { phase: ph.name, why }); }
  } else if (crewed && !crewSafe) {
    outcome = 'failure'; reason = T('out.crewUnsafe');
  } else {
    const missedCritical = objectives.filter((o, k) => !o.done && mission.objectives[k].critical);
    const missed = objectives.filter((o) => !o.done);
    if (missedCritical.length) { outcome = crewed ? 'failure' : 'partial'; reason = T('out.critMissed', { list: missedCritical.map((o) => o.name).join(', ') }); }
    else if (isMars && !scienceDone) { outcome = 'partial'; reason = T('out.lowScience'); }
    else if (missed.length) { outcome = 'partial'; reason = T('out.someMissed', { list: missed.map((o) => o.name).join(', ') }); }
    else { outcome = 'success'; reason = T(crewed ? 'out.successCrew' : 'out.success'); }
  }

  const scienceGoals = goalResults(internal, { failedAt, sciencePhaseOk, commsPhaseOk, crewed, lostIds }, T);
  const result = { phases: out, outcome, reason, objectives, scienceGoals, seed: seedToInt(seed), model: T('model.label') };
  if (landingOk !== null) result.landing = { ok: !!landingOk };
  result.science = { score: scienceScore, done: scienceDone };
  return result;
}

// Bilim hedefleri: hazırlıktaki durum + simülasyonda olanlar (alet arızası, aşama kaybı, veri iletimi).
const LIMIT_REASON = { power: 1, thermal: 1, comms: 1 };
function goalResults(internal, s, T) {
  const act = internal.act;
  return arr(internal.scienceGoals).map((g) => {
    let done = false, reason;
    const lost = arr(g.providers).some((id) => s.lostIds.has(id));
    const dataGoal = act.some((x) => arr(g.providers).includes(x.item.id) && num(x.item.dataGenMbPerSol) > 0);
    const limits = arr(g.limitedBy).filter((k) => k !== 'priority');
    if (arr(g.missingTags).length) reason = T('gr.missing', { list: arr(g.missingNames).join(', ') });
    else if (arr(g.limitedBy).includes('priority')) reason = T('gr.priority');
    else if (limits.length) reason = T('gr.limited', { list: limits.map((k) => (LIMIT_REASON[k] ? T(`glimit.${k}`) : k)).join(', ') });
    else if (s.sciencePhaseOk === false || (s.sciencePhaseOk === null && s.failedAt >= 0)) reason = T('gr.noScience');
    else if (s.crewed && s.failedAt >= 0) reason = T('gr.noReturn');
    else if (lost && internal.priority !== 'goals') reason = T('gr.lost');
    else if (dataGoal && s.commsPhaseOk === false) reason = T('gr.noData');
    else { done = true; reason = T(lost ? 'gr.backup' : 'gr.done'); }
    return { id: g.id, name: g.name, done, reason };
  });
}

// Hedef tamamlandı mı? Öncelik: o.phase → aynı id'li aşama → anahtar kelime.
function objectiveDone(o, s) {
  const { mission, out, failedAt, landingOk, scienceDone, commsPhaseOk, sciencePhaseOk, crewSafe, evaluation } = s;
  const all = failedAt < 0;
  const phaseOk = (id) => { const ph = out.find((x) => x.id === id); return !!ph && ph.status !== 'fail'; };
  if (o.phase) return phaseOk(o.phase);
  const text = `${o.id} ${o.metric || ''}`.toLowerCase();
  if (/crew|murettebat/.test(text)) return all && crewSafe;
  if (/data|veri/.test(text)) return scienceDone && commsPhaseOk === true;
  if (/science|bilim|sample/.test(text)) return scienceDone;
  if (/eva/.test(text)) {
    const eva = evaluation.readiness.find((r) => r.id === 'eva');
    return sciencePhaseOk === true && (!eva || eva.status === 'PASS');
  }
  if (mission.phases.some((p) => p.id === o.id)) return phaseOk(o.id);
  if (/comm|iletisim/.test(text)) return commsPhaseOk === true;
  if (/land|inis/.test(text)) return !!landingOk;
  if (/lunar-orbit|loi/.test(text)) return phaseOk(mission.phases.find((p) => /loi/.test(p.id)) ? mission.phases.find((p) => /loi/.test(p.id)).id : '');
  if (/orbit|launch|kalkis/.test(text)) { const li = s.mission.phases.findIndex((p) => num(p.dvMs) > 0); return li >= 0 && phaseOk(mission.phases[li].id); }
  return all;
}

module.exports = { simulate, RISK };
