'use strict';
// Simülasyon modülü için küçük, saf yardımcılar.

// Sonlu sayı değilse varsayılanı döndürür (eksik alan = 0).
function num(x, d = 0) {
  return typeof x === 'number' && Number.isFinite(x) ? x : d;
}

function arr(x) {
  return Array.isArray(x) ? x : [];
}

function obj(x) {
  return x && typeof x === 'object' && !Array.isArray(x) ? x : {};
}

function clamp(x, lo, hi) {
  return Math.min(hi, Math.max(lo, x));
}

function round(x, digits = 0) {
  const f = Math.pow(10, digits);
  return Math.round(num(x) * f) / f;
}

// Veri değeri: `{ v, unit, src, class }` ya da düz sayı.
function val(x, d) {
  if (x && typeof x === 'object' && 'v' in x) return num(x.v, d);
  return num(x, d);
}

// Nokta yollu değer okuma: get(constants, 'mars.atmosphere.scaleHeightM', 11000)
function get(root, path, d) {
  let cur = root;
  for (const k of String(path).split('.')) {
    if (!cur || typeof cur !== 'object') return d;
    cur = cur[k];
  }
  return val(cur, d);
}

function clone(x) {
  return x === undefined ? undefined : JSON.parse(JSON.stringify(x));
}

// Tohumlu PRNG (mulberry32). Aynı tohum → aynı dizi.
function mulberry32(seed) {
  let a = seed >>> 0;
  return function next() {
    a = (a + 0x6D2B79F5) >>> 0;
    let t = a;
    t = Math.imul(t ^ (t >>> 15), t | 1);
    t ^= t + Math.imul(t ^ (t >>> 7), t | 61);
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
  };
}

// Herhangi bir tohumu (sayı/metin) 32 bit tamsayıya çevirir (FNV-1a).
function seedToInt(seed) {
  if (typeof seed === 'number' && Number.isFinite(seed)) return (Math.floor(seed) >>> 0);
  const s = String(seed === undefined || seed === null ? 'pixel-payload' : seed);
  let h = 0x811c9dc5;
  for (let i = 0; i < s.length; i++) {
    h ^= s.charCodeAt(i);
    h = Math.imul(h, 0x01000193) >>> 0;
  }
  return h >>> 0;
}

// Bir parçanın "etiket kümesi": tags + provides + id + category (uyumluluk/gereksinim eşleşmesi için).
function tagSet(item) {
  const s = new Set();
  if (!item) return s;
  for (const t of arr(item.tags)) s.add(String(t));
  for (const t of arr(item.provides)) s.add(String(t));
  if (item.id) s.add(String(item.id));
  if (item.category) s.add(String(item.category));
  return s;
}

// Etiket/kategori/id içinde anahtar kelimelerden biri geçiyor mu?
function hasWord(item, words) {
  for (const t of tagSet(item)) {
    const low = t.toLowerCase();
    if (words.some((w) => low.includes(w))) return true;
  }
  return false;
}

// Sayıyı dile göre yazar. tr (varsayılan): fmt(4147) → "4.147", fmt(1.25, 2) → "1,25"; en: "4,147", "1.25"
function fmt(x, digits = 0, lang = 'tr') {
  const n = num(x);
  const loc = lang === 'en' ? 'en-US' : 'tr-TR';
  try { return n.toLocaleString(loc, { maximumFractionDigits: digits, minimumFractionDigits: 0 }); } catch (_) { return String(round(n, digits)); }
}

module.exports = { fmt, num, arr, obj, clamp, round, val, get, clone, mulberry32, seedToInt, tagSet, hasWord };
