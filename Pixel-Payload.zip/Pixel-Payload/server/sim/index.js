'use strict';
// Simülasyon modülü giriş noktası — saf, durumsuz, sunucu yetkili.
// createSim({ dataDir }) ya da createSim({ equipment, missions, constants, sources }).
// Tüm modeller BASİTLEŞTİRİLMİŞ EĞİTSEL MODEL'dir; gerçek uçuş modeli değildir.
// Hiçbir yöntem istisna atmaz: geçersiz girdi hata kodu döner.

const path = require('path');
const { loadFromDir, normalizeData, loadOverlays, localizeData } = require('./loader');
const { msg, normLang, langOf } = require('./i18n');
const { evaluateInternal } = require('./evaluate');
const { simulate } = require('./simulate');
const { debrief } = require('./debrief');
const { arr, clone, num, tagSet } = require('./util');
const physics = require('./physics');

const ENGINEERS = ['rocket', 'spacecraft', 'payload'];
const PUBLIC_KEYS = ['id', 'name', 'category', 'role', 'module', 'icon', 'desc'];

// opts.i18n (isteğe bağlı, sabit veriyle): { en: { items: {..}, missions: { <missionId>: ov }, sources: {..} } }
// dataDir ile: data/i18n/en/* otomatik yüklenir. Dil verilmezse 'tr' (geri uyum).
function createSim(opts = {}) {
  const fixed = !!(opts.equipment || opts.missions);
  const dataDir = opts.dataDir || path.join(__dirname, '..', '..', 'data');
  const rawTr = fixed ? normalizeData(opts) : loadFromDir(dataDir);
  const overlays = opts.i18n || (fixed ? {} : loadOverlays(dataDir));
  const makeCtx = (raw) => ({
    raw,
    itemList: raw.items,
    items: new Map(raw.items.map((i) => [i.id, i])),
    missions: new Map(raw.missions.map((m) => [m.id, m])),
    constants: raw.constants,
    sources: raw.sources,
  });
  const ctxs = { tr: makeCtx(rawTr) };
  // Dil bağlamı: aynı sayılar, metin alanları bindirmeli (ilk istekte hazırlanır)
  const ctxFor = (lang) => {
    const l = normLang(lang);
    if (!ctxs[l]) ctxs[l] = makeCtx(localizeData(rawTr, overlays, l));
    return ctxs[l];
  };
  const raw = rawTr;
  const ctx = ctxs.tr;
  const inMission = (it, missionId) => !Array.isArray(it.missions) || it.missions.includes(missionId);
  const safe = (fn, fallback) => (...a) => { try { return fn(...a); } catch (_) { return typeof fallback === 'function' ? fallback(...a) : fallback; } };

  function listMissions(lang) {
    return ctxFor(langOf(lang)).raw.missions.map((m) => ({ id: m.id, name: m.name, summary: m.summary, educationalNote: m.educationalNote }));
  }
  function getMission(id, lang) {
    const m = ctxFor(langOf(lang)).missions.get(id);
    return m ? clone(m) : undefined;
  }
  function getItem(id, lang) {
    const it = ctxFor(langOf(lang)).items.get(id);
    return it ? clone(it) : undefined;
  }
  function catalogFor(missionId, role, lang) {
    const c = ctxFor(langOf(lang));
    if (!c.missions.has(missionId)) return [];
    return c.itemList.filter((it) => it.role === role && inMission(it, missionId)).map(clone);
  }
  function publicItem(itemId, lang) {
    const it = ctxFor(langOf(lang)).items.get(itemId);
    if (!it) return null;
    const o = {};
    for (const k of PUBLIC_KEYS) o[k] = it[k] === undefined ? null : it[k];
    return o;
  }

  // Takma kontrolü. `requires` eksikliği engel DEĞİL (hazırlıkta FAIL olur).
  function canAdd(build, missionId, role, itemId, moduleId, lang) {
    const L = langOf(lang);
    const ctx = ctxFor(L);
    const it = ctx.items.get(itemId);
    if (!it) return { ok: false, error: 'INVALID_ITEM', reason: msg(L, 'add.invalidItem') };
    if (!ENGINEERS.includes(role) || it.role !== role) return { ok: false, error: 'NOT_ALLOWED', reason: msg(L, 'add.notAllowed') };
    const mission = ctx.missions.get(missionId);
    if (!mission || !inMission(it, missionId)) return { ok: false, error: 'WRONG_MISSION', reason: msg(L, 'add.wrongMission') };
    const modId = moduleId || it.module;
    const mod = mission.modules.find((m) => m.id === modId);
    const cat = mod && mod.categories.find((c) => c.category === it.category);
    if (!mod || it.module !== modId || !cat) return { ok: false, error: 'WRONG_MODULE', reason: msg(L, 'add.wrongModule') };
    const list = arr(build).filter((b) => b && ctx.items.has(b.itemId));
    const same = list.filter((b) => b.itemId === itemId).length;
    if (same >= Math.max(1, num(it.maxCount, 1))) return { ok: false, error: 'DUPLICATE', reason: msg(L, 'add.duplicate') };
    const inCat = list.filter((b) => (b.moduleId || ctx.items.get(b.itemId).module) === modId && ctx.items.get(b.itemId).category === it.category).length;
    if (cat.max !== undefined && inCat >= num(cat.max)) return { ok: false, error: 'CATEGORY_FULL', reason: msg(L, 'add.categoryFull', { max: cat.max }) };
    // Uyumsuzluk iki yönlü kontrol edilir
    const mine = tagSet(it);
    for (const b of list) {
      const other = ctx.items.get(b.itemId);
      const theirs = tagSet(other);
      const hit = arr(it.incompatibleWith).find((x) => x && theirs.has(x.tag))
        || arr(other.incompatibleWith).find((x) => x && mine.has(x.tag));
      if (hit) return { ok: false, error: 'INCOMPATIBLE', reason: msg(L, 'add.incompatible', { name: other.name, reason: hit.reason || msg(L, 'add.incompatibleDefault') }) };
    }
    // Alan (U): modül kapasitesi sert sınırdır; build'deki standart (auto) parçalar da sayılır.
    const capU = num(mod.capacityU);
    const vol = Math.max(0, num(it.volumeU));
    if (capU > 0 && vol > 0) {
      const used = list.filter((b) => (b.moduleId || ctx.items.get(b.itemId).module) === modId)
        .reduce((a, b) => a + Math.max(0, num(ctx.items.get(b.itemId).volumeU)), 0);
      if (used + vol > capU) return { ok: false, error: 'NO_SPACE', reason: msg(L, 'add.noSpace', { used, cap: capU, vol }) };
    }
    return { ok: true };
  }

  // Standart donanım: `auto: true` işaretli kategorilerin (tek seçenekli) parçaları.
  function autoItems(missionId) {
    const mission = ctx.missions.get(missionId);
    if (!mission) return [];
    const out = [];
    for (const mod of mission.modules) {
      for (const c of mod.categories) {
        if (!c || c.auto !== true) continue;
        const it = raw.items.find((i) => i.module === mod.id && i.category === c.category && inMission(i, missionId));
        if (it) out.push({ itemId: it.id, moduleId: mod.id, role: c.role || it.role });
      }
    }
    return out;
  }

  function defaultSettings(missionId) {
    const m = ctx.missions.get(missionId);
    const out = {};
    if (m) for (const s of m.settings) out[s.key] = s.default;
    return out;
  }

  function validateSetting(missionId, role, key, value) {
    const m = ctx.missions.get(missionId);
    const def = m && m.settings.find((s) => s.key === key);
    if (!def || def.role !== role) return { ok: false, error: 'BAD_SETTING' };
    if (def.type === 'number') {
      const v = typeof value === 'string' && value.trim() !== '' ? Number(value) : value;
      if (typeof v !== 'number' || !Number.isFinite(v)) return { ok: false, error: 'BAD_SETTING' };
      const lo = num(def.min, -Infinity), hi = num(def.max, Infinity);
      if (v < lo - 1e-9 || v > hi + 1e-9) return { ok: false, error: 'BAD_SETTING' };
      let out = v;
      if (num(def.step) > 0 && Number.isFinite(lo)) out = lo + Math.round((v - lo) / def.step) * def.step;
      out = Math.min(hi, Math.max(lo, Math.round(out * 1e6) / 1e6));
      return { ok: true, value: out };
    }
    const opts = arr(def.options).map((o) => (o && typeof o === 'object' ? o.value : o));
    if (!opts.includes(value)) return { ok: false, error: 'BAD_SETTING' };
    return { ok: true, value };
  }

  function evaluate(missionId, build, settings, o) {
    const L = langOf(o);
    const r = evaluateInternal(ctxFor(L), missionId, build, settings, L);
    if (!r) return { ok: false, error: 'INVALID_MISSION', telemetry: null, readiness: [], overall: 'FAIL', launchStatus: 'INSUFFICIENT', needs: { rocket: [], spacecraft: [], payload: [] }, unmetRequirements: [] };
    return r.evaluation;
  }

  return {
    listMissions: safe(listMissions, []),
    getMission: safe(getMission, undefined),
    getItem: safe(getItem, undefined),
    catalogFor: safe(catalogFor, []),
    publicItem: safe(publicItem, null),
    autoItems: safe(autoItems, []),
    canAdd: safe(canAdd, (b, m, r, i, mo, l) => ({ ok: false, error: 'INVALID_ITEM', reason: msg(langOf(l), 'add.bad') })),
    defaultSettings: safe(defaultSettings, {}),
    validateSetting: safe(validateSetting, { ok: false, error: 'BAD_SETTING' }),
    evaluate: safe(evaluate, () => ({ ok: false, error: 'EVAL_ERROR', telemetry: null, readiness: [], overall: 'FAIL', launchStatus: 'INSUFFICIENT', needs: { rocket: [], spacecraft: [], payload: [] }, unmetRequirements: [] })),
    simulate: safe((m, b, s, seed, o) => simulate(ctxFor(langOf(o)), evaluateInternal, m, b, s, seed, langOf(o)),
      (m, b, s, seed, o) => ({ ok: false, error: 'SIM_ERROR', phases: [], outcome: 'failure', reason: msg(langOf(o), 'sim.error'), objectives: [], scienceGoals: [] })),
    debrief: safe((m, e, r, t, o) => debrief(ctxFor(langOf(o)), m, e, r, t, langOf(o)),
      () => ({ ok: false, error: 'DEBRIEF_ERROR', score: 0, stars: 0, outcome: 'failure', sectionTotal: 0, adjustments: [], sections: [], lessons: [], nasaReality: '', sources: [], budget: null, scienceGoals: [] })),
    physics,
  };
}

module.exports = { createSim };
