'use strict';
// debrief(): puan (0–1000), 0–3 yıldız, bölümler, dersler, NASA gerçeği, kaynaklar.
// Puanlama bir oyun modelidir (class: game); BASİTLEŞTİRİLMİŞ EĞİTSEL MODEL.

const { num, arr, obj, clamp, round, fmt } = require('./util');
const { msg } = require('./i18n');

// Bölüm ağırlıkları (toplam 1000). Aşama 8: bilim hedefleri bölümü eklendi.
const MAX = { objectives: 225, engineering: 100, fuel: 75, power: 75, comms: 50, science: 100, scienceGoals: 100, budget: 75, events: 50, failed: 50, team: 100 };
const BUDGET_PENALTY = { base: 30, perPct: 6, max: 150 }; // aşım cezası: 30 + %başına 6 puan, en çok 150 (oyun değeri)
const TITLES = {
  objectives: 'Tamamlanan hedefler', engineering: 'Mühendislik performansı', fuel: 'Yakıt verimi', power: 'Güç verimi',
  comms: 'İletişim', science: 'Bilim çıktısı', scienceGoals: 'Bilim hedefleri', budget: 'Bütçe', events: 'Kritik olaylar', failed: 'Karşılanmayan gereksinimler', team: 'Ekip koordinasyonu',
};
const ROLE_TR = { rocket: 'İtki', spacecraft: 'Uzay aracı', payload: 'Bilim & faydalı yük' };

// Tetiklenen kural → ders (mühendislik ödünleşimini açıklar)
const LESSONS = [
  [/^dv-|^fuel$/, 'lesson.dv'],
  [/^twr/, 'lesson.twr'],
  [/^mass-/, 'lesson.mass'],
  [/^power$|^power-[a-z]+-/, 'lesson.power'],
  [/^power-(science|comms|eva|life)$/, 'lesson.powerChain'],
  [/^thermal/, 'lesson.thermal'],
  [/^comms-/, 'lesson.comms'],
  [/^landing/, 'lesson.landing'],
  [/^edl-/, 'lesson.edl'],
  [/^life-|^crew-vehicle$/, 'lesson.life'],
  [/^eva$/, 'lesson.eva'],
  [/^budget$/, 'lesson.budget'],
  [/^capacity-/, 'lesson.capacity'],
  [/^science$|^instrument-capacity$/, 'lesson.science'],
  [/^req-|^cat-/, 'lesson.deps'],
];

function sourcesFor(ctx, mission) {
  const ids = new Set();
  for (const r of Object.values(obj(mission.refs))) if (r && r.src) ids.add(r.src);
  for (const it of ctx.itemList) {
    if (Array.isArray(it.missions) && !it.missions.includes(mission.id)) continue;
    for (const r of Object.values(obj(it.refs))) if (r && r.src) ids.add(r.src);
  }
  const list = ctx.sources.filter((s) => ids.has(s.id) && s.url);
  return (list.length ? list : ctx.sources).map((s) => ({ title: s.title || s.id, url: s.url || '' }));
}

function debrief(ctx, missionId, evaluation, simResult, team, lang = 'tr') {
  const T = (k, p) => msg(lang, k, p);
  const F = (v, d) => fmt(v, d, lang);
  const mission = ctx.missions.get(missionId);
  if (!mission) return { ok: false, error: 'INVALID_MISSION', score: 0, stars: 0, outcome: 'failure', sectionTotal: 0, adjustments: [], sections: [], lessons: [], nasaReality: '', sources: [] };
  const ev = obj(evaluation);
  const sim = obj(simResult);
  const tel = obj(ev.telemetry);
  const readiness = arr(ev.readiness);
  const t = obj(team);
  const outcome = sim.outcome || 'failure';
  const sections = [];
  const sec = (id, ratio, lines) => sections.push({ id, title: T(`sec.${id}`), score: round(MAX[id] * clamp(ratio, 0, 1)), max: MAX[id], lines });

  // Hedefler (kritik hedef 2 kat ağırlık)
  const objs = arr(sim.objectives);
  const defs = new Map(mission.objectives.map((o) => [o.id, o]));
  let w = 0, got = 0;
  for (const o of objs) { const k = defs.get(o.id) && defs.get(o.id).critical ? 2 : 1; w += k; if (o.done) got += k; }
  sec('objectives', w ? got / w : 0, objs.map((o) => T(o.done ? 'db.objDone' : 'db.objMissed', { name: o.name })));

  // Mühendislik: hazırlık PASS oranı
  const graded = readiness.filter((r) => r.id !== 'budget');
  const pass = graded.filter((r) => r.status === 'PASS').length;
  sec('engineering', graded.length ? pass / graded.length : 0, [T('db.readiness', { pass, total: graded.length, overall: ev.overall || '—' })]
    .concat(graded.filter((r) => r.status !== 'PASS').slice(0, 6).map((r) => `${r.status}: ${r.system}`)));

  // Yakıt: Δv marjları (%0 → 0, %10 ve üstü → tam)
  const dvs = Object.entries(obj(tel.dv));
  const marg = dvs.map(([, d]) => (num(d.required) > 0 ? (num(d.available) - num(d.required)) / num(d.required) : 0));
  const fuelRatio = marg.length ? marg.reduce((a, m) => a + (m < 0 ? 0 : clamp(m / 0.1, 0.3, 1)), 0) / marg.length : 0;
  sec('fuel', fuelRatio, dvs.map(([id, d]) => T('db.dv', { id, a: num(d.available), r: num(d.required) }))
    .concat(tel.propellant ? [T('db.fuelLeft', { kg: num(tel.propellant.remainingKg) })] : []));

  // Güç: pozitif ve dar olmayan marj iyi; aşırı büyük marj = gereksiz kütle
  const pw = obj(tel.power);
  const pm = num(pw.useW) > 0 ? num(pw.marginW) / num(pw.useW) : 1;
  const powerRatio = num(pw.marginW) < 0 ? 0.2 : pm < 0.05 ? 0.7 : pm > 1 ? 0.8 : 1;
  sec('power', powerRatio, [T('db.power', { gen: num(pw.genW), use: num(pw.useW), margin: num(pw.marginW) })]
    .concat(arr(pw.buses).length > 1 ? arr(pw.buses).map((b) => T('db.bus', { id: b.id, gen: b.genW, use: b.useW })) : []));

  // İletişim
  const cm = obj(tel.comms);
  const link = num(cm.relayBps) + num(cm.directBps) > 0;
  const cr = num(cm.dataMbPerSol) > 0 ? clamp(num(cm.downlinkMbPerSol) / num(cm.dataMbPerSol), 0, 1) : 1;
  sec('comms', link ? cr : 0, [T('db.comms', { down: num(cm.downlinkMbPerSol), data: num(cm.dataMbPerSol), delay: num(cm.delayS) })]);

  // Bilim: hedefe ulaşmak %70, hedefin ötesindeki genel keşif %30 (en iyi aletlerin %60'ı tam puan)
  const sci = obj(tel.science);
  const target = num(mission.limits.minScience) || num(sci.max) * 0.25;
  const achievedPts = (num(obj(sim.science).score) / 100) * num(sci.max);
  const sciRatio = target > 0 ? 0.7 * clamp(achievedPts / target, 0, 1) + 0.3 * clamp(achievedPts / (0.6 * num(sci.max) || 1), 0, 1) : 0;
  sec('science', sciRatio, [T('db.science', { got: F(achievedPts, 1), target: F(target, 1), n: num(sci.instruments) })]);

  // Bilim hedefleri: tamamlanan hedef değeri / en değerli ikisinin toplamı (üçü birden makul tasarıma sığmaz)
  const goalDefs = arr(mission.scienceGoals).filter((g) => g && g.id);
  const evGoals = new Map(arr(tel.scienceGoals).map((g) => [g.id, g]));
  const simGoals = new Map(arr(sim.scienceGoals).map((g) => [g.id, g]));
  const scienceGoals = goalDefs.map((g) => {
    const sg = obj(simGoals.get(g.id)), eg = obj(evGoals.get(g.id));
    return { id: g.id, name: g.name || g.id, value: num(g.value), status: eg.status || 'missing', done: sg.done === true,
      reason: sg.reason || T(eg.status === 'ready' ? 'db.goalNoSim' : 'db.goalNoGear') };
  });
  if (goalDefs.length) {
    const vals = goalDefs.map((g) => num(g.value)).sort((a, b) => b - a);
    const goalTarget = vals.slice(0, Math.max(1, vals.length - 1)).reduce((a, b) => a + b, 0);
    const goalGot = scienceGoals.filter((g) => g.done).reduce((a, g) => a + g.value, 0);
    sec('scienceGoals', goalTarget > 0 ? goalGot / goalTarget : 0, scienceGoals.map((g) => T(g.done ? 'db.goalDone' : 'db.goalMissed', { name: g.name, reason: g.reason })));
  } else {
    sec('scienceGoals', clamp(num(obj(sim.science).score) / 100, 0, 1), [T('db.noGoals')]);
  }

  // Bütçe: içinde kalmak + tasarruf ödülü (en çok %30 tasarrufa kadar). Aşım: bölüm 0 + ayrı ceza.
  const tb = obj(tel.budget);
  const cost = typeof tb.spent === 'number' ? num(tb.spent) : num(tel.cost);
  const budget = num(tb.budget) || num(tel.budget) || num(mission.budget);
  const overrun = budget > 0 ? Math.max(0, round(cost - budget, 2)) : 0;
  const overrunPct = budget > 0 ? round(overrun / budget, 4) : 0;
  const penalty = overrun > 0 ? Math.min(BUDGET_PENALTY.max, Math.round(BUDGET_PENALTY.base + BUDGET_PENALTY.perPct * overrunPct * 100)) : 0;
  const br = !budget ? 1 : cost > budget ? 0 : 0.6 + 0.4 * clamp((1 - cost / budget) / 0.3, 0, 1);
  sec('budget', br, [T('db.spend', { cost: F(cost, 1), budget: F(budget, 1) })]
    .concat(overrun > 0 ? [T('db.overrun', { pct: F(overrunPct * 100, 1), over: F(overrun, 1), penalty })] : []));

  // Olaylar
  const events = arr(sim.phases).flatMap((p) => arr(p.events).map((e) => Object.assign({ phase: p.name }, e)));
  const warns = events.filter((e) => e.severity === 'warn');
  const crit = events.filter((e) => e.severity === 'critical');
  sec('events', (MAX.events - 8 * warns.length - 30 * crit.length) / MAX.events,
    crit.concat(warns).slice(0, 8).map((e) => T(e.severity === 'critical' ? 'db.evCrit' : 'db.evWarn', { phase: e.phase, text: e.text })));

  // Karşılanmayan gereksinimler
  const unmet = arr(ev.unmetRequirements);
  const softFails = readiness.filter((r) => r.status === 'FAIL' && !r.critical && !String(r.id).startsWith('req-') && r.id !== 'budget' && r.kind !== 'budget');
  const critFails = readiness.filter((r) => r.status === 'FAIL' && r.critical);
  sec('failed', (MAX.failed - 15 * (unmet.length + softFails.length) - 25 * critFails.length) / MAX.failed,
    unmet.map((u) => u.text).concat(softFails.concat(critFails).map((r) => `${r.system}: ${r.text}`)).slice(0, 8));

  // Ekip koordinasyonu: operatörle mesajlaşma, inceleme turları, onaylar, tasarım süresi
  const chat = obj(t.chat);
  let teamPts = 0;
  const teamLines = [];
  for (const r of ['rocket', 'spacecraft', 'payload']) {
    const n = num(chat[r]);
    teamPts += (n >= 1 ? 15 : 0) + (n >= 3 ? 5 : 0);
    teamLines.push(T('db.chat', { role: T(`role.${r}`), n }));
  }
  const rounds = num(t.reviewRounds);
  teamPts += rounds <= 2 ? 20 : rounds === 3 ? 10 : 0;
  teamPts += num(t.signoffs) >= 3 ? 10 : num(t.signoffs) > 0 ? 5 : 0;
  const ds = num(t.designSec);
  teamPts += ds > 0 && ds <= 900 ? 10 : ds <= 1800 ? 5 : 0;
  teamLines.push(T('db.rounds', { n: rounds }), T('db.signoffs', { n: num(t.signoffs) }), T('db.designTime', { min: F(ds / 60, 1) }));
  sec('team', teamPts / MAX.team, teamLines);

  // Puan her zaman açıklanabilir: skor = bölüm toplamı + düzeltmeler (adjustments, negatif puanlar)
  const sectionTotal = sections.reduce((a, s) => a + s.score, 0);
  const adjustments = [];
  const applied = Math.min(penalty, sectionTotal); // puan 0'ın altına inmez
  if (applied > 0) adjustments.push({ id: 'budget-overrun', title: T('adj.budgetTitle'), points: -applied, text: T('adj.budgetText', { pct: F(overrunPct * 100, 1) }) });
  let running = sectionTotal - applied;
  if (outcome === 'failure') {
    const cut = running - Math.round(running * 0.7);
    if (cut > 0) adjustments.push({ id: 'mission-failure', title: T('adj.failTitle'), points: -cut, text: T('adj.failText') });
    running -= cut;
  }
  const score = sectionTotal + adjustments.reduce((a, x) => a + x.points, 0);
  const stars = outcome === 'failure' ? 0 : outcome === 'partial' ? (score >= 700 ? 2 : 1) : (score >= 850 ? 3 : score >= 650 ? 2 : 1);

  // Dersler: tetiklenen kurallardan (tekrarsız)
  const lessons = [];
  const triggered = readiness.filter((r) => r.status !== 'PASS').map((r) => String(r.id));
  for (const [rx, key] of LESSONS) { const text = T(key); if (triggered.some((id) => rx.test(id)) && !lessons.includes(text)) lessons.push(text); }
  if (overrun > 0) lessons.push(T('lesson.overrun', { pct: F(overrunPct * 100, 1), penalty }));
  if (scienceGoals.some((g) => !g.done && g.status !== 'ready')) lessons.push(T('lesson.goals'));
  // Parça arızası olayı (her iki dilin metni tanınır; simResult başka dilde üretilmiş olabilir)
  if (events.some((e) => /arızalandı|arıza verdi|malfunctioned|failed with no backup/.test(e.text))) lessons.push(T('lesson.reliability'));
  if (['rocket', 'spacecraft', 'payload'].some((r) => num(chat[r]) === 0)) lessons.push(T('lesson.asym'));
  if (!lessons.length) lessons.push(T('lesson.balanced'));

  return {
    score, stars, outcome, reason: sim.reason || '', sections, lessons,
    nasaReality: mission.nasaReality || '',
    sources: sourcesFor(ctx, mission),
    sectionTotal, adjustments,
    budget: { budget, spent: round(cost, 2), overrun, overrunPct, penalty },
    scienceGoals,
    model: T('model.debrief'),
  };
}

module.exports = { debrief, MAX };
