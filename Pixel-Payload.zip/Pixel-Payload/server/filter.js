'use strict';
// GÜVENLİK: istemciye giden TEK görünüm. Her alan BEYAZ LİSTE ile yeni nesneye kopyalanır.
// Mühendise: başka rolün sayıları, bütçe/maliyet, operatörün hedef listesi, needs değerleri,
// başka mühendislerin sohbeti ASLA gitmez. Kimseye başka oyuncunun playerId'si gitmez (seat kullanılır).
// debrief fazında herkes tam sonucu görür.

// Aşama 9: metinler izleyen oyuncunun dilinde (me.lang); sayılar/sonuç dilden bağımsız.
const { ROLES, ENGINEER_ROLES, PHASES, launchStatusOf, normLang, msg } = require('./constants');
const { evalFor, simResultFor, debriefFor } = require('./rooms');

const str = (v) => (typeof v === 'string' ? v : '');
const isNum = (v) => typeof v === 'number' && Number.isFinite(v);
const num = (v) => (isNum(v) ? v : 0);
const arr = (v) => (Array.isArray(v) ? v : []);
const obj = (v) => (v && typeof v === 'object' && !Array.isArray(v) ? v : {});

// İsteğe bağlı bir fonksiyonu güvenle çağır (yoksa/hata atarsa undefined)
function call(o, fn, ...args) {
  if (!o || typeof o[fn] !== 'function') return undefined;
  try {
    return o[fn](...args);
  } catch {
    return undefined;
  }
}

// Düz veri kopyası (fonksiyon/sınıf/sonsuz sayı atılır)
function plain(v, depth = 0) {
  if (depth > 12) return null;
  if (Array.isArray(v)) return v.map((x) => plain(x, depth + 1));
  if (v && typeof v === 'object') {
    const out = {};
    for (const k of Object.keys(v)) out[k] = plain(v[k], depth + 1);
    return out;
  }
  if (typeof v === 'number') return Number.isFinite(v) ? v : null;
  if (typeof v === 'string' || typeof v === 'boolean' || v === null) return v;
  return null;
}

// Beyaz listedeki anahtarları kopyala (yalnız var olanlar)
function pick(src, keys) {
  const s = obj(src);
  const out = {};
  for (const k of keys) if (Object.prototype.hasOwnProperty.call(s, k) && s[k] !== undefined) out[k] = plain(s[k]);
  return out;
}

// --- Parça görünümleri -------------------------------------------------------

const PUBLIC_ITEM_KEYS = ['id', 'name', 'category', 'role', 'module', 'icon', 'desc'];
// Kendi kataloğundaki parça (sayılı, MALİYETSİZ)
const OWN_ITEM_KEYS = [
  ...PUBLIC_ITEM_KEYS, 'missions', 'massKg', 'powerW', 'powerGenW', 'batteryWh', 'thrustN', 'ispS',
  'propellantKg', 'dataRateBps', 'dataGenMbPerSol', 'scienceValue', 'reliability', 'tempRangeC',
  'provides', 'requires', 'incompatibleWith', 'tags', 'lifeSupport', 'edl', 'volumeU', 'auto',
];

function publicItem(sim, itemId, lang) {
  const p = call(sim, 'publicItem', itemId, lang);
  return pick(p || { id: itemId }, PUBLIC_ITEM_KEYS);
}

function ownItem(item) {
  const out = pick(item, OWN_ITEM_KEYS);
  // kaynak kayıtları: maliyet kaydı hariç
  const refs = {};
  for (const [k, v] of Object.entries(obj(item.refs))) {
    if (k === 'cost') continue;
    refs[k] = pick(v, ['src', 'class', 'note']);
  }
  out.refs = refs;
  return out;
}

// --- Görev görünümleri -------------------------------------------------------

const MISSION_PUBLIC_KEYS = ['id', 'name', 'summary', 'educationalNote'];

function missionPublic(sim, missionId, lang) {
  if (!missionId) return null;
  const m = call(sim, 'getMission', missionId, lang);
  if (!m) return { id: missionId, name: missionId, summary: '' };
  return pick(m, MISSION_PUBLIC_KEYS);
}

// Operatörün gördüğü tam görev (brifinglerden yalnız kendisininki)
function missionForDirector(m) {
  if (!m) return null;
  const out = pick(m, [
    ...MISSION_PUBLIC_KEYS, 'budget', 'crew', 'durationDays', 'modules', 'phases', 'objectives',
    'settings', 'limits', 'nasaReality', 'refs',
  ]);
  out.briefing = arr(obj(m.briefing).director).map(str);
  return out;
}

// Mühendisin gördüğü modül yapısı: kategori sınırları yalnız kendi kataloğundaki kategoriler için
function modulesForEngineer(m, ownCategories) {
  return arr(m && m.modules).map((mod) => ({
    id: str(mod.id),
    name: str(mod.name),
    role: str(mod.role),
    categories: arr(mod.categories)
      .filter((c) => c && ownCategories.has(c.category))
      .map((c) => pick(c, ['category', 'min', 'max', 'auto'])),
  }));
}

// Mühendisin ayar tanımı: optionInfo'dan YALNIZ metin alanları (useFactor/dutyFactor/... sayıları atılır)
const OPTION_TEXT_KEYS = ['label', 'desc', 'note', 'text', 'help'];
function settingDefForEngineer(d) {
  const out = pick(d, ['key', 'role', 'label', 'type', 'min', 'max', 'step', 'default', 'unit', 'options']);
  if (typeof d.help === 'string') out.help = d.help;
  const info = obj(d.optionInfo);
  if (Object.keys(info).length) {
    out.optionInfo = {};
    for (const [opt, v] of Object.entries(info)) {
      const o = {};
      for (const k of OPTION_TEXT_KEYS) if (typeof obj(v)[k] === 'string') o[k] = v[k];
      out.optionInfo[opt] = o;
    }
  }
  return out;
}

// --- Değerlendirme parçaları -----------------------------------------------

const READINESS_KEYS = ['id', 'system', 'role', 'status', 'critical', 'kind', 'text', 'value', 'limit', 'unit', 'cascadeFrom'];

function readinessFull(ev) {
  return arr(ev && ev.readiness).map((r) => pick(r, READINESS_KEYS));
}

// Bütçe kalemi mi? (mühendise ASLA gitmez; o yalnız budgetBand görür)
const isBudgetItem = (r) => r.kind === 'budget' || r.id === 'budget';

// Mühendis: yalnız kendi rolünün kalemleri; zincirli (cascadeFrom) kalemlerde sayı atılır
function readinessFor(ev, role) {
  return arr(ev && ev.readiness)
    .filter((r) => r && r.role === role && !isBudgetItem(r))
    .map((r) => {
      const cascade = arr(r.cascadeFrom).length > 0;
      return pick(r, cascade
        ? ['id', 'system', 'role', 'status', 'critical', 'kind', 'text', 'cascadeFrom']
        : READINESS_KEYS);
    });
}

// --- Aşama 8: kapasite, bütçe, bilim hedefleri -------------------------------

const numOrNull = (v) => (isNum(v) ? v : null);

// Herkese: modül başına alan (U). mineU = izleyenin rolünün kullandığı (operatör/rolsüz 0).
// Başka rollerin ayrı U değerleri gitmez (yalnız toplam usedU).
function capacityView(ev, role) {
  const cap = obj(obj(ev && ev.telemetry).capacity);
  const out = {};
  for (const [modId, c] of Object.entries(cap)) {
    const m = obj(c);
    out[modId] = {
      name: str(m.name),
      usedU: num(m.usedU),
      capacityU: numOrNull(m.capacityU),
      freeU: numOrNull(m.freeU),
      mineU: ENGINEER_ROLES.includes(role) ? num(obj(m.byRole)[role]) : 0,
    };
  }
  return out;
}

// Bütçe: telemetry.budget (yoksa eski cost/budget alanlarından + build maliyetlerinden türet)
function budgetFull(ev, room, sim) {
  const tel = obj(ev && ev.telemetry);
  const b = { ...obj(tel.budget) }; // kopya: değerlendirme nesnesi değişmesin
  if (!isNum(b.budget) && !isNum(tel.budget)) {
    // son çare: görev verisindeki bütçe
    const m = room.missionId ? obj(call(sim, 'getMission', room.missionId)) : {};
    if (isNum(m.budget)) b.budget = m.budget;
  }
  const byRole = { rocket: 0, spacecraft: 0, payload: 0 };
  for (const e of arr(room.build)) {
    if (!(e.role in byRole)) continue;
    byRole[e.role] += isNum(e.cost) ? e.cost : num(obj(call(sim, 'getItem', e.itemId)).cost);
  }
  const budget = isNum(b.budget) ? b.budget : numOrNull(tel.budget);
  const spent = isNum(b.spent) ? b.spent : (isNum(tel.cost) ? tel.cost : byRole.rocket + byRole.spacecraft + byRole.payload);
  const remaining = isNum(b.remaining) ? b.remaining : (budget === null ? null : budget - spent);
  const br = obj(b.byRole);
  for (const r of ENGINEER_ROLES) if (isNum(br[r])) byRole[r] = br[r];
  return { budget, spent, remaining, byRole };
}

// Mühendis: SAYISIZ bant. tight = harcanan %90'ın üstünde, over = bütçe aşıldı. Bütçe bilinmiyorsa null.
function budgetBand(ev, room, sim) {
  const { budget, spent } = budgetFull(ev, room, sim);
  if (!isNum(budget) || budget <= 0) return null;
  if (spent > budget) return 'over';
  return spent > budget * 0.9 ? 'tight' : 'ok';
}

// Bilim hedefleri: operatöre value dahil; payload mühendisine value YOK
const GOAL_KEYS = ['id', 'name', 'desc', 'status', 'missingTags'];
function scienceGoalsFor(ev, withValue) {
  const keys = withValue ? [...GOAL_KEYS, 'value'] : GOAL_KEYS;
  return arr(obj(ev && ev.telemetry).scienceGoals).map((g) => pick(g, keys));
}

// Harcama defteri (operatör): yeni → eski
const LEDGER_KEYS = ['id', 'ts', 'role', 'playerName', 'action', 'itemId', 'itemName', 'moduleId', 'cost'];
// itemName ve standart donanım adı izleyenin dilinde
function ledgerView(room, sim, lang) {
  return arr(room.ledger).slice().reverse().map((e) => {
    const out = pick(e, LEDGER_KEYS);
    const it = obj(call(sim, 'getItem', e.itemId, lang));
    if (typeof it.name === 'string' && it.name) out.itemName = it.name;
    if (e.action === 'auto') out.playerName = msg(lang, 'ledger.standard');
    return out;
  });
}

function needsFull(ev) {
  const out = {};
  const n = obj(ev && ev.needs);
  for (const r of ENGINEER_ROLES) out[r] = arr(n[r]).map((x) => pick(x, ['id', 'label', 'value', 'unit', 'fromRole']));
  return out;
}

// Mühendis: yalnız etiket + kaynak rol (DEĞER YOK)
function needsFor(ev, role) {
  return arr(obj(ev && ev.needs)[role]).map((x) => pick(x, ['id', 'label', 'fromRole']));
}

function telemetryFull(ev) {
  return plain(obj(ev && ev.telemetry));
}

// Kendi parçalarının toplamları
function ownSums(sim, room, role) {
  const s = { massKg: 0, powerW: 0, propellantKg: 0, dataGenMbPerSol: 0, count: 0 };
  for (const b of arr(room.build)) {
    if (b.role !== role) continue;
    const it = obj(call(sim, 'getItem', b.itemId));
    s.massKg += num(it.massKg);
    s.powerW += num(it.powerW);
    s.propellantKg += num(it.propellantKg);
    s.dataGenMbPerSol += num(it.dataGenMbPerSol);
    s.count++;
  }
  return s;
}

// Mühendisin alt sistem telemetrisi
function telemetryFor(sim, room, role, ev) {
  const tel = obj(ev && ev.telemetry);
  const own = ownSums(sim, room, role);
  if (role === 'rocket') {
    const load = isNum(obj(room.settings).propellantLoad) ? room.settings.propellantLoad : 1;
    return {
      massKg: { mine: own.massKg },
      twr: isNum(tel.twr) ? tel.twr : null,
      stages: arr(tel.stages).map((x) => pick(x, ['id', 'dvMs'])),
      dv: plain(obj(tel.dv)),
      propellant: { capacityKg: own.propellantKg, load, loadedKg: own.propellantKg * load },
    };
  }
  if (role === 'spacecraft') {
    return {
      massKg: { mine: own.massKg },
      power: pick(tel.power, ['genW', 'useW', 'batteryWh', 'marginW']),
      thermal: pick(tel.thermal, ['status', 'note', 'label']),
      comms: pick(tel.comms, ['relayBps', 'directBps', 'delayS', 'downlinkMbPerSol']),
      lifeSupport: tel.lifeSupport ? pick(tel.lifeSupport, ['crew', 'days', 'o2Days', 'waterDays', 'co2Days']) : null,
      edl: tel.edl ? pick(tel.edl, ['entryMs', 'peakHeatWcm2', 'shieldMaxWcm2', 'chuteMach', 'landingVms', 'hazard']) : null,
    };
  }
  if (role === 'payload') {
    return {
      science: pick(tel.science, ['value', 'max', 'instruments']),
      instruments: { count: own.count, massKg: own.massKg, powerW: own.powerW },
      dataMbPerSol: own.dataGenMbPerSol,
    };
  }
  return {};
}

// Operatör: rol başına parça sayısı + eksik kategoriler (min karşılanmayan)
function teamProgress(sim, room, mission) {
  const out = {};
  for (const r of ENGINEER_ROLES) out[r] = { items: 0, missingCategories: [] };
  const have = {}; // moduleId|category -> n
  for (const b of arr(room.build)) {
    if (out[b.role]) out[b.role].items++;
    const it = obj(call(sim, 'getItem', b.itemId));
    const k = `${b.moduleId}|${str(it.category)}`;
    have[k] = (have[k] || 0) + 1;
  }
  for (const mod of arr(mission && mission.modules)) {
    for (const c of arr(mod.categories)) {
      const n = have[`${mod.id}|${c.category}`] || 0;
      if (isNum(c.min) && n < c.min) {
        // kategorinin sahibi: o kategorideki ilk parçanın rolü, yoksa modülün rolü
        const role = out[c.role] ? c.role : (out[mod.role] ? mod.role : null);
        const entry = { moduleId: str(mod.id), category: str(c.category), min: c.min, have: n };
        if (role) out[role].missingCategories.push(entry);
      }
    }
  }
  return out;
}

// --- Ortak parçalar ----------------------------------------------------------

function playersView(room) {
  return [...room.players.values()]
    .sort((a, b) => a.seat - b.seat)
    .map((p) => ({
      seat: p.seat, name: str(p.name), role: p.role || null, ready: !!p.ready,
      connected: !!p.connected, isHost: p.id === room.hostId,
    }));
}

function vehicleView(sim, room, role, lang) {
  return arr(room.build).map((b) => ({
    uid: str(b.uid), moduleId: str(b.moduleId), item: publicItem(sim, b.itemId, lang), role: str(b.role), mine: !!role && b.role === role,
    auto: b.auto === true,
    volumeU: num(obj(call(sim, 'getItem', b.itemId)).volumeU), // alan herkesçe görülür (pazarlık)
  }));
}

function simPhase(p) {
  const out = pick(p, ['id', 'name', 'status', 'note']);
  out.events = arr(p && p.events).map((e) => pick(e, ['id', 'severity', 'text', 'roles']));
  return out;
}

function simulationView(room, phaseMs, missionFull, simResult) {
  if (!room.sim) return null;
  const phases = arr(simResult && simResult.phases);
  const shown = room.phase === PHASES.DEBRIEF ? phases.length : Math.min(room.sim.shownPhases || 0, phases.length);
  const out = { phases: phases.slice(0, shown).map(simPhase), phaseMs: isNum(phaseMs) ? phaseMs : null };
  // görev aşamalarının adları (herkese; yalnız id/name — dvMs/checks gibi sayı/kural yok)
  if (room.phase === PHASES.SIMULATION || room.phase === PHASES.DEBRIEF) {
    out.phaseList = arr(missionFull && missionFull.phases).filter((p) => p && p.id).map((p) => ({ id: str(p.id), name: str(p.name) }));
  }
  return out;
}

// debrief: herkes tam sonucu görür
function resultView(room, sim, lang, ev) {
  if (room.phase !== PHASES.DEBRIEF || !room.debrief) return null;
  return {
    debrief: plain(debriefFor(room, sim, lang)),
    simulation: plain(simResultFor(room, sim, lang)),
    telemetry: telemetryFull(ev),
    readiness: readinessFull(ev),
    overall: ev ? str(ev.overall) : null,
    needs: needsFull(ev),
  };
}

// Sohbet: chat.viewFor çıktısı yine beyaz listeden geçer (mühendis: yalnız mine + broadcast)
const MSG_KEYS = ['id', 'ts', 'thread', 'from', 'fromName', 'text'];
function chatView(chat, room, playerId, role) {
  if (!role) return null;
  const v = call(chat, 'viewFor', room, playerId);
  const threads = obj(v && v.threads);
  const keys = role === 'director' ? [...ENGINEER_ROLES, 'broadcast'] : ['mine', 'broadcast'];
  const out = {};
  for (const k of keys) out[k] = arr(threads[k]).map((m) => pick(m, MSG_KEYS));
  return { threads: out };
}

// --- Ana fonksiyon -----------------------------------------------------------

function viewFor(room, playerId, sim, chat, opts = {}) {
  if (!room || !room.players || typeof playerId !== 'string') return null;
  const me = room.players.get(playerId);
  if (!me) return null;
  const role = me.role || null;
  const lang = normLang(me.lang);
  const phase = room.phase;
  const ev = evalFor(room, sim, lang) || null; // oyuncunun dilindeki değerlendirme
  const missionFull = room.missionId ? call(sim, 'getMission', room.missionId, lang) : null;

  const view = {
    phase,
    code: str(room.code),
    me: { seat: me.seat, name: str(me.name), role, isHost: me.id === room.hostId, lang },
    players: playersView(room),
    missionOptions: (phase === PHASES.LOBBY || phase === PHASES.MISSION_SELECT)
      ? arr(call(sim, 'listMissions', lang)).map((m) => pick(m, MISSION_PUBLIC_KEYS)) : [],
    mission: missionPublic(sim, room.missionId, lang),
    vehicle: vehicleView(sim, room, role, lang),
    overall: ev ? str(ev.overall) || null : null,
    launchStatus: launchStatusOf(ev),
    launchNote: ev && typeof ev.launchNote === 'string' ? ev.launchNote : null, // sayısız Türkçe açıklama (AF)
    capacity: capacityView(ev, role),
    signoff: pick(room.signoff, ENGINEER_ROLES),
    briefing: { acked: ROLES.filter((r) => room.briefingAck && room.briefingAck.has(r)) },
    review: { rounds: num(room.reviewRounds) },
    design: { startedAt: isNum(room.designStartedAt) ? room.designStartedAt : null, elapsedMs: num(room.designMs) },
    simulation: simulationView(room, opts.phaseMs, missionFull, simResultFor(room, sim, lang)),
    chat: chatView(chat, room, playerId, role),
    result: resultView(room, sim, lang, ev),
    director: null,
    engineer: null,
  };

  if (role === 'director') {
    const catalog = {};
    if (room.missionId) {
      // operatör kataloğu: takmadan önce fiyatı görsün diye cost eklenir (mühendis kataloğunda ASLA)
      for (const r of ENGINEER_ROLES) {
        catalog[r] = arr(call(sim, 'catalogFor', room.missionId, r, lang)).map((it) => ({ ...ownItem(it), cost: num(obj(it).cost) }));
      }
    }
    view.director = {
      // görev seçiminde iki görevin ayrıntıları (hedefler, limitler, bütçe) yalnız operatörde
      missionDetails: phase === PHASES.MISSION_SELECT
        ? arr(call(sim, 'listMissions', lang)).map((m) => missionForDirector(call(sim, 'getMission', m && m.id, lang))).filter(Boolean)
        : [],
      mission: missionForDirector(missionFull),
      settings: plain(obj(room.settings)),
      telemetry: ev ? telemetryFull(ev) : null,
      readiness: readinessFull(ev),
      needs: needsFull(ev),
      unmetRequirements: arr(ev && ev.unmetRequirements).map((u) => pick(u, ['itemId', 'requires', 'requiresNames', 'text'])),
      progress: teamProgress(sim, room, missionFull),
      catalog,
      costs: Object.fromEntries(arr(room.build).map((b) => [b.uid, isNum(b.cost) ? b.cost : num(obj(call(sim, 'getItem', b.itemId)).cost)])),
      // Aşama 8
      launchStatus: launchStatusOf(ev),
      budget: room.missionId ? budgetFull(ev, room, sim) : null,
      ledger: ledgerView(room, sim, lang),
    };
    // telemetry.capacity / telemetry.scienceGoals telemetryFull ile zaten tam gider; hedefleri beyaz listeden geçir
    if (view.director.telemetry && Array.isArray(view.director.telemetry.scienceGoals)) {
      view.director.telemetry.scienceGoals = scienceGoalsFor(ev, true);
    }
  } else if (ENGINEER_ROLES.includes(role)) {
    const own = room.missionId ? arr(call(sim, 'catalogFor', room.missionId, role, lang)) : [];
    const ownCats = new Set(own.map((it) => it && it.category));
    const settingDefs = arr(missionFull && missionFull.settings).filter((s) => s && s.role === role);
    const mySettings = {};
    for (const d of settingDefs) {
      if (Object.prototype.hasOwnProperty.call(obj(room.settings), d.key)) mySettings[d.key] = plain(room.settings[d.key]);
    }
    view.engineer = {
      briefing: arr(obj(missionFull && missionFull.briefing)[role]).map(str),
      modules: modulesForEngineer(missionFull, ownCats),
      catalog: own.map((it) => {
        const out = ownItem(it);
        const res = phase === PHASES.DESIGN
          ? call(sim, 'canAdd', structuredClone(arr(room.build)), room.missionId, role, it.id, it.module, lang)
          : null;
        out.canAdd = res ? pick(res, ['ok', 'error', 'reason']) : null;
        return out;
      }),
      settingDefs: settingDefs.map(settingDefForEngineer),
      settings: mySettings,
      readiness: readinessFor(ev, role),
      needs: needsFor(ev, role),
      telemetry: room.missionId ? telemetryFor(sim, room, role, ev) : null,
      budgetBand: room.missionId ? budgetBand(ev, room, sim) : null, // SAYI YOK
    };
    if (role === 'payload') view.engineer.scienceGoals = scienceGoalsFor(ev, false);
  }
  return view;
}

module.exports = { viewFor };
