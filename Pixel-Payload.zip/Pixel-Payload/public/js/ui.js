// Pixel Payload — arayüz yardımcıları (Modül AC). DOM API ile çizer; innerHTML kullanılmaz.
import { t, getLang, setLang, locale } from './i18n.js';
import './lang/shell.js';

const SVG_NS = 'http://www.w3.org/2000/svg';

// ---- Rol ve faz adları (sunucu constants.js ile aynı) ----
// Dil duyarlı: her okuma geçerli dili kullanır (getter); dışa açık adlar korunur.
export const ROLES = ['director', 'rocket', 'spacecraft', 'payload'];
function langMap(keys, prefix) {
  const o = {};
  keys.forEach((k) => Object.defineProperty(o, k, { enumerable: true, get: () => t(prefix + k) }));
  return Object.freeze(o);
}
export const ROLE_NAMES = langMap(ROLES, 'shell.role.');
export const ROLE_SHORT = langMap(ROLES, 'shell.roleShort.');
export const ROLE_ICONS = { director: 'antenna', rocket: 'engine', spacecraft: 'satellite', payload: 'flask' };
export const PHASE_NAMES = langMap(['lobby', 'mission-select', 'briefing', 'design', 'review', 'simulation', 'debrief'], 'shell.phase.');

// ---- h(tag, attrs, ...children) ----
// attrs: class, text, style (nesne), dataset (nesne), on<Olay> (fonksiyon), boolean/özellikler
// (disabled, hidden, checked, value, type…), diğerleri setAttribute. Çocuk: düğüm, metin, dizi; null/false atlanır.
const PROPS = new Set(['value', 'checked', 'disabled', 'hidden', 'selected', 'readOnly', 'required', 'tabIndex', 'htmlFor']);
export function h(tag, attrs, ...children) {
  const el = document.createElement(tag);
  if (attrs) {
    for (const [k, v] of Object.entries(attrs)) {
      if (v === undefined || v === null || v === false) continue;
      if (k === 'class' || k === 'className') el.className = Array.isArray(v) ? v.filter(Boolean).join(' ') : v;
      else if (k === 'text') el.textContent = String(v);
      else if (k === 'style' && typeof v === 'object') Object.assign(el.style, v);
      else if (k === 'dataset' && typeof v === 'object') Object.entries(v).forEach(([dk, dv]) => { if (dv !== undefined && dv !== null) el.dataset[dk] = String(dv); });
      else if (k.startsWith('on') && typeof v === 'function') el.addEventListener(k.slice(2).toLowerCase(), v);
      else if (PROPS.has(k)) el[k] = v;
      else el.setAttribute(k, v === true ? '' : String(v));
    }
  }
  append(el, children);
  return el;
}
function append(el, children) {
  for (const c of children) {
    if (c === null || c === undefined || c === false) continue;
    if (Array.isArray(c)) append(el, c);
    else el.appendChild(c instanceof Node ? c : document.createTextNode(String(c)));
  }
}
export function clear(node) { while (node && node.firstChild) node.removeChild(node.firstChild); return node; }

function svg(tag, attrs, ...children) {
  const el = document.createElementNS(SVG_NS, tag);
  for (const [k, v] of Object.entries(attrs || {})) if (v !== undefined && v !== null) el.setAttribute(k, String(v));
  children.flat().forEach((c) => c && el.appendChild(c));
  return el;
}
let uidSeq = 0;
const uid = (p) => `pp-${p}-${++uidSeq}`;

// ---- İkonlar (24×24, 2px çizgi, currentColor) ----
const ICONS = {
  rocket: ['M12 2c3 2.5 4.5 6 4.5 10v5h-9v-5C7.5 8 9 4.5 12 2z', 'M7.5 13l-3 3v3h3', 'M16.5 13l3 3v3h-3', 'M10 21h4', 'M10.5 9a1.5 1.5 0 1 0 3 0a1.5 1.5 0 1 0-3 0'],
  crew: ['M5 10a7 7 0 1 0 14 0a7 7 0 1 0-14 0', 'M8.5 8.5h7v3.5h-7z', 'M4 22c1-3.5 4-5 8-5s7 1.5 8 5'],
  shield: ['M12 2l8 3v6c0 5-3.5 9-8 11c-4.5-2-8-6-8-11V5z', 'M8.5 12l2.5 2.5 4.5-5'],
  antenna: ['M12 13v8', 'M8 21h8', 'M10.5 11.5a1.5 1.5 0 1 0 3 0a1.5 1.5 0 1 0-3 0', 'M8.5 8a5 5 0 0 0 0 7', 'M15.5 8a5 5 0 0 1 0 7', 'M5.5 5a9 9 0 0 0 0 13', 'M18.5 5a9 9 0 0 1 0 13'],
  flask: ['M9 3h6', 'M10 3v6l-5 9a2 2 0 0 0 2 3h10a2 2 0 0 0 2-3l-5-9V3', 'M7.5 15h9'],
  power: ['M13 2L4 14h7l-1 8 9-12h-7z'],
  thermo: ['M10 4a2 2 0 0 1 4 0v10a4 4 0 1 1-4 0z', 'M12 9v8'],
  fuel: ['M12 3c3.5 4.5 6 8 6 11a6 6 0 0 1-12 0c0-3 2.5-6.5 6-11z', 'M9.5 14a2.5 2.5 0 0 0 2.5 2.5'],
  engine: ['M8 3h8v5H8z', 'M9 8l-3 9h12l-3-9', 'M9 20l-.5 2', 'M15 20l.5 2', 'M12 20v2'],
  chart: ['M3 3v18h18', 'M7 15l4-5 3 3 5-7'],
  gear: ['M9 12a3 3 0 1 0 6 0a3 3 0 1 0-6 0', 'M12 2v3M12 19v3M2 12h3M19 12h3M4.9 4.9L7 7M17 17l2.1 2.1M4.9 19.1L7 17M17 7l2.1-2.1', 'M5 12a7 7 0 1 0 14 0a7 7 0 1 0-14 0'],
  chat: ['M4 4h16v12H9l-5 4z', 'M8 9h8', 'M8 12h5'],
  back: ['M20 12H5', 'M11 6l-6 6 6 6'],
  check: ['M4 12l5 5L20 6'],
  cross: ['M6 6l12 12', 'M18 6L6 18'],
  warn: ['M12 3l10 18H2z', 'M12 10v5', 'M12 17.5v1'],
  clock: ['M3 12a9 9 0 1 0 18 0a9 9 0 1 0-18 0', 'M12 7v5l3 2'],
  star: ['M12 2.5l2.9 6.2 6.6.7-4.9 4.5 1.4 6.6L12 17.2l-6 3.3 1.4-6.6-4.9-4.5 6.6-.7z'],
  satellite: ['M9 7l8 8-3 3-8-8z', 'M3 11l3-3 2 2-3 3z', 'M13 21l3-3-2-2-3 3z', 'M17 3a4 4 0 0 1 4 4', 'M16 6.5a1.5 1.5 0 0 1 1.5 1.5'],
  rover: ['M4 12h16v4H4z', 'M7 12V8h7v4', 'M14 8l3-3', 'M4.5 19a1.5 1.5 0 1 0 3 0a1.5 1.5 0 1 0-3 0', 'M10.5 19a1.5 1.5 0 1 0 3 0a1.5 1.5 0 1 0-3 0', 'M16.5 19a1.5 1.5 0 1 0 3 0a1.5 1.5 0 1 0-3 0'],
  moon: ['M20 14.5A8.5 8.5 0 1 1 9.5 4a7 7 0 0 0 10.5 10.5z'],
  mars: ['M4 12a8 8 0 1 0 16 0a8 8 0 1 0-16 0', 'M7 9h4', 'M13 15h4', 'M9 14l2 2'],
  play: ['M7 4l13 8-13 8z'],
  exit: ['M10 4H4v16h6', 'M14 8l4 4-4 4', 'M18 12H9'],
  eye: ['M2 12s4-7 10-7 10 7 10 7-4 7-10 7S2 12 2 12z', 'M9 12a3 3 0 1 0 6 0a3 3 0 1 0-6 0'],
  // ek ikonlar
  copy: ['M8 8h12v12H8z', 'M4 16V4h12'],
  crown: ['M4 18l-1-11 5 4 4-6 4 6 5-4-1 11z'],
  info: ['M3 12a9 9 0 1 0 18 0a9 9 0 1 0-18 0', 'M12 11v6', 'M12 7.5v1'],
  lock: ['M5 11h14v10H5z', 'M8 11V7a4 4 0 0 1 8 0v4'],
  book: ['M3 5h7a2 2 0 0 1 2 2v13a2 2 0 0 0-2-2H3z', 'M21 5h-7a2 2 0 0 0-2 2v13a2 2 0 0 1 2-2h7z'],
  wifi: ['M2 9a15 15 0 0 1 20 0', 'M5 12.5a10 10 0 0 1 14 0', 'M8.5 16a5 5 0 0 1 7 0', 'M12 19.5v.5'],
  users: ['M6 8a3 3 0 1 0 6 0a3 3 0 1 0-6 0', 'M2 20c.5-3.5 3-5 7-5s6.5 1.5 7 5', 'M15 5a3 3 0 0 1 0 6', 'M18 15c2 .5 3.5 2 4 5'],
  link: ['M10 14a4 4 0 0 0 6 0l3-3a4 4 0 0 0-6-6l-1 1', 'M14 10a4 4 0 0 0-6 0l-3 3a4 4 0 0 0 6 6l1-1'],
  globe: ['M3 12a9 9 0 1 0 18 0a9 9 0 1 0-18 0', 'M3 12h18', 'M12 3c3 3 3 15 0 18', 'M12 3c-3 3-3 15 0 18']
};
export function icon(name, size) {
  const paths = ICONS[name] || ICONS.info;
  const el = svg('svg', {
    class: 'icon', viewBox: '0 0 24 24', width: size || 24, height: size || 24, fill: 'none',
    stroke: 'currentColor', 'stroke-width': 2, 'stroke-linecap': 'square', 'stroke-linejoin': 'miter', 'aria-hidden': 'true', focusable: 'false'
  }, paths.map((d) => svg('path', { d })));
  el.dataset.icon = name;
  return el;
}

// ---- Panel (kesik köşe, başlık şeridi) ----
// accent: 'cyan' (varsayılan) | 'green' | 'amber' | 'red' | 'purple' | rol id'si; actions: düğüm/dizi
export function panel({ title, icon: ic, accent, actions, active, className } = {}, ...children) {
  const head = title || actions
    ? h('header', { class: 'panel__head' },
        title ? h('h2', { class: 'panel__title' }, ic ? icon(ic, 20) : null, h('span', { text: title })) : null,
        actions ? h('div', { class: 'panel__actions' }, actions) : null)
    : null;
  return h('section', { class: ['panel', className], dataset: { accent: accent || undefined, active: active ? '1' : undefined } },
    head, h('div', { class: 'panel__body' }, children));
}

// ---- Düğme ----
// onClick bir Promise döndürürse bitene kadar düğme meşgul (devre dışı) kalır.
// disabled + reason: gerekçe düğmenin içinde ikinci satırda ve title'da görünür.
export function button({ label, sub, variant = 'primary', onClick, disabled, reason, icon: ic, type = 'button', className, size, ariaLabel } = {}) {
  const b = h('button', { type, class: ['btn', `btn--${variant}`, size ? `btn--${size}` : null, className], 'aria-label': ariaLabel || undefined },
    ic ? icon(ic, size === 'lg' ? 28 : 20) : null,
    h('span', { class: 'btn__text' },
      h('span', { class: 'btn__label', text: label || '' }),
      sub ? h('span', { class: 'btn__sub', text: sub }) : null,
      disabled && reason ? h('span', { class: 'btn__reason', text: reason }) : null));
  if (disabled) {
    b.disabled = true;
    if (reason) b.title = reason;
  }
  if (onClick) {
    b.addEventListener('click', async (e) => {
      if (b.disabled || b.dataset.busy === '1') return;
      const r = onClick(e);
      if (r && typeof r.then === 'function') {
        b.dataset.busy = '1';
        b.disabled = true;
        b.setAttribute('aria-busy', 'true');
        try { await r; } finally {
          {
            delete b.dataset.busy;
            b.disabled = !!disabled;
            b.removeAttribute('aria-busy');
          }
        }
      }
    });
  }
  return b;
}

// ---- Durum noktası / hapı ----
const STATUS_KIND = {
  PASS: 'ok', ok: 'ok', OK: 'ok', GO: 'ok', ready: 'ok', online: 'ok', done: 'ok', success: 'ok',
  WARN: 'warn', warn: 'warn', wait: 'warn', partial: 'warn', connecting: 'warn', pending: 'idle', active: 'info',
  FAIL: 'fail', fail: 'fail', 'NO-GO': 'fail', offline: 'fail', error: 'fail', failure: 'fail', critical: 'fail',
  info: 'info', idle: 'idle'
};
const STATUS_ICON = { ok: 'check', warn: 'warn', fail: 'cross', info: 'play', idle: 'clock' };
export function statusKind(status) { return STATUS_KIND[status] || 'idle'; }
export function statusDot(status) {
  const k = statusKind(status);
  return h('span', { class: 'dot', dataset: { status: k }, 'aria-hidden': 'true' });
}
export function statusPill(status, label) {
  const k = statusKind(status);
  const text = label || (typeof status === 'string' && /^[A-Z-]+$/.test(status) ? status : t('shell.status.' + k));
  return h('span', { class: 'pill', dataset: { status: k } }, icon(STATUS_ICON[k], 16), h('span', { text }));
}

// ---- Rol rozeti ----
export function roleBadge(role, { short = true } = {}) {
  if (!role || !ROLE_NAMES[role]) return h('span', { class: 'role-badge', dataset: { role: 'none' }, text: t('shell.ui.noRole') });
  return h('span', { class: 'role-badge', dataset: { role }, title: ROLE_NAMES[role] },
    icon(ROLE_ICONS[role], 16), h('span', { text: short ? ROLE_SHORT[role] : ROLE_NAMES[role] }));
}

// ---- Gösterge çubuğu ----
export function meter({ value, max, status, label } = {}) {
  const pct = max > 0 && Number.isFinite(value) ? Math.max(0, Math.min(100, (value / max) * 100)) : 0;
  const fill = h('span', { class: 'meter__fill', style: { width: pct.toFixed(1) + '%' } });
  return h('div', {
    class: 'meter', dataset: { status: status ? statusKind(status) : 'info' },
    role: 'meter', 'aria-valuemin': 0, 'aria-valuemax': max || 0, 'aria-valuenow': Number.isFinite(value) ? value : 0,
    'aria-label': label || undefined
  }, fill);
}

// ---- Adım listesi: [{ label, status: 'done'|'active'|'pending'|'ok'|'warn'|'fail', note? }] ----
export function stepList(steps = []) {
  return h('ol', { class: 'steps' }, steps.map((s, i) => {
    const st = s.status === 'done' ? 'ok' : s.status === 'active' ? 'info' : s.status === 'pending' ? 'idle' : statusKind(s.status);
    return h('li', { class: 'steps__item', dataset: { status: st }, 'aria-current': s.status === 'active' ? 'step' : undefined },
      h('span', { class: 'steps__mark', 'aria-hidden': 'true' }, st === 'idle' || st === 'info' ? String(i + 1) : icon(STATUS_ICON[st], 16)),
      h('span', { class: 'steps__text' }, h('span', { class: 'steps__label', text: s.label }), s.note ? h('span', { class: 'steps__note', text: s.note }) : null));
  }));
}

// ---- Toast (aynı anda en çok 2) ----
export function toast(msg, kind = 'info', ms = 3800) {
  let root = document.getElementById('toast');
  if (!root) { root = h('div', { id: 'toast' }); document.body.appendChild(root); }
  while (root.children.length >= 2) root.removeChild(root.firstChild);
  const k = kind === 'error' ? 'fail' : kind === 'success' ? 'ok' : statusKind(kind);
  const t = h('div', { class: 'toast', dataset: { status: k }, role: k === 'fail' ? 'alert' : 'status' },
    icon(STATUS_ICON[k] || 'info', 20), h('span', { text: msg }));
  root.appendChild(t);
  const close = () => { t.dataset.leaving = '1'; setTimeout(() => t.remove(), 200); };
  t.addEventListener('click', close);
  setTimeout(close, ms);
  return t;
}

// ---- Modal: actions [{ label, variant, onClick, close = true }] → { close } ----
export function modal({ title, body, actions = [], onClose } = {}) {
  let root = document.getElementById('modal-root');
  if (!root) { root = h('div', { id: 'modal-root' }); document.body.appendChild(root); }
  const prevFocus = document.activeElement;
  const titleId = uid('mt');
  let closed = false;
  const close = () => {
    if (closed) return;
    closed = true;
    document.removeEventListener('keydown', onKey, true);
    wrap.remove();
    if (onClose) onClose();
    if (prevFocus && prevFocus.focus && prevFocus.isConnected) prevFocus.focus();
  };
  const btns = (actions.length ? actions : [{ label: t('shell.ui.ok'), variant: 'primary' }]).map((a) => button({
    label: a.label, variant: a.variant || 'ghost', icon: a.icon,
    onClick: async (e) => {
      const r = a.onClick ? await a.onClick(e) : undefined;
      if (a.close !== false && r !== false) close();
    }
  }));
  const card = h('div', { class: 'modal', role: 'dialog', 'aria-modal': 'true', 'aria-labelledby': titleId },
    h('header', { class: 'modal__head' },
      h('h2', { id: titleId, class: 'modal__title', text: title || '' }),
      h('button', { type: 'button', class: 'modal__x', 'aria-label': t('shell.ui.close'), onClick: close }, icon('cross', 20))),
    h('div', { class: 'modal__body' }, typeof body === 'string' ? h('p', { text: body }) : body),
    h('footer', { class: 'modal__actions' }, btns));
  const wrap = h('div', { class: 'modal-wrap', onClick: (e) => { if (e.target === wrap) close(); } }, card);
  function onKey(e) {
    if (e.key === 'Escape') { e.preventDefault(); close(); return; }
    if (e.key !== 'Tab') return;
    const f = [...card.querySelectorAll('button, [href], input, select, textarea, [tabindex]:not([tabindex="-1"])')].filter((n) => !n.disabled);
    if (!f.length) return;
    const first = f[0], last = f[f.length - 1];
    if (e.shiftKey && document.activeElement === first) { e.preventDefault(); last.focus(); }
    else if (!e.shiftKey && document.activeElement === last) { e.preventDefault(); first.focus(); }
  }
  document.addEventListener('keydown', onKey, true);
  root.appendChild(wrap);
  (btns[btns.length - 1] || card).focus();
  return { close, el: card };
}

// Onay modalı kısayolu → Promise<boolean>
export function confirmModal({ title, body, okLabel, okVariant = 'nogo', cancelLabel }) {
  if (!okLabel) okLabel = t('shell.ui.yes');
  if (!cancelLabel) cancelLabel = t('shell.ui.cancel');
  return new Promise((resolve) => {
    let answered = false;
    modal({
      title, body,
      actions: [
        { label: cancelLabel, variant: 'ghost', onClick: () => { answered = true; resolve(false); } },
        { label: okLabel, variant: okVariant, onClick: () => { answered = true; resolve(true); } }
      ],
      onClose: () => { if (!answered) resolve(false); }
    });
  });
}

// ---- Dil anahtarı (EN | TR) ----
// Basınca setLang; core sunucuya bildirir, app ekranı yeniden çizer.
export const LANGS = ['en', 'tr'];
export function langSwitch({ className } = {}) {
  const cur = getLang();
  return h('div', { class: ['lang-switch', className], role: 'group', 'aria-label': t('shell.lang.aria') },
    icon('globe', 18),
    LANGS.map((l) => h('button', {
      type: 'button', class: 'lang-switch__opt', lang: l, dataset: { lang: l },
      'aria-pressed': cur === l ? 'true' : 'false', title: t('shell.lang.name.' + l),
      'aria-label': `${l.toUpperCase()} · ${t('shell.lang.name.' + l)}`,
      onClick: () => setLang(l)
    }, h('span', { text: l.toUpperCase(), 'aria-hidden': 'true' }))));
}

// ---- Biçimleyiciler ----
export const fmt = {
  num(n, digits = 0) {
    if (!Number.isFinite(Number(n))) return '—';
    return Number(n).toLocaleString(locale(), { minimumFractionDigits: digits, maximumFractionDigits: digits });
  },
  unit(n, unit, digits = 0) {
    const s = fmt.num(n, digits);
    return s === '—' || !unit ? s : `${s} ${unit}`;
  },
  // Zaman damgası (ms, > 1e11) → "SS:DD"; süre (ms) → "dd:ss" / "s:dd:ss"
  time(v) {
    const n = Number(v);
    if (!Number.isFinite(n)) return '—';
    return n > 1e11 ? fmt.clock(n) : fmt.duration(n);
  },
  clock(ts) {
    const d = new Date(Number(ts));
    return Number.isNaN(d.getTime()) ? '—' : `${String(d.getHours()).padStart(2, '0')}:${String(d.getMinutes()).padStart(2, '0')}`;
  },
  duration(ms) {
    const t = Math.max(0, Math.floor(Number(ms) / 1000));
    const hh = Math.floor(t / 3600), mm = Math.floor((t % 3600) / 60), ss = t % 60;
    const p = (x) => String(x).padStart(2, '0');
    return hh ? `${hh}:${p(mm)}:${p(ss)}` : `${p(mm)}:${p(ss)}`;
  }
};

// ---- Piksel-art roket (SVG rect) ----
const ROCKET_MAP = [
  '....rr....',
  '...rrrr...',
  '...wwww...',
  '..wwwwgw..',
  '..wcccgw..',
  '..wcbcgw..',
  '..wcccgw..',
  '..wwwwgw..',
  '..wwwwgw..',
  '..wrrrgw..',
  '..wwwwgw..',
  '.rwwwwgwr.',
  'rrwwwwgwrr',
  'rr.dddd.rr',
  '...oyyo...',
  '....oy....',
  '....o.....'
];
const ROCKET_COLORS = { r: '#ff4d5e', w: '#e6f1ff', g: '#8aa4c8', c: '#38c8ff', b: '#0b3a66', d: '#3a4a66', o: '#ff8a3d', y: '#ffc247' };
export function pixelRocket(size = 48) {
  const w = ROCKET_MAP[0].length, hgt = ROCKET_MAP.length;
  const el = svg('svg', { class: 'pixel-rocket', viewBox: `0 0 ${w} ${hgt}`, width: size * (w / hgt), height: size, 'shape-rendering': 'crispEdges', 'aria-hidden': 'true', focusable: 'false' });
  ROCKET_MAP.forEach((row, y) => {
    let x = 0;
    while (x < row.length) {
      const ch = row[x];
      if (ch === '.') { x++; continue; }
      let len = 1;
      while (row[x + len] === ch) len++;
      el.appendChild(svg('rect', { x, y, width: len, height: 1, fill: ROCKET_COLORS[ch], class: ch === 'o' || ch === 'y' ? 'pixel-rocket__flame' : null }));
      x += len;
    }
  });
  return el;
}

// ---- Dünya yayı (sağ alttan; dekoratif) ----
export function earthArc() {
  const g = uid('earth'), a = uid('atm');
  return svg('svg', { class: 'earth-arc', viewBox: '0 0 1000 700', preserveAspectRatio: 'xMaxYMax slice', 'aria-hidden': 'true', focusable: 'false' },
    svg('defs', {},
      svg('radialGradient', { id: g, cx: '0.35', cy: '0.3', r: '0.8' },
        svg('stop', { offset: '0', 'stop-color': '#2c7fd0' }),
        svg('stop', { offset: '0.55', 'stop-color': '#0d3f7a' }),
        svg('stop', { offset: '1', 'stop-color': '#04152e' })),
      svg('radialGradient', { id: a, cx: '0.5', cy: '0.5', r: '0.5' },
        svg('stop', { offset: '0.9', 'stop-color': '#38c8ff', 'stop-opacity': '0' }),
        svg('stop', { offset: '0.965', 'stop-color': '#38c8ff', 'stop-opacity': '0.45' }),
        svg('stop', { offset: '1', 'stop-color': '#38c8ff', 'stop-opacity': '0' }))),
    svg('ellipse', { cx: 980, cy: 1120, rx: 980, ry: 700, fill: 'none', stroke: '#38c8ff', 'stroke-opacity': '0.18', 'stroke-width': 1.5, 'stroke-dasharray': '4 10' }),
    svg('circle', { cx: 1000, cy: 1180, r: 760, fill: `url(#${a})` }),
    svg('circle', { cx: 1000, cy: 1180, r: 700, fill: `url(#${g})` }),
    // kıta lekeleri (basit)
    svg('path', { d: 'M520 640c40-50 110-60 160-30s40 70 0 70-120 10-160-40z', fill: '#2f8f6a', 'fill-opacity': '0.55' }),
    svg('path', { d: 'M760 540c50-30 120-20 150 20s-10 60-60 50-110-40-90-70z', fill: '#2f8f6a', 'fill-opacity': '0.45' }),
    svg('path', { d: 'M600 560c30-10 60 0 70 15s-20 25-45 20-40-25-25-35z', fill: '#e6f1ff', 'fill-opacity': '0.25' }),
    svg('circle', { cx: 1000, cy: 1180, r: 700, fill: 'none', stroke: '#7fe0ff', 'stroke-width': 3, 'stroke-opacity': '0.8' }));
}

// ---- Gezegen çizimi (ek yardımcı): kind 'moon' | 'mars' | 'earth' ----
const PLANET_COLORS = {
  moon: ['#e3e7ee', '#8a93a3', '#2a3140'],
  mars: ['#ff9a5c', '#c2482a', '#3d140c'],
  earth: ['#4fb0ff', '#0d4f9a', '#04152e']
};
export function planet(kind = 'moon', size = 160) {
  const c = PLANET_COLORS[kind] || PLANET_COLORS.moon;
  const g = uid('pl');
  const craters = kind === 'mars'
    ? [svg('path', { d: 'M30 70c15-6 40-4 55 4', stroke: '#7a2a18', 'stroke-width': 4, fill: 'none', 'stroke-opacity': '0.6' }),
       svg('circle', { cx: 120, cy: 60, r: 9, fill: '#7a2a18', 'fill-opacity': '0.45' }),
       svg('circle', { cx: 70, cy: 120, r: 6, fill: '#7a2a18', 'fill-opacity': '0.4' }),
       svg('path', { d: 'M60 30c12 4 20 2 30-4', stroke: '#fff2e6', 'stroke-width': 5, fill: 'none', 'stroke-opacity': '0.5' })]
    : kind === 'moon'
      ? [[52, 58, 14], [112, 52, 9], [96, 112, 18], [48, 118, 8], [128, 92, 6]].map(([x, y, r]) =>
          svg('circle', { cx: x, cy: y, r, fill: '#5d6575', 'fill-opacity': '0.45', stroke: '#c9d0dc', 'stroke-opacity': '0.35' }))
      : [];
  return svg('svg', { class: 'planet', 'data-kind': kind, viewBox: '0 0 160 160', width: size, height: size, 'aria-hidden': 'true', focusable: 'false' },
    svg('defs', {}, svg('radialGradient', { id: g, cx: '0.35', cy: '0.32', r: '0.75' },
      svg('stop', { offset: '0', 'stop-color': c[0] }), svg('stop', { offset: '0.6', 'stop-color': c[1] }), svg('stop', { offset: '1', 'stop-color': c[2] }))),
    svg('circle', { cx: 80, cy: 80, r: 74, fill: `url(#${g})` }),
    craters,
    svg('circle', { cx: 80, cy: 80, r: 74, fill: 'none', stroke: '#38c8ff', 'stroke-opacity': '0.35', 'stroke-width': 1.5 }));
}
