// Pixel Payload — istemci çekirdeği (Modül AC).
// Socket bağlantısı, son `state`, oturum (sessionStorage), URL parametreleri, postMessage sözleşmesi,
// fazsız ekran gezintisi (`nav`) ve yerel tercihler (`prefs`). Oyun kuralı hesaplamaz.
// Dil (Aşama 9): oda olaylarına `lang` eklenir; dil değişince `player:lang` gönderilir.
import { t, getLang, setLang, onLang } from './i18n.js';
import './lang/shell.js';

// ---- URL parametreleri (demo/iframe; hiçbiri yoksa davranış değişmez) ----
const params = new URLSearchParams(location.search);
function safeParam(name, re) {
  const v = params.get(name);
  return v !== null && re.test(v) ? v : null;
}
const SLOT = safeParam('slot', /^[A-Za-z0-9_-]{1,32}$/);          // ayrı oturum anahtarı
const AUTO_MODE = safeParam('auto', /^(create|join)$/);           // otomatik giriş
const AUTO_NAME = (params.get('name') || '').slice(0, 16);
const AUTO_ROLE = safeParam('role', /^(director|rocket|spacecraft|payload)$/);
const AUTO_CODE = (params.get('code') || '').trim().toUpperCase();
const EMBED = params.get('embed') === '1';
const DEBUG = params.get('debug') === '1';
const IN_FRAME = window.parent !== window;
const ROOT = document.documentElement;
if (EMBED) ROOT.setAttribute('data-embed', '1');
if (DEBUG) ROOT.setAttribute('data-debug', '1');

// ?lang=en|tr (demo/iframe) dili kalıcı olarak seçer; başka sekme/çerçevede değişirse burada da uygulanır
const URL_LANG = safeParam('lang', /^(en|tr)$/);
if (URL_LANG) setLang(URL_LANG);
window.addEventListener('storage', (e) => { if (e.key === 'pp.lang' && (e.newValue === 'en' || e.newValue === 'tr')) setLang(e.newValue); });

const STORAGE_KEY = SLOT ? 'pixelPayloadSession:' + SLOT : 'pixelPayloadSession';

// ---- Oturum (her sekme/yuva ayrı) ----
export const session = {
  key: STORAGE_KEY,
  slot: SLOT,
  embed: EMBED,
  debug: DEBUG,
  inFrame: IN_FRAME,
  params: { lang: URL_LANG, slot: SLOT, auto: AUTO_MODE, name: AUTO_NAME, role: AUTO_ROLE, code: AUTO_CODE, embed: EMBED, debug: DEBUG },
  load() {
    try {
      const s = JSON.parse(sessionStorage.getItem(STORAGE_KEY));
      return s && s.code && s.playerId ? s : null;
    } catch (e) { return null; }
  },
  save(code, playerId) {
    try { sessionStorage.setItem(STORAGE_KEY, JSON.stringify({ code, playerId })); } catch (e) { /* yok say */ }
  },
  clear() {
    try { sessionStorage.removeItem(STORAGE_KEY); } catch (e) { /* yok say */ }
  }
};

// ---- Tercihler (localStorage) ----
const PREFS_KEY = 'pixelPayloadPrefs';
const PREF_DEFAULTS = { reduceMotion: false, textScale: 1, name: '' };
let prefData = { ...PREF_DEFAULTS };
try {
  const raw = JSON.parse(localStorage.getItem(PREFS_KEY));
  if (raw && typeof raw === 'object') prefData = { ...PREF_DEFAULTS, ...raw };
} catch (e) { /* yok say */ }

function applyPrefs() {
  ROOT.setAttribute('data-reduce-motion', prefData.reduceMotion ? '1' : '0');
  const sc = Number(prefData.textScale);
  ROOT.style.setProperty('--text-scale', String(sc >= 0.9 && sc <= 1.5 ? sc : 1));
}
applyPrefs();

export const prefs = {
  get(key) { return prefData[key]; },
  all() { return { ...prefData }; },
  set(key, value) {
    if (!(key in PREF_DEFAULTS)) return;
    prefData[key] = value;
    try { localStorage.setItem(PREFS_KEY, JSON.stringify(prefData)); } catch (e) { /* yok say */ }
    applyPrefs();
  }
};

// ---- Olay dinleyicileri ----
const listeners = new Map();   // ad → Set<fn>
export function onEvent(name, fn) {
  if (!listeners.has(name)) listeners.set(name, new Set());
  listeners.get(name).add(fn);
  return () => listeners.get(name).delete(fn);
}
function fire(name, payload) {
  const set = listeners.get(name);
  if (!set) return;
  [...set].forEach((fn) => { try { fn(payload); } catch (e) { console.error(e); } });
}

// ---- Durum ----
let state = null;
const subs = new Set();
export function getState() { return state; }
export function subscribe(fn) {
  subs.add(fn);
  return () => subs.delete(fn);
}
function setState(next) {
  const prev = state;
  state = next;
  [...subs].forEach((fn) => { try { fn(state, prev); } catch (e) { console.error(e); } });
}

// ---- Bağlantı durumu: 'connecting' | 'online' | 'offline' ----
let conn = 'connecting';
export function connection() { return conn; }
function setConn(c) {
  if (c === conn) return;
  conn = c;
  fire('connection', c);
}

// ---- Fazsız ekran gezintisi ----
const LOCAL_SCREENS = ['home', 'create', 'join', 'how', 'data', 'settings'];
const navStack = ['home'];
export const nav = {
  go(id) {
    if (!LOCAL_SCREENS.includes(id)) return;
    if (navStack[navStack.length - 1] !== id) navStack.push(id);
    if (navStack.length > 20) navStack.splice(1, navStack.length - 20);
    fire('nav', id);
  },
  back() {
    if (navStack.length > 1) navStack.pop();
    fire('nav', navStack[navStack.length - 1]);
  },
  canBack() { return navStack.length > 1; },
  reset(id = 'home') {
    navStack.length = 0;
    navStack.push(LOCAL_SCREENS.includes(id) ? id : 'home');
    fire('nav', navStack[0]);
  },
  current() { return navStack[navStack.length - 1]; }
};

// ---- postMessage (iframe/demo sözleşmesi; görev/sayı YOK) ----
function notifyParent(s) {
  if (!IN_FRAME) return;
  try {
    window.parent.postMessage({
      type: 'pp-state',
      slot: SLOT,
      code: s && s.code ? s.code : null,
      phase: s && s.phase ? s.phase : null,
      role: s && s.me ? s.me.role || null : null,
      name: s && s.me ? s.me.name || null : null
    }, location.origin);
  } catch (e) { /* yok say */ }
}
function notifyParentError(res) {
  if (!IN_FRAME) return;
  try {
    window.parent.postMessage({
      type: 'pp-error',
      slot: SLOT,
      error: res && typeof res.error === 'string' ? res.error : 'UNKNOWN',
      message: res && typeof res.message === 'string' ? res.message : t('shell.err.unknown')
    }, location.origin);
  } catch (e) { /* yok say */ }
}

// ---- Socket ----
let socket = null;
const ACK_TIMEOUT_MS = 8000;
const ROOM_ENTRY = ['room:create', 'room:join', 'room:rejoin'];

// Oda dışına düşünce (ayrıl, kapandı, çıkarıldı) yerel durumu temizle
function dropRoom() {
  session.clear();
  setState(null);
  notifyParent(null);
}

// emit → Promise<ack>; ack her zaman { ok, error?, message? } biçiminde döner
export function emit(event, payload = {}) {
  return new Promise((resolve) => {
    if (!socket || !socket.connected) {
      resolve({ ok: false, error: 'OFFLINE', message: t('shell.err.offline') });
      return;
    }
    // oda giriş olaylarına oyuncunun dili eklenir
    if (ROOM_ENTRY.includes(event) && payload && typeof payload === 'object' && !payload.lang) payload = { ...payload, lang: getLang() };
    let done = false;
    const timer = setTimeout(() => {
      if (done) return;
      done = true;
      resolve({ ok: false, error: 'TIMEOUT', message: t('shell.err.timeout') });
    }, ACK_TIMEOUT_MS);
    socket.emit(event, payload, (res) => {
      if (done) return;
      done = true;
      clearTimeout(timer);
      const ack = res && typeof res === 'object' ? res : { ok: false, error: 'UNKNOWN', message: t('shell.err.unknown') };
      if (ack.ok && (event === 'room:create' || event === 'room:join' || event === 'room:rejoin') && ack.code && ack.playerId) {
        session.save(ack.code, ack.playerId);
      }
      if (event === 'room:leave') dropRoom();
      resolve(ack);
    });
  });
}

// Demo: otomatik giriş (yalnız ilk bağlantıda bir kez)
let autoPending = !!AUTO_MODE;
let autoRoleTried = !AUTO_ROLE;
async function runAuto() {
  if (AUTO_NAME) prefs.set('name', AUTO_NAME);
  let res;
  if (AUTO_MODE === 'create') {
    res = await emit('room:create', { name: AUTO_NAME, lang: getLang() });
  } else {
    if (!AUTO_CODE) {
      res = { ok: false, error: 'BAD_REQUEST', message: t('shell.err.codeRequired') };
    } else {
      res = await emit('room:join', { code: AUTO_CODE, name: AUTO_NAME, lang: getLang() });
    }
  }
  if (!res.ok) {
    notifyParentError(res);
    fire('error', res);
  }
}
async function maybeAutoRole(s) {
  if (autoRoleTried || !s || s.phase !== 'lobby' || !s.me || s.me.role) return;
  autoRoleTried = true;
  const res = await emit('role:select', { role: AUTO_ROLE });
  if (!res.ok) {
    notifyParentError(res);
    fire('error', res);
  }
}

export function connect() {
  if (socket) return socket;
  if (typeof window.io !== 'function') {
    setConn('offline');
    fire('error', { ok: false, error: 'NO_SOCKET', message: t('shell.err.noSocket') });
    return null;
  }
  socket = window.io();

  socket.on('connect', async () => {
    setConn('online');
    const s = session.load();
    const firstAuto = autoPending;
    autoPending = false;
    if (!s) {
      if (firstAuto) runAuto();
      return;
    }
    const res = await emit('room:rejoin', { code: s.code, playerId: s.playerId, lang: getLang() });
    if (!res.ok) {
      dropRoom();
      if (res.message) fire('error', res);
      if (firstAuto) runAuto();
    }
  });
  socket.on('disconnect', () => setConn('offline'));
  socket.io.on('reconnect_attempt', () => { if (conn !== 'online') setConn('offline'); });

  socket.on('state', (s) => {
    if (!s || typeof s !== 'object') return;
    setState(s);
    maybeAutoRole(s);
    notifyParent(s);
  });
  socket.on('chat:message', (m) => fire('chat:message', m));
  socket.on('room:closed', (p) => {
    dropRoom();
    fire('room:closed', p || {});
  });
  socket.on('kicked', (p) => {
    dropRoom();
    fire('kicked', p || {});
  });
  return socket;
}

// ---- Dil değişimi: odadaysak sunucuya bildir (yeni `state` oyuncunun dilinde gelir) ----
onLang(async (lang) => {
  fire('lang', lang);
  if (!state || !state.phase || !socket || !socket.connected) return;
  const res = await emit('player:lang', { lang });
  if (!res.ok && res.message) fire('error', res);
});
