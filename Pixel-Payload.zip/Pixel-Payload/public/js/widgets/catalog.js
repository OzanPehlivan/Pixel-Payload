// Mühendis ekipman kataloğu — KARAR odaklı: her kategori bir karar kartı, seçenekler yan yana kıyaslanır
// (aynı satırlarda aynı ölçüler + "en hafif / en çok yer kaplar" gibi kısa artı/eksi). Standart donanım
// (auto) ayrı, kilitli bir satırda. canAdd sonucu sunucudan gelir; istemci yalnız kendi gördüğü sayıları kıyaslar.
import { h, categoryName, smart, num, pct, REF_CLASS, upper, itemIcon, tagName, trTags } from './util.js';
import { t } from '../i18n.js';

// Gösterilecek sayısal alanlar (etiket, birim)
export const FIELDS = [
  ['massKg', 'Kütle', 'kg'], ['thrustN', 'İtki', 'N'], ['ispS', 'Özgül itki (Isp)', 's'], ['propellantKg', 'Yakıt', 'kg'],
  ['powerGenW', 'Güç üretimi', 'W'], ['powerW', 'Güç tüketimi', 'W'], ['batteryWh', 'Batarya', 'Wh'],
  ['dataRateBps', 'Veri hızı', 'bps'], ['dataGenMbPerSol', 'Veri üretimi', 'Mb/sol'], ['scienceValue', 'Bilim değeri', ''],
];
// etiket (indis 1) her okumada geçerli dilde
for (const row of FIELDS) { const k = row[0]; Object.defineProperty(row, 1, { get: () => t(`work.field.${k}`), enumerable: true }); }

// Kıyas ölçüleri: yön (+1 büyük iyi, -1 küçük iyi, 0 yön yok) ve artı/eksi etiketleri
const COMPARE = [
  { k: 'massKg', label: 'Kütle', unit: 'kg', dir: -1, best: 'En hafif', worst: 'En ağır' },
  { k: 'thrustN', label: 'İtki', unit: 'N', dir: 1, best: 'En güçlü itki', worst: 'En zayıf itki' },
  { k: 'ispS', label: 'Verim (Isp)', unit: 's', dir: 1, best: 'En verimli', worst: 'En az verimli' },
  { k: 'propellantKg', label: 'Yakıt', unit: 'kg', dir: 0 },
  { k: 'powerGenW', label: 'Güç üretimi', unit: 'W', dir: 1, best: 'En çok güç üretir', worst: 'En az güç üretir' },
  { k: 'powerW', label: 'Güç ihtiyacı', unit: 'W', dir: -1, best: 'En az güç ister', worst: 'En çok güç ister' },
  { k: 'batteryWh', label: 'Batarya', unit: 'Wh', dir: 1, best: 'En büyük batarya', worst: 'En küçük batarya' },
  { k: 'dataRateBps', label: 'Veri hızı', unit: 'bps', dir: 1, best: 'En hızlı veri', worst: 'En yavaş veri' },
  { k: 'dataGenMbPerSol', label: 'Veri üretimi', unit: 'Mb/sol', dir: 1, best: 'En çok veri', worst: 'En az veri' },
  { k: 'scienceValue', label: 'Bilim değeri', unit: '', dir: 1, best: 'En çok bilim', worst: 'En az bilim' },
  { k: 'reliability', label: 'Güvenilirlik', unit: '%', dir: 1, best: 'En güvenilir', worst: 'En az güvenilir' },
  { k: 'volumeU', label: 'Alan', unit: 'U', dir: -1, best: 'En az yer kaplar', worst: 'En çok yer kaplar' },
];
// etiketler geçerli dilde (work.cmp.<k>, .best, .worst)
for (const c of COMPARE) {
  Object.defineProperty(c, 'label', { get: () => t(`work.cmp.${c.k}`) });
  Object.defineProperty(c, 'best', { get: () => t(`work.cmp.${c.k}.best`) });
  Object.defineProperty(c, 'worst', { get: () => t(`work.cmp.${c.k}.worst`) });
}
const isNum = (v) => typeof v === 'number' && Number.isFinite(v);
function fmtField(k, unit, v) {
  if (!isNum(v)) return '—';
  if (k === 'reliability') return pct(v * 100, 1);
  if (unit === 'U') return `${num(v)} U`;
  if (unit === 'Mb/sol') return `${num(v)} Mb/sol`;
  return unit ? smart(v, unit) : num(v);
}

const BLOCK_TEXT = {
  CATEGORY_FULL: 'Bu kategori dolu', DUPLICATE: 'Zaten takılı', INCOMPATIBLE: 'Takılı bir parçayla uyumsuz', WRONG_MODULE: 'Bu modüle uymaz',
  WRONG_MISSION: 'Bu göreve uygun değil', NOT_ALLOWED: 'Başka ekibin parçası', INVALID_ITEM: 'Geçersiz parça', MISSING_REQUIREMENT: 'Gereksinim eksik',
  NO_SPACE: 'Modülde yer yok', LOCKED: 'Standart donanım',
};
for (const code of Object.keys(BLOCK_TEXT)) Object.defineProperty(BLOCK_TEXT, code, { get: () => t(`work.block.${code}`) });

// Sekmeler: modül kategori tanımlarındaki sıra, sonra katalogdaki diğerleri
export function categoryTabs(catalog, modules) {
  const seen = new Map();
  for (const m of modules || []) {
    for (const c of m.categories || []) if (!seen.has(c.category)) seen.set(c.category, { ...c, moduleId: m.id, moduleName: m.name });
  }
  for (const it of catalog || []) if (it.category && !seen.has(it.category)) seen.set(it.category, { category: it.category, moduleId: it.module });
  return [...seen.values()].filter((c) => (catalog || []).some((it) => it.category === c.category));
}

// Karar listesi: { category, min, max, moduleId, moduleName, items, mine, standard, state:'done'|'need'|'optional' }
// Standart = veride auto işaretli kategori ya da tek seçenekli ve otomatik takılmış kategori.
export function decisionList(catalog = [], modules = [], vehicle = []) {
  return categoryTabs(catalog, modules).map((t) => {
    const items = catalog.filter((it) => it.category === t.category);
    const mine = vehicle.filter((v) => v.mine && v.item && v.item.category === t.category);
    const standard = t.auto === true || t.standard === true || (items.length > 0 && items.every((i) => i.auto === true))
      || (items.length <= 1 && mine.length > 0 && mine.every((v) => v.auto));
    const min = typeof t.min === 'number' ? t.min : 0;
    const state = mine.length >= Math.max(min, 1) ? 'done' : min > 0 ? 'need' : 'optional';
    return { ...t, min, items, mine, standard, state };
  });
}

// Bir kategorideki seçenekleri kıyasla: değişen ölçüler + seçenek başına artı/eksi
function compare(items) {
  const rows = COMPARE.filter((c) => items.some((i) => isNum(i[c.k])));
  const differing = rows.filter((c) => new Set(items.map((i) => (isNum(i[c.k]) ? i[c.k] : null))).size > 1);
  const show = (differing.length ? differing : rows).filter((c) => c.k !== 'volumeU').slice(0, 4);
  const notes = new Map(items.map((i) => [i.id, { pros: [], cons: [], best: new Set(), worst: new Set() }]));
  if (items.length > 1) {
    for (const c of differing) {
      if (!c.dir) continue;
      const vals = items.filter((i) => isNum(i[c.k]));
      if (vals.length < 2) continue;
      const score = (i) => i[c.k] * c.dir;
      const hi = Math.max(...vals.map(score));
      const lo = Math.min(...vals.map(score));
      for (const i of vals) {
        const n = notes.get(i.id);
        if (score(i) === hi) { n.pros.push(c.best); n.best.add(c.k); } else if (score(i) === lo) { n.cons.push(c.worst); n.worst.add(c.k); }
      }
    }
  }
  return { rows: show, notes };
}

// Karar şeridi: her karar bir düğme (durum ikonu + ad + sayı)
function decisionNav(kit, decisions, active, onTab) {
  return h('div', { class: 'ad-dnav', role: 'tablist', 'aria-label': t('work.dec.aria') }, decisions.map((d) => {
    const ic = d.state === 'done' ? 'check' : d.state === 'need' ? 'warn' : null;
    const lim = typeof d.max === 'number' && d.max > 1 ? `${d.mine.length}/${d.max}` : '';
    return h('button', {
      type: 'button', role: 'tab', class: ['ad-dnav__btn', `is-${d.state}`, d.category === active && 'is-active'],
      'aria-selected': d.category === active ? 'true' : 'false', data: { fk: `tab:${d.category}` },
      title: t(d.state === 'need' ? 'work.dec.needTitle' : d.state === 'optional' ? 'work.dec.optTitle' : 'work.dec.doneTitle'),
      on: { click: () => onTab(d.category) },
    }, ic ? kit.icon(ic) : h('span', { class: 'ad-dnav__dot', 'aria-hidden': 'true' }),
    h('span', { text: categoryName(d.category) }), lim ? h('span', { class: 'ad-dnav__n', text: lim }) : null);
  }));
}

// Tek karar kartı: seçenekler yan yana
function decisionCard(kit, d, o) {
  const { rows, notes } = compare(d.items);
  const max = typeof d.max === 'number' ? d.max : null;
  const swapFrom = max === 1 && d.mine.length === 1 && !d.mine[0].auto ? d.mine[0] : null;
  const stateText = d.state === 'done' ? t('work.dec.done') : d.state === 'need' ? t('work.dec.need', { n: d.min }) : t('work.dec.optional');
  const head = h('header', { class: 'ad-dcard__head' },
    h('div', { class: 'ad-dcard__title' },
      h('h3', { text: upper(categoryName(d.category)) }),
      h('p', { class: 'ad-muted', text: [d.moduleName, max && max > 1 ? t('work.dec.max', { n: max }) : null].filter(Boolean).join(' · ') })),
    h('span', { class: ['ad-dstate', `is-${d.state}`], text: stateText }));

  const opts = h('div', { class: 'ad-opts', role: 'list' }, d.items.map((it) => {
    const ca = it.canAdd;
    const n = notes.get(it.id);
    const installed = d.mine.filter((v) => v.item && v.item.id === it.id);
    const canSwap = o.design && swapFrom && !installed.length && ca && ca.ok === false && ca.error === 'CATEGORY_FULL';
    const blocked = o.design && !installed.length && !canSwap && ca && ca.ok === false;
    const selected = it.id === o.selectedId;
    let action = null;
    if (o.design) {
      if (installed.length) {
        const locked = installed.every((v) => v.auto);
        action = locked ? h('span', { class: 'ad-badge is-info', text: t('work.dec.locked') })
          : kit.button({ label: t('work.dec.remove'), variant: 'ghost', small: true, fk: `rm:${it.id}`, ariaLabel: t('work.dec.removeAria', { name: it.name }),
            onClick: () => o.onRemove(installed.find((v) => !v.auto)) });
      } else if (canSwap) {
        action = kit.button({ label: t('work.dec.swap'), sub: t('work.dec.swapSub', { name: swapFrom.item.name }), variant: 'primary', small: true,
          fk: `swap:${it.id}`, ariaLabel: t('work.dec.swapAria', { name: it.name }), onClick: () => o.onSwap(it, swapFrom) });
      } else {
        action = kit.button({ label: t('work.dec.add'), variant: blocked ? 'ghost' : 'primary', small: true, disabled: blocked, fk: `add:${it.id}`,
          ariaLabel: t('work.dec.addAria', { name: it.name }), onClick: () => o.onAdd(it) });
      }
    }
    return h('article', { role: 'listitem', class: ['ad-opt', selected && 'is-selected', installed.length && 'is-installed', blocked && 'is-blocked'] },
      h('button', {
        type: 'button', class: 'ad-opt__pick', data: { fk: `pick:${it.id}` }, 'aria-pressed': selected ? 'true' : 'false',
        on: { click: () => o.onSelect(it.id) },
      },
      h('span', { class: 'ad-opt__icon' }, kit.icon(itemIcon(it.icon))),
      h('span', { class: 'ad-opt__name', text: it.name || it.id }),
      installed.length ? h('span', { class: 'ad-opt__on' }, kit.icon('check'), installed.length > 1 ? t('work.dec.installedN', { n: installed.length }) : t('work.dec.installed')) : null),
      isNum(it.volumeU) ? h('span', { class: ['ad-vol', n.best.has('volumeU') && 'is-best', n.worst.has('volumeU') && 'is-worst'], title: t('work.dec.volTitle') },
        h('b', { text: num(it.volumeU) }), ' U') : null,
      rows.length ? h('dl', { class: 'ad-opt__stats' }, rows.map((c) => [
        h('dt', { text: c.label }),
        h('dd', { class: [n.best.has(c.k) && 'is-best', n.worst.has(c.k) && 'is-worst'], text: fmtField(c.k, c.unit, it[c.k]) })])) : null,
      n.pros.length || n.cons.length ? h('ul', { class: 'ad-tradeoffs' },
        n.pros.slice(0, 3).map((t) => h('li', { class: 'is-pro', text: `+ ${t}` })),
        n.cons.slice(0, 2).map((t) => h('li', { class: 'is-con', text: `− ${t}` }))) : null,
      blocked ? h('p', { class: ['ad-opt__why', ca.error === 'NO_SPACE' && 'is-space'] }, kit.icon('warn'),
        h('span', { text: trTags(ca.reason) || BLOCK_TEXT[ca.error] || t('work.block.default') })) : null,
      action);
  }));
  return h('section', { class: 'ad-dcard', 'aria-label': t('work.dec.cardAria', { cat: categoryName(d.category) }) }, head, opts);
}

// Standart donanım: otomatik takılı, çıkarılamaz; tek sade satır
export function standardRow(kit, decisions, vehicle = []) {
  const autoMine = vehicle.filter((v) => v.mine && v.auto);
  const names = autoMine.map((v) => (v.item && v.item.name) || v.uid);
  const extra = decisions.filter((d) => d.standard && !d.mine.length).map((d) => categoryName(d.category));
  if (!names.length && !extra.length) return null;
  return h('details', { class: 'ad-std' },
    h('summary', null, kit.icon('shield'),
      h('b', { text: t('work.std.title') }),
      h('span', { class: 'ad-muted', text: t('work.std.count', { n: names.length }) })),
    h('ul', { class: 'ad-std__list' },
      autoMine.map((v) => h('li', null, kit.icon(itemIcon(v.item && v.item.icon)),
        h('span', { text: (v.item && v.item.name) || v.uid }),
        h('small', { class: 'ad-muted', text: [categoryName(v.item && v.item.category), isNum(v.volumeU) && v.volumeU > 0 ? `${num(v.volumeU)} U` : null].filter(Boolean).join(' · ') }))),
      extra.map((c) => h('li', null, kit.icon('clock'), h('span', { text: c }), h('small', { class: 'ad-muted', text: t('work.std.later') })))),
    h('p', { class: 'ad-hint', text: t('work.std.hint') }));
}

// Ana katalog görünümü: karar şeridi + aktif karar kartı + standart donanım
// o: { catalog, modules, vehicle, tab, selectedId, design, onTab, onSelect, onAdd, onRemove, onSwap }
export function catalogView(kit, o) {
  const { catalog = [], modules = [], vehicle = [], design } = o;
  const all = decisionList(catalog, modules, vehicle);
  const decisions = all.filter((d) => !d.standard);
  if (!decisions.length) {
    return h('div', { class: 'ad-catalog' },
      h('p', { class: 'ad-empty', text: catalog.length ? t('work.dec.allStandard') : t('work.dec.noCatalog') }),
      standardRow(kit, all, vehicle));
  }
  const active = decisions.find((d) => d.category === o.tab) || decisions[0];
  const req = decisions.filter((d) => d.min > 0);
  const done = req.filter((d) => d.state === 'done').length;
  return h('div', { class: 'ad-catalog' },
    h('div', { class: 'ad-dprog' },
      h('span', { class: 'ad-dprog__k', text: t('work.dec.required') }),
      h('b', { class: done === req.length ? 'is-ok' : '', text: `${done} / ${req.length}` }),
      h('span', { class: 'ad-muted', text: t('work.dec.optionalN', { n: decisions.length - req.length }) })),
    decisionNav(kit, decisions, active.category, o.onTab),
    decisionCard(kit, active, { ...o, design }),
    standardRow(kit, all, vehicle));
}

// Seçili parçanın tüm sayıları + kaynak sınıfı (refs)
export function itemDetail(kit, item) {
  if (!item) return h('p', { class: 'ad-empty', text: t('work.det.empty') });
  const refs = item.refs || {};
  const rows = [];
  if (isNum(item.volumeU)) {
    rows.push(h('div', { class: 'ad-spec' }, h('span', { class: 'ad-spec__k', text: t('work.det.volume') }),
      h('span', { class: 'ad-spec__v', text: `${num(item.volumeU)} U` })));
  }
  for (const [k, label, unit] of FIELDS) {
    if (typeof item[k] !== 'number') continue;
    const ref = refs[k];
    const cls = ref && REF_CLASS[ref.class];
    rows.push(h('div', { class: 'ad-spec' },
      h('span', { class: 'ad-spec__k', text: label }),
      h('span', { class: 'ad-spec__v', text: unit === 'Mb/sol' ? `${num(item[k])} Mb/sol` : unit ? smart(item[k], unit) : num(item[k]) }),
      cls ? h('span', { class: ['ad-src', `is-${cls.tone}`], title: ref.note || undefined, text: cls.label }) : null));
  }
  if (typeof item.reliability === 'number') {
    const ref = refs.reliability && REF_CLASS[refs.reliability.class];
    rows.push(h('div', { class: 'ad-spec' }, h('span', { class: 'ad-spec__k', text: t('work.det.reliability') }),
      h('span', { class: 'ad-spec__v', text: pct(item.reliability * 100, 1) }),
      ref ? h('span', { class: ['ad-src', `is-${ref.tone}`], text: ref.label }) : null));
  }
  if (Array.isArray(item.tempRangeC) && item.tempRangeC.length === 2) {
    rows.push(h('div', { class: 'ad-spec' }, h('span', { class: 'ad-spec__k', text: t('work.det.temp') }),
      h('span', { class: 'ad-spec__v', text: `${num(item.tempRangeC[0])} … ${num(item.tempRangeC[1])} °C` })));
  }
  const ls = item.lifeSupport;
  if (ls && (ls.o2Kg || ls.waterKg || ls.co2ScrubPersonDays)) {
    rows.push(h('div', { class: 'ad-spec' }, h('span', { class: 'ad-spec__k', text: t('work.det.life') }),
      h('span', { class: 'ad-spec__v', text: [ls.o2Kg && `O₂ ${num(ls.o2Kg)} kg`, ls.waterKg && t('work.det.water', { v: num(ls.waterKg) }), ls.co2ScrubPersonDays && t('work.det.co2', { v: num(ls.co2ScrubPersonDays) })].filter(Boolean).join(' · ') })));
  }
  const e = item.edl;
  if (e && (e.maxHeatFluxWcm2 || e.dragArea || e.maxMach)) {
    rows.push(h('div', { class: 'ad-spec' }, h('span', { class: 'ad-spec__k', text: 'EDL' }),
      h('span', { class: 'ad-spec__v', text: [e.maxHeatFluxWcm2 && t('work.det.edlFlux', { v: num(e.maxHeatFluxWcm2) }), e.dragArea && t('work.det.edlDrag', { v: num(e.dragArea, 1) }), e.maxMach && `Mach ${num(e.maxMach, 1)}`].filter(Boolean).join(' · ') })));
  }
  const tagList = (arr) => (arr || []).map((t) => h('span', { class: 'ad-tagchip', title: t, text: tagName(t) }));
  const inc = (item.incompatibleWith || []).filter((x) => x && x.reason);
  const usedRefs = Object.values(refs).filter((r) => r && r.class);
  return h('div', { class: 'ad-detail' },
    h('div', { class: 'ad-detail__head' },
      h('span', { class: 'ad-detail__icon' }, kit.icon(itemIcon(item.icon))),
      h('div', null, h('h3', { class: 'ad-detail__name', text: item.name }), h('p', { class: 'ad-muted', text: categoryName(item.category) }))),
    item.desc ? h('p', { class: 'ad-detail__desc', text: trTags(item.desc) }) : null,
    h('div', { class: 'ad-specs' }, rows),
    item.provides && item.provides.length ? h('div', { class: 'ad-detail__tags' }, h('span', { class: 'ad-muted', text: t('work.det.provides') }), tagList(item.provides)) : null,
    item.requires && item.requires.length ? h('div', { class: 'ad-detail__tags' }, h('span', { class: 'ad-muted', text: t('work.det.requires') }), tagList(item.requires)) : null,
    inc.length ? h('ul', { class: 'ad-detail__inc' }, inc.map((x) => h('li', null, kit.icon('warn'), h('span', { text: trTags(x.reason) })))) : null,
    usedRefs.length ? h('p', { class: 'ad-detail__note' }, t('work.det.sources'),
      [...new Set(usedRefs.map((r) => r.class))].map((c) => (REF_CLASS[c] ? REF_CLASS[c].label : upper(c))).join(' · '),
      t('work.det.model')) : null);
}

// Takılı ekipmanım (standart donanım kilitli, ÇIKAR yok)
export function installedList(kit, o) {
  const mine = (o.vehicle || []).filter((v) => v.mine);
  if (!mine.length) return h('p', { class: 'ad-empty', text: t('work.inst.empty') });
  const modName = (id) => ((o.modules || []).find((m) => m.id === id) || {}).name || id;
  return h('ul', { class: 'ad-installed' }, mine.map((v) => h('li', { class: ['ad-installed__row', v.auto && 'is-auto'] },
    h('span', { class: 'ad-installed__icon' }, kit.icon(itemIcon(v.item && v.item.icon))),
    h('span', { class: 'ad-installed__txt' },
      h('b', { text: (v.item && v.item.name) || v.uid }),
      h('small', { text: [modName(v.moduleId), categoryName(v.item && v.item.category), isNum(v.volumeU) && v.volumeU > 0 ? `${num(v.volumeU)} U` : null].filter(Boolean).join(' · ') })),
    v.auto ? h('span', { class: 'ad-badge is-info', text: t('work.inst.std') })
      : o.design ? kit.button({ label: t('work.dec.remove'), variant: 'nogo', small: true, fk: `rm:${v.uid}`, ariaLabel: t('work.dec.removeAria', { name: v.item && v.item.name }), onClick: () => o.onRemove(v) }) : null)));
}
