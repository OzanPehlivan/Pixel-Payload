// Ortak 2B araç görünümü. AE'nin createVehicleScene'i varsa onu kullanır; yoksa (ya da hata verirse)
// modülleri dikey yığın olarak gösteren sade bir yedek çizer. Takılı parçalar rol renginde.
// Aşama 8: altında modül KAPASİTE yuvaları (kendi / diğer / boş bloklar). Kapasite `v.capacity`'den,
// verilmediyse sunucu durumundaki `capacity`'den okunur (operatör/inceleme çağrıları değişmeden çalışır).
import { h, refill, ROLE_SHORT, categoryName, num } from './util.js';
import { getState } from '../core.js';
import { t } from '../i18n.js';

// set() alanları: { missionId, modules:[{id,name,role}], items: state.vehicle, highlightModule?, mineRole?,
//   capacity?: state.capacity, preview?: { moduleId, volumeU, name } }
export function mountVehicle(container, api, opts = {}) {
  const host = h('div', { class: 'ad-vehicle' });
  const fallback = h('ol', { class: 'ad-stack', 'aria-label': t('work.veh.aria') });
  const bays = h('div', { class: 'ad-bays', hidden: true });
  container.append(host);
  host.append(bays);
  let scene = null;
  let last = null;
  let clickFn = opts.onModuleClick || null;
  let alive = true;
  const seen = new Set(); // önceden görülen parça uid'leri (yeni takılan blok kısa animasyonla gelir)
  let firstBays = true;

  function clickable(el, id, label) {
    if (!clickFn) return el;
    el.tabIndex = 0;
    el.setAttribute('role', 'button');
    if (label) el.setAttribute('aria-label', label);
    el.addEventListener('click', () => clickFn(id));
    el.addEventListener('keydown', (e) => { if (e.key === 'Enter' || e.key === ' ') { e.preventDefault(); clickFn(id); } });
    return el;
  }

  function drawFallback(v) {
    if (!fallback.isConnected) host.prepend(fallback);
    const mods = (v.modules || []).slice().reverse(); // üstte son modül (araç burnu yukarı)
    refill(fallback, mods.map((m) => {
      const items = (v.items || []).filter((it) => it.moduleId === m.id);
      const hi = v.highlightModule === m.id || (v.mineRole && m.role === v.mineRole);
      const head = h('div', { class: 'ad-stack__head' },
        h('span', { class: 'ad-stack__name', text: m.name || m.id }),
        m.role ? h('span', { class: ['ad-stack__owner', `ad-c-${m.role}`], text: ROLE_SHORT[m.role] || m.role }) : null);
      const body = h('div', { class: 'ad-stack__items' },
        items.length
          ? items.map((it) => h('span', {
            class: ['ad-chip', `ad-chip--${it.role}`, it.mine && 'is-mine'],
            title: it.item && it.item.category ? categoryName(it.item.category) : undefined,
            text: (it.item && it.item.name) || '?',
          }))
          : h('span', { class: 'ad-stack__empty', text: t('work.veh.empty') }));
      return clickable(h('li', { class: ['ad-stack__mod', hi && 'is-hi', !items.length && 'is-empty'] }, head, body), m.id);
    }));
  }

  // Kapasite verisi: önce çağıranın verdiği, yoksa sunucu durumundaki
  function capacityOf(v) {
    if (v.capacity && typeof v.capacity === 'object') return v.capacity;
    try { const st = getState(); return (st && st.capacity) || null; } catch { return null; }
  }

  // Tek modül yuvası: blok genişliği = parça hacmi (U). Kendi rolüm dolu renk, diğerleri soluk, boş kesik.
  function bay(v, m, cap) {
    const mine = v.mineRole || null;
    const items = (v.items || []).filter((it) => it.moduleId === m.id && (it.volumeU || 0) > 0);
    const used = typeof cap.usedU === 'number' ? cap.usedU : items.reduce((s, it) => s + (it.volumeU || 0), 0);
    const limit = typeof cap.capacityU === 'number' && cap.capacityU > 0 ? cap.capacityU : null;
    const free = limit === null ? null : (typeof cap.freeU === 'number' ? cap.freeU : Math.max(0, limit - used));
    const listed = items.reduce((s, it) => s + (it.volumeU || 0), 0);
    const pv = v.preview && v.preview.moduleId === m.id && (v.preview.volumeU || 0) > 0 ? v.preview : null;
    const pvFits = pv && (free === null || pv.volumeU <= free);
    const hi = v.highlightModule === m.id;
    const mineU = typeof cap.mineU === 'number' ? cap.mineU : items.filter((it) => it.mine).reduce((s, it) => s + (it.volumeU || 0), 0);

    const blocks = items.map((it) => {
      const isNew = !firstBays && !seen.has(it.uid);
      const own = mine ? it.role === mine : true;
      const name = (it.item && it.item.name) || '?';
      return h('span', {
        class: ['ad-blk', `ad-blk--${it.role}`, own ? 'is-own' : 'is-other', it.auto && 'is-auto', isNew && 'is-new'],
        style: { flexGrow: String(it.volumeU) },
        title: `${name} · ${num(it.volumeU)} U${it.auto ? t('work.veh.std') : ''}${!own ? ` · ${ROLE_SHORT[it.role] || it.role}` : ''}`,
      }, h('span', { class: 'ad-blk__t', text: `${num(it.volumeU)}U` }));
    });
    if (used > listed) blocks.push(h('span', { class: ['ad-blk', 'is-other'], style: { flexGrow: String(used - listed) }, title: t('work.veh.other', { n: num(used - listed) }) }));
    if (pv) {
      const g = limit === null ? pv.volumeU : Math.min(pv.volumeU, Math.max(free, 0));
      if (g > 0) blocks.push(h('span', { class: ['ad-blk', 'is-ghost', !pvFits && 'is-over'], style: { flexGrow: String(g) }, title: `${pv.name || t('work.veh.selPart')} · ${num(pv.volumeU)} U` },
        h('span', { class: 'ad-blk__t', text: `+${num(pv.volumeU)}U` })));
    }
    const freeLeft = free === null ? 0 : Math.max(0, free - (pv && pvFits ? pv.volumeU : 0));
    if (freeLeft > 0) blocks.push(h('span', { class: ['ad-blk', 'is-free'], style: { flexGrow: String(freeLeft) }, title: t('work.veh.free', { n: num(freeLeft) }) }));

    const pct = limit ? used / limit : 0;
    const state = limit === null ? 'is-open' : free <= 0 ? 'is-full' : pct >= 0.85 ? 'is-tight' : '';
    const shared = new Set(items.map((it) => it.role)).size > 1 || (mine && mineU < used && mineU > 0);
    const el = h('div', { class: ['ad-bay', state, hi && 'is-hi'] },
      h('div', { class: 'ad-bay__head' },
        h('span', { class: 'ad-bay__name', text: cap.name || m.name || m.id }),
        shared ? h('span', { class: 'ad-bay__shared', text: t('work.veh.shared') }) : null,
        h('span', { class: 'ad-bay__num' },
          limit === null ? h('span', { text: t('work.veh.noLimit') })
            : [h('b', { text: num(used) }), ` / ${num(limit)} U`,
              h('span', { class: 'ad-bay__free', text: free > 0 ? t('work.veh.freeN', { n: num(free) }) : t('work.veh.full') })])),
      limit === null && !blocks.length ? null : h('div', { class: 'ad-bay__bar', role: 'img',
        'aria-label': limit === null ? t('work.veh.ariaNoLimit', { name: m.name })
          : t('work.veh.ariaUsed', { name: m.name, used: num(used), limit: num(limit) }) + (mine ? t('work.veh.ariaMine', { n: num(mineU) }) : '') }, blocks),
      pv && !pvFits ? h('p', { class: 'ad-bay__warn', text: t('work.veh.noFit', { name: pv.name || t('work.veh.selPart'), need: num(pv.volumeU), free: num(Math.max(free, 0)) }) }) : null);
    return clickable(el, m.id, t('work.veh.module', { name: m.name || m.id }));
  }

  function drawBays(v) {
    const cap = capacityOf(v);
    const mods = (v.modules || []).filter((m) => cap && cap[m.id]);
    if (!mods.length) {
      bays.hidden = true; bays.replaceChildren();
      for (const it of v.items || []) seen.add(it.uid);
      firstBays = false;
      return;
    }
    bays.hidden = false;
    const legend = h('div', { class: 'ad-bays__legend', 'aria-hidden': 'true' },
      v.mineRole ? h('span', { class: ['ad-lg', `ad-lg--${v.mineRole}`] }, t('work.veh.mine')) : null,
      h('span', { class: ['ad-lg', v.mineRole ? 'ad-lg--other' : 'ad-lg--roles'] }, v.mineRole ? t('work.veh.others') : t('work.veh.teams')),
      h('span', { class: 'ad-lg ad-lg--free' }, t('work.veh.freeLg')));
    refill(bays, h('div', { class: 'ad-bays__top' }, h('h3', { class: 'ad-tgroup__title', text: t('work.veh.title') }), legend),
      mods.map((m) => bay(v, m, cap[m.id])));
    for (const it of v.items || []) seen.add(it.uid);
    firstBays = false;
  }

  function apply() {
    if (!last) return;
    drawBays(last);
    if (scene) {
      try {
        scene.setVehicle({ missionId: last.missionId, modules: last.modules, items: last.items, highlightModule: last.highlightModule });
        return;
      } catch { scene = null; }
    }
    drawFallback(last);
  }

  // Sahneyi tembel yükle; yoksa yedekle devam
  (async () => {
    let mod = null;
    try { mod = typeof api.scene === 'function' ? await api.scene() : null; } catch { mod = null; }
    if (!alive || !mod || typeof mod.createVehicleScene !== 'function') return;
    try {
      const box = h('div', { class: 'ad-vehicle__scene' });
      host.prepend(box);
      scene = mod.createVehicleScene(box);
      if (scene && typeof scene.onModuleClick === 'function' && clickFn) scene.onModuleClick((id) => clickFn && clickFn(id));
      fallback.remove();
      apply();
    } catch { scene = null; }
  })();

  return {
    set(v) { last = v; apply(); },
    onModuleClick(fn) { clickFn = fn; },
    destroy() {
      alive = false;
      try { scene && scene.dispose && scene.dispose(); } catch { /* yok say */ }
      host.remove();
    },
  };
}
