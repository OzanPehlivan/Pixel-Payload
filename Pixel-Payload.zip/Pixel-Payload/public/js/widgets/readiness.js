// Hazırlık kalemleri listesi. Sunucunun verdiği kalemleri olduğu gibi çizer; her kalem TÜRÜYLE rozetlenir
// (Hazır / Eksik / Riskli / Fiziksel yetersiz / Bütçe). Tür yoksa durumdan türetilir (geri uyum).
// cascadeFrom'lu kalemler "BAŞKA EKİPTEN ETKİ" rozetiyle; sayı yalnız sunucu gönderdiyse görünür.
import { h, ROLE_SHORT, withUnit, num, trTags } from './util.js';
import { t, locale } from '../i18n.js';

// Tür adları (AI'nin operatör/inceleme ekranları da kullanır). Dil duyarlı getter'lar: her okumada geçerli dil.
export const KIND_TR = {};
for (const k of ['ok', 'missing', 'risky', 'physical', 'budget']) {
  Object.defineProperty(KIND_TR, k, { get: () => t(`work.kind.${k}`), enumerable: true });
}
// Tür → ton ve ikon (renk tek başına anlam taşımasın diye ikon + etiket)
export const KIND_TONE = { ok: 'ok', missing: 'warn', risky: 'warn', physical: 'bad', budget: 'info' };
const KIND_ICON = { ok: 'check', missing: 'warn', risky: 'warn', physical: 'cross', budget: 'chart' };
const KINDS = ['physical', 'missing', 'risky', 'budget', 'ok'];

// Kalemin türü: sunucu `kind` verdiyse o; yoksa durum + metinden makul tahmin.
export function kindOf(item) {
  if (!item) return 'risky';
  if (KIND_TR[item.kind]) return item.kind;
  const st = String(item.status || '').toUpperCase();
  if (st === 'PASS') return 'ok';
  const hay = `${item.id || ''} ${item.system || ''} ${item.text || ''}`.toLocaleLowerCase(locale());
  if (/budget|bütçe|maliyet|cost/.test(hay)) return 'budget';
  if (/missing|eksik|requirement|gereksinim|kategori|category|zorunlu|required/.test(hay)) return 'missing';
  if (/Δv|delta-?v|\bdv\b|twr|itki\/ağırlık|kütle|mass|temas|touchdown|landing-speed|yakıt yetmez|not enough propellant|insufficient propellant/.test(hay)) return 'physical';
  return 'risky';
}

const ORDER = { physical: 0, missing: 1, risky: 2, budget: 3, ok: 4 };

// Tür rozeti
export function kindBadge(kit, kind) {
  const k = KIND_TR[kind] ? kind : 'risky';
  return h('span', { class: ['ad-kind', `is-${k}`] }, kit.icon(KIND_ICON[k]), h('span', { text: KIND_TR[k] }));
}

export function readinessList(kit, items, opts = {}) {
  const list = (items || []).slice().sort((a, b) =>
    ORDER[kindOf(a)] - ORDER[kindOf(b)] || (b.critical ? 1 : 0) - (a.critical ? 1 : 0));
  if (!list.length) {
    return h('p', { class: 'ad-empty', text: opts.empty || t('work.ready.empty') });
  }
  return h('ul', { class: 'ad-ready' }, list.map((r) => {
    const kind = kindOf(r);
    const cascade = Array.isArray(r.cascadeFrom) && r.cascadeFrom.length > 0;
    const hasVal = typeof r.value === 'number';
    const hasLim = typeof r.limit === 'number';
    return h('li', { class: ['ad-ready__row', `is-${String(r.status || '').toLowerCase()}`, `is-k-${kind}`] },
      kindBadge(kit, kind),
      h('div', { class: 'ad-ready__main' },
        h('div', { class: 'ad-ready__top' },
          r.system ? h('span', { class: 'ad-ready__sys', text: r.system }) : null,
          r.critical && kind !== 'ok' ? h('span', { class: 'ad-badge is-bad', text: t('work.ready.critical') }) : null,
          cascade ? h('span', { class: 'ad-badge is-cascade', text: t('work.ready.cascade', { roles: r.cascadeFrom.map((x) => ROLE_SHORT[x] || x).join(', ') }) }) : null,
          opts.showRole && r.role ? kit.roleTag(r.role) : null),
        h('p', { class: 'ad-ready__text', text: trTags(r.text || '') }),
        hasVal || hasLim ? h('p', { class: 'ad-ready__num' },
          hasVal ? h('span', { text: withUnit(r.value, r.unit, 2) }) : null,
          hasLim ? h('span', { class: 'ad-muted', text: t('work.ready.limit', { v: `${num(r.limit, 2)}${r.unit ? ' ' + r.unit : ''}` }) }) : null) : null));
  }));
}

// Durum ve tür sayıları (yalnız gelen kalemlerden sayım; kural değil). Eski alanlar korunur.
export function readinessCounts(items) {
  const c = { PASS: 0, WARN: 0, FAIL: 0, critical: 0, kinds: { ok: 0, missing: 0, risky: 0, physical: 0, budget: 0 } };
  for (const r of items || []) {
    if (c[r.status] !== undefined) c[r.status]++;
    if (r.status === 'FAIL' && r.critical) c.critical++;
    c.kinds[kindOf(r)]++;
  }
  return c;
}

// Tür sayıları şeridi: HAZIR her zaman, diğerleri yalnız varsa
export function countsStrip(kit, items) {
  const { kinds } = readinessCounts(items);
  return h('div', { class: 'ad-counts' }, KINDS.slice().reverse()
    .filter((k) => k === 'ok' || kinds[k] > 0)
    .map((k) => h('span', { class: ['ad-count', `is-${KIND_TONE[k]}`] }, kit.icon(KIND_ICON[k]), h('b', { text: kinds[k] }), h('span', { text: KIND_TR[k] }))));
}
