// Telemetri okumaları. Mühendis: yalnız sunucunun verdiği kendi alt sistemi. Operatör: birleşik telemetri.
// Hiçbir değer istemcide hesaplanmaz; yalnız biçimlenir. Metinler cmd.* sözlüğünden (lang/command.js).
import { h, smart, num, withUnit, meter } from './util.js';
import * as R from './readiness.js';
import * as U from './util.js';
import { t, upperL } from '../i18n.js';
import { tk, roleShort } from '../lang/command.js';
const trT = (x) => (typeof U.trTags === 'function' ? U.trTags(x) : x);
// readiness/util ad alanı içe aktarımı: kindOf/trTags varsa kullanılır, yoksa çökmez

// Aşama adı: görev verisi (names) > sözlük (cmd.phase.<id>) > okunur hâle getirilmiş kimlik (ham kimlik görünmesin)
const phaseLabel = (id, names) => (names && names[id]) || tk(`cmd.phase.${id}`)
  || String(id || '').replace(/[-_]+/g, ' ').replace(/^./, (x) => upperL(x));
// names: { id: ad } nesnesi ya da [{ id, name }] dizisi (ör. state.simulation.phaseList)
const toNames = (n) => (Array.isArray(n) ? Object.fromEntries(n.filter((p) => p && p.id).map((p) => [p.id, p.name])) : n || null);

// Tek okuma: etiket + büyük değer (+ isteğe bağlı ton)
function readout(label, value, tone, icon, kit) {
  return h('div', { class: ['ad-read', tone && `is-${tone}`] },
    h('span', { class: 'ad-read__label' }, icon && kit ? kit.icon(icon) : null, h('span', { text: label })),
    h('span', { class: 'ad-read__value', text: value }));
}

function group(title, ...children) {
  const kids = children.flat().filter(Boolean);
  if (!kids.length) return null;
  return h('div', { class: 'ad-tgroup' }, h('h3', { class: 'ad-tgroup__title', text: title }), h('div', { class: 'ad-reads' }, kids));
}

// Δv: her aşama için mevcut / gerekli (ikisi de sunucudan)
function dvRows(dv, names) {
  const entries = Object.entries(dv || {});
  if (!entries.length) return null;
  return h('ul', { class: 'ad-dv' }, entries.map(([id, d]) => {
    const av = d && d.available;
    const rq = d && d.required;
    const short = typeof av === 'number' && typeof rq === 'number' && av < rq;
    return h('li', { class: ['ad-dv__row', short && 'is-short'] },
      h('span', { class: 'ad-dv__name', text: phaseLabel(id, names) }),
      meter(av, rq > 0 ? Math.max(rq, av || 0) : av, short ? 'bad' : 'ok'),
      h('span', { class: 'ad-dv__val', text: `${smart(av, 'm/s')} / ${smart(rq, 'm/s')}` }));
  }));
}

const THERMAL_KEY = { PASS: 'ok', OK: 'ok', WARN: 'warn', FAIL: 'fail' };
const thermalTone = (s) => (s === 'PASS' || s === 'ok' ? 'ok' : s === 'WARN' || s === 'warn' ? 'warn' : s === 'FAIL' || s === 'fail' ? 'bad' : null);

function powerGroup(kit, p) {
  if (!p || !Object.keys(p).length) return null;
  return group(t('cmd.tel.power'),
    readout(t('cmd.tel.gen'), smart(p.genW, 'W'), null, 'power', kit),
    readout(t('cmd.tel.use'), smart(p.useW, 'W')),
    readout(t('cmd.tel.margin'), smart(p.marginW, 'W'), typeof p.marginW === 'number' ? (p.marginW < 0 ? 'bad' : 'ok') : null),
    readout(t('cmd.tel.battery'), smart(p.batteryWh, 'Wh')));
}
function thermalGroup(kit, th) {
  if (!th || !th.status) return null;
  const k = THERMAL_KEY[String(th.status).toUpperCase()];
  return group(t('cmd.tel.thermal'), h('div', { class: ['ad-read', 'ad-read--wide', `is-${thermalTone(th.status) || 'idle'}`] },
    h('span', { class: 'ad-read__label' }, kit.icon('thermo'), h('span', { text: t('cmd.tel.status') })),
    h('span', { class: 'ad-read__value', text: th.label || (k ? t(`cmd.thermal.${k}`) : String(th.status)) }),
    th.note ? h('span', { class: 'ad-read__note', text: th.note }) : null));
}
function commsGroup(kit, c, full) {
  if (!c || !Object.keys(c).length) return null;
  return group(t('cmd.tel.comms'),
    readout(t('cmd.tel.relay'), smart(c.relayBps, 'bps'), null, 'antenna', kit),
    readout(t('cmd.tel.direct'), smart(c.directBps, 'bps')),
    readout(t('cmd.tel.delay'), withUnit(c.delayS, 's', 1)),
    full && c.dataMbPerSol !== undefined ? readout(t('cmd.tel.dataGen'), withUnit(c.dataMbPerSol, 'Mb/sol', 0)) : null,
    readout(t('cmd.tel.downlink'), withUnit(c.downlinkMbPerSol, 'Mb/sol', 0)));
}
function lifeGroup(kit, l) {
  if (!l) return null;
  const day = t('cmd.unit.day');
  return group(t('cmd.tel.life'),
    readout(t('cmd.tel.crew'), t('cmd.tel.crewVal', { crew: num(l.crew), days: num(l.days) }), null, 'crew', kit),
    readout('O₂', withUnit(l.o2Days, day, 1), typeof l.o2Days === 'number' && typeof l.days === 'number' ? (l.o2Days < l.days ? 'bad' : 'ok') : null),
    readout(t('cmd.tel.water'), withUnit(l.waterDays, day, 1), typeof l.waterDays === 'number' && typeof l.days === 'number' ? (l.waterDays < l.days ? 'bad' : 'ok') : null),
    readout(t('cmd.tel.co2'), withUnit(l.co2Days, day, 1), typeof l.co2Days === 'number' && typeof l.days === 'number' ? (l.co2Days < l.days ? 'bad' : 'ok') : null));
}
function edlGroup(kit, e) {
  if (!e) return null;
  return group(t('cmd.tel.edl'),
    readout(t('cmd.tel.entry'), smart(e.entryMs, 'm/s'), null, 'shield', kit),
    readout(t('cmd.tel.heatFlux'), `${num(e.peakHeatWcm2, 1)} / ${num(e.shieldMaxWcm2, 1)} W/cm²`,
      typeof e.peakHeatWcm2 === 'number' && typeof e.shieldMaxWcm2 === 'number' ? (e.peakHeatWcm2 > e.shieldMaxWcm2 ? 'bad' : 'ok') : null),
    readout(t('cmd.tel.chuteMach'), num(e.chuteMach, 2)),
    readout(t('cmd.tel.touchdown'), withUnit(e.landingVms, 'm/s', 1)),
    e.hazard !== undefined && e.hazard !== null ? readout(t('cmd.tel.hazard'), typeof e.hazard === 'number' ? num(e.hazard, 2) : String(e.hazard)) : null);
}

const dvTitle = () => t('cmd.tel.dvTitle');

// Mühendisin kendi telemetrisi
// names (isteğe bağlı, geriye uyumlu): aşama adları; yoksa sözlük
export function engineerTelemetry(kit, role, tel, names) {
  names = toNames(names);
  if (!tel) return h('p', { class: 'ad-empty', text: t('cmd.tel.emptyEng') });
  const out = [];
  if (role === 'rocket') {
    const pr = tel.propellant || {};
    out.push(group(t('cmd.tel.propulsion'),
      readout(t('cmd.tel.myMass'), smart(tel.massKg && tel.massKg.mine, 'kg'), null, 'engine', kit),
      readout(t('cmd.tel.twrLong'), num(tel.twr, 2)),
      readout(t('cmd.tel.propCap'), smart(pr.capacityKg, 'kg'), null, 'fuel', kit),
      readout(t('cmd.tel.propLoaded'), `${smart(pr.loadedKg, 'kg')} · ${t('cmd.pct', { v: num((pr.load || 0) * 100) })}`)));
    const dv = dvRows(tel.dv, names);
    if (dv) out.push(h('div', { class: 'ad-tgroup' }, h('h3', { class: 'ad-tgroup__title', text: dvTitle() }), dv));
    if (Array.isArray(tel.stages) && tel.stages.length) {
      out.push(group(t('cmd.tel.stages'), tel.stages.map((s) => readout(phaseLabel(s.id, names), smart(s.dvMs, 'm/s')))));
    }
  } else if (role === 'spacecraft') {
    out.push(group(t('cmd.tel.structure'), readout(t('cmd.tel.myMass'), smart(tel.massKg && tel.massKg.mine, 'kg'), null, 'satellite', kit)));
    out.push(powerGroup(kit, tel.power), thermalGroup(kit, tel.thermal), commsGroup(kit, tel.comms), lifeGroup(kit, tel.lifeSupport), edlGroup(kit, tel.edl));
  } else if (role === 'payload') {
    const sc = tel.science || {};
    const ins = tel.instruments || {};
    out.push(h('div', { class: 'ad-tgroup' },
      h('h3', { class: 'ad-tgroup__title', text: t('cmd.tel.sciValue') }),
      h('div', { class: 'ad-big' }, h('b', { text: num(sc.value) }), h('span', { text: ` / ${num(sc.max)}` })),
      meter(sc.value, sc.max, 'ok')));
    out.push(group(t('cmd.tel.instruments'),
      readout(t('cmd.tel.insCount'), num(ins.count), null, 'flask', kit),
      readout(t('cmd.tel.totalMass'), smart(ins.massKg, 'kg')),
      readout(t('cmd.tel.totalPower'), smart(ins.powerW, 'W'), null, 'power', kit),
      readout(t('cmd.tel.dataProd'), withUnit(tel.dataMbPerSol, 'Mb/sol', 0))));
  }
  const kids = out.filter(Boolean);
  return kids.length ? h('div', { class: 'ad-tele' }, kids) : h('p', { class: 'ad-empty', text: t('cmd.tel.none') });
}

// Operatörün birleşik telemetrisi
export function directorTelemetry(kit, tel, mission) {
  if (!tel) return h('p', { class: 'ad-empty', text: t('cmd.tel.emptyDir') });
  const names = {};
  for (const p of (mission && mission.phases) || []) names[p.id] = p.name;
  const m = tel.massKg || {};
  const lim = (mission && mission.limits) || {};
  const out = [];
  out.push(group(t('cmd.tel.vehicle'),
    readout(t('cmd.tel.totalMass'), smart(m.total, 'kg'), typeof lim.maxLaunchMassKg === 'number' && typeof m.total === 'number' ? (m.total > lim.maxLaunchMassKg ? 'bad' : null) : null, 'rocket', kit),
    typeof lim.maxLaunchMassKg === 'number' ? readout(t('cmd.tel.massLimit'), smart(lim.maxLaunchMassKg, 'kg')) : null,
    readout('TWR', num(tel.twr, 2), typeof lim.minTWR === 'number' && typeof tel.twr === 'number' ? (tel.twr < lim.minTWR ? 'bad' : 'ok') : null),
    typeof lim.minTWR === 'number' ? readout(t('cmd.tel.minTwr'), num(lim.minTWR, 2)) : null));
  if (m.byRole) {
    out.push(group(t('cmd.tel.massByRole'), ['rocket', 'spacecraft', 'payload'].filter((r) => m.byRole[r] !== undefined)
      .map((r) => readout(t(`cmd.massRole.${r}`), smart(m.byRole[r], 'kg')))));
  }
  const dv = dvRows(tel.dv, names);
  if (dv) out.push(h('div', { class: 'ad-tgroup' }, h('h3', { class: 'ad-tgroup__title', text: dvTitle() }), dv));
  out.push(powerGroup(kit, tel.power), thermalGroup(kit, tel.thermal), commsGroup(kit, tel.comms, true), lifeGroup(kit, tel.lifeSupport), edlGroup(kit, tel.edl));
  if (tel.science) {
    out.push(group(t('cmd.tel.science'),
      readout(t('cmd.tel.sciValueShort'), `${num(tel.science.value)} / ${num(tel.science.max)}`, null, 'flask', kit),
      readout(t('cmd.tel.insCount'), num(tel.science.instruments))));
  }
  return h('div', { class: 'ad-tele' }, out.filter(Boolean));
}

export { phaseLabel };

// ---------------------------------------------------------------- Aşama 8 ekleri (Modül AI)
const ENG = ['rocket', 'spacecraft', 'payload'];

// Hazırlık türleri (etiketler dile göre; getter → her okumada güncel dil)
const KINDS = ['ok', 'missing', 'physical', 'risky', 'budget'];
export const KIND_LABEL = Object.defineProperties({}, Object.fromEntries(KINDS.map((k) => [k, { enumerable: true, get: () => t(`cmd.kind.${k}`) }])));
export const KIND_ORDER = ['physical', 'missing', 'risky', 'budget', 'ok'];
export function kindOfItem(it) {
  if (typeof R.kindOf === 'function') { try { const k = R.kindOf(it); if (KINDS.includes(k)) return k; } catch { /* yedek */ } }
  if (it && KINDS.includes(it.kind)) return it.kind;
  return it && it.status === 'PASS' ? 'ok' : 'risky';
}
export function kindCounts(items) {
  const c = { ok: 0, missing: 0, physical: 0, risky: 0, budget: 0 };
  for (const it of items || []) c[kindOfItem(it)]++;
  return c;
}

// Fırlatma durumu: sunucunun launchStatus'u; yoksa kalemlerden/overall'dan türet (geri uyum)
// label/line getter: dil değişince yeni çizimde güncel metin gelir
const launchDef = (code, tone, icon) => Object.defineProperties({ tone, icon }, {
  label: { enumerable: true, get: () => t(`cmd.launch.${code}`) },
  line: { enumerable: true, get: () => t(`cmd.launchLine.${code}`) },
});
export const LAUNCH = {
  READY: launchDef('READY', 'ok', 'check'),
  RISKY: launchDef('RISKY', 'warn', 'warn'),
  MISSING: launchDef('MISSING', 'bad', 'cross'),
  INSUFFICIENT: launchDef('INSUFFICIENT', 'bad', 'cross'),
};
// Sunucunun durum açıklaması (launchNote, oyuncunun dilinde) varsa onu, yoksa sabit metni ver
export const launchLine = (st, code) => (st && typeof st.launchNote === 'string' && st.launchNote.trim()) || (LAUNCH[code] ? LAUNCH[code].line : '');
export const LAUNCH_ORDER = ['INSUFFICIENT', 'MISSING', 'RISKY', 'READY'];
export function launchStatusOf(st, items) {
  const own = (st.director && st.director.launchStatus) || st.launchStatus;
  if (LAUNCH[own]) return own;
  const list = items || [];
  if (list.some((i) => i.status === 'FAIL' && i.critical && kindOfItem(i) === 'physical')) return 'INSUFFICIENT';
  if (list.some((i) => i.status === 'FAIL' && i.critical)) return 'MISSING';
  if (list.some((i) => i.status === 'WARN' || i.status === 'FAIL') || st.overall === 'WARN' || st.overall === 'FAIL') return 'RISKY';
  return st.overall === 'PASS' || list.length ? 'READY' : null;
}

// En dar Δv marjı (yalnız sunucu sayılarının farkı; kural değil)
export function tightestDv(dv, names) {
  let worst = null;
  for (const [id, d] of Object.entries(dv || {})) {
    if (!d || typeof d.available !== 'number' || typeof d.required !== 'number' || d.required <= 0) continue;
    const pct = (d.available - d.required) / d.required * 100;
    if (!worst || pct < worst.pct) worst = { id, name: phaseLabel(id, names), pct, av: d.available, rq: d.required };
  }
  return worst;
}

// Modül kapasitesi: rol renkli yığılı çubuk + kullanılan/boş U. capacity: {[mid]:{name,usedU,capacityU,freeU,byRole?,mineU?}}
export function capacityView(kit, capacity, opts = {}) {
  const entries = Object.entries(capacity || {});
  if (!entries.length) return opts.empty === null ? null : h('p', { class: 'ad-empty', text: opts.empty || t('cmd.cap.none') });
  return h('ul', { class: 'cc-cap' }, entries.map(([id, c]) => {
    const cap = typeof c.capacityU === 'number' && c.capacityU > 0 ? c.capacityU : null;
    const used = typeof c.usedU === 'number' ? c.usedU : 0;
    const total = cap || Math.max(used, 1);
    const full = cap !== null && used >= cap;
    const tight = cap !== null && !full && used / cap >= 0.85;
    const segs = [];
    if (c.byRole) {
      for (const r of ENG) {
        const u = c.byRole[r];
        if (typeof u === 'number' && u > 0) segs.push(h('span', { class: ['cc-cap__seg', `cc-seg--${r}`], title: `${roleShort(r)}: ${num(u)} U`, style: { width: `${Math.min(100, u / total * 100)}%` } }));
      }
    } else if (used > 0) {
      const mine = typeof c.mineU === 'number' ? Math.min(c.mineU, used) : 0;
      if (mine > 0) segs.push(h('span', { class: ['cc-cap__seg', 'cc-seg--me'], style: { width: `${mine / total * 100}%` } }));
      segs.push(h('span', { class: ['cc-cap__seg', 'cc-seg--used'], style: { width: `${Math.min(100, (used - mine) / total * 100)}%` } }));
    }
    const name = c.name || id;
    return h('li', { class: ['cc-cap__row', full && 'is-full', tight && 'is-tight'] },
      h('div', { class: 'cc-cap__head' },
        h('span', { class: 'cc-cap__name', text: name }),
        h('span', { class: 'cc-cap__val' },
          h('b', { text: num(used) }), h('span', { text: cap ? ` / ${num(cap)} U` : ` U · ${t('cmd.cap.unlimited')}` }))),
      h('div', { class: 'cc-cap__bar', role: 'img', 'aria-label': t('cmd.cap.aria', { name, used: num(used), cap: cap ? ` / ${num(cap)}` : '' }) }, segs),
      cap ? h('span', { class: 'cc-cap__free', text: full ? t('cmd.cap.full') : t('cmd.cap.free', { n: num(typeof c.freeU === 'number' ? c.freeU : cap - used) }) }) : null);
  }));
}

// Bilim hedefleri: ready / partial / missing (+ eksik etiketler). showValue yalnız operatörde.
const GOAL = { ready: { t: 'ok', i: 'check' }, partial: { t: 'warn', i: 'warn' }, missing: { t: 'idle', i: 'cross' } };
export function scienceGoalsView(kit, goals, opts = {}) {
  if (!Array.isArray(goals) || !goals.length) return null;
  return h('ul', { class: 'cc-goals' }, goals.map((g) => {
    const key = GOAL[g.status] ? g.status : 'missing';
    const s = GOAL[key];
    const miss = Array.isArray(g.missingTags) ? g.missingTags : [];
    return h('li', { class: ['cc-goal', `is-${s.t}`] },
      h('span', { class: 'cc-goal__ico' }, kit.icon(s.i)),
      h('span', { class: 'cc-goal__txt' },
        h('b', { text: g.name || g.id }),
        miss.length ? h('small', { text: t('cmd.goal.missing_tags', { list: miss.map(trT).join(', ') }) }) : (g.desc ? h('small', { text: g.desc }) : null)),
      opts.showValue && typeof g.value === 'number' ? h('span', { class: 'cc-goal__val', text: `+${num(g.value)}` }) : null,
      h('span', { class: 'cc-goal__st', text: t(`cmd.goal.${key}`) }));
  }));
}
