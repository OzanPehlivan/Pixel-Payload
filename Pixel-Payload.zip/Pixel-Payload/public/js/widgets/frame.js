// Ekran iskeleti yardımcıları: başlık şeridi, bölüm ezberleme (gereksiz yeniden çizimi önler),
// iki adımlı onay düğmesi ve tasarım süre sayacı.
import { h, refill, clock } from './util.js';
import { t } from '../i18n.js';

// Başlık şeridi: [ BÜYÜK BAŞLIK ] + alt satır + sağ öğeler
export function titleBar(title, sub, right) {
  const subEl = h('p', { class: 'ad-titlebar__sub', text: sub || '' });
  const rightEl = h('div', { class: 'ad-titlebar__right' });
  if (right) refill(rightEl, right);
  const el = h('header', { class: 'ad-titlebar' },
    h('div', { class: 'ad-titlebar__text' }, h('h1', { class: 'ad-titlebar__title', text: title }), subEl), rightEl);
  return { el, sub: subEl, right: rightEl };
}

// Bölüm: imza değişmedikçe yeniden çizilmez
export function section(el, draw) {
  let sig = null;
  return {
    el,
    render(signature, force) {
      const s = JSON.stringify(signature);
      if (!force && s === sig) return;
      sig = s;
      refill(el, draw());
    },
    reset() { sig = null; },
  };
}

// İki adımlı onay: ilk tıklamada etiketi "EMİN MİSİN?" (work.confirm) yapar, 4 sn içinde ikinci tıklama eylemi çalıştırır
export function confirmButton(kit, o) {
  let armed = false;
  let timer = null;
  const btn = kit.button({
    ...o,
    onClick: async () => {
      if (!armed) {
        armed = true;
        label.textContent = o.confirmLabel || t('work.confirm');
        btn.classList.add('is-armed');
        timer = setTimeout(disarm, 4000);
        return;
      }
      disarm();
      await o.onClick();
    },
  });
  const realBtn = btn.tagName === 'BUTTON' ? btn : btn.querySelector('button');
  const label = realBtn ? realBtn.querySelector('.btn__label, .ad-btn__label') : null;
  function disarm() {
    armed = false;
    clearTimeout(timer);
    if (label) label.textContent = o.label;
    btn.classList.remove('is-armed');
  }
  return btn;
}

// Tasarım süresi: önceki turlar + bu turun başlangıcından beri (yalnız gösterim)
export function designTimer() {
  const el = h('span', { class: 'ad-timer' });
  let base = 0;
  let start = null;
  let offset = 0;
  const tick = () => { el.textContent = clock(base + (start ? Date.now() - offset - start : 0)); };
  const iv = setInterval(tick, 1000);
  return {
    el,
    set(design) {
      base = (design && design.elapsedMs) || 0;
      // startedAt sunucu saatidir; istemci saat farkı ilk görüşte sıfırlanır (yaklaşık gösterim)
      const s = design && typeof design.startedAt === 'number' ? design.startedAt : null;
      if (s !== start) { start = s; offset = s && Date.now() < s ? Date.now() - s : 0; }
      tick();
    },
    destroy() { clearInterval(iv); },
  };
}
