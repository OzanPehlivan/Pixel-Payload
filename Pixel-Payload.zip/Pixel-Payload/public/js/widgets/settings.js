// Mühendisin kendi ayarları — tamamen `settingDefs`'ten genel çizilir (anahtar sabit kodlaması yok).
// number → kaydırıcı (bırakınca gönderir); enum/options → seçenek düğmeleri (optionInfo.label + kısa açıklama).
// Doğrulama sunucuda (validateSetting); hata toast olur ve görünüm sunucu değerine döner.
import { h, num, upper, pct } from './util.js';
import { t } from '../i18n.js';

// Seçenek bilgisi: etiket optionInfo[opt].label; açıklama desc || note || text || help
const infoOf = (d, v) => (d.optionInfo && typeof d.optionInfo === 'object' && d.optionInfo[v]) || {};
const descOf = (inf) => [inf.desc, inf.note, inf.text, inf.help].find((x) => typeof x === 'string' && x.trim()) || '';
const prettify = (v) => upper(String(v).replace(/([a-z])([A-Z])/g, '$1 $2').replace(/[-_]+/g, ' '));

function optionsOf(d) {
  const raw = Array.isArray(d.options) && d.options.length ? d.options
    : d.optionInfo && typeof d.optionInfo === 'object' && Object.keys(d.optionInfo).length ? Object.keys(d.optionInfo) : null;
  if (!raw) return null;
  return raw.map((o) => {
    if (o && typeof o === 'object') {
      const v = o.value ?? o.id;
      const inf = infoOf(d, v);
      return { value: v, label: upper(o.label || o.name || inf.label || prettify(v)), desc: descOf(o) || descOf(inf) };
    }
    const inf = infoOf(d, o);
    return { value: o, label: typeof inf.label === 'string' && inf.label ? upper(inf.label) : prettify(o), desc: descOf(inf) };
  });
}

// Değer biçimi: birimsiz 0..1 aralığı ya da '%' birimi yüzde olarak
function fmtVal(d, v) {
  if (typeof v !== 'number') return String(v ?? '—');
  const frac = !d.unit && typeof d.max === 'number' && d.max <= 1 && (d.min ?? 0) >= 0;
  if (frac) return pct(v * 100);
  if (d.unit === '%') return pct(v, 1);
  return `${num(v, 2)}${d.unit ? ' ' + d.unit : ''}`;
}

function enumSetting(d, o, cur, id, help, opts) {
  const sel = opts.find((op) => op.value === cur);
  const rich = opts.some((op) => op.desc); // açıklamalı seçenekler kart gibi çizilir
  return h('fieldset', { class: 'ad-setting', 'aria-describedby': help ? `${id}-help` : undefined },
    h('legend', { class: 'ad-setting__label', text: d.label || prettify(d.key) }),
    help,
    h('div', { class: ['ad-seg', rich && 'ad-seg--rich'], role: 'radiogroup', 'aria-label': d.label || d.key }, opts.map((op) => h('button', {
      type: 'button', role: 'radio', class: ['ad-seg__btn', op.value === cur && 'is-on'],
      'aria-checked': op.value === cur ? 'true' : 'false', disabled: !o.design, data: { fk: `set:${d.key}:${op.value}` },
      on: { click: () => { if (op.value !== cur) o.onSet(d.key, op.value); } },
    }, h('span', { class: 'ad-seg__label', text: op.label }), rich && op.desc ? h('span', { class: 'ad-seg__desc', text: op.desc }) : null))),
    !rich && sel && sel.desc ? h('p', { class: 'ad-hint', text: `${sel.label}: ${sel.desc}` }) : null);
}

function numberSetting(d, o, cur, id, help) {
  const out = h('output', { class: 'ad-setting__val', for: id, text: fmtVal(d, cur) });
  const input = h('input', {
    id, type: 'range', class: 'ad-range', min: String(d.min ?? 0), max: String(d.max ?? 1), step: String(d.step ?? 0.01),
    value: String(cur ?? d.default ?? 0), disabled: !o.design, data: { fk: `set:${d.key}` },
    'aria-describedby': help ? `${id}-help` : undefined,
  });
  input.addEventListener('input', () => { out.textContent = fmtVal(d, Number(input.value)); });
  input.addEventListener('change', () => o.onSet(d.key, Number(input.value)));
  return h('div', { class: 'ad-setting' },
    h('div', { class: 'ad-setting__row' }, h('label', { class: 'ad-setting__label', for: id, text: d.label || prettify(d.key) }), out),
    help,
    input,
    typeof d.min === 'number' && typeof d.max === 'number'
      ? h('div', { class: 'ad-setting__ends' }, h('span', { text: fmtVal(d, d.min) }), h('span', { text: fmtVal(d, d.max) })) : null);
}

export function settingsView(kit, o) {
  const defs = (o.defs || []).filter((d) => d && d.key);
  if (!defs.length) return h('p', { class: 'ad-empty', text: t('work.set.empty') });
  return h('div', { class: 'ad-settings' }, defs.map((d) => {
    const cur = o.values && o.values[d.key] !== undefined ? o.values[d.key] : d.default;
    const id = `ad-set-${d.key}`;
    const help = typeof d.help === 'string' && d.help.trim() ? h('p', { class: 'ad-hint', id: `${id}-help`, text: d.help }) : null;
    const opts = d.type === 'number' ? null : optionsOf(d);
    if (opts) return enumSetting(d, o, cur, id, help, opts);
    if (d.type === 'number' || typeof cur === 'number') return numberSetting(d, o, cur, id, help);
    return h('div', { class: 'ad-setting' }, h('span', { class: 'ad-setting__label', text: d.label || prettify(d.key) }),
      h('span', { class: 'ad-setting__val', text: String(cur ?? '—') }), help);
  }));
}
