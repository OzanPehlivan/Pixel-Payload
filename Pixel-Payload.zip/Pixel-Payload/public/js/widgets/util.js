// Modül AD ortak yardımcıları: DOM kurucu, ui.js varsa onu kullanan "kit", biçimleyiciler, sözlükler.
// Metinler dil duyarlı (i18n.js + lang/work.js). innerHTML YOK; her şey DOM API ile kurulur. İstemci kural hesaplamaz, yalnız gelen veriyi çizer.

import { t, getLang, locale, upperL } from '../i18n.js';
import { TAG_IDS } from '../lang/work.js';

// --- DOM ---------------------------------------------------------------------
// h('div', { class, text, on: { click }, data: { k }, aria-*, ... }, ...çocuklar)
export function h(tag, attrs, ...children) {
  const el = document.createElement(tag);
  const a = attrs || {};
  for (const [k, v] of Object.entries(a)) {
    if (v === undefined || v === null || v === false) continue;
    if (k === 'class') el.className = Array.isArray(v) ? v.filter(Boolean).join(' ') : v;
    else if (k === 'text') el.textContent = String(v);
    else if (k === 'on') for (const [ev, fn] of Object.entries(v)) el.addEventListener(ev, fn);
    else if (k === 'data') for (const [dk, dv] of Object.entries(v)) el.dataset[dk] = String(dv);
    else if (k === 'style' && typeof v === 'object') Object.assign(el.style, v);
    else if (k in el && typeof v !== 'string') el[k] = v;
    else el.setAttribute(k, v === true ? '' : String(v));
  }
  append(el, children);
  return el;
}

export function append(el, children) {
  for (const c of children.flat(Infinity)) {
    if (c === null || c === undefined || c === false) continue;
    el.append(c instanceof Node ? c : document.createTextNode(String(c)));
  }
  return el;
}

// İçeriği yenile; odaktaki öğe (data-fk anahtarıyla) yeniden odaklanır
export function refill(el, ...children) {
  const act = document.activeElement;
  const fk = act && el.contains(act) && act.dataset ? act.dataset.fk : null;
  el.replaceChildren();
  append(el, children);
  if (fk) {
    const again = el.querySelector(`[data-fk="${CSS.escape(fk)}"]`);
    if (again && !again.disabled) again.focus({ preventScroll: true });
  }
  return el;
}

// --- Sözlükler (dil duyarlı: her okumada geçerli dilde; adlar Aşama 8 ile aynı) ---------------
// Metinler lang/work.js'te (work.*); rol adları önce shell.role.* (AM), yoksa work.role.* yedeği.
const has = (key) => t(key) !== key;
const tOr = (key, fb) => (has(key) ? t(key) : t(fb));
// Anahtarları sabit, değerleri getter olan nesne (Object.keys/entries ve spread geçerli dilde çalışır)
function liveMap(keys, fn) {
  const o = {};
  for (const k of keys) Object.defineProperty(o, k, { get: () => fn(k), enumerable: true });
  return o;
}

export const ENGINEERS = ['rocket', 'spacecraft', 'payload'];
const ROLES = ['director', ...ENGINEERS];
export const ROLE_NAME = liveMap(ROLES, (r) => tOr(`shell.role.${r}`, `work.role.${r}`));
export const ROLE_SHORT = liveMap(ROLES, (r) => tOr(`shell.roleShort.${r}`, `work.roleShort.${r}`));
export const ROLE_ICON = { director: 'crew', rocket: 'engine', spacecraft: 'satellite', payload: 'flask' };
export const ROLE_DUTY = liveMap(ROLES, (r) => t(`work.duty.${r}`));

// Veri ikon adları → ui.js ikon seti
const ITEM_ICON = {
  tank: 'fuel', computer: 'gear', panel: 'power', chute: 'shield', radar: 'antenna', camera: 'eye', generic: 'gear', legs: 'rocket',
  battery: 'power', spectrometer: 'flask', sensor: 'eye', station: 'flask', drill: 'gear', capsule: 'crew', suit: 'crew',
};
export const itemIcon = (name) => ITEM_ICON[name] || name || 'gear';
export function categoryName(c) {
  if (!c) return t('work.cat.other');
  const key = `work.cat.${c}`;
  return has(key) ? t(key) : String(c).replace(/[-_]+/g, ' ').replace(/^./, (x) => upperL(x));
}

const REF_TONE = { measured: 'ok', derived: 'info', estimated: 'warn', game: 'demo' };
export const REF_CLASS = liveMap(Object.keys(REF_TONE), (k) => ({ label: t(`work.ref.${k}`), tone: REF_TONE[k] }));

export const STATUS_TR = liveMap(['PASS', 'WARN', 'FAIL'], (k) => t(`work.status.${k}`));

// Takım tasarım durumu (launchStatus) ve mühendis bütçe bandı: sayı yok, yalnız anlam
const LAUNCH_META = { READY: ['ok', 'check'], RISKY: ['warn', 'warn'], MISSING: ['warn', 'warn'], INSUFFICIENT: ['bad', 'cross'] };
export const LAUNCH_TR = liveMap(Object.keys(LAUNCH_META), (k) => ({
  label: t(`work.launch.${k}`), tone: LAUNCH_META[k][0], icon: LAUNCH_META[k][1], hint: t(`work.launch.${k}.hint`) }));
const BUDGET_META = { ok: ['ok', 'check'], tight: ['warn', 'warn'], over: ['bad', 'cross'] };
export const BUDGET_BAND = liveMap(Object.keys(BUDGET_META), (k) => ({
  label: t(`work.budget.${k}`), tone: BUDGET_META[k][0], icon: BUDGET_META[k][1], hint: t(`work.budget.${k}.hint`) }));

// Bilim/ekipman etiketleri (provides/requires/requiresTags) → geçerli dilde ad; bilinmeyen okunur hale getirilir.
export function tagName(tag) {
  if (!tag) return '';
  return TAG_IDS.has(tag) ? t(`work.tag.${tag}`) : String(tag).replace(/[-_]+/g, ' ');
}
// Sunucu metnindeki ham etiketleri (ör. "surface-power-supply") geçerli dildeki adlarıyla değiştir; yalnız sözlükte olanlar
export function trTags(text) {
  if (typeof text !== 'string' || !text) return text || '';
  return text.replace(/(?<![\p{L}\d-])[a-z][a-z0-9]*(?:-[a-z0-9]+)*(?![\p{L}\d-])/gu, (w) => (TAG_IDS.has(w) ? t(`work.tag.${w}`) : w));
}

// --- Biçimleyiciler ------------------------------------------------------------
export function num(v, digits = 0) {
  if (typeof v !== 'number' || !Number.isFinite(v)) return '—';
  return v.toLocaleString(locale(), { maximumFractionDigits: digits, minimumFractionDigits: 0 });
}
export function withUnit(v, unit, digits = 0) {
  const s = num(v, digits);
  return s === '—' || !unit ? s : `${s} ${unit}`;
}
// büyük değerleri okunur birime çevir (kg → t, W → kW, bps → kbps/Mbps)
export function smart(v, unit) {
  if (typeof v !== 'number' || !Number.isFinite(v)) return '—';
  const a = Math.abs(v);
  if (unit === 'kg' && a >= 10000) return withUnit(v / 1000, 't', 1);
  if (unit === 'W' && a >= 10000) return withUnit(v / 1000, 'kW', 1);
  if (unit === 'N' && a >= 1e6) return withUnit(v / 1e6, 'MN', 2);
  if (unit === 'N' && a >= 1e4) return withUnit(v / 1e3, 'kN', 0);
  if (unit === 'bps' && a >= 1e6) return withUnit(v / 1e6, 'Mbps', 1);
  if (unit === 'bps' && a >= 1e3) return withUnit(v / 1e3, 'kbps', 1);
  if (unit === 'm/s' && a >= 1000) return withUnit(v / 1000, 'km/s', 2);
  return withUnit(v, unit, a < 10 ? 2 : a < 100 ? 1 : 0);
}
export function clock(ms) {
  const s = Math.max(0, Math.floor((ms || 0) / 1000));
  const m = Math.floor(s / 60);
  return `${String(m).padStart(2, '0')}:${String(s % 60).padStart(2, '0')}`;
}
export function hhmm(ts) {
  if (typeof ts !== 'number') return '--:--';
  const d = new Date(ts);
  return `${String(d.getHours()).padStart(2, '0')}:${String(d.getMinutes()).padStart(2, '0')}`;
}
export const upper = (s) => upperL(s);
// Yüzde: TR "%12", EN "12%"
export function pct(v, digits = 0) {
  const s = num(v, digits);
  if (s === '—') return s;
  return getLang() === 'tr' ? `%${s}` : `${s}%`;
}

// --- Kit: ui.js (AC) varsa onu, yoksa yerel yedekleri kullanır ------------------------
const ICON_PATHS = {
  rocket: 'M12 2c3 3 4 7 3 12h-6C8 9 9 5 12 2zM9 14l-3 4h4M15 14l3 4h-4M11 18h2v3h-2z',
  engine: 'M8 3h8v5l2 3v3H6v-3l2-3zM9 14l-1 7M15 14l1 7M12 14v7',
  satellite: 'M9 9l6 6M4 4l5 5-3 3-5-5zM20 20l-5-5 3-3 5 5zM12 12l3-3M17 17a4 4 0 0 0 2-4',
  flask: 'M9 3h6M10 3v6l-5 10h14l-5-10V3M7 15h10',
  crew: 'M12 4a3 3 0 1 1 0 6 3 3 0 0 1 0-6zM5 20c0-4 3-7 7-7s7 3 7 7',
  chat: 'M4 5h16v11H9l-5 4z',
  check: 'M5 12l5 5 9-10', cross: 'M6 6l12 12M18 6L6 18', warn: 'M12 3l10 18H2zM12 10v5M12 18v.5',
  clock: 'M12 3a9 9 0 1 1 0 18 9 9 0 0 1 0-18zM12 7v5l3 3', power: 'M13 2L5 14h6l-1 8 8-12h-6z',
  thermo: 'M10 4a2 2 0 0 1 4 0v10a4 4 0 1 1-4 0z', fuel: 'M5 21V5h9v16M14 9l4 3v6a2 2 0 0 0 4 0M5 11h9',
  antenna: 'M12 12v9M8 21h8M7 8a7 7 0 0 1 10 0M4 5a11 11 0 0 1 16 0', chart: 'M4 20V4M4 20h16M8 16v-4M12 16V8M16 16v-6',
  gear: 'M12 8a4 4 0 1 1 0 8 4 4 0 0 1 0-8zM12 2v3M12 19v3M2 12h3M19 12h3M5 5l2 2M17 17l2 2M5 19l2-2M17 7l2-2',
  shield: 'M12 3l8 3v6c0 5-4 8-8 9-4-1-8-4-8-9V6z', star: 'M12 3l3 6 6 1-4.5 4 1 6.5L12 17l-5.5 3.5 1-6.5L3 10l6-1z',
  rover: 'M4 14h16v-4H4zM8 10V6h6v4M6 18a2 2 0 1 0 0-.1M18 18a2 2 0 1 0 0-.1M12 18a2 2 0 1 0 0-.1',
  moon: 'M15 3a9 9 0 1 0 6 13A8 8 0 0 1 15 3z', mars: 'M12 3a9 9 0 1 1 0 18 9 9 0 0 1 0-18zM7 10h4M13 15h4',
  play: 'M7 4l13 8-13 8z', exit: 'M10 4H4v16h6M14 8l4 4-4 4M18 12H9', eye: 'M2 12s4-7 10-7 10 7 10 7-4 7-10 7S2 12 2 12zM12 9a3 3 0 1 1 0 6 3 3 0 0 1 0-6z',
  back: 'M15 5l-7 7 7 7',
};
function localIcon(name) {
  const NS = 'http://www.w3.org/2000/svg';
  const svg = document.createElementNS(NS, 'svg');
  svg.setAttribute('viewBox', '0 0 24 24');
  svg.setAttribute('aria-hidden', 'true');
  svg.setAttribute('class', 'ad-ico');
  const p = document.createElementNS(NS, 'path');
  p.setAttribute('d', ICON_PATHS[name] || ICON_PATHS.gear);
  svg.append(p);
  return svg;
}

let toastBox = null;
function localToast(msg, kind = 'info') {
  if (!toastBox || !toastBox.isConnected) {
    toastBox = h('div', { class: 'ad-toasts', role: 'status', 'aria-live': 'polite' });
    document.body.append(toastBox);
  }
  const t = h('div', { class: ['ad-toast', `is-${kind}`], text: msg });
  toastBox.append(t);
  while (toastBox.children.length > 2) toastBox.firstChild.remove();
  setTimeout(() => t.remove(), 3800);
}

// work.css kabukta bağlı değilse bir kez ekle
function ensureCss() {
  if (document.querySelector('link[href$="css/work.css"]')) return;
  document.head.append(h('link', { rel: 'stylesheet', href: '/css/work.css' }));
}

export function makeKit(api) {
  ensureCss();
  const ui = (api && api.ui) || {};
  const safe = (fn, fb) => (...args) => {
    if (typeof fn === 'function') {
      try { const r = fn(...args); if (r !== undefined) return r; } catch { /* yedeğe düş */ }
    }
    return fb(...args);
  };
  const icon = safe(ui.icon, localIcon);

  // Düğme: { label, sub, variant, onClick, disabled, reason, fk, small, ariaLabel }
  // Kendi düğmemiz: durum (yükleniyor, devre dışı nedeni) tam kontrolümüzde; base.css varsa .btn sınıflarını da taşır.
  function button(o) {
    const variant = o.variant || 'ghost';
    // AC'nin ui.button'ı varsa onu kullan (base.css .btn görünümü, meşgul durumu, gerekçe satırı)
    if (typeof ui.button === 'function') {
      try {
        const b = ui.button({
          label: o.label, sub: o.sub, variant, disabled: !!o.disabled, reason: o.reason, icon: o.icon, ariaLabel: o.ariaLabel,
          className: ['ad-btn-ac', o.small && 'ad-btn--sm', o.class].filter(Boolean).join(' '),
          onClick: o.onClick ? () => o.onClick() : undefined,
        });
        if (b) { if (o.fk) b.dataset.fk = o.fk; return b; }
      } catch { /* yedeğe düş */ }
    }
    const b = h('button', {
      type: 'button', class: ['btn', `btn--${variant}`, 'ad-btn', `ad-btn--${variant}`, o.small && 'ad-btn--sm', o.class],
      disabled: !!o.disabled, 'aria-label': o.ariaLabel, data: o.fk ? { fk: o.fk } : undefined,
      title: o.disabled && o.reason ? o.reason : undefined,
    },
    o.icon ? icon(o.icon) : null,
    h('span', { class: 'ad-btn__label', text: o.label }),
    o.sub ? h('span', { class: 'ad-btn__sub', text: o.sub }) : null);
    if (o.onClick) {
      b.addEventListener('click', async () => {
        if (b.disabled || b.classList.contains('is-busy')) return;
        b.classList.add('is-busy');
        b.setAttribute('aria-busy', 'true');
        try { await o.onClick(); } finally {
          b.classList.remove('is-busy');
          b.removeAttribute('aria-busy');
        }
      });
    }
    if (o.disabled && o.reason) {
      return h('div', { class: 'ad-btnwrap' }, b, h('p', { class: 'ad-reason', text: o.reason }));
    }
    return b;
  }

  // Panel: kesik köşeli çerçeve + ikonlu BÜYÜK HARF başlık şeridi
  function panel(o, ...children) {
    if (typeof ui.panel === 'function') {
      try {
        const tag = o.tag ? h('span', { class: 'ad-panel__tag', text: o.tag }) : null;
        const accent = o.accent && o.accent !== 'focus' ? o.accent : undefined;
        const p = ui.panel({ title: upper(o.title || ''), icon: o.icon, accent, active: o.accent === 'focus', actions: tag || o.actions || undefined,
          className: ['ad-panel-ac', o.class].filter(Boolean).join(' ') }, children);
        if (p) { p.setAttribute('aria-label', o.title || ''); return p; }
      } catch { /* yedeğe düş */ }
    }
    return h('section', { class: ['ad-panel', o.accent && `ad-panel--${o.accent}`, o.class], 'aria-label': o.title },
      o.title ? h('header', { class: 'ad-panel__head' },
        o.icon ? icon(o.icon) : null,
        h('h2', { class: 'ad-panel__title', text: upper(o.title) }),
        o.tag ? h('span', { class: 'ad-panel__tag', text: o.tag }) : null,
        o.actions ? h('div', { class: 'ad-panel__actions' }, o.actions) : null) : null,
      h('div', { class: 'ad-panel__body' }, children));
  }

  function pill(status, text) {
    if (typeof ui.statusPill === 'function') {
      const s0 = String(status || '').toUpperCase();
      try { const p = ui.statusPill(status || 'idle', text || STATUS_TR[s0] || t('work.pending')); if (p) return p; } catch { /* yedek */ }
    }
    const s = String(status || '').toUpperCase();
    const tone = s === 'PASS' || s === 'OK' || s === 'GO' ? 'ok' : s === 'WARN' ? 'warn' : s === 'FAIL' || s === 'NO-GO' ? 'bad' : 'idle';
    const ic = tone === 'ok' ? 'check' : tone === 'warn' ? 'warn' : tone === 'bad' ? 'cross' : 'clock';
    return h('span', { class: ['ad-pill', `is-${tone}`] }, icon(ic), h('span', { text: text || STATUS_TR[s] || s || t('work.pending') }));
  }

  function roleTag(role) {
    if (typeof ui.roleBadge === 'function') { try { const r = ui.roleBadge(role); if (r) return r; } catch { /* yedek */ } }
    return h('span', { class: ['ad-role', `ad-role--${role}`] }, icon(ROLE_ICON[role] || 'crew'), h('span', { text: ROLE_SHORT[role] || upper(role) }));
  }

  const toast = safe(ui.toast, localToast);
  // emit + hata toast'ı; ack döner
  async function act(event, payload, okMsg) {
    let ack;
    try { ack = await api.emit(event, payload); } catch (e) { ack = { ok: false, message: t('work.err.connection') }; }
    if (!ack || ack.ok === false) toast((ack && ack.message) || t('work.err.generic'), 'error');
    else if (okMsg) toast(okMsg, 'success');
    return ack || { ok: false };
  }

  return { h, icon, button, panel, pill, roleTag, toast, act };
}

// Basit ölçek çubuğu (değer/üst sınır); oran sunucudan gelen iki sayının oranıdır
export function meter(value, max, tone) {
  const pct = typeof value === 'number' && typeof max === 'number' && max > 0 ? Math.max(0, Math.min(1, value / max)) : 0;
  const bar = h('div', { class: ['ad-meter', tone && `is-${tone}`], role: 'presentation' }, h('span', { class: 'ad-meter__fill' }));
  bar.firstChild.style.transform = `scaleX(${pct})`;
  return bar;
}
