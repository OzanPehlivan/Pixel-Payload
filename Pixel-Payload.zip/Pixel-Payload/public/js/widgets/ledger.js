// Harcama defteri (yalnız operatör): kim, ne, hangi modül, ±maliyet, saat. Kayıtlar sunucudan yeni→eski gelir.
// İstemci hesap yapmaz; yalnız biçimler. Liste kendi içinde kaydırılır.
import { h, num, hhmm } from './util.js';
import { t } from '../i18n.js';
import { roleShort } from '../lang/command.js';

const ACTION = {
  add: { sign: '+', tone: 'spend' },
  remove: { sign: '−', tone: 'refund' },
  auto: { sign: '+', tone: 'auto' },
};

// entries: director.ledger · opts.moduleName(id) → ad · opts.limit (varsayılan 120)
export function ledgerView(kit, entries, opts = {}) {
  const list = Array.isArray(entries) ? entries.slice(0, opts.limit || 120) : [];
  if (!list.length) {
    return h('p', { class: 'ad-empty', text: t('cmd.ledger.empty') });
  }
  const modName = typeof opts.moduleName === 'function' ? opts.moduleName : (id) => id;
  return h('ol', { class: 'cc-ledger', 'aria-label': t('cmd.ledger.aria') }, list.map((e) => {
    const act = ACTION[e.action] ? e.action : 'add';
    const a = ACTION[act];
    const cost = typeof e.cost === 'number' ? Math.abs(e.cost) : null;
    const who = e.action === 'auto' ? t('cmd.ledger.standard') : (e.playerName || (e.role && roleShort(e.role)) || '—');
    return h('li', { class: ['cc-ledger__row', `is-${a.tone}`, e.role && `cc-ledger__row--${e.role}`] },
      h('time', { class: 'cc-ledger__time', text: hhmm(e.ts) }),
      h('span', { class: 'cc-ledger__who' },
        h('i', { class: 'cc-ledger__dot', 'aria-hidden': 'true' }),
        h('span', { text: who }),
        e.role && e.action !== 'auto' ? h('small', { text: roleShort(e.role) }) : null),
      h('span', { class: 'cc-ledger__what' },
        h('span', { class: 'cc-ledger__verb', text: t(`cmd.ledger.${act}`) }),
        h('b', { text: e.itemName || e.itemId || '?' }),
        e.moduleId ? h('small', { text: modName(e.moduleId) }) : null),
      h('span', { class: 'cc-ledger__cost', text: cost === null ? '—' : `${a.sign}${num(cost, 1)} M$` }));
  }));
}
