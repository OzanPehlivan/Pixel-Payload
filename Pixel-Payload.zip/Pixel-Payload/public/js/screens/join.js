// Odaya katıl: 4 harfli kod + ad → room:join.
import { t } from '../i18n.js';
import '../lang/shell.js';

const screen = {
  id: 'join',
  render(root, state, api) {
    const { h, icon, button, panel } = api.ui;
    const err = h('p', { class: 'field__error', id: 'join-err', role: 'alert' });
    const code = h('input', {
      class: 'field__input field__input--code', id: 'join-code', type: 'text', maxlength: 4, autocomplete: 'off',
      autocapitalize: 'characters', spellcheck: 'false', inputmode: 'text', placeholder: 'ABCD',
      value: (api.session.params.code || '').slice(0, 4), 'aria-describedby': 'join-err'
    });
    code.addEventListener('input', () => {
      // kod yalnız A–Z; i/ı her dilde I olur
      const v = code.value.toUpperCase().replace(/İ/g, 'I').replace(/[^A-Z]/g, '').slice(0, 4);
      if (v !== code.value) code.value = v;
    });
    const name = h('input', {
      class: 'field__input', id: 'join-name', type: 'text', maxlength: 16, autocomplete: 'nickname',
      value: api.prefs.get('name') || '', placeholder: t('shell.form.namePlaceholder'), 'aria-describedby': 'join-err'
    });
    const submit = async () => {
      const c = code.value.trim().toUpperCase();
      const n = name.value.trim();
      code.removeAttribute('aria-invalid');
      name.removeAttribute('aria-invalid');
      if (c.length !== 4) { err.textContent = t('shell.join.codeErr'); code.setAttribute('aria-invalid', 'true'); code.focus(); return; }
      if (!n) { err.textContent = t('shell.form.nameErr'); name.setAttribute('aria-invalid', 'true'); name.focus(); return; }
      err.textContent = '';
      api.prefs.set('name', n);
      const res = await api.emit('room:join', { code: c, name: n });
      if (!res.ok) {
        err.textContent = res.message || t('shell.join.failed');
        if (res.error === 'ROOM_NOT_FOUND') { code.setAttribute('aria-invalid', 'true'); code.focus(); }
      }
    };
    const go = button({ label: t('shell.join.go'), variant: 'primary', size: 'lg', icon: 'users', className: 'btn--block', type: 'submit' });
    const form = h('form', {
      class: 'entry__form', novalidate: true,
      onSubmit: async (e) => {
        e.preventDefault();
        if (go.disabled) return;
        go.disabled = true; go.setAttribute('aria-busy', 'true');
        try { await submit(); } finally { go.disabled = false; go.removeAttribute('aria-busy'); }
      }
    },
    h('div', { class: 'field' }, h('label', { class: 'field__label', for: 'join-code', text: t('shell.join.codeLabel') }), code,
      h('span', { class: 'field__hint', text: t('shell.join.codeHint') })),
    h('div', { class: 'field' }, h('label', { class: 'field__label', for: 'join-name', text: t('shell.form.nameLabel') }), name),
    err, go);

    root.appendChild(h('div', { class: 'screen-head' },
      h('span', { class: 'eyebrow', text: t('shell.join.eyebrow') }),
      h('h1', { class: 'screen-title', text: t('shell.join.title') })));
    root.appendChild(h('div', { class: 'entry' },
      panel({ title: t('shell.join.panel'), icon: 'link', active: true }, form),
      h('div', { class: 'entry__aside' },
        h('p', { class: 'entry__note' }, icon('wifi', 20), h('span', { text: t('shell.join.note1') })),
        h('p', { class: 'entry__note' }, icon('info', 20), h('span', { text: t('shell.join.note2') })))));
    setTimeout(() => (code.value ? name : code).focus(), 0);
  }
};
export default screen;
