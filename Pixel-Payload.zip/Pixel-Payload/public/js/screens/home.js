// Açılış ekranı (Stitch 01): BAŞLA → oda kur / katıl, DEMO MODU, NASIL OYNANIR; sağda Dünya + roket. Altta EN | TR.
import { t } from '../i18n.js';
import '../lang/shell.js';

const SVG_NS = 'http://www.w3.org/2000/svg';

function orbitArt() {
  const s = document.createElementNS(SVG_NS, 'svg');
  s.setAttribute('class', 'hero__orbit');
  s.setAttribute('viewBox', '0 0 800 520');
  s.setAttribute('preserveAspectRatio', 'xMidYMid slice');
  s.setAttribute('aria-hidden', 'true');
  const add = (tag, attrs) => {
    const n = document.createElementNS(SVG_NS, tag);
    Object.entries(attrs).forEach(([k, v]) => n.setAttribute(k, String(v)));
    s.appendChild(n);
    return n;
  };
  // hedef halkaları + yörünge eğrisi
  [70, 120, 170].forEach((r, i) => add('circle', { cx: 210, cy: 170, r, fill: 'none', stroke: '#38c8ff', 'stroke-opacity': 0.22 - i * 0.05, 'stroke-width': 1.5 }));
  add('path', { d: 'M210 100 A70 70 0 0 1 280 170 L210 170 Z', fill: '#38c8ff', 'fill-opacity': 0.12 });
  add('path', { d: 'M-40 470 C 200 300, 520 180, 860 120', fill: 'none', stroke: '#38c8ff', 'stroke-opacity': 0.35, 'stroke-width': 1.5, 'stroke-dasharray': '6 8' });
  add('line', { x1: 0, y1: 170, x2: 800, y2: 170, stroke: '#38c8ff', 'stroke-opacity': 0.08 });
  add('line', { x1: 210, y1: 0, x2: 210, y2: 520, stroke: '#38c8ff', 'stroke-opacity': 0.08 });
  return s;
}

const screen = {
  id: 'home',
  render(root, state, api) {
    const { h, icon, button, earthArc, pixelRocket, langSwitch } = api.ui;
    let split = null;

    const start = h('button', {
      type: 'button', class: 'menu-card', dataset: { tone: 'primary' }, 'aria-expanded': 'false', 'aria-controls': 'start-split',
      onClick: () => {
        const open = start.getAttribute('aria-expanded') !== 'true';
        start.setAttribute('aria-expanded', open ? 'true' : 'false');
        split.hidden = !open;
        if (open) split.querySelector('button').focus();
      }
    },
    h('span', { class: 'menu-card__title' }, icon('play', 28), t('shell.home.start')),
    h('span', { class: 'menu-card__sub', text: t('shell.home.startSub') }));

    split = h('div', { id: 'start-split', class: 'menu-split', hidden: true },
      button({ label: t('shell.home.create'), sub: t('shell.home.createSub'), variant: 'primary', icon: 'crown', onClick: () => api.nav.go('create') }),
      button({ label: t('shell.home.join'), sub: t('shell.home.joinSub'), variant: 'primary', icon: 'users', onClick: () => api.nav.go('join') }));

    const demo = h('a', { class: 'menu-card', dataset: { tone: 'demo' }, href: '/demo.html' },
      h('span', { class: 'menu-card__title' }, icon('eye', 28), t('shell.home.demo')),
      h('span', { class: 'menu-card__sub', text: t('shell.home.demoSub') }));

    const how = h('button', { type: 'button', class: 'menu-card', dataset: { tone: 'ghost' }, onClick: () => api.nav.go('how') },
      h('span', { class: 'menu-card__title' }, icon('book', 28), t('shell.tab.how')),
      h('span', { class: 'menu-card__sub', text: t('shell.home.howSub') }));

    // Dil anahtarı: menünün altında, sessiz bir satır
    const lang = h('div', { class: 'home__lang' },
      h('span', { class: 'home__lang-k', text: t('shell.lang.label') }), langSwitch());

    const rocket = pixelRocket(170);
    rocket.classList.add('hero__rocket');

    const hero = h('div', { class: 'home__hero' },
      earthArc(), orbitArt(), rocket,
      h('div', { class: 'hero__tag bracket' },
        h('h1', { class: 'hero__name', text: 'PIXEL PAYLOAD' }),
        h('p', { class: 'hero__line', text: t('shell.home.line') }),
        h('p', { class: 'hero__status' }, t('shell.home.missions'), h('b', { text: t('shell.home.missionsList') }))),
      h('div', { class: 'hero__readout', 'aria-hidden': 'true' },
        h('span', { text: t('shell.home.read1') }),
        h('span', { text: t('shell.home.read2') }),
        h('span', { text: t('shell.home.read3') })));

    root.appendChild(h('div', { class: 'home' },
      h('div', { class: 'home__menu' }, start, split, demo, how, lang),
      hero));
  }
};
export default screen;
