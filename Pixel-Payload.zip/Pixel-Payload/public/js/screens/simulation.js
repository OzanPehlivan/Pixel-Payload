// Pixel Payload — Simülasyon ekranı (Modül AE; Stitch 06 düzeni).
// Sol: aşama listesi · orta: 2B araç + playPhase · sağ: telemetri · olay akışı · alt: büyük durum şeridi.
// Yalnız gelen state'i çizer; oyun kuralı hesaplamaz. Mühendis yalnız kendi telemetrisini (engineer.telemetry) görür.
import { h, clear, panel, icon, roleBadge, fmt } from '../ui.js';
import { t as L, upperL, getLang } from '../i18n.js';
import '../lang/command.js';

const STATUS_WORD = { ok: 1, warn: 1, fail: 1 }; // metin: cmd.sim.st.<status>
const STATUS_ICON = { ok: 'check', warn: 'warn', fail: 'cross' };
const SEV = { info: 'info', warn: 'warn', critical: 'fail' };

// ---- sahne modülünü yükle (app api.scene varsa onu, yoksa doğrudan) ----
async function loadScene(api) {
  try {
    if (api && typeof api.scene === 'function') { const m = await api.scene(); if (m && m.createVehicleScene) return m; }
  } catch (e) { /* yedeğe düş */ }
  try { return await import('/scene2d.js'); } catch (e) { return null; }
}

export function missionModules(state) {
  const d = state && state.director && state.director.mission && state.director.mission.modules;
  if (Array.isArray(d)) return d.map((m) => ({ id: m.id, name: m.name, role: m.role }));
  const e = state && state.engineer && state.engineer.modules;
  if (Array.isArray(e)) return e.map((m) => ({ id: m.id, name: m.name, role: m.role }));
  return [];
}

// ---- telemetri satırları: [{ icon, label, value, status? }] ----
const n0 = (v) => fmt.num(v, 0);
const n1 = (v) => fmt.num(v, 1);
const has = (v) => v !== undefined && v !== null && !(typeof v === 'number' && !Number.isFinite(v));
function massText(kg) { return has(kg) ? (Math.abs(kg) >= 10000 ? `${n1(kg / 1000)} t` : `${n0(kg)} kg`) : null; }
function bpsText(b) { if (!has(b)) return null; return b >= 1e6 ? `${n1(b / 1e6)} Mbps` : b >= 1e3 ? `${n1(b / 1e3)} kbps` : `${n0(b)} bps`; }

export function telemetryRows(t, phaseId) {
  if (!t || typeof t !== 'object') return [];
  const rows = [];
  const push = (ic, label, value, status) => { if (value !== null && value !== undefined && value !== '') rows.push({ icon: ic, label, value, status }); };
  if (t.massKg) push('rocket', L('cmd.team.mass'), massText(has(t.massKg.total) ? t.massKg.total : t.massKg.mine));
  if (has(t.twr)) push('engine', L('cmd.sim.twr'), n1(t.twr) + '', t.twr < 1 ? 'fail' : undefined);
  if (t.dv && phaseId && t.dv[phaseId]) {
    const d = t.dv[phaseId];
    push('fuel', L('cmd.sim.dvPhase'), `${n0(d.available)} / ${n0(d.required)} m/s`, has(d.available) && has(d.required) && d.available < d.required ? 'fail' : 'ok');
  }
  if (t.propellant && has(t.propellant.loadedKg)) push('fuel', L('cmd.sim.fuel'), massText(t.propellant.loadedKg));
  if (t.power) {
    const p = t.power;
    if (has(p.marginW)) push('power', L('cmd.sim.powerMargin'), `${p.marginW > 0 ? '+' : ''}${n0(p.marginW)} W`, p.marginW < 0 ? 'fail' : 'ok');
    else if (has(p.genW)) push('power', L('cmd.sim.powerGen'), `${n0(p.genW)} W`);
    if (has(p.batteryWh)) push('power', L('cmd.tel.battery'), `${n0(p.batteryWh)} Wh`);
  }
  if (t.thermal && t.thermal.status) push('thermo', L('cmd.sim.thermal'), t.thermal.label || L(`cmd.thermal.${({ PASS: 'ok', WARN: 'warn', FAIL: 'fail' })[String(t.thermal.status).toUpperCase()] || 'ok'}`), t.thermal.status === 'FAIL' ? 'fail' : t.thermal.status === 'WARN' ? 'warn' : 'ok');
  if (t.comms) {
    const c = t.comms;
    push('antenna', L('cmd.sim.comms'), bpsText(Math.max(c.relayBps || 0, c.directBps || 0) || null));
    if (has(c.delayS)) push('clock', L('cmd.sim.delay'), `${n1(c.delayS)} ${L('cmd.unit.sec')}`);
    if (has(c.downlinkMbPerSol)) push('antenna', L('cmd.sim.downlink'), `${n0(c.downlinkMbPerSol)} ${L('cmd.unit.mbDay')}`, has(c.dataMbPerSol) && c.downlinkMbPerSol < c.dataMbPerSol ? 'warn' : undefined);
  }
  if (t.lifeSupport) {
    const l = t.lifeSupport;
    const min = [l.o2Days, l.waterDays, l.co2Days].filter(has);
    if (min.length) push('crew', L('cmd.sim.life'), `${n0(Math.min(...min))} / ${n0(l.days)} ${L('cmd.unit.day')}`, has(l.days) && Math.min(...min) < l.days ? 'fail' : 'ok');
  }
  if (t.edl) {
    const e = t.edl;
    if (has(e.peakHeatWcm2)) push('thermo', L('cmd.tel.heatFlux'), `${n0(e.peakHeatWcm2)} / ${n0(e.shieldMaxWcm2)} W/cm²`, has(e.shieldMaxWcm2) && e.peakHeatWcm2 > e.shieldMaxWcm2 ? 'fail' : 'ok');
    if (has(e.landingVms)) push('mars', L('cmd.sim.landing'), `${n1(e.landingVms)} m/s`);
  }
  if (t.science) push('flask', L('cmd.tel.sciValueShort'), has(t.science.max) ? `${n0(t.science.value)} / ${n0(t.science.max)}` : n0(t.science.value));
  if (t.instruments && has(t.instruments.count)) push('flask', L('cmd.sim.instr'), `${L('cmd.sim.instrN', { n: n0(t.instruments.count) })} · ${n0(t.instruments.powerW)} W`);
  if (has(t.dataMbPerSol)) push('chart', L('cmd.tel.dataProd'), `${n0(t.dataMbPerSol)} ${L('cmd.unit.mbDay')}`);
  const budgetObj = typeof t.budget === 'object' && t.budget ? t.budget : null;
  const budgetN = budgetObj ? budgetObj.budget : t.budget;
  const spentN = has(t.cost) ? t.cost : (budgetObj ? budgetObj.spent : undefined);
  if (has(spentN) && has(budgetN)) push('chart', L('cmd.sim.budget'), `${n0(spentN)} / ${n0(budgetN)}`, spentN > budgetN ? 'fail' : 'ok');
  return rows;
}

let S = null; // etkin ekran örneği (aynı anda tek simülasyon ekranı)

export default {
  id: 'simulation',
  render(root, state, api) {
    S = {};
    const inst = S; // eşzamansız geri çağrılar kendi örneğine bağlı kalsın
    S.api = api;
    S.state = state;
    S.played = 0;
    S.queue = Promise.resolve();
    S.alive = true;
    S.scene = null;
    S.comms = null;

    const me = state.me || {};
    const myRole = me.role;
    const wrap = h('div', { class: 'sim', dataset: { role: myRole || 'none', mission: (state.mission && state.mission.id) || '' } });

    // Başlık satırı
    S.el = {};
    S.el.title = h('h1', { class: 'sim__title' }, icon('rocket', 28), h('span', { text: L('cmd.sim.title') }));
    S.el.mission = h('span', { class: 'sim__mission' });
    S.el.commsBtn = h('div', { class: 'sim__comms-slot' });
    wrap.append(h('header', { class: 'sim__head' }, h('div', { class: 'sim__head-text' }, S.el.title, S.el.mission), S.el.commsBtn));

    // Sol: aşamalar
    S.el.phases = h('ol', { class: 'sim-phases' });
    const phasesPanel = panel({ title: L('cmd.sim.phases'), icon: 'chart', className: 'sim__phases' }, S.el.phases);

    // Orta: sahne + durum şeridi
    S.el.stage = h('div', { class: 'sim-stage', 'aria-label': L('cmd.sim.stageAria') });
    S.el.strip = h('div', { class: 'sim-strip', role: 'status', 'aria-live': 'polite' });
    const center = h('div', { class: 'sim__center' }, h('div', { class: 'sim-stage-frame' }, S.el.stage), S.el.strip);

    // Sağ: telemetri + olaylar
    S.el.telemetry = h('dl', { class: 'sim-telemetry' });
    S.el.telemetryPanel = panel({ title: myRole === 'director' ? L('cmd.sim.tel') : L('cmd.sim.mine'), icon: 'chart', className: 'sim__telemetry' }, S.el.telemetry);
    S.el.events = h('ol', { class: 'sim-events', 'aria-live': 'polite' });
    const eventsPanel = panel({ title: L('cmd.sim.events'), icon: 'warn', className: 'sim__events' }, S.el.events);

    wrap.append(h('div', { class: 'sim__grid' }, phasesPanel, center, h('div', { class: 'sim__side' }, S.el.telemetryPanel, eventsPanel)));
    root.appendChild(wrap);
    S.root = wrap;

    // Sahne (tembel)
    loadScene(api).then((mod) => {
      if (!inst.alive || !mod) return;
      try {
        inst.scene = mod.createVehicleScene(inst.el.stage);
        applyVehicle(inst.state);
        // Önceden açılmış aşamalar (yeniden bağlanma): sonuncusu hariç anında son poz
        const phases = (inst.state.simulation && inst.state.simulation.phases) || [];
        for (let i = 0; i < phases.length - 1; i++) inst.scene.playPhase(phases[i].id, phases[i].status, { instant: true });
        inst.played = Math.max(0, phases.length - 1);
        syncAnimations(inst.state);
      } catch (e) { inst.scene = null; }
    });

    // İletişim: app.js (AC) simülasyon fazında kendi çekmecesini/sekmesini (comms.js) zaten kurar; burada ikinci kez kurulmaz.

    paint(state);
  },

  update(state) {
    if (!S) return;
    S.state = state;
    paint(state);
    applyVehicle(state);
    syncAnimations(state);
    if (S.comms && typeof S.comms.update === 'function') { try { S.comms.update(state); } catch (e) { /* yok say */ } }
  },

  destroy() {
    if (!S) return;
    S.alive = false;
    try { S.scene && S.scene.dispose(); } catch (e) { /* yok say */ }
    try { S.comms && (S.comms.destroy || S.comms.dispose) && (S.comms.destroy || S.comms.dispose).call(S.comms); } catch (e) { /* yok say */ }
    S.scene = null;
  },

};

function applyVehicle(state) {
    if (!S.scene) return;
    S.scene.setVehicle({ missionId: (state.mission && state.mission.id) || 'lunar', modules: missionModules(state), items: state.vehicle || [] });
}

// Yeni açılan aşamaları sırayla oynat (her playPhase resolve olur)
function syncAnimations(state) {
    if (!S.scene) return;
    const phases = (state.simulation && state.simulation.phases) || [];
    while (S.played < phases.length) {
      const p = phases[S.played++];
      S.queue = S.queue.then(() => (S.alive && S.scene ? S.scene.playPhase(p.id, p.status) : null));
    }
}

function paint(state) {
    const me = state.me || {};
    const sim = state.simulation || { phases: [] };
    const shown = sim.phases || [];
    // Tam aşama listesi: sunucunun herkese gönderdiği simulation.phaseList (sayısız); yoksa operatörün görev verisi
    const full = Array.isArray(sim.phaseList) && sim.phaseList.length ? sim.phaseList
      : (state.director && state.director.mission && Array.isArray(state.director.mission.phases) ? state.director.mission.phases : null);
    const last = shown[shown.length - 1] || null;
    const failed = shown.some((p) => p.status === 'fail');
    const total = full ? full.length : null;
    const finished = failed || (total !== null && shown.length >= total);

    S.el.mission.textContent = state.mission ? state.mission.name : '';

    // ---- aşama listesi
    const items = [];
    const list = full || shown;
    list.forEach((ph, i) => {
      const s = shown[i];
      const st = s ? s.status : (failed ? 'skip' : (i === shown.length ? 'next' : 'pending'));
      items.push(h('li', { class: 'sim-phase', dataset: { status: st }, 'aria-current': s && s === last ? 'step' : undefined },
        h('span', { class: 'sim-phase__mark', 'aria-hidden': 'true' }, s ? icon(STATUS_ICON[s.status] || 'check', 18) : String(i + 1)),
        h('span', { class: 'sim-phase__text' },
          h('span', { class: 'sim-phase__name', text: (s && s.name) || ph.name || ph.id }),
          s && s.note ? h('span', { class: 'sim-phase__note', text: s.note }) : null,
          !s && st === 'next' ? h('span', { class: 'sim-phase__note', text: L('cmd.sim.next') }) : null)));
    });
    if (!full && !finished) {
      items.push(h('li', { class: 'sim-phase', dataset: { status: 'next' } },
        h('span', { class: 'sim-phase__mark', 'aria-hidden': 'true' }, String(shown.length + 1)),
        h('span', { class: 'sim-phase__text' }, h('span', { class: 'sim-phase__name', text: L('cmd.sim.nextPhase') }))));
    }
    clear(S.el.phases).append(...items);

    // ---- telemetri (operatör tam; mühendis kendi; yoksa gizli)
    const tel = me.role === 'director' ? state.director && state.director.telemetry : state.engineer && state.engineer.telemetry;
    const rows = telemetryRows(tel, last ? last.id : (full && full[0] && full[0].id));
    S.el.telemetryPanel.hidden = rows.length === 0;
    clear(S.el.telemetry).append(...rows.map((r) => h('div', { class: 'sim-tel', dataset: { status: r.status || 'none' } },
      h('dt', {}, icon(r.icon, 20), h('span', { text: r.label })),
      h('dd', { text: r.value }))));

    // ---- olay akışı (en yeni üstte; kendi rolünü ilgilendiren vurgulu)
    const events = [];
    shown.forEach((p) => (p.events || []).forEach((ev) => events.push({ ev, phase: p })));
    events.reverse();
    const evNodes = events.map(({ ev, phase }) => {
      const roles = Array.isArray(ev.roles) ? ev.roles : [];
      const mine = !!me.role && me.role !== 'director' && roles.includes(me.role);
      return h('li', { class: ['sim-event', mine && 'is-mine'], dataset: { severity: SEV[ev.severity] || 'info' } },
        h('span', { class: 'sim-event__sev', 'aria-hidden': 'true' }, icon(ev.severity === 'critical' ? 'cross' : ev.severity === 'warn' ? 'warn' : 'check', 16)),
        h('span', { class: 'sim-event__body' },
          h('span', { class: 'sim-event__meta' },
            h('span', { class: 'sim-event__phase', text: phase.name || phase.id }),
            roles.map((r) => roleBadge(r)),
            mine ? h('span', { class: 'sim-event__you', text: L('cmd.sim.forYou') }) : null),
          h('span', { class: 'sim-event__text', text: ev.text })));
    });
    if (!evNodes.length) evNodes.push(h('li', { class: 'sim-event sim-event--empty', text: L('cmd.sim.noEvents') }));
    clear(S.el.events).append(...evNodes);

    // ---- alt durum şeridi
    const strip = S.el.strip;
    let st = 'info', head, sub;
    if (!last) { head = L('cmd.sim.prep'); sub = L('cmd.sim.prepSub'); }
    else {
      st = last.status === 'fail' ? 'fail' : last.status === 'warn' ? 'warn' : 'ok';
      head = `${upperL(last.name || last.id)} ${STATUS_WORD[last.status] ? L(`cmd.sim.st.${last.status}`) : ''}`.trim();
      const firstEv = (last.events || [])[0];
      sub = last.note || (firstEv && firstEv.text) || '';
      if (failed) sub = (sub ? sub + ' · ' : '') + L('cmd.sim.stopped');
      else if (finished) sub = (sub ? sub + ' · ' : '') + L('cmd.sim.done');
    }
    const progress = total ? `${shown.length} / ${total}` : L('cmd.sim.nth', { n: shown.length });
    const key = `${shown.length}:${st}:${getLang()}`;
    if (strip.dataset.key !== key) {
      strip.dataset.key = key;
      strip.dataset.status = st;
      const bar = h('span', { class: 'sim-strip__timer', 'aria-hidden': 'true' });
      if (!finished && sim.phaseMs) bar.style.animationDuration = `${sim.phaseMs}ms`;
      else bar.hidden = true;
      clear(strip).append(
        h('span', { class: 'sim-strip__chev', 'aria-hidden': 'true' }),
        h('span', { class: 'sim-strip__icon', 'aria-hidden': 'true' }, icon(st === 'info' ? 'clock' : STATUS_ICON[st], 36)),
        h('span', { class: 'sim-strip__text' }, h('strong', { class: 'sim-strip__head', text: head }), sub ? h('span', { class: 'sim-strip__sub', text: sub }) : null),
        h('span', { class: 'sim-strip__progress', text: progress }),
        bar);
    }
}
