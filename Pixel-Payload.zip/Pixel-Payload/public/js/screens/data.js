// UÇUŞ VERİLERİ: bilimsel kaynaklar (GET /api/sources?lang=) + veri sınıfları açıklaması.
import { t, getLang } from '../i18n.js';
import '../lang/shell.js';

const CLASSES = [['measured', 'check'], ['derived', 'chart'], ['estimated', 'warn'], ['game', 'star']];

let cache = null;   // { status: 'loading'|'ok'|'error', list, lang }

async function fetchSources(lang) {
  const r = await fetch('/api/sources?lang=' + encodeURIComponent(lang), { cache: 'no-store' });
  if (!r.ok) throw new Error(String(r.status));
  const j = await r.json();
  const list = Array.isArray(j) ? j : j && Array.isArray(j.sources) ? j.sources : null;
  if (!list) throw new Error('format');
  return list.filter((s) => s && typeof s === 'object');
}

// Yalnız http(s) bağlantıları açılır
const safeUrl = (u) => (typeof u === 'string' && /^https?:\/\//i.test(u) ? u : null);

const screen = {
  id: 'data',
  render(root, state, api) {
    const { h, icon, button, panel, clear } = api.ui;
    const listBox = h('div', { 'aria-live': 'polite' });

    const draw = () => {
      clear(listBox);
      if (!cache || cache.status === 'loading') {
        listBox.appendChild(h('div', { class: 'loading', role: 'status' }, h('span', { class: 'loading__bar' }), h('span', { text: t('shell.data.loading') })));
      } else if (cache.status === 'error') {
        listBox.appendChild(h('div', { class: 'empty' },
          h('p', { class: 'row' }, icon('warn', 20), h('span', { text: t('shell.data.error') })),
          button({ label: t('shell.common.retry'), variant: 'ghost', onClick: () => load(true) })));
      } else if (!cache.list.length) {
        listBox.appendChild(h('div', { class: 'empty' }, h('p', { text: t('shell.data.empty') })));
      } else {
        listBox.appendChild(h('ul', { class: 'list' }, cache.list.map((s) => {
          const url = safeUrl(s.url);
          const meta = [s.publisher, s.accessed ? t('shell.data.accessed', { date: s.accessed }) : null].filter(Boolean).join(' · ');
          return h('li', { class: 'list__item' },
            icon('book', 20),
            h('div', { class: 'source list__main' },
              url ? h('a', { class: 'source__title', href: url, target: '_blank', rel: 'noopener noreferrer', text: s.title || s.id || url })
                  : h('span', { class: 'source__title', text: s.title || s.id || '—' }),
              meta ? h('span', { class: 'source__meta', text: meta }) : null));
        })));
      }
    };
    const load = async (force) => {
      const lang = getLang();
      if (cache && cache.status === 'ok' && cache.lang === lang && !force) { draw(); return; }
      cache = { status: 'loading', list: [], lang };
      draw();
      try { cache = { status: 'ok', list: await fetchSources(lang), lang }; } catch (e) { cache = { status: 'error', list: [], lang }; }
      if (listBox.isConnected) draw();
    };

    root.appendChild(h('div', { class: 'doc stack' },
      h('div', { class: 'screen-head' }, h('span', { class: 'eyebrow', text: t('shell.data.eyebrow') }), h('h1', { class: 'screen-title', text: t('shell.tab.data') }),
        h('p', { class: 'muted', text: t('shell.data.intro') })),
      panel({ title: t('shell.data.classes'), icon: 'info' },
        h('div', { class: 'class-key' }, CLASSES.map(([id, ic]) => h('div', { class: 'class-key__item' },
          icon(ic, 22), h('div', {}, h('h3', { class: 'how-step__t', text: t(`shell.data.${id}.t`) }), h('p', { class: 'muted', text: t(`shell.data.${id}.d`) })))))),
      panel({ title: t('shell.data.list'), icon: 'book' }, listBox)));
    load(false);
  }
};
export default screen;
