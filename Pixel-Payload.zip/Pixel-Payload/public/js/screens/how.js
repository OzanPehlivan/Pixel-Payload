// Nasıl oynanır: akış, roller, sohbet kuralları. Statik içerik.
import { t } from '../i18n.js';
import '../lang/shell.js';

const STEPS = [1, 2, 3, 4];

const screen = {
  id: 'how',
  render(root, state, api) {
    const { h, icon, button, panel, ROLES, ROLE_NAMES, ROLE_ICONS } = api.ui;
    const rule = (ok, text) => h('li', { class: 'rule', dataset: { ok: ok ? '1' : '0' } }, icon(ok ? 'check' : 'cross', 18), h('span', { text }));
    root.appendChild(h('div', { class: 'doc stack' },
      h('div', { class: 'screen-head' }, h('span', { class: 'eyebrow', text: t('shell.how.eyebrow') }), h('h1', { class: 'screen-title', text: t('shell.tab.how') }),
        h('p', { class: 'muted', text: t('shell.how.intro') })),
      h('ol', { class: 'how-steps', 'aria-label': t('shell.how.stepsAria') }, STEPS.map((n, i) => h('li', { class: 'how-step' },
        h('span', { class: 'how-step__n', 'aria-hidden': 'true', text: String(i + 1).padStart(2, '0') }),
        h('h2', { class: 'how-step__t', text: t(`shell.how.step${n}.t`) }), h('p', { text: t(`shell.how.step${n}.d`) })))),
      h('div', { class: 'grid-2' },
        panel({ title: t('shell.how.roles'), icon: 'users' },
          ROLES.map((r) => h('div', { class: 'role-row', dataset: { role: r } },
            h('span', { class: 'role-row__icon' }, icon(ROLE_ICONS[r], 22)),
            h('div', {}, h('h3', { class: 'how-step__t', text: ROLE_NAMES[r] }), h('p', { class: 'muted', text: t('shell.how.role.' + r) }))))),
        h('div', { class: 'stack' },
          panel({ title: t('shell.how.chat'), icon: 'chat', accent: 'amber' },
            h('ul', { class: 'list stack' },
              rule(true, t('shell.how.rule1')),
              rule(true, t('shell.how.rule2')),
              rule(false, t('shell.how.rule3')))),
          panel({ title: t('shell.how.info'), icon: 'eye' },
            h('p', { text: t('shell.how.info1') }),
            h('p', { class: 'muted', text: t('shell.how.info2') })),
          panel({ title: t('shell.how.sources'), icon: 'globe', accent: 'dim' },
            h('p', { class: 'muted', text: t('shell.how.sourcesBody') }),
            h('div', { class: 'row' }, button({ label: t('shell.tab.data'), variant: 'ghost', icon: 'book', onClick: () => api.nav.go('data') })))))));
  }
};
export default screen;
