// Hazırlık incelemesi (review fazı). Fırlatma durumu (4 durum) + açıklaması, kalemler TÜRE göre gruplu, ekip onay şeridi.
// Mühendis: kendi kalemleri + ONAY / DÜZELT. Operatör: tüm kalemler + FIRLAT (GO) / TASARIMA DÖN (NO-GO).
// FIRLAT'ı yalnız eksik onaylar kapatır. Durum HAZIR değilse önce açık risk onayı modalı → mission:launch { confirm: true }.
// Sunucu LAUNCH_CONFIRM döndürürse de aynı modal açılır. Asıl karar sunucudadır. Metinler cmd.* sözlüğünden.
import { h, makeKit, ENGINEERS, ROLE_ICON, num } from '../widgets/util.js';
import { titleBar, section, confirmButton } from '../widgets/frame.js';
import { mountVehicle } from '../widgets/vehicle.js';
import { readinessList } from '../widgets/readiness.js';
import { kindCounts, kindOfItem, KIND_LABEL, KIND_ORDER, LAUNCH, LAUNCH_ORDER, launchStatusOf, launchLine } from '../widgets/telemetry.js';
import { modal } from '../ui.js';
import * as U from '../widgets/util.js'; // trTags varsa etiket kimliklerini okunur ada çevirir
import { t, upperL, getLang } from '../i18n.js';
import { roleShort, roleName } from '../lang/command.js';
const tr = (x) => (typeof U.trTags === 'function' ? U.trTags(x) : x);

let inst = null;

const isDirector = (st) => st.me && st.me.role === 'director';
const itemsOf = (st) => (isDirector(st) ? (st.director && st.director.readiness) : (st.engineer && st.engineer.readiness)) || [];

// Fırlatılırsa ne olur (türe göre, kısa)
const EFFECT_KINDS = ['physical', 'missing', 'risky', 'budget'];
const kindEffect = (k) => (EFFECT_KINDS.includes(k) ? t(`cmd.effect.${k}`) : '');

function statusPanel(kit, st) {
  const items = itemsOf(st);
  const code = launchStatusOf(st, items);
  const L = code ? LAUNCH[code] : null;
  const c = kindCounts(items);
  const signed = ENGINEERS.filter((r) => st.signoff && st.signoff[r] === 'ok').length;
  return h('div', { class: 'cc-rstatus' },
    h('div', { class: ['cc-status', 'cc-status--compact', L ? `is-${L.tone}` : 'is-idle'], 'aria-live': 'polite' },
      h('span', { class: 'cc-status__k', text: t('cmd.status.k') }),
      h('span', { class: 'cc-status__v' }, L ? kit.icon(L.icon) : null, h('span', { text: L ? L.label : t('cmd.status.noData') })),
      L ? h('p', { class: 'cc-status__line', text: launchLine(st, code) }) : null),
    // dört durumun tanımı; etkin olan vurgulu
    h('ol', { class: 'cc-states' }, LAUNCH_ORDER.slice().reverse().map((k) => h('li', { class: ['cc-states__i', `is-${LAUNCH[k].tone}`, k === code && 'is-on'] },
      h('b', { text: LAUNCH[k].label }), h('span', { text: LAUNCH[k].line })))),
    h('div', { class: 'cc-team__kinds' },
      KIND_ORDER.filter((k) => c[k] > 0).map((k) => h('span', { class: ['cc-kind', `is-${k}`] }, h('b', { text: num(c[k]) }), h('span', { text: KIND_LABEL[k] }))),
      h('span', { class: ['cc-kind', signed === 3 ? 'is-ok' : 'is-dim'] }, h('b', { text: `${signed}/3` }), h('span', { text: t('cmd.rv.signed') }))),
    h('p', { class: 'ad-muted', text: t('cmd.rv.round', { n: (st.review && st.review.rounds || 0) + 1 }) }));
}

function signoffStrip(kit, st) {
  const holder = (r) => (st.players || []).find((p) => p.role === r);
  return h('ul', { class: 'ad-votes' }, ENGINEERS.map((r) => {
    const ok = st.signoff && st.signoff[r] === 'ok';
    const p = holder(r);
    const me = st.me && st.me.role === r;
    return h('li', { class: ['ad-vote', `ad-vote--${r}`, ok && 'is-ok', me && 'is-me'] },
      h('span', { class: 'ad-vote__icon' }, kit.icon(ROLE_ICON[r])),
      h('span', { class: 'ad-vote__txt' },
        h('b', { text: upperL(roleName(r)) }),
        h('small', { text: p ? (me ? `${p.name} · ${t('cmd.rv.you')}` : p.name) : t('cmd.team.empty') })),
      h('span', { class: ['ad-vote__state', ok ? 'is-ok' : 'is-idle'] }, kit.icon(ok ? 'check' : 'clock'), h('span', { text: ok ? t('cmd.rv.approved') : t('cmd.rv.waiting') })));
  }));
}

// ---- Fırlatma akışı (operatör)
function riskBody(kit, code, items, serverMsg) {
  const L = LAUNCH[code] || LAUNCH.RISKY;
  const bad = items.filter((i) => kindOfItem(i) !== 'ok')
    .sort((a, b) => KIND_ORDER.indexOf(kindOfItem(a)) - KIND_ORDER.indexOf(kindOfItem(b)) || (b.critical ? 1 : 0) - (a.critical ? 1 : 0));
  const shown = bad.slice(0, 5);
  return h('div', { class: 'cc-risk' },
    h('p', { class: ['cc-risk__head', `is-${L.tone}`] }, kit.icon(L.icon),
      h('span', { text: code === 'RISKY' ? t('cmd.risk.headRisky') : t('cmd.risk.headBad') }),
      h('b', { text: L.label })),
    serverMsg && !shown.length ? h('p', { text: tr(serverMsg) }) : null,
    shown.length ? h('ul', { class: 'cc-risk__list' }, shown.map((i) => {
      const k = kindOfItem(i);
      const eff = kindEffect(k);
      return h('li', { class: `is-${k}` },
        h('span', { class: ['cc-kind', `is-${k}`] }, h('span', { text: KIND_LABEL[k] })),
        h('span', { class: 'cc-risk__txt' }, h('b', { text: i.system || i.id }), h('small', { text: `${tr(i.text || '')}${eff ? ` → ${eff}` : ''}` })));
    })) : null,
    bad.length > shown.length ? h('p', { class: 'ad-muted', text: t('cmd.risk.more', { n: bad.length - shown.length }) }) : null,
    h('p', { class: 'ad-hint', text: t('cmd.risk.hint') }));
}

function openRisk(kit, api, st, serverMsg) {
  const items = itemsOf(st);
  const code = launchStatusOf(st, items) || 'RISKY';
  modal({
    title: t('cmd.risk.title'),
    body: riskBody(kit, code === 'READY' ? 'RISKY' : code, items, serverMsg),
    actions: [
      { label: t('cmd.cancel'), variant: 'ghost' },
      { label: t('cmd.risk.go'), variant: 'nogo', icon: 'play', onClick: () => doLaunch(kit, api, true) },
    ],
  });
}

async function doLaunch(kit, api, confirm) {
  let ack;
  try { ack = await api.emit('mission:launch', { confirm }); } catch { ack = { ok: false, message: t('cmd.err.conn') }; }
  if (ack && ack.ok) return;
  if (ack && ack.error === 'LAUNCH_CONFIRM') {
    // modal kapanıp odak geri döndükten sonra risk onayını aç
    setTimeout(() => inst && openRisk(kit, api, inst.last(), ack.message), 0);
    return;
  }
  kit.toast((ack && ack.message) || t('cmd.err.launch'), 'error');
}

function startLaunch(kit, api, st) {
  const code = launchStatusOf(st, itemsOf(st));
  if (code && code !== 'READY') { openRisk(kit, api, st); return; }
  modal({
    title: t('cmd.launchOk.title'),
    body: h('p', { text: t('cmd.launchOk.body') }),
    actions: [
      { label: t('cmd.cancel'), variant: 'ghost' },
      { label: t('cmd.rv.go'), variant: 'go', icon: 'play', onClick: () => doLaunch(kit, api, false) },
    ],
  });
}

function decisionPanel(kit, api, st) {
  if (isDirector(st)) {
    const missing = ENGINEERS.filter((r) => !(st.signoff && st.signoff[r] === 'ok'));
    const blocked = missing.length > 0;
    const code = launchStatusOf(st, itemsOf(st));
    const risky = code && code !== 'READY';
    return h('div', { class: 'ad-decide' },
      h('div', { class: 'ad-gonogo' },
        kit.button({
          label: t('cmd.rv.go'), sub: !blocked && risky ? t('cmd.rv.goSub', { status: LAUNCH[code].label }) : null, variant: 'go', icon: 'play', disabled: blocked,
          reason: blocked ? t('cmd.rv.waitFor', { list: missing.map((r) => roleShort(r)).join(', ') }) : null, fk: 'launch',
          onClick: () => startLaunch(kit, api, inst ? inst.last() : st),
        }),
        confirmButton(kit, {
          label: t('cmd.rv.nogo'), confirmLabel: t('cmd.rv.nogoConfirm'), variant: 'nogo', icon: 'cross', fk: 'back',
          onClick: () => kit.act('review:back', {}, t('cmd.rv.backDone')),
        })),
      h('p', { class: 'ad-hint', text: t('cmd.rv.dirHint') }));
  }
  const role = st.me.role;
  const ok = st.signoff && st.signoff[role] === 'ok';
  const c = kindCounts(itemsOf(st));
  const issues = c.physical + c.missing;
  return h('div', { class: 'ad-decide' },
    ok
      ? h('p', { class: 'ad-done' }, kit.icon('check'), h('span', { text: t('cmd.rv.signedWait') }))
      : h('p', { class: 'ad-hint', text: issues ? t('cmd.rv.engIssues') : t('cmd.rv.engCheck') }),
    h('div', { class: 'ad-gonogo' },
      kit.button({ label: ok ? t('cmd.rv.okDone') : t('cmd.rv.ok'), variant: 'go', icon: 'check', disabled: ok, fk: 'ok',
        onClick: () => kit.act('review:signoff', { decision: 'ok' }, t('cmd.rv.okSent')) }),
      confirmButton(kit, { label: t('cmd.rv.fix'), confirmLabel: t('cmd.rv.fixConfirm'), variant: 'nogo', icon: 'gear', fk: 'fix',
        onClick: () => kit.act('review:signoff', { decision: 'fix' }) })),
    h('p', { class: 'ad-muted', text: t('cmd.rv.fixNote') }));
}

// Kalemler türe göre (Fiziksel yetersiz → Eksik → Riskli → Bütçe → Hazır); hazır olanlar katlanır
function itemsView(kit, st) {
  const items = itemsOf(st);
  const dir = isDirector(st);
  if (!items.length) return h('p', { class: 'ad-empty', text: dir ? t('cmd.more.noItems') : t('cmd.rv.noMine') });
  return h('div', { class: 'cc-kgroups' }, KIND_ORDER.map((k) => {
    const list = items.filter((i) => kindOfItem(i) === k);
    if (!list.length) return null;
    const eff = kindEffect(k);
    const head = h('h3', { class: ['cc-kgroup__title', `is-${k}`] },
      h('span', { text: upperL(KIND_LABEL[k]) }), h('small', { text: `${t('cmd.more.items', { n: list.length, count: num(list.length) })}${eff ? ` · ${eff}` : ''}` }));
    const body = readinessList(kit, list, { showRole: dir });
    if (k === 'ok') return h('details', { class: 'cc-kgroup cc-kgroup--ok' }, h('summary', null, head), body);
    return h('div', { class: 'cc-kgroup' }, head, body);
  }));
}

function draw(st) {
  const s = inst;
  s.title.sub.textContent = st.mission ? `${st.mission.name} · ${t('cmd.rv.sub')}` : t('cmd.rv.subShort');
  const mods = isDirector(st)
    ? ((st.director && st.director.mission && st.director.mission.modules) || [])
    : ((st.engineer && st.engineer.modules) || []);
  s.vehicle.set({ missionId: st.mission && st.mission.id, modules: mods.map((m) => ({ id: m.id, name: m.name, role: m.role })),
    items: st.vehicle || [], mineRole: isDirector(st) ? null : st.me.role });
  const ls = [st.launchStatus, st.director && st.director.launchStatus, st.launchNote, getLang()];
  s.secStatus.render([itemsOf(st), st.overall, st.signoff, st.review, ls]);
  s.secDecide.render([itemsOf(st), st.overall, st.signoff, ls]);
  s.secVotes.render([st.signoff, st.players, ls]);
  s.secItems.render([itemsOf(st), ls]);
}

const screen = {
  id: 'review',
  render(root, state, api) {
    screen.destroy();
    const kit = makeKit(api);
    let last = state;
    const dir = isDirector(state);
    const myRole = state.me && state.me.role;
    const title = titleBar(dir ? t('cmd.rv.titleDir') : t('cmd.rv.titleEng', { role: myRole ? roleShort(myRole) : '' }), '');
    const box = () => h('div', { class: 'ad-sec' });
    const secStatus = section(box(), () => statusPanel(kit, last));
    const secDecide = section(box(), () => decisionPanel(kit, api, last));
    const secVotes = section(box(), () => signoffStrip(kit, last));
    const secItems = section(box(), () => itemsView(kit, last));
    const vehBox = h('div', { class: 'ad-vehbox ad-vehbox--tall' });
    const page = h('div', { class: ['ad-work', 'ad-review', 'cc', dir ? 'ad-review--op' : 'ad-review--eng'] },
      title.el,
      h('div', { class: 'ad-grid ad-grid--review' },
        kit.panel({ title: t('cmd.rv.pStatus'), icon: 'shield', class: 'ad-a-status' }, secStatus.el),
        kit.panel({ title: t('cmd.rv.pVehicle'), icon: 'rocket', class: 'ad-a-vehicle' }, vehBox),
        kit.panel({ title: dir ? t('cmd.rv.pDecideDir') : t('cmd.rv.pDecideEng'), icon: dir ? 'play' : 'check', class: 'ad-a-decide', accent: 'focus' }, secDecide.el),
        kit.panel({ title: t('cmd.rv.pVotes'), icon: 'crew', class: 'ad-a-votes' }, secVotes.el),
        kit.panel({ title: dir ? t('cmd.rv.pItemsDir') : t('cmd.rv.pItemsEng'), icon: 'chart', class: 'ad-a-items' }, secItems.el)));
    root.append(page);
    const vehicle = mountVehicle(vehBox, api);
    inst = { kit, title, vehicle, page, secStatus, secDecide, secVotes, secItems, last: () => last, setLast: (s) => { last = s; } };
    draw(state);
  },
  update(state) {
    if (!inst || !state) return;
    inst.setLast(state);
    draw(state);
  },
  destroy() {
    if (!inst) return;
    inst.vehicle.destroy();
    inst.page.remove();
    inst = null;
  },
};

export default screen;
