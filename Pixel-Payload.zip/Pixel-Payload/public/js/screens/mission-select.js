// Görev seçimi: iki büyük görev kartı (Ay / Mars). Ayrıntılar ve SEÇ yalnız Operatörde.
import { t } from '../i18n.js';
import '../lang/shell.js';

const KIND = { lunar: 'moon', mars: 'mars' };
const tag = (id) => (id === 'lunar' || id === 'mars' ? t('shell.ms.tag.' + id) : t('shell.ms.tag.default'));
const objType = (type) => (['primary', 'secondary', 'science'].includes(type) ? t('shell.ms.obj.' + type) : type || '');

function build(root, st, api) {
  const { h, icon, button, planet, fmt, toast, statusDot, PHASE_NAMES } = api.ui;
  const isDirector = st.me && st.me.role === 'director';
  const options = Array.isArray(st.missionOptions) ? st.missionOptions : [];
  const details = isDirector && st.director && Array.isArray(st.director.missionDetails) ? st.director.missionDetails : [];

  root.appendChild(h('div', { class: 'screen-head' },
    h('span', { class: 'eyebrow', text: isDirector ? t('shell.ms.eyebrowDirector') : PHASE_NAMES['mission-select'] }),
    h('h1', { class: 'screen-title', text: isDirector ? t('shell.ms.titleDirector') : t('shell.ms.titleOther') })));

  if (!isDirector) {
    root.appendChild(h('p', { class: 'waiting', role: 'status', style: null }, statusDot('wait'),
      h('span', { text: t('shell.ms.waiting') })));
  }

  if (!options.length) {
    root.appendChild(h('div', { class: 'empty' }, h('p', { text: t('shell.ms.empty') })));
    return;
  }

  const cards = options.map((m) => {
    const d = details.find((x) => x && x.id === m.id);
    const kind = KIND[m.id] || 'moon';
    const body = [];
    if (isDirector && d) {
      const facts = [
        [t('shell.ms.budget'), Number.isFinite(d.budget) ? fmt.num(d.budget) + ' M$' : '—'],
        [t('shell.ms.crew'), Number.isFinite(d.crew) && d.crew > 0 ? String(d.crew) : t('shell.ms.none')],
        [t('shell.ms.duration'), Number.isFinite(d.durationDays) && d.durationDays > 0 ? t('shell.ms.days', { n: d.durationDays }).replace(String(d.durationDays), fmt.num(d.durationDays)) : '—'],
        [t('shell.ms.phases'), Array.isArray(d.phases) ? String(d.phases.length) : '—']
      ];
      body.push(h('div', { class: 'facts' }, facts.map(([k, v]) => h('div', { class: 'fact' }, h('div', { class: 'fact__k', text: k }), h('div', { class: 'fact__v', text: v })))));
      const objs = Array.isArray(d.objectives) ? d.objectives : [];
      if (objs.length) {
        body.push(h('div', { class: 'stack', dataset: { gap: 'sm' } },
          h('span', { class: 'eyebrow', text: t('shell.ms.objectives') }),
          h('ul', { class: 'obj-list' }, objs.map((o) => h('li', {},
            icon(o.critical ? 'shield' : o.type === 'science' ? 'flask' : 'check', 18),
            h('span', {}, h('b', { text: o.name || o.id }), h('span', { class: 'muted', text: ` · ${objType(o.type)}${o.critical ? t('shell.ms.critical') : ''}` })))))));
      }
      body.push(button({
        label: t('shell.ms.select'), variant: 'primary', size: 'lg', icon: 'rocket', className: 'btn--block',
        onClick: async () => {
          const res = await api.emit('mission:select', { missionId: m.id });
          if (!res.ok) toast(res.message || t('shell.ms.selectFail'), 'error');
        }
      }));
    } else if (isDirector) {
      body.push(h('p', { class: 'muted', text: t('shell.ms.noDetail') }));
    } else {
      body.push(h('p', { class: 'row muted' }, icon('lock', 18), h('span', { text: t('shell.ms.locked') })));
    }
    return h('article', { class: 'mission-card', dataset: { kind } },
      h('div', { class: 'mission-card__top' }, planet(kind, 140),
        h('div', { class: 'stack', dataset: { gap: 'sm' } },
          h('span', { class: 'eyebrow mission-card__tag', text: tag(m.id) }),
          h('h2', { class: 'mission-card__name', text: m.name || m.id }))),
      h('p', { class: 'mission-card__summary', text: m.summary || '' }),
      body,
      m.educationalNote ? h('p', { class: 'edu-note', text: m.educationalNote }) : null);
  });
  root.appendChild(h('div', { class: 'missions' }, cards));
}

let rootEl = null;
const screen = {
  id: 'mission-select',
  render(root, state, api) { rootEl = root; build(root, state, api); },
  update(state, prev, api) {
    // yalnız görev listesi ya da rol değiştiyse yeniden çiz (düğme odağı korunur)
    const key = (s) => JSON.stringify([s && s.missionOptions, s && s.me && s.me.role, s && s.director && s.director.missionDetails]);
    if (prev && key(state) === key(prev)) return;
    api.ui.clear(rootEl);
    build(rootEl, state, api);
  },
  destroy() { rootEl = null; }
};
export default screen;
