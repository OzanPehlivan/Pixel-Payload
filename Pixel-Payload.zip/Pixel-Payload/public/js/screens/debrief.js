// Pixel Payload — Sonuç (debrief) ekranı (Modül AE; Stitch 07 düzeni, takım sıralaması/ödül/kredi YOK).
// Büyük sonuç başlığı · yıldız + puan · bölümler · dersler · "Gerçekte NASA" · kaynaklar · TEKRAR OYNA / AYNI GÖREV / ÇIK.
import { h, panel, button, icon, meter, toast, confirmModal, fmt } from '../ui.js';
import { missionModules } from './simulation.js';
import { t, getLang } from '../i18n.js';
import '../lang/command.js';

// başlık/satır metinleri: cmd.deb.<outcome>.title / .line
const OUTCOME = {
  success: { status: 'ok', icon: 'check' },
  partial: { status: 'warn', icon: 'warn' },
  failure: { status: 'fail', icon: 'cross' }
};
const SECTION_ICON = {
  objectives: 'star', engineering: 'gear', fuel: 'fuel', power: 'power', comms: 'antenna', science: 'flask',
  budget: 'chart', events: 'warn', failed: 'cross', team: 'users'
};

let S = null;

async function loadScene(api) {
  try { if (api && typeof api.scene === 'function') { const m = await api.scene(); if (m && m.createVehicleScene) return m; } } catch (e) { /* yedek */ }
  try { return await import('/scene2d.js'); } catch (e) { return null; }
}

function stars(count) {
  const n = Math.max(0, Math.min(3, Number(count) || 0));
  return h('div', { class: 'deb-stars', role: 'img', 'aria-label': t('cmd.deb.stars', { n }) },
    [0, 1, 2].map((i) => h('span', { class: ['deb-star', i < n && 'is-on'], style: { animationDelay: `${200 + i * 160}ms` } }, icon('star', 40))));
}

function sectionNode(s) {
  const ratio = s.max > 0 ? s.score / s.max : 0;
  const st = ratio >= 0.75 ? 'ok' : ratio >= 0.4 ? 'warn' : 'fail';
  const lines = Array.isArray(s.lines) ? s.lines : [];
  const parts = () => [
    h('span', { class: 'deb-sec__icon', 'aria-hidden': 'true' }, icon(SECTION_ICON[s.id] || 'chart', 20)),
    h('span', { class: 'deb-sec__title', text: s.title || s.id }),
    h('span', { class: 'deb-sec__score', text: s.max > 0 ? `${fmt.num(s.score)} / ${fmt.num(s.max)}` : fmt.num(s.score) }),
    s.max > 0 ? meter({ value: s.score, max: s.max, status: st, label: `${s.title}: ${s.score} / ${s.max}` }) : h('span')];
  if (!lines.length) return h('div', { class: 'deb-sec deb-sec--flat', dataset: { status: st } }, h('div', { class: 'deb-sec__sum' }, parts()));
  return h('details', { class: 'deb-sec', dataset: { status: st } }, h('summary', { class: 'deb-sec__sum' }, parts()),
    h('ul', { class: 'deb-sec__lines' }, lines.map((l) => h('li', { text: l }))));
}

// Bilim hedefleri: yapıldı / yapılamadı + neden (alan yoksa panel yok)
function scienceGoalsPanel(goals) {
  if (!Array.isArray(goals) || !goals.length) return null;
  const done = goals.filter((g) => g && g.done).length;
  return panel({ title: t('cmd.deb.sciGoals'), icon: 'flask', className: 'deb__goals', actions: h('span', { class: 'deb-goals__n', text: `${done} / ${goals.length}` }) },
    h('ul', { class: 'deb-goals' }, goals.map((g) => h('li', { class: 'deb-goal', dataset: { done: g.done ? '1' : '0' } },
      icon(g.done ? 'check' : 'cross', 20),
      h('span', { class: 'deb-goal__txt' }, h('b', { text: g.name || g.id }),
        h('small', { text: g.reason || (g.done ? t('cmd.deb.goalDone') : t('cmd.deb.goalNot')) }))))));
}

// Bütçe raporu: harcanan / bütçe, aşım tutarı ve yüzdesi, puan etkisi (bölüm puanı)
// Puan düzeltmeleri: bölümler toplamı + her düzeltme (negatif) = toplam puan; alan yoksa hiçbir şey
function adjustmentsNode(deb) {
  const adj = Array.isArray(deb.adjustments) ? deb.adjustments.filter((a) => a && typeof a.points === 'number') : [];
  if (!adj.length && typeof deb.sectionTotal !== 'number') return null;
  const sign = (n) => (n > 0 ? `+${fmt.num(n)}` : n < 0 ? `−${fmt.num(Math.abs(n))}` : '0');
  return h('div', { class: 'deb-adj' },
    typeof deb.sectionTotal === 'number' ? h('p', { class: 'deb-adj__row deb-adj__row--sub' },
      h('span', { text: t('cmd.deb.sectionTotal') }), h('b', { text: fmt.num(deb.sectionTotal) })) : null,
    adj.map((a) => h('div', { class: 'deb-adj__row', dataset: { status: a.points < 0 ? 'fail' : 'ok' } },
      icon(a.points < 0 ? 'warn' : 'check', 18),
      h('span', { class: 'deb-adj__txt' }, h('span', { text: a.title || a.id }), a.text ? h('small', { text: a.text }) : null),
      h('b', { text: sign(a.points) }))),
    h('p', { class: 'deb-adj__row deb-adj__row--total' }, h('span', { text: t('cmd.deb.total') }), h('b', { text: fmt.num(deb.score) })));
}

function budgetPanel(b, sec, adj) {
  if (!b || typeof b.spent !== 'number') return null;
  const over = typeof b.overrun === 'number' && b.overrun > 0;
  const st = over ? 'fail' : 'ok';
  return panel({ title: t('cmd.deb.budget'), icon: 'chart', className: 'deb__budget' },
    h('div', { class: 'deb-budget', dataset: { status: st } },
      h('p', { class: 'deb-budget__big' },
        h('b', { text: fmt.num(b.spent, 1) }), h('span', { text: ` / ${fmt.num(b.budget, 1)} M$` })),
      meter({ value: Math.min(b.spent, b.budget), max: Math.max(b.budget, b.spent), status: st, label: t('cmd.g.spentOf', { spent: fmt.num(b.spent, 1), budget: fmt.num(b.budget, 1) }) }),
      h('p', { class: 'deb-budget__verdict' }, icon(over ? 'warn' : 'check', 18),
        h('span', { text: over
          ? t('cmd.deb.over', { v: fmt.num(b.overrun, 1), pct: t('cmd.pct', { v: fmt.num(b.overrunPct, 1) }) })
          : (typeof b.budget === 'number' ? t('cmd.deb.withinLeft', { v: fmt.num(b.budget - b.spent, 1) }) : t('cmd.deb.within')) })),
      sec && sec.max > 0 ? h('p', { class: 'deb-budget__score', text: t('cmd.deb.effect', { score: fmt.num(sec.score), max: fmt.num(sec.max) }) }) : null,
      adj && typeof adj.points === 'number' && adj.points !== 0
        ? h('p', { class: 'deb-budget__penalty' }, h('b', { text: t('cmd.deb.points', { v: `${adj.points < 0 ? '−' : '+'}${fmt.num(Math.abs(adj.points))}` }) }),
          h('span', { text: ` ${adj.title || t('cmd.deb.penalty')}${adj.text ? ` · ${adj.text}` : ''}` })) : null));
}

const screen = {
  id: 'debrief',
  render(root, state, api) {
    S = { alive: true, scene: null, root, api, lang: getLang() };
    const inst = S;
    const res = state.result || {};
    const deb = res.debrief || {};
    const sim = res.simulation || {};
    const outcome = deb.outcome || sim.outcome || 'failure';
    const outcomeKey = OUTCOME[outcome] ? outcome : 'failure';
    const o = OUTCOME[outcomeKey];
    const me = state.me || {};
    const canRestart = !!(me.isHost || me.role === 'director');
    const reason = t('cmd.deb.restartReason');

    const wrap = h('div', { class: 'deb', dataset: { outcome: o.status } });

    // ---- başlık
    wrap.append(h('header', { class: 'deb-hero' },
      h('div', { class: 'deb-hero__text' },
        h('p', { class: 'deb-hero__mission', text: state.mission ? state.mission.name : t('cmd.deb.mission') }),
        h('h1', { class: 'deb-hero__title' }, icon(o.icon, 40), h('span', { text: t(`cmd.deb.${outcomeKey}.title`) })),
        h('p', { class: 'deb-hero__reason', text: sim.reason || t(`cmd.deb.${outcomeKey}.line`) })),
      h('div', { class: 'deb-hero__score' },
        stars(deb.stars),
        h('p', { class: 'deb-score' }, h('span', { class: 'deb-score__num', text: fmt.num(deb.score) }), h('span', { class: 'deb-score__unit', text: t('cmd.deb.score') })))));

    // ---- sol: bölümler
    const sections = Array.isArray(deb.sections) ? deb.sections : [];
    const secPanel = panel({ title: t('cmd.deb.breakdown'), icon: 'chart', className: 'deb__sections' },
      sections.length ? h('div', { class: 'deb-secs' }, sections.map(sectionNode)) : h('p', { class: 'deb-empty', text: t('cmd.deb.noBreakdown') }),
      adjustmentsNode(deb));

    // ---- orta: araç + hedefler + aşamalar
    const stage = h('div', { class: 'deb-stage', 'aria-label': t('cmd.deb.stageAria') });
    const objectives = Array.isArray(sim.objectives) ? sim.objectives : [];
    const phases = Array.isArray(sim.phases) ? sim.phases : ((state.simulation && state.simulation.phases) || []);
    const objList = objectives.length ? h('ul', { class: 'deb-objs' }, objectives.map((ob) => h('li', { class: 'deb-obj', dataset: { done: ob.done ? '1' : '0' } },
      icon(ob.done ? 'check' : 'cross', 20), h('span', { text: ob.name || ob.id })))) : null;
    const phaseRow = phases.length ? h('ol', { class: 'deb-phases', 'aria-label': t('cmd.sim.phases') }, phases.map((p) => h('li', { class: 'deb-phase', dataset: { status: p.status }, title: p.note || '' },
      icon(p.status === 'fail' ? 'cross' : p.status === 'warn' ? 'warn' : 'check', 16), h('span', { text: p.name || p.id }))),
      // oynanmayan aşamalar (simulation.phaseList'ten) soluk, yalnız adla
      ((state.simulation && Array.isArray(state.simulation.phaseList)) ? state.simulation.phaseList : [])
        .filter((pl) => pl && !phases.some((p) => p.id === pl.id))
        .map((pl) => h('li', { class: 'deb-phase deb-phase--skip', dataset: { status: 'pending' }, title: t('cmd.deb.notReached') }, h('span', { text: pl.name || pl.id })))) : null;
    const center = h('div', { class: 'deb__center' }, h('div', { class: 'deb-stage-frame' }, stage), phaseRow,
      objList ? panel({ title: t('cmd.deb.objectives'), icon: 'star', className: 'deb__objectives' }, objList) : null,
      scienceGoalsPanel(deb.scienceGoals || sim.scienceGoals),
      budgetPanel(deb.budget, sections.find((s) => s && s.id === 'budget'), (Array.isArray(deb.adjustments) ? deb.adjustments : []).find((a) => a && a.id === 'budget-overrun')));

    // ---- sağ: dersler + NASA + kaynaklar + eylemler
    const lessons = Array.isArray(deb.lessons) ? deb.lessons : [];
    const sources = Array.isArray(deb.sources) ? deb.sources.filter((s) => s && s.url && /^https?:\/\//i.test(s.url)) : [];
    const actions = h('div', { class: 'deb-actions' },
      button({ label: t('cmd.deb.again'), sub: t('cmd.deb.againSub'), icon: 'play', variant: 'go', size: 'lg', disabled: !canRestart,
        onClick: () => send(api, 'game:again', { mode: 'new' }) }),
      button({ label: t('cmd.deb.same'), sub: t('cmd.deb.sameSub'), icon: 'rocket', variant: 'ghost', disabled: !canRestart,
        onClick: () => send(api, 'game:again', { mode: 'same' }) }),
      button({ label: t('cmd.deb.exit'), icon: 'exit', variant: 'ghost', onClick: () => leave(api) }));
    if (!canRestart) actions.querySelectorAll('button:disabled').forEach((b) => { b.title = reason; b.setAttribute('aria-describedby', 'deb-restart-note'); });
    if (!canRestart) actions.append(h('p', { class: 'deb-actions__note', id: 'deb-restart-note' }, icon('info', 16), h('span', { text: reason + '.' })));

    const side = h('div', { class: 'deb__side' },
      actions,
      lessons.length ? panel({ title: t('cmd.deb.lessons'), icon: 'book', className: 'deb__lessons' }, h('ul', { class: 'deb-lessons' }, lessons.map((l) => h('li', { text: l })))) : null,
      deb.nasaReality ? panel({ title: t('cmd.deb.nasa'), icon: 'globe', className: 'deb__nasa' }, h('p', { class: 'deb-nasa', text: deb.nasaReality })) : null,
      sources.length ? panel({ title: t('cmd.deb.sources'), icon: 'link', className: 'deb__sources' },
        h('ul', { class: 'deb-sources' }, sources.map((s) => h('li', {},
          h('a', { href: s.url, target: '_blank', rel: 'noopener noreferrer' }, h('span', { text: s.title || s.url }), icon('link', 14)))))) : null);

    wrap.append(h('div', { class: 'deb__grid' }, secPanel, center, side));
    if (state.mission && state.mission.educationalNote) wrap.append(h('p', { class: 'deb-note', text: state.mission.educationalNote }));
    root.appendChild(wrap);

    // Araç: son aşamanın pozu, animasyonsuz
    loadScene(api).then((mod) => {
      if (!inst.alive || !mod) return;
      try {
        inst.scene = mod.createVehicleScene(stage);
        inst.scene.setVehicle({ missionId: (state.mission && state.mission.id) || 'lunar', modules: missionModules(state), items: state.vehicle || [] });
        for (const p of phases) inst.scene.playPhase(p.id, p.status, { instant: true });
      } catch (e) { inst.scene = null; }
    });
  },
  update(state, prev) {
    // Sonuç sabit; yalnız yetki (host devri / rol), dil ya da sonuç verisi (dil değişince sunucu yeniden gönderir) değişirse yeniden çiz
    if (!S || !prev) return;
    const a = prev.me || {}, b = state.me || {};
    const lang = getLang();
    if (a.isHost === b.isHost && a.role === b.role && S.lang === lang && prev.result === state.result) return;
    const { root, api } = S;
    screen.destroy();
    while (root.firstChild) root.removeChild(root.firstChild);
    screen.render(root, state, api);
  },
  destroy() {
    if (!S) return;
    S.alive = false;
    try { S.scene && S.scene.dispose(); } catch (e) { /* yok say */ }
    S.scene = null;
  }
};
export default screen;

async function send(api, event, payload) {
  const res = await api.emit(event, payload);
  if (!res || !res.ok) toast((res && res.message) || t('cmd.err.request'), 'error');
}

async function leave(api) {
  const ok = await confirmModal({ title: t('cmd.deb.leaveTitle'), body: t('cmd.deb.leaveBody'), okLabel: t('cmd.deb.exit'), okVariant: 'nogo' });
  if (!ok) return;
  const res = await api.emit('room:leave', {});
  if (res && !res.ok && res.error !== 'OFFLINE') toast(res.message || t('cmd.err.leave'), 'error');
  try { if (api.nav && typeof api.nav.reset === 'function') api.nav.reset('home'); } catch (e) { /* yok say */ }
}
