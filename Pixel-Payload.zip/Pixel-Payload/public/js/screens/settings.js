// Ayarlar: dil, ad, hareketi azalt, yazı boyutu (localStorage; core.prefs / i18n). Değişiklik anında uygulanır.
import { t } from '../i18n.js';
import '../lang/shell.js';

const SCALES = [[1, 'normal'], [1.15, 'large'], [1.3, 'xlarge']];

const screen = {
  id: 'settings',
  render(root, state, api) {
    const { h, panel, toast, langSwitch } = api.ui;
    const p = api.prefs;

    const name = h('input', { class: 'field__input', id: 'set-name', type: 'text', maxlength: 16, value: p.get('name') || '', autocomplete: 'nickname' });
    name.addEventListener('change', () => { p.set('name', name.value.trim()); toast(t('shell.set.nameSaved'), 'ok', 1800); });

    const motion = h('input', { type: 'checkbox', id: 'set-motion', checked: !!p.get('reduceMotion') });
    motion.addEventListener('change', () => p.set('reduceMotion', motion.checked));

    const seg = h('div', { class: 'seg', role: 'group', 'aria-label': t('shell.set.textSize') });
    const drawSeg = () => {
      api.ui.clear(seg);
      const cur = Number(p.get('textScale')) || 1;
      SCALES.forEach(([v, key]) => seg.appendChild(h('button', {
        type: 'button', class: 'seg__opt', 'aria-pressed': Math.abs(cur - v) < 0.01 ? 'true' : 'false', text: t('shell.set.scale.' + key),
        onClick: () => { p.set('textScale', v); drawSeg(); }
      })));
    };
    drawSeg();

    root.appendChild(h('div', { class: 'settings stack' },
      h('div', { class: 'screen-head' }, h('span', { class: 'eyebrow', text: t('shell.set.eyebrow') }), h('h1', { class: 'screen-title', text: t('shell.tab.settings') }),
        h('p', { class: 'muted', text: t('shell.set.intro') })),
      panel({ title: t('shell.set.language'), icon: 'globe' },
        h('div', { class: 'stack' }, langSwitch(), h('span', { class: 'field__hint', text: t('shell.lang.hint') }))),
      panel({ title: t('shell.set.player'), icon: 'crew' },
        h('div', { class: 'field' }, h('label', { class: 'field__label', for: 'set-name', text: t('shell.set.defaultName') }), name,
          h('span', { class: 'field__hint', text: t('shell.set.nameHint') }))),
      panel({ title: t('shell.set.display'), icon: 'eye' },
        h('div', { class: 'stack' },
          h('label', { class: 'toggle', for: 'set-motion' }, motion, h('span', {}, h('b', { text: t('shell.set.reduceMotion') }),
            h('span', { class: 'muted', text: t('shell.set.reduceMotionHint') }))),
          h('div', { class: 'field' }, h('span', { class: 'field__label', text: t('shell.set.textSize') }), seg)))));
  }
};
export default screen;
