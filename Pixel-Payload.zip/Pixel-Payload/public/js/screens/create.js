// Oda kur: ad gir → room:create. Başarılı olunca sunucu `state` gönderir, app lobiye geçer.
import { t } from '../i18n.js';
import '../lang/shell.js';

const screen = {
  id: 'create',
  render(root, state, api) {
    const { h, icon, button, panel } = api.ui;
    const err = h('p', { class: 'field__error', id: 'create-err', role: 'alert' });
    const name = h('input', {
      class: 'field__input', id: 'create-name', type: 'text', maxlength: 16, autocomplete: 'nickname',
      value: api.prefs.get('name') || '', 'aria-describedby': 'create-err create-hint', placeholder: t('shell.form.namePlaceholder')
    });
    const submit = async () => {
      const v = name.value.trim();
      if (!v) { err.textContent = t('shell.form.nameErr'); name.setAttribute('aria-invalid', 'true'); name.focus(); return; }
      err.textContent = '';
      name.removeAttribute('aria-invalid');
      api.prefs.set('name', v);
      const res = await api.emit('room:create', { name: v });
      if (!res.ok) { err.textContent = res.message || t('shell.create.failed'); name.focus(); }
    };
    const go = button({ label: t('shell.create.go'), variant: 'primary', size: 'lg', icon: 'crown', className: 'btn--block', type: 'submit' });
    const form = h('form', { class: 'entry__form', novalidate: true, onSubmit: (e) => { e.preventDefault(); if (!go.disabled) busy(go, submit()); } },
      h('div', { class: 'field' },
        h('label', { class: 'field__label', for: 'create-name', text: t('shell.form.nameLabel') }),
        name,
        h('span', { class: 'field__hint', id: 'create-hint', text: t('shell.create.hint') }),
        err),
      go);

    root.appendChild(h('div', { class: 'screen-head' },
      h('span', { class: 'eyebrow', text: t('shell.create.eyebrow') }),
      h('h1', { class: 'screen-title', text: t('shell.create.title') })));
    root.appendChild(h('div', { class: 'entry' },
      panel({ title: t('shell.create.panel'), icon: 'crown', active: true }, form),
      h('div', { class: 'entry__aside' },
        note(h, icon, 'wifi', t('shell.create.note1')),
        note(h, icon, 'users', t('shell.create.note2')),
        note(h, icon, 'crown', t('shell.create.note3')))));
    setTimeout(() => name.focus(), 0);
  }
};

function note(h, icon, ic, text) {
  return h('p', { class: 'entry__note' }, icon(ic, 20), h('span', { text }));
}
// Form gönderiminde düğmeyi meşgul göster
async function busy(btn, p) {
  btn.disabled = true;
  btn.setAttribute('aria-busy', 'true');
  try { await p; } finally { btn.disabled = false; btn.removeAttribute('aria-busy'); }
}
export default screen;
