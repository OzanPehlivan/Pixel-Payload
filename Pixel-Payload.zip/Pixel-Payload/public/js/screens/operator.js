// Operatör komuta merkezi (design fazı). Üstte tek bakışta: fırlatma durumu (4 durum) + bütçe, kütle, enerji, itki.
// Ortada: araç + modül kapasitesi, rol başına sistem durumu, aktarılacak değerler, görev ve bilim hedefleri.
// Altta: harcama defteri; ayrıntılı hazırlık raporu ve telemetri katlanır bölümde. İstemci kural hesaplamaz.
// Metinler cmd.* sözlüğünden (lang/command.js); rol adları shell.role* (AM).
import { h, makeKit, ENGINEERS, categoryName, num, smart, withUnit, meter } from '../widgets/util.js';
import { titleBar, section, designTimer } from '../widgets/frame.js';
import { mountVehicle } from '../widgets/vehicle.js';
import {
  directorTelemetry, capacityView, scienceGoalsView, tightestDv, kindCounts, kindOfItem,
  KIND_LABEL, KIND_ORDER, LAUNCH, LAUNCH_ORDER, launchStatusOf, launchLine,
} from '../widgets/telemetry.js';
import { readinessList, countsStrip } from '../widgets/readiness.js';
import { ledgerView } from '../widgets/ledger.js';
import { t, upperL, getLang } from '../i18n.js';
import { tk, roleShort, roleName } from '../lang/command.js';

let inst = null;

// ---- veri yardımcıları (yalnız okuma/biçim)
function budgetOf(d) {
  if (d.budget && typeof d.budget.spent === 'number') return d.budget;
  const tel = d.telemetry || {};
  const total = typeof tel.budget === 'number' ? tel.budget : d.mission && d.mission.budget;
  if (typeof tel.cost !== 'number' || typeof total !== 'number') return null;
  return { budget: total, spent: tel.cost, remaining: total - tel.cost, byRole: null };
}
const missionNames = (d) => {
  const out = {};
  for (const p of (d.mission && d.mission.phases) || []) out[p.id] = p.name;
  return out;
};
const modNameFn = (d) => {
  const mods = (d.mission && d.mission.modules) || [];
  return (id) => (mods.find((m) => m.id === id) || {}).name || id;
};

// ---- 1) Fırlatma durumu: büyük kelime + 4 basamaklı durum merdiveni
function statusView(kit, st) {
  const d = st.director || {};
  const code = launchStatusOf(st, d.readiness);
  if (!code) {
    return h('div', { class: 'cc-status is-idle' },
      h('span', { class: 'cc-status__k', text: t('cmd.status.k') }),
      h('span', { class: 'cc-status__v', text: t('cmd.status.noData') }),
      h('p', { class: 'cc-status__line', text: t('cmd.status.noDataLine') }));
  }
  const L = LAUNCH[code];
  return h('div', { class: ['cc-status', `is-${L.tone}`], 'aria-live': 'polite' },
    h('span', { class: 'cc-status__k', text: t('cmd.status.k') }),
    h('span', { class: 'cc-status__v' }, kit.icon(L.icon), h('span', { text: L.label })),
    h('p', { class: 'cc-status__line', text: launchLine(st, code) }),
    h('ol', { class: 'cc-ladder', 'aria-label': t('cmd.status.ladder') }, LAUNCH_ORDER.map((c) => h('li', {
      class: ['cc-ladder__step', `is-${LAUNCH[c].tone}`, c === code && 'is-on'], 'aria-current': c === code ? 'step' : null,
    }, h('span', { text: LAUNCH[c].label })))));
}

// ---- 2) Ana göstergeler: bütçe, kütle, enerji, itki (az ama büyük sayı)
function gauge(kit, { label, icon, value, unit, sub, tone, extra }) {
  return h('div', { class: ['cc-gauge', tone && `is-${tone}`] },
    h('span', { class: 'cc-gauge__k' }, kit.icon(icon), h('span', { text: label })),
    h('span', { class: 'cc-gauge__v' }, h('b', { text: value }), unit ? h('span', { text: unit }) : null),
    extra || null,
    sub ? h('span', { class: 'cc-gauge__sub', text: sub }) : null);
}

function budgetBar(b) {
  const total = Math.max(b.budget || 0, b.spent || 0, 1);
  const segs = [];
  if (b.byRole) {
    for (const r of ENGINEERS) {
      const v = b.byRole[r];
      if (typeof v === 'number' && v > 0) segs.push(h('span', { class: ['cc-cap__seg', `cc-seg--${r}`], title: `${roleShort(r)}: ${num(v, 1)} M$`, style: { width: `${v / total * 100}%` } }));
    }
  } else if (b.spent > 0) segs.push(h('span', { class: ['cc-cap__seg', 'cc-seg--used'], style: { width: `${Math.min(100, b.spent / total * 100)}%` } }));
  const over = b.spent > b.budget;
  return h('div', { class: ['cc-cap__bar', 'cc-budgetbar', over && 'is-over'], role: 'img', 'aria-label': t('cmd.g.spentOf', { spent: num(b.spent, 1), budget: num(b.budget, 1) }) }, segs,
    over ? h('i', { class: 'cc-budgetbar__limit', style: { left: `${b.budget / total * 100}%` }, 'aria-hidden': 'true' }) : null);
}

function gaugesView(kit, st) {
  const d = st.director || {};
  const tel = d.telemetry || {};
  const lim = (d.mission && d.mission.limits) || {};
  const out = [];

  const b = budgetOf(d);
  if (b) {
    const over = b.remaining < 0;
    out.push(gauge(kit, {
      label: over ? t('cmd.g.budgetOver') : t('cmd.g.budgetLeft'), icon: 'chart', tone: over ? 'bad' : b.remaining < b.budget * 0.1 ? 'warn' : 'ok',
      value: num(Math.abs(b.remaining), 1), unit: 'M$', extra: budgetBar(b),
      sub: t('cmd.g.spentOf', { spent: num(b.spent, 1), budget: num(b.budget, 1) }) + (over ? ` · ${t('cmd.g.overNote')}` : ''),
    }));
  }

  const m = tel.massKg || {};
  if (typeof m.total === 'number') {
    const maxM = typeof lim.maxLaunchMassKg === 'number' ? lim.maxLaunchMassKg : null;
    const parts = smart(m.total, 'kg').split(' ');
    out.push(gauge(kit, {
      label: t('cmd.g.mass'), icon: 'rocket', tone: maxM && m.total > maxM ? 'bad' : null,
      value: parts[0], unit: parts[1] || '', extra: maxM ? meter(m.total, maxM, m.total > maxM ? 'bad' : 'ok') : null,
      sub: maxM ? t('cmd.g.massLimit', { v: smart(maxM, 'kg') }) : null,
    }));
  }

  const p = tel.power || {};
  if (typeof p.marginW === 'number') {
    const parts = smart(Math.abs(p.marginW), 'W').split(' ');
    out.push(gauge(kit, {
      label: p.marginW < 0 ? t('cmd.g.powerDeficit') : t('cmd.g.powerMargin'), icon: 'power', tone: p.marginW < 0 ? 'bad' : 'ok',
      value: `${p.marginW < 0 ? '−' : '+'}${parts[0]}`, unit: parts[1] || 'W',
      extra: typeof p.genW === 'number' && typeof p.useW === 'number' ? meter(p.useW, Math.max(p.genW, p.useW), p.marginW < 0 ? 'bad' : 'ok') : null,
      sub: t('cmd.g.genUse', { gen: smart(p.genW, 'W'), use: smart(p.useW, 'W') }),
    }));
  }

  const dvW = tightestDv(tel.dv, missionNames(d));
  if (typeof tel.twr === 'number' || dvW) {
    const minT = typeof lim.minTWR === 'number' ? lim.minTWR : null;
    const twrBad = minT !== null && typeof tel.twr === 'number' && tel.twr < minT;
    const dvBad = dvW && dvW.pct < 0;
    const dvLow = dvW && dvW.pct < 5;
    out.push(gauge(kit, {
      label: t('cmd.g.thrust'), icon: 'engine', tone: twrBad || dvBad ? 'bad' : dvLow ? 'warn' : 'ok',
      value: num(tel.twr, 2), unit: minT !== null ? t('cmd.g.twrMin', { v: num(minT, 2) }) : 'TWR',
      sub: dvW ? t('cmd.g.tightDv', { name: dvW.name, pct: `${dvW.pct >= 0 ? '+' : ''}${num(dvW.pct, 0)}`, av: smart(dvW.av, 'm/s'), rq: smart(dvW.rq, 'm/s') }) : null,
    }));
  }
  if (!out.length) return h('p', { class: 'ad-empty', text: t('cmd.g.empty') });
  return h('div', { class: 'cc-gauges' }, out);
}

// ---- 3) Rol başına sistem durumu
function teamView(kit, st) {
  const d = st.director || {};
  const items = d.readiness || [];
  const prog = d.progress || {};
  const b = budgetOf(d);
  const mass = (d.telemetry && d.telemetry.massKg && d.telemetry.massKg.byRole) || {};
  const modName = modNameFn(d);
  const holder = (r) => (st.players || []).find((p) => p.role === r);
  return h('ul', { class: 'cc-team' }, ENGINEERS.map((r) => {
    const c = kindCounts(items.filter((i) => i.role === r));
    const bad = KIND_ORDER.filter((k) => k !== 'ok' && c[k] > 0);
    const pl = holder(r);
    const p = prog[r] || { items: 0, missingCategories: [] };
    const miss = p.missingCategories || [];
    const worst = bad[0];
    return h('li', { class: ['cc-team__row', `cc-team__row--${r}`, worst ? `is-${worst}` : 'is-ok'] },
      h('div', { class: 'cc-team__head' },
        kit.roleTag(r),
        h('span', { class: 'cc-team__who' },
          pl ? h('i', { class: ['ad-dot', pl.connected ? 'is-ok' : 'is-bad'], 'aria-hidden': 'true' }) : null,
          h('span', { text: pl ? pl.name : t('cmd.team.empty') }))),
      h('div', { class: 'cc-team__kinds' },
        bad.length
          ? bad.map((k) => h('span', { class: ['cc-kind', `is-${k}`] }, h('b', { text: num(c[k]) }), h('span', { text: KIND_LABEL[k] })))
          : h('span', { class: 'cc-kind is-ok' }, kit.icon('check'), h('span', { text: c.ok ? t('cmd.team.allReady') : t('cmd.team.noItems') })),
        c.ok && bad.length ? h('span', { class: 'cc-kind is-dim' }, h('b', { text: num(c.ok) }), h('span', { text: KIND_LABEL.ok })) : null),
      h('dl', { class: 'cc-team__facts' },
        h('div', null, h('dt', { text: t('cmd.team.parts') }), h('dd', { text: num(p.items) })),
        typeof mass[r] === 'number' ? h('div', null, h('dt', { text: t('cmd.team.mass') }), h('dd', { text: smart(mass[r], 'kg') })) : null,
        b && b.byRole && typeof b.byRole[r] === 'number' ? h('div', null, h('dt', { text: t('cmd.team.spend') }), h('dd', { text: `${num(b.byRole[r], 1)} M$` })) : null),
      miss.length ? h('p', { class: 'cc-team__miss' }, kit.icon('warn'),
        h('span', { text: miss.slice(0, 2).map((m) => `${categoryName(m.category)} · ${modName(m.moduleId)} (${num(m.have)}/${num(m.min)})`).join(' · ') + (miss.length > 2 ? ` · +${miss.length - 2}` : '') })) : null);
  }));
}

// ---- 4) Aktarılacak değerler (AKTAR → özel mesaj)
function needsView(kit, st, onRelay) {
  const needs = (st.director && st.director.needs) || {};
  const rows = ENGINEERS.filter((r) => (needs[r] || []).length);
  if (!rows.length) return h('p', { class: 'ad-empty', text: t('cmd.needs.empty') });
  return h('div', { class: 'ad-relay' },
    h('p', { class: 'ad-muted', text: t('cmd.needs.hint') }),
    rows.map((r) => h('div', { class: 'ad-relay__group' },
      h('div', { class: 'ad-relay__to' }, h('span', { class: 'ad-muted', text: t('cmd.needs.tell') }), kit.roleTag(r)),
      h('ul', { class: 'ad-relay__list' }, needs[r].map((n) => h('li', { class: 'ad-relay__row' },
        h('span', { class: 'ad-relay__txt' }, h('small', { text: n.label }), h('b', { text: withUnit(n.value, n.unit, 1) }),
          n.fromRole ? h('small', { class: `ad-c-${n.fromRole}`, text: t('cmd.needs.source', { role: roleShort(n.fromRole) }) }) : null),
        kit.button({ label: t('cmd.needs.relay'), variant: 'ghost', small: true, icon: 'chat', fk: `relay:${r}:${n.id}`, ariaLabel: t('cmd.needs.relayAria', { label: n.label, role: roleName(r) }),
          onClick: () => onRelay(r, `${n.label}: ${withUnit(n.value, n.unit, 1)}`) })))))));
}

// ---- 5) Görev hedefleri + bilim hedefleri
function goalsView(kit, d) {
  const list = (d.mission && d.mission.objectives) || [];
  const sg = d.telemetry && d.telemetry.scienceGoals;
  const lines = (d.mission && d.mission.briefing) || [];
  return [
    list.length ? h('ol', { class: 'ad-objs' }, list.map((o, i) => h('li', { class: ['ad-obj', o.critical && 'is-critical'] },
      h('span', { class: 'ad-obj__n', text: String(i + 1).padStart(2, '0') }),
      h('span', { class: 'ad-obj__txt' }, h('b', { text: o.name }),
        h('small', null, h('span', { text: tk(`cmd.objType.${o.type}`) || upperL(o.type || '') }),
          o.critical ? h('span', { class: 'ad-badge is-bad', text: t('cmd.goals.critical') }) : null))))) : h('p', { class: 'ad-empty', text: t('cmd.goals.none') }),
    Array.isArray(sg) && sg.length ? h('div', { class: 'cc-sub' },
      h('h3', { class: 'cc-sub__title', text: t('cmd.goals.sciTitle') }),
      scienceGoalsView(kit, sg, { showValue: true }),
      h('p', { class: 'ad-hint', text: t('cmd.goals.sciHint') })) : null,
    lines.length ? h('details', { class: 'ad-brief__more' }, h('summary', { text: t('cmd.goals.briefing') }),
      h('ul', { class: 'ad-brief__list' }, lines.map((l) => h('li', { text: l })))) : null,
  ];
}

// ---- 6) Ayrıntılar: hazırlık raporu (türe göre) + birleşik telemetri (katlanır)
function detailsView(kit, d) {
  const items = d.readiness || [];
  const unmet = d.unmetRequirements || [];
  const groups = KIND_ORDER.map((k) => ({ k, list: items.filter((i) => kindOfItem(i) === k) })).filter((g) => g.list.length);
  return [
    h('details', { class: 'cc-more' },
      h('summary', null, h('span', { text: t('cmd.more.report') }), h('small', { text: t('cmd.more.items', { n: items.length, count: num(items.length) }) })),
      countsStrip(kit, items),
      groups.length ? groups.map((g) => h('div', { class: 'cc-kgroup' },
        h('h3', { class: ['cc-kgroup__title', `is-${g.k}`], text: `${upperL(KIND_LABEL[g.k])} · ${num(g.list.length)}` }),
        readinessList(kit, g.list, { showRole: true }))) : h('p', { class: 'ad-empty', text: t('cmd.more.noItems') }),
      unmet.length ? h('div', { class: 'ad-unmet' }, h('h3', { class: 'ad-tgroup__title', text: t('cmd.more.unmet') }),
        h('ul', null, unmet.map((u) => h('li', null, kit.icon('warn'), h('span', { text: u.text || `${u.itemId}: ${u.requires}` }))))) : null),
    h('details', { class: 'cc-more' },
      h('summary', null, h('span', { text: t('cmd.more.tele') }), h('small', { text: t('cmd.more.allNums') })),
      directorTelemetry(kit, d.telemetry, d.mission)),
  ];
}

function draw(st) {
  const s = inst;
  const d = st.director || {};
  const design = st.phase === 'design';
  s.title.sub.textContent = st.mission ? `${st.mission.name} · ${design ? t('cmd.op.design') : upperL(tk(`shell.phase.${st.phase}`) || st.phase)}` : '';
  s.timer.set(st.design);

  const mods = ((d.mission && d.mission.modules) || []).map((m) => ({ id: m.id, name: m.name, role: m.role }));
  s.vehicle.set({ missionId: st.mission && st.mission.id, modules: mods, items: st.vehicle || [], highlightModule: null });

  const tel = d.telemetry || {};
  const lang = getLang(); // dil değişince bölümler yeniden çizilsin
  s.secStatus.render([launchStatusOf(st, d.readiness), st.launchNote, lang]);
  s.secGauges.render([d.budget, tel.cost, tel.budget, tel.massKg && tel.massKg.total, tel.power, tel.twr, tel.dv, d.mission && d.mission.limits, lang]);
  s.secCap.render([tel.capacity || st.capacity, lang]);
  s.secTeam.render([d.progress, st.players, d.readiness, d.budget && d.budget.byRole, tel.massKg && tel.massKg.byRole, lang]);
  s.secNeeds.render([d.needs, lang]);
  s.secGoals.render([d.mission && d.mission.objectives, tel.scienceGoals, d.mission && d.mission.briefing, lang]);
  s.secLedger.render([d.ledger, lang]);
  s.ledgerPanel.hidden = !Array.isArray(d.ledger);
  s.secMore.render([d.readiness, d.unmetRequirements, d.telemetry, lang]);
  s.openWrap.hidden = !design;
}

const screen = {
  id: 'operator',
  render(root, state, api) {
    screen.destroy();
    const kit = makeKit(api);
    let last = state;
    const cur = () => last.director || {};

    const title = titleBar(t('cmd.op.title'), '');
    const timer = designTimer();
    title.right.append(h('div', { class: 'ad-stat' }, kit.icon('clock'), h('span', { class: 'ad-muted', text: t('cmd.op.time') }), timer.el));

    const openBtn = kit.button({
      label: t('cmd.op.open'), sub: t('cmd.op.openSub'), variant: 'primary', icon: 'shield',
      onClick: () => kit.act('review:open', {}),
    });
    const openWrap = h('div', { class: 'cc-open' }, openBtn,
      h('p', { class: 'ad-hint', text: t('cmd.op.openHint') }));

    const box = (cls) => h('div', { class: ['ad-sec', cls] });
    const relay = (role, text) => kit.act('chat:send', { to: role, text }, t('cmd.needs.sent', { role: roleShort(role) }));

    const secStatus = section(box('cc-hero__status'), () => statusView(kit, last));
    const secGauges = section(box('cc-hero__gauges'), () => gaugesView(kit, last));
    const secCap = section(box(), () => {
      const cap = (cur().telemetry && cur().telemetry.capacity) || last.capacity;
      return cap ? [h('h3', { class: 'cc-sub__title', text: t('cmd.op.capacity') }), capacityView(kit, cap),
        h('div', { class: 'cc-legend', 'aria-hidden': 'true' }, ENGINEERS.map((r) => h('span', { class: `cc-legend__i cc-legend__i--${r}`, text: roleShort(r) })))] : null;
    });
    const secTeam = section(box(), () => teamView(kit, last));
    const secNeeds = section(box(), () => needsView(kit, last, relay));
    const secGoals = section(box(), () => goalsView(kit, cur()));
    const secLedger = section(box('cc-ledger-wrap'), () => ledgerView(kit, cur().ledger, { moduleName: modNameFn(cur()) }));
    const secMore = section(box(), () => detailsView(kit, cur()));
    secLedger.el.tabIndex = 0; // kaydırılabilir bölge klavyeyle de gezilir
    secLedger.el.setAttribute('aria-label', t('cmd.op.ledgerAria'));

    const vehBox = h('div', { class: 'ad-vehbox cc-vehbox' });
    const ledgerPanel = kit.panel({ title: t('cmd.op.ledger'), icon: 'chart', class: 'cc-a-ledger' }, secLedger.el);
    const hero = h('section', { class: 'cc-hero', 'aria-label': t('cmd.op.heroAria') }, secStatus.el, secGauges.el);
    const grid = h('div', { class: 'cc-grid' },
      kit.panel({ title: t('cmd.op.team'), icon: 'crew', class: 'cc-a-team' }, secTeam.el),
      kit.panel({ title: t('cmd.op.vehicle'), icon: 'rocket', class: 'cc-a-veh' }, vehBox, secCap.el),
      kit.panel({ title: t('cmd.op.needs'), icon: 'antenna', class: 'cc-a-needs', accent: 'focus' }, secNeeds.el),
      kit.panel({ title: t('cmd.op.goals'), icon: 'star', class: 'cc-a-goals' }, secGoals.el),
      ledgerPanel,
      kit.panel({ title: t('cmd.op.details'), icon: 'shield', class: 'cc-a-more' }, secMore.el));
    const page = h('div', { class: 'ad-work ad-op cc' }, title.el, hero, openWrap, grid);
    root.append(page);

    const vehicle = mountVehicle(vehBox, api);
    inst = { kit, title, timer, vehicle, openWrap, page, ledgerPanel,
      secStatus, secGauges, secCap, secTeam, secNeeds, secGoals, secLedger, secMore, setLast: (s) => { last = s; } };
    draw(state);
  },
  update(state) {
    if (!inst || !state) return;
    inst.setLast(state);
    draw(state);
  },
  destroy() {
    if (!inst) return;
    inst.timer.destroy();
    inst.vehicle.destroy();
    inst.page.remove();
    inst = null;
  },
};

export default screen;
