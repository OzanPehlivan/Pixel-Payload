// Mühendis çalışma alanı (design fazı). Karar odaklı: kategori = karar kartı, seçenekler yan yana kıyaslanır;
// modül alanı (kendi / diğer / boş) araç altında anında güncellenir; hazırlık kalemleri türleriyle rozetlenir.
// Yalnız sunucunun bu mühendise verdiği veri çizilir. Maliyet/bütçe SAYISI yok: yalnız bütçe bandı.
import { h, makeKit, ROLE_NAME, ROLE_SHORT, ROLE_ICON, ROLE_DUTY, upper, LAUNCH_TR, BUDGET_BAND, tagName } from '../widgets/util.js';
import { titleBar, section, designTimer } from '../widgets/frame.js';
import { mountVehicle } from '../widgets/vehicle.js';
import { engineerTelemetry } from '../widgets/telemetry.js';
import { readinessList, countsStrip } from '../widgets/readiness.js';
import { catalogView, itemDetail, decisionList } from '../widgets/catalog.js';
import { settingsView } from '../widgets/settings.js';
import { mountCommsDrawer } from './comms.js';
import { t, onLang } from '../i18n.js';

let inst = null;

function roleCard(kit, st) {
  const role = st.me.role;
  const eng = st.engineer || {};
  const lines = eng.briefing || [];
  return h('div', { class: ['ad-rolecard', `ad-rolecard--${role}`] },
    h('div', { class: 'ad-rolecard__id' },
      h('span', { class: 'ad-rolecard__icon' }, kit.icon(ROLE_ICON[role] || 'crew')),
      h('div', null,
        h('p', { class: 'ad-rolecard__role', text: upper(ROLE_NAME[role] || role) }),
        h('p', { class: 'ad-rolecard__name', text: st.me.name || '' }))),
    h('p', { class: 'ad-rolecard__duty', text: ROLE_DUTY[role] || '' }),
    lines.length ? h('details', { class: 'ad-brief__more' },
      h('summary', { text: t('work.eng.brief', { n: lines.length }) }),
      h('ul', { class: 'ad-brief__list' }, lines.map((l) => h('li', { text: l })))) : null);
}

function needsView(kit, st) {
  const needs = (st.engineer && st.engineer.needs) || [];
  if (!needs.length) return h('p', { class: 'ad-empty', text: t('work.eng.needsEmpty') });
  return h('div', { class: 'ad-needs' },
    h('p', { class: 'ad-muted', text: t('work.eng.needsHint') }),
    h('ul', { class: 'ad-needs__list' }, needs.map((n) => h('li', { class: 'ad-need' },
      kit.icon('eye'),
      h('span', { class: 'ad-need__txt' }, h('small', { text: t('work.eng.needFrom') }), h('b', { text: n.label })),
      n.fromRole ? h('span', { class: ['ad-need__from', `ad-c-${n.fromRole}`], text: ROLE_SHORT[n.fromRole] || n.fromRole }) : null))),
    kit.button({ label: t('work.eng.ask'), sub: t('work.eng.askSub'), variant: 'ghost', icon: 'chat', small: true,
      onClick: () => kit.act('chat:send', { to: 'director', text: t('work.eng.askText', { list: needs.map((n) => n.label).join(', ') }).slice(0, 300) }, t('work.eng.asked')) }));
}

// Durum çipi (tasarım durumu / bütçe bandı): ikon + etiket + değer, sayı yok
function statusChip(kit, key, info, title) {
  if (!info) return null;
  return h('span', { class: ['ad-schip', `is-${info.tone}`], title: info.hint, data: { k: key } },
    kit.icon(info.icon), h('span', { class: 'ad-schip__k', text: title }), h('b', { text: info.label }));
}

// Payload: bilim hedefleri (isteğe bağlı). Eksik etiketler için katalogdan "sağlayan" seçenekler gösterilir.
const GOAL_TR = { ready: { tone: 'ok', icon: 'check' }, partial: { tone: 'warn', icon: 'warn' }, missing: { tone: 'idle', icon: 'clock' } };
for (const k of Object.keys(GOAL_TR)) Object.defineProperty(GOAL_TR[k], 'label', { get: () => t(`work.goal.${k}`) });
function goalsView(kit, st, onPick) {
  const goals = (st.engineer && st.engineer.scienceGoals) || [];
  const catalog = (st.engineer && st.engineer.catalog) || [];
  const ready = goals.filter((g) => g.status === 'ready').length;
  return h('div', { class: 'ad-goals' },
    h('p', { class: 'ad-hint' }, h('b', { text: t('work.goal.count', { ready, total: goals.length }) }), t('work.goal.hint')),
    h('ul', { class: 'ad-goals__list' }, goals.map((g) => {
      const s = GOAL_TR[g.status] || GOAL_TR.missing;
      const miss = (g.missingTags || []).map((t) => ({ t, by: catalog.filter((i) => (i.provides || []).includes(t)).slice(0, 3) }));
      return h('li', { class: ['ad-goal', `is-${s.tone}`] },
        h('div', { class: 'ad-goal__head' },
          h('span', { class: ['ad-schip', `is-${s.tone}`] }, kit.icon(s.icon), h('b', { text: s.label })),
          h('h3', { class: 'ad-goal__name', text: g.name || g.id })),
        g.desc ? h('p', { class: 'ad-goal__desc', text: g.desc }) : null,
        miss.length ? h('ul', { class: 'ad-goal__miss' }, miss.map((m) => h('li', null,
          h('span', { class: 'ad-goal__tag', text: t('work.goal.miss', { tag: tagName(m.t) }) }),
          m.by.length ? h('span', { class: 'ad-goal__by' }, h('span', { class: 'ad-muted', text: t('work.goal.by') }),
            m.by.map((it) => h('button', { type: 'button', class: 'ad-linkbtn', data: { fk: `goal:${g.id}:${it.id}` },
              on: { click: () => onPick(it) }, text: it.name }))) : null))) : null);
    })));
}

function draw(st) {
  const s = inst;
  const eng = st.engineer || {};
  const design = st.phase === 'design';
  const role = st.me.role;
  const catalog = eng.catalog || [];

  // başlık: süre + takım tasarım durumu + bütçe bandı
  const phaseKey = `shell.phase.${st.phase}`;
  const phaseName = t(phaseKey) !== phaseKey ? upper(t(phaseKey)) : upper(st.phase);
  s.title.sub.textContent = st.mission ? `${st.mission.name} · ${design ? t('work.eng.design') : phaseName}` : '';
  s.timer.set(st.design);
  const ls = LAUNCH_TR[st.launchStatus] || (st.overall ? LAUNCH_TR[{ PASS: 'READY', WARN: 'RISKY', FAIL: 'MISSING' }[st.overall]] : null);
  s.chips.replaceChildren(...[statusChip(s.kit, 'launch', ls, t('work.eng.design')), statusChip(s.kit, 'budget', BUDGET_BAND[eng.budgetBand], t('work.eng.budget'))].filter(Boolean));

  // seçim durumu: aktif karar ve seçili seçenek geçerli kalsın
  const decisions = decisionList(catalog, eng.modules || [], st.vehicle || []).filter((d) => !d.standard);
  if (!decisions.some((d) => d.category === s.ui.tab)) {
    const firstNeed = decisions.find((d) => d.state === 'need') || decisions[0];
    s.ui.tab = firstNeed && firstNeed.category;
    s.ui.selected = null;
  }
  const inTab = catalog.filter((it) => it.category === s.ui.tab);
  if (!inTab.some((it) => it.id === s.ui.selected)) s.ui.selected = inTab[0] && inTab[0].id;
  const sel = catalog.find((i) => i.id === s.ui.selected);
  const selInstalled = sel && (st.vehicle || []).some((v) => v.mine && v.item && v.item.id === sel.id);

  // araç + modül alanı (seçili, takılı olmayan parça yuvada önizlenir)
  const mods = (eng.modules || []).map((m) => ({ id: m.id, name: m.name, role: m.role }));
  s.vehicle.set({ missionId: st.mission && st.mission.id, modules: mods, items: st.vehicle || [], highlightModule: (sel && sel.module) || s.ui.module,
    mineRole: role, capacity: st.capacity || null,
    preview: design && sel && !selInstalled && sel.volumeU > 0 ? { moduleId: sel.module, volumeU: sel.volumeU, name: sel.name } : null });

  s.secRole.render([st.me, eng.briefing]);
  s.secNeeds.render([eng.needs]);
  s.secTele.render([eng.telemetry]);
  s.secReady.render([eng.readiness]);
  s.secCatalog.render([catalog, eng.modules, st.vehicle, s.ui.tab, s.ui.selected, design]);
  s.secDetail.render([s.ui.selected, sel]);
  s.secSettings.render([eng.settingDefs, eng.settings, design]);
  const hasGoals = Array.isArray(eng.scienceGoals) && eng.scienceGoals.length > 0;
  s.goalsPanel.hidden = !hasGoals;
  s.grid.classList.toggle('ad-grid--goals', hasGoals);
  if (hasGoals) s.secGoals.render([eng.scienceGoals, catalog.map((i) => i.id)]);
  s.drawer.update(st);
}

const screen = {
  id: 'engineer',
  render(root, state, api) {
    screen.destroy();
    const kit = makeKit(api);
    const role = state.me && state.me.role;
    const ui = { tab: null, selected: null, module: null };
    let last = state;
    const eng = () => last.engineer || {};

    const title = titleBar(t('work.eng.station', { role: ROLE_SHORT[role] || '' }), '');
    const timer = designTimer();
    const chips = h('div', { class: 'ad-schips' });
    title.right.append(h('div', { class: 'ad-stat' }, kit.icon('clock'), h('span', { class: 'ad-muted', text: t('work.eng.time') }), timer.el), chips);

    const act = kit.act;
    // bir parçayı seç ve kararına geç (bilim hedefi "sağlayan" bağlantısı, modül tıklaması)
    const focusItem = (it) => {
      ui.tab = it.category; ui.selected = it.id; draw(last);
      secCatalog.el.scrollIntoView({ behavior: 'smooth', block: 'nearest' });
    };

    const box = () => h('div', { class: 'ad-sec' });
    const secRole = section(box(), () => roleCard(kit, last));
    const secNeeds = section(box(), () => needsView(kit, last));
    const secTele = section(box(), () => engineerTelemetry(kit, role, eng().telemetry));
    const secReady = section(box(), () => {
      const items = eng().readiness || [];
      return [items.length ? countsStrip(kit, items) : null, readinessList(kit, items, { empty: t('work.eng.readyEmpty') }),
        h('p', { class: 'ad-hint', text: t('work.eng.readyHint') })];
    });
    const secGoals = section(box(), () => goalsView(kit, last, focusItem));
    const secCatalog = section(box(), () => catalogView(kit, {
      catalog: eng().catalog || [], modules: eng().modules || [], vehicle: last.vehicle || [], tab: ui.tab, selectedId: ui.selected,
      design: last.phase === 'design',
      onTab: (t) => { ui.tab = t; ui.selected = null; draw(last); },
      onSelect: (id) => { ui.selected = id; draw(last); },
      onAdd: (it) => act('equip:add', { itemId: it.id, moduleId: it.module }, t('work.eng.added', { name: it.name })),
      onRemove: (v) => (v ? act('equip:remove', { uid: v.uid }, t('work.eng.removed', { name: (v.item && v.item.name) || t('work.eng.part') })) : null),
      // tek seçimlik kararda değiştir: eskisini çıkar, yenisini tak; olmazsa eskisini geri tak
      onSwap: async (it, old) => {
        const r = await act('equip:remove', { uid: old.uid });
        if (!r.ok) return r;
        const a = await act('equip:add', { itemId: it.id, moduleId: it.module }, t('work.eng.picked', { name: it.name }));
        if (!a.ok && old.item) await act('equip:add', { itemId: old.item.id, moduleId: old.moduleId });
        return a;
      },
    }));
    const secDetail = section(box(), () => itemDetail(kit, (eng().catalog || []).find((i) => i.id === ui.selected)));
    const secSettings = section(box(), () => settingsView(kit, {
      defs: eng().settingDefs || [], values: eng().settings || {}, design: last.phase === 'design',
      onSet: async (key, value) => { const a = await act('setting:set', { key, value }); if (!a.ok) { secSettings.reset(); draw(last); } },
    }));

    const vehBox = h('div', { class: 'ad-vehbox' });
    const goalsPanel = kit.panel({ title: t('work.panel.goals'), icon: 'star', class: 'ad-a-goals', tag: t('work.panel.optional') }, secGoals.el);
    goalsPanel.hidden = true;
    const grid = h('div', { class: 'ad-grid ad-grid--eng' },
      kit.panel({ title: t('work.panel.role'), icon: ROLE_ICON[role], class: 'ad-a-role', accent: role }, secRole.el),
      kit.panel({ title: t('work.panel.needs'), icon: 'eye', class: 'ad-a-needs' }, secNeeds.el),
      kit.panel({ title: t('work.panel.vehicle'), icon: 'rocket', class: 'ad-a-vehicle' }, h('div', { class: 'ad-vehtele' }, vehBox, secTele.el)),
      kit.panel({ title: t('work.panel.ready'), icon: 'shield', class: 'ad-a-ready' }, secReady.el),
      goalsPanel,
      kit.panel({ title: t('work.panel.decisions'), icon: 'gear', class: 'ad-a-catalog', accent: 'focus', tag: t('work.panel.decisionsTag') }, secCatalog.el),
      kit.panel({ title: t('work.panel.detail'), icon: 'eye', class: 'ad-a-detail' }, secDetail.el),
      kit.panel({ title: t('work.panel.settings'), icon: 'gear', class: 'ad-a-settings' }, secSettings.el));
    const page = h('div', { class: ['ad-work', 'ad-eng', `ad-eng--${role}`], data: { role } }, title.el, grid);
    root.append(page);

    // modüle tıklayınca o modüldeki ilk kararıma geç
    const vehicle = mountVehicle(vehBox, api, {
      onModuleClick: (moduleId) => {
        ui.module = moduleId;
        const d = decisionList(eng().catalog || [], eng().modules || [], last.vehicle || [])
          .filter((x) => !x.standard && x.items.some((i) => i.module === moduleId));
        const pick = d.find((x) => x.state === 'need') || d[0];
        if (pick) { ui.tab = pick.category; ui.selected = null; }
        draw(last);
        if (pick) secCatalog.el.scrollIntoView({ behavior: 'smooth', block: 'nearest' });
        else kit.toast(t('work.eng.noDecision'), 'info');
      },
    });

    // design fazında kabuk çekmecesi yok: mühendisin OPERATÖR kanalını bu ekran açar
    const drawer = mountCommsDrawer(root, () => last, api, { fabHost: title.right });
    // dil değişince: kabuk bu ekranı yeniden çizmediyse kendini yeniden çiz
    const me = {};
    const offLang = onLang(() => setTimeout(() => { if (inst === me) screen.render(root, last, api); }, 0));
    Object.assign(me, { kit, ui, title, timer, chips, vehicle, drawer, page, grid, goalsPanel,
      secRole, secNeeds, secTele, secReady, secGoals, secCatalog, secDetail, secSettings, offLang,
      setLast: (s) => { last = s; } });
    inst = me;
    draw(state);
  },
  update(state) {
    if (!inst || !state) return;
    inst.setLast(state);
    draw(state);
  },
  destroy() {
    if (!inst) return;
    inst.offLang();
    inst.timer.destroy();
    inst.vehicle.destroy();
    inst.drawer.destroy();
    inst.page.remove();
    inst = null;
  },
};

export default screen;
