// Brifing: rolüne göre görev metni (poster), ANLADIM; Operatörde kimlerin okuduğu + ATLAT.
import { t } from '../i18n.js';
import '../lang/shell.js';

const KIND = { lunar: 'moon', mars: 'mars' };

function lines(st) {
  const role = st.me && st.me.role;
  if (role === 'director') {
    const b = st.director && st.director.mission ? st.director.mission.briefing : null;
    if (Array.isArray(b)) return b;
    if (b && Array.isArray(b.director)) return b.director;
    return [];
  }
  return st.engineer && Array.isArray(st.engineer.briefing) ? st.engineer.briefing : [];
}

function build(root, st, api) {
  const { h, icon, button, panel, planet, roleBadge, statusPill, ROLES, ROLE_NAMES, ROLE_SHORT, PHASE_NAMES, toast, confirmModal } = api.ui;
  const role = st.me && st.me.role;
  const isDirector = role === 'director';
  const acked = st.briefing && Array.isArray(st.briefing.acked) ? st.briefing.acked : [];
  const iAcked = acked.includes(role);
  const m = st.mission || {};
  const text = lines(st);

  root.appendChild(h('div', { class: 'screen-head' },
    h('span', { class: 'eyebrow', text: t('shell.brief.eyebrow', { role: ROLE_NAMES[role] || '' }) }),
    h('h1', { class: 'screen-title', text: m.name || PHASE_NAMES.briefing })));

  const poster = panel({ title: t('shell.brief.panel'), icon: 'book', accent: role || undefined, active: true },
    h('div', { class: 'poster' },
      planet(KIND[m.id] || 'moon', 150),
      h('div', { class: 'stack' },
        roleBadge(role, { short: false }),
        m.summary ? h('p', { class: 'mission-card__summary', text: m.summary }) : null)),
    h('div', { class: 'stack', style: null },
      text.length
        ? h('ol', { class: 'brief-lines' }, text.map((x) => h('li', { text: String(x) })))
        : h('p', { class: 'muted', text: t('shell.brief.noText') })),
    m.educationalNote ? h('p', { class: 'edu-note', text: m.educationalNote }) : null);

  // Mühendis: operatörden öğrenmesi gereken değerler (yalnız etiket)
  const needs = !isDirector && st.engineer && Array.isArray(st.engineer.needs) ? st.engineer.needs : [];
  const needsPanel = needs.length ? panel({ title: t('shell.brief.needsPanel'), icon: 'chat', accent: 'amber' },
    h('ul', { class: 'list' }, needs.map((n) => h('li', { class: 'list__item' },
      icon('info', 18), h('span', { class: 'list__main', text: n.label || n.id }), n.fromRole ? roleBadge(n.fromRole) : null))),
    h('p', { class: 'muted', text: t('shell.brief.needsNote') })) : null;

  const ack = button({
    label: iAcked ? t('shell.brief.acked') : t('shell.brief.ack'), variant: 'go', size: 'lg', icon: 'check', className: 'btn--block',
    disabled: iAcked, reason: iAcked ? t('shell.brief.waitOthers') : undefined,
    onClick: async () => {
      const res = await api.emit('briefing:ack', {});
      if (!res.ok) toast(res.message || t('shell.brief.ackFail'), 'error');
    }
  });

  const team = panel({ title: t('shell.brief.team'), icon: 'users' },
    isDirector
      ? h('ul', { class: 'list' }, ROLES.map((r) => h('li', { class: 'list__item' },
          h('span', { class: 'list__main' }, roleBadge(r)),
          acked.includes(r) ? statusPill('ok', t('shell.brief.read')) : statusPill('wait', t('shell.brief.reading')))))
      : h('p', { class: 'lobby__status', text: t('shell.brief.count', { n: acked.length }) }),
    h('p', { class: 'muted', text: t('shell.brief.teamNote') }));

  const side = [ack, team];
  if (isDirector) {
    const waiting = ROLES.filter((r) => !acked.includes(r));
    side.push(button({
      label: t('shell.brief.skip'), sub: waiting.length ? t('shell.brief.waiting', { list: waiting.map((r) => ROLE_SHORT[r]).join(', ') }) : undefined,
      variant: 'ghost', icon: 'play', className: 'btn--block',
      onClick: async () => {
        const ok = await confirmModal({ title: t('shell.brief.skipTitle'), body: t('shell.brief.skipBody'), okLabel: t('shell.brief.skipOk'), okVariant: 'primary' });
        if (!ok) return;
        const res = await api.emit('briefing:skip', {});
        if (!res.ok) toast(res.message || t('shell.brief.skipFail'), 'error');
      }
    }));
  }

  root.appendChild(h('div', { class: 'briefing' },
    h('div', { class: 'stack' }, poster, needsPanel),
    h('div', { class: 'stack' }, side)));
}

let rootEl = null;
const screen = {
  id: 'briefing',
  render(root, state, api) { rootEl = root; build(root, state, api); },
  update(state, prev, api) {
    api.ui.clear(rootEl);
    build(rootEl, state, api);
  },
  destroy() { rootEl = null; }
};
export default screen;
