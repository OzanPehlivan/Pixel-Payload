// İletişim merkezi (05). Operatör: 4 kanal (İtki, Uzay Aracı, Bilim, TÜM EKİP) + okunmamış sayıları.
// Mühendis: tek kanal OPERATÖR (özel) + operatör yayınları. Yetki sunucuda (chat:send); istemci yalnız çizer.
// Dışa açılanlar: default ekran modülü, createCommsPanel, mountCommsDrawer(root, getState, api).
import { h, refill, makeKit, ENGINEERS, ROLE_NAME, ROLE_SHORT, ROLE_ICON, hhmm } from '../widgets/util.js';
import { t, onLang } from '../i18n.js';

const MAX_LEN = 300;
const CHANNELS = [...ENGINEERS, 'broadcast'];
const CHANNEL_NAME = {};
for (const ch of CHANNELS) Object.defineProperty(CHANNEL_NAME, ch, { get: () => t(`work.chan.${ch}`), enumerable: true });

// core.js (AC) olay aboneliği: varsa canlı chat:message ve state aboneliği
let coreP = null;
function core() {
  if (!coreP) coreP = import('../core.js').catch(() => null);
  return coreP;
}

// --- Okunmamış takibi (sekme oturumu boyunca) -----------------------------------
const SEEN_KEY = 'ppCommsSeen';
function loadSeen() {
  try { return JSON.parse(sessionStorage.getItem(SEEN_KEY) || '{}') || {}; } catch { return {}; }
}
const seen = loadSeen();
function saveSeen() { try { sessionStorage.setItem(SEEN_KEY, JSON.stringify(seen)); } catch { /* yok say */ } }
const seenKey = (st, ch) => `${st.code || ''}:${(st.me && st.me.role) || ''}:${ch}`;
const msgKey = (m) => (typeof m.id === 'number' ? m.id : Number(m.ts) || 0);

// Kanal → mesajlar (state + canlı gelenler birleşik, id ile tekilleşmiş)
function channelMessages(st, extra, ch) {
  const th = (st.chat && st.chat.threads) || {};
  const src = st.me && st.me.role === 'director'
    ? [...(th[ch] || []), ...(extra[ch] || [])]
    : [...(th.mine || []), ...(th.broadcast || []), ...(extra.mine || []), ...(extra.broadcast || [])];
  const byId = new Map();
  for (const m of src) if (m) byId.set(`${m.thread}:${m.id}`, m);
  return [...byId.values()].sort((a, b) => (a.ts || 0) - (b.ts || 0) || msgKey(a) - msgKey(b));
}

function unreadOf(st, extra, ch) {
  const last = seen[seenKey(st, ch)] || 0;
  const me = st.me && st.me.role;
  return channelMessages(st, extra, ch).filter((m) => m.from !== me && msgKey(m) > last).length;
}

export function totalUnread(st, extra = {}) {
  if (!st || !st.chat || !st.me || !st.me.role) return 0;
  const chans = st.me.role === 'director' ? CHANNELS : ['mine'];
  return chans.reduce((n, ch) => n + unreadOf(st, extra, ch), 0);
}

function markSeen(st, extra, ch) {
  const msgs = channelMessages(st, extra, ch);
  const max = msgs.reduce((a, m) => Math.max(a, msgKey(m)), 0);
  const k = seenKey(st, ch);
  if ((seen[k] || 0) < max) { seen[k] = max; saveSeen(); }
}

// --- Panel -------------------------------------------------------------------------
// mode: 'full' (tam ekran, ekip kartları) | 'drawer' (dar, sekmeli)
export function createCommsPanel(api, opts = {}) {
  const kit = makeKit(api);
  const mode = opts.mode || 'full';
  let st = null;
  let channel = 'rocket';
  let visible = false;
  const extra = {}; // canlı chat:message ile gelen ama state'te henüz olmayanlar
  let unsub = null;
  let alive = true;

  const chanBox = h('div', { class: 'ad-chans', role: 'tablist', 'aria-label': t('work.com.channels') });
  const head = h('div', { class: 'ad-comms__head' });
  const list = h('ol', { class: 'ad-msgs', 'aria-live': 'polite', 'aria-relevant': 'additions' });
  const input = h('textarea', {
    class: 'ad-compose__input', rows: '2', maxlength: String(MAX_LEN), 'aria-label': t('work.com.msg'), placeholder: t('work.com.placeholder'),
  });
  const counter = h('span', { class: 'ad-compose__count', text: `0/${MAX_LEN}` });
  const target = h('span', { class: 'ad-compose__to' });
  let sending = false;
  const sendBtn = kit.button({ label: t('work.com.send'), variant: 'primary', icon: 'chat', onClick: () => send() });
  const form = h('form', { class: 'ad-compose', on: { submit: (e) => { e.preventDefault(); send(); } } },
    h('div', { class: 'ad-compose__meta' }, target, counter), h('div', { class: 'ad-compose__row' }, input, sendBtn));
  input.addEventListener('input', () => { counter.textContent = `${[...input.value].length}/${MAX_LEN}`; });
  input.addEventListener('keydown', (e) => {
    if (e.key === 'Enter' && !e.shiftKey && !e.isComposing) { e.preventDefault(); send(); }
  });

  const el = h('div', { class: ['ad-comms', `ad-comms--${mode}`] },
    h('div', { class: 'ad-comms__side' }, chanBox),
    h('div', { class: 'ad-comms__main' }, head, h('div', { class: 'ad-msgs-wrap' }, list), form));

  const isDirector = () => !!(st && st.me && st.me.role === 'director');
  const curKey = () => (isDirector() ? channel : 'mine');
  const toOf = () => (isDirector() ? (channel === 'broadcast' ? 'engineers' : channel) : 'director');
  const holder = (role) => (st && st.players || []).find((p) => p.role === role);

  async function send() {
    const text = input.value.trim();
    if (!text || sending || !st) return;
    if ([...text].length > MAX_LEN) { kit.toast(t('work.com.tooLong', { n: MAX_LEN }), 'error'); return; }
    sending = true;
    try {
      const ack = await kit.act('chat:send', { to: toOf(), text });
      if (ack && ack.ok) {
        input.value = '';
        counter.textContent = `0/${MAX_LEN}`;
        if (ack.message) addLive(ack.message);
      }
    } finally { sending = false; input.focus(); }
  }

  function addLive(m) {
    if (!m || !alive || !st) return;
    const k = isDirector() ? m.thread : (m.thread === 'broadcast' ? 'broadcast' : 'mine');
    (extra[k] = extra[k] || []).push(m);
    draw();
  }

  function chanButton(ch, title, sub, role, icon) {
    const n = unreadOf(st, extra, ch);
    const p = role ? holder(role) : null;
    const active = curKey() === ch || (!isDirector() && ch === 'mine');
    return h('button', {
      type: 'button', role: 'tab', class: ['ad-chan', role && `ad-chan--${role}`, active && 'is-active'],
      'aria-selected': active ? 'true' : 'false', data: { fk: `chan:${ch}` },
      on: { click: () => { if (isDirector()) { channel = ch; draw(); input.focus(); } } },
    },
    h('span', { class: 'ad-chan__icon' }, kit.icon(icon)),
    h('span', { class: 'ad-chan__txt' },
      h('b', { text: title }),
      sub ? h('small', { class: 'ad-chan__sub' },
        p ? h('i', { class: ['ad-dot', p.connected ? 'is-ok' : 'is-bad'], 'aria-hidden': 'true' }) : null,
        h('span', { text: sub })) : null),
    n ? h('span', { class: 'ad-unread', 'aria-label': t('work.com.unread', { n }), text: n > 99 ? '99+' : String(n) }) : null);
  }

  function draw() {
    if (!st || !alive) return;
    if (!st.chat) {
      refill(chanBox);
      refill(head, h('p', { class: 'ad-empty', text: t('work.com.noRole') }));
      refill(list);
      form.hidden = true;
      return;
    }
    form.hidden = false;
    // kanallar
    if (isDirector()) {
      refill(chanBox, CHANNELS.map((ch) => {
        if (ch === 'broadcast') return chanButton(ch, CHANNEL_NAME.broadcast, t('work.com.castSub'), null, 'antenna');
        const p = holder(ch);
        return chanButton(ch, CHANNEL_NAME[ch], p ? p.name : t('work.com.emptySeat'), ch, ROLE_ICON[ch]);
      }));
    } else {
      const op = holder('director');
      refill(chanBox, chanButton('mine', t('work.com.operator'), op ? op.name : t('work.com.emptySeat'), 'director', 'crew'));
    }
    // başlık + alıcı
    const ch = curKey();
    if (isDirector()) {
      const pr = ch !== 'broadcast';
      refill(head,
        h('h3', { class: 'ad-comms__title', text: pr ? t('work.com.chanTitle', { ch: CHANNEL_NAME[ch] }) : t('work.com.castTitle') }),
        h('p', { class: 'ad-muted', text: pr ? t('work.com.onlySees', { role: ROLE_NAME[ch] }) : t('work.com.castNote') }));
      refill(target, kit.icon(pr ? 'chat' : 'antenna'), h('span', { text: pr ? t('work.com.to', { who: ROLE_SHORT[ch] }) : t('work.com.toCast') }));
    } else {
      refill(head,
        h('h3', { class: 'ad-comms__title', text: t('work.com.opTitle') }),
        h('p', { class: 'ad-muted', text: t('work.com.opNote') }));
      refill(target, kit.icon('chat'), h('span', { text: t('work.com.to', { who: t('work.com.operator') }) }));
    }
    // mesajlar
    const nearBottom = list.parentElement && list.parentElement.scrollHeight - list.parentElement.scrollTop - list.parentElement.clientHeight < 60;
    const msgs = channelMessages(st, extra, ch);
    const me = st.me.role;
    refill(list, msgs.length ? msgs.map((m) => h('li', { class: ['ad-msg', m.from === me && 'is-mine', m.thread === 'broadcast' && 'is-cast'] },
      h('div', { class: 'ad-msg__meta' },
        h('time', { class: 'ad-msg__time', text: hhmm(m.ts) }),
        h('b', { class: ['ad-msg__from', `ad-c-${m.from}`], text: m.from === me ? t('work.com.you') : (m.fromName || ROLE_SHORT[m.from] || '?') }),
        h('span', { class: 'ad-msg__role', text: ROLE_SHORT[m.from] || '' }),
        m.thread === 'broadcast' && !isDirector() ? h('span', { class: 'ad-badge is-info', text: t('work.com.cast') }) : null),
      h('p', { class: 'ad-msg__text', text: m.text })))
      : h('li', { class: 'ad-empty', text: isDirector()
        ? t('work.com.emptyDir')
        : t('work.com.emptyEng') }));
    if (nearBottom !== false) list.parentElement && (list.parentElement.scrollTop = list.parentElement.scrollHeight);
    if (visible) markSeen(st, extra, ch);
    if (visible) refreshBadges();
    if (opts.onUnread) opts.onUnread(totalUnread(st, extra));
  }

  // okundu işaretlendikten sonra rozetleri tazele (yalnız sayılar)
  function refreshBadges() {
    for (const b of chanBox.querySelectorAll('.ad-chan.is-active .ad-unread')) b.remove();
  }

  // canlı mesaj aboneliği
  core().then((m) => {
    if (!alive || !m || typeof m.onEvent !== 'function') return;
    const off = m.onEvent('chat:message', (msg) => addLive(msg));
    unsub = typeof off === 'function' ? off : null;
  });

  return {
    el,
    update(state) {
      st = state;
      // state'e geçmiş canlı mesajları at (tekrar etmesin diye zaten id ile tekil)
      for (const k of Object.keys(extra)) {
        const th = (state && state.chat && state.chat.threads && state.chat.threads[k]) || [];
        const ids = new Set(th.map((m) => m.id));
        extra[k] = extra[k].filter((m) => !ids.has(m.id));
      }
      draw();
    },
    // Operatör: kanalı seç, isteğe bağlı taslak yaz
    focus(ch, draft) {
      if (ch && CHANNELS.includes(ch)) channel = ch;
      if (typeof draft === 'string' && draft) {
        input.value = draft.slice(0, MAX_LEN);
        counter.textContent = `${[...input.value].length}/${MAX_LEN}`;
      }
      draw();
      setTimeout(() => input.focus(), 0);
    },
    setVisible(v) { visible = !!v; draw(); },
    unread() { return st ? totalUnread(st, extra) : 0; },
    destroy() { alive = false; if (unsub) try { unsub(); } catch { /* yok say */ } el.remove(); },
  };
}

// --- Çekmece: design/review/simulation ekranlarında sağdan açılır -------------------------
// mountCommsDrawer(root, getState, api) → { open(channel?, draft?), close(), toggle(), update(state), destroy(), el }
// opts.fabHost: verilirse İLETİŞİM düğmesi oraya (ör. başlık şeridi) yerleşir; dar ekranda CSS ile sağ altta sabitlenir.
export function mountCommsDrawer(root, getState, api, opts = {}) {
  const kit = makeKit(api);
  let open = false;
  const badge = h('span', { class: 'ad-unread', hidden: true });
  const fab = h('button', {
    type: 'button', class: 'ad-fab', 'aria-expanded': 'false', 'aria-controls': 'ad-drawer',
    on: { click: () => (open ? close() : show()) },
  }, kit.icon('chat'), h('span', { text: t('work.com.comms') }), badge);
  const panel = createCommsPanel(api, {
    mode: 'drawer',
    onUnread: (n) => { badge.hidden = !n; badge.textContent = n > 99 ? '99+' : String(n); fab.setAttribute('aria-label', n ? t('work.com.commsUnread', { n }) : t('work.com.commsAria')); },
  });
  const closeBtn = h('button', { type: 'button', class: 'ad-drawer__close', 'aria-label': t('work.com.close'), on: { click: () => close() } }, kit.icon('cross'));
  const drawer = h('aside', { id: 'ad-drawer', class: 'ad-drawer', role: 'dialog', 'aria-modal': 'false', 'aria-label': t('work.com.commsAria'), hidden: true },
    h('header', { class: 'ad-drawer__head' }, kit.icon('chat'), h('h2', { text: t('work.com.comms') }), closeBtn), panel.el);
  const wrap = h('div', { class: 'ad-drawer-host' }, drawer);
  if (opts.fabHost) { fab.classList.add('ad-fab--docked'); opts.fabHost.append(fab); } else wrap.prepend(fab);
  root.append(wrap);

  const onKey = (e) => { if (e.key === 'Escape' && open) { close(); fab.focus(); } };
  document.addEventListener('keydown', onKey);

  function show(ch, draft) {
    open = true;
    drawer.hidden = false;
    fab.setAttribute('aria-expanded', 'true');
    wrap.classList.add('is-open');
    panel.setVisible(true);
    panel.focus(ch, draft);
  }
  function close() {
    open = false;
    drawer.hidden = true;
    fab.setAttribute('aria-expanded', 'false');
    wrap.classList.remove('is-open');
    panel.setVisible(false);
  }

  // core aboneliği: çağıran update etmese de güncel kalır
  let unsub = null;
  let alive = true;
  core().then((m) => {
    if (!alive || !m || typeof m.subscribe !== 'function') return;
    const off = m.subscribe((s) => { if (s) panel.update(s); });
    unsub = typeof off === 'function' ? off : null;
  });
  const first = typeof getState === 'function' ? getState() : null;
  if (first) panel.update(first);

  return {
    el: wrap,
    open: show,
    close,
    toggle() { (open ? close : show)(); },
    update(state) { if (state) panel.update(state); },
    destroy() {
      alive = false;
      document.removeEventListener('keydown', onKey);
      if (unsub) try { unsub(); } catch { /* yok say */ }
      panel.destroy();
      wrap.remove();
      fab.remove();
    },
  };
}

// --- Kabuk ekranı: app.js bunu #comms-root içine çizer (data-mode="full" | "drawer") ------------
let inst = null;

function teamStrip(kit, st) {
  return h('div', { class: 'ad-crew' }, (st.players || []).filter((p) => p.role).map((p) => h('div', {
    class: ['ad-crew__card', `ad-crew__card--${p.role}`, st.me && p.role === st.me.role && 'is-me'],
  },
  h('span', { class: 'ad-crew__icon' }, kit.icon(ROLE_ICON[p.role] || 'crew')),
  h('b', { text: ROLE_SHORT[p.role] || p.role }),
  h('small', null, h('i', { class: ['ad-dot', p.connected ? 'is-ok' : 'is-bad'], 'aria-hidden': 'true' }),
    h('span', { text: st.me && p.role === st.me.role ? t('work.com.meTag', { name: p.name }) : p.name })))));
}

const screen = {
  id: 'comms',
  render(root, state, api) {
    screen.destroy();
    const kit = makeKit(api);
    const panel = createCommsPanel(api, { mode: 'full' });
    const crew = h('div', { class: 'ad-comms-page__crew' });
    const page = h('div', { class: 'ad-work ad-comms-page' },
      h('header', { class: 'ad-titlebar ad-comms-page__title' },
        h('div', { class: 'ad-titlebar__text' },
          h('h1', { class: 'ad-titlebar__title', text: t('work.com.center') }),
          h('p', { class: 'ad-titlebar__sub', text: t('work.com.centerSub') }))),
      kit.panel({ title: t('work.com.messages'), icon: 'chat', class: 'ad-comms-page__panel' }, panel.el),
      kit.panel({ title: t('work.com.crew'), icon: 'crew', class: 'ad-comms-page__crewpanel' }, crew));
    root.append(page);
    // görünürlük: çekmece açılınca / tam ekrana geçince okundu işaretle
    let io = null;
    if (typeof IntersectionObserver === 'function') {
      io = new IntersectionObserver((entries) => { for (const e of entries) panel.setVisible(e.isIntersecting); });
      io.observe(panel.el);
    } else panel.setVisible(true);
    // dil değişince: kabuk yeniden çizmediyse kendini yeniden çiz
    const me = { panel, crew, kit, page, io, last: state };
    me.offLang = onLang(() => setTimeout(() => { if (inst === me) screen.render(root, me.last, api); }, 0));
    inst = me;
    screen.update(state);
  },
  update(state) {
    if (!inst || !state) return;
    inst.last = state;
    inst.panel.update(state);
    refill(inst.crew, teamStrip(inst.kit, state));
  },
  destroy() {
    if (!inst) return;
    if (inst.offLang) inst.offLang();
    if (inst.io) inst.io.disconnect();
    inst.panel.destroy();
    inst.page.remove();
    inst = null;
  },
};

export default screen;
