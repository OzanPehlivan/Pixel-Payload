// Lobi: büyük oda kodu + LAN adresleri, 4 rol koltuğu, hazır, host eylemleri (başlat/çıkar/devret).
import { t } from '../i18n.js';
import '../lang/shell.js';

const SVG_NS = 'http://www.w3.org/2000/svg';
const roleDesc = (r) => t('shell.lobby.desc.' + r);

// Rol renginde astronot kaskı (Stitch 05 ekip kartları gibi; kodla çizilir)
function astronaut(size = 72) {
  const s = document.createElementNS(SVG_NS, 'svg');
  s.setAttribute('viewBox', '0 0 64 64');
  s.setAttribute('width', size);
  s.setAttribute('height', size);
  s.setAttribute('aria-hidden', 'true');
  const add = (tag, a) => { const n = document.createElementNS(SVG_NS, tag); Object.entries(a).forEach(([k, v]) => n.setAttribute(k, String(v))); s.appendChild(n); };
  add('path', { d: 'M10 62c2-12 10-18 22-18s20 6 22 18z', fill: 'currentColor', 'fill-opacity': 0.35, stroke: 'currentColor', 'stroke-width': 2 });
  add('circle', { cx: 32, cy: 26, r: 18, fill: '#0a1d38', stroke: 'currentColor', 'stroke-width': 3 });
  add('rect', { x: 20, y: 19, width: 24, height: 13, rx: 5, fill: 'currentColor', 'fill-opacity': 0.55 });
  add('rect', { x: 23, y: 21, width: 7, height: 3, fill: '#e6f1ff', 'fill-opacity': 0.7 });
  add('rect', { x: 28, y: 50, width: 8, height: 6, fill: '#0a1d38', stroke: 'currentColor', 'stroke-width': 1.5 });
  return s;
}

let lan = { status: 'idle', urls: [] };   // GET /api/info önbelleği (oturum boyunca)
async function loadLan(onDone) {
  if (lan.status === 'loading' || lan.status === 'ok') { onDone(); return; }
  lan = { status: 'loading', urls: [] };
  onDone();
  try {
    const r = await fetch('/api/info', { cache: 'no-store' });
    if (!r.ok) throw new Error(String(r.status));
    const j = await r.json();
    lan = { status: 'ok', urls: Array.isArray(j.lanUrls) ? j.lanUrls.filter((u) => typeof u === 'string') : [] };
  } catch (e) {
    lan = { status: 'error', urls: [] };
  }
  onDone();
}

let rootEl = null;
let apiRef = null;

function build(root, st, api) {
  const { h, icon, button, panel, statusPill, ROLES, ROLE_NAMES, ROLE_SHORT, confirmModal, toast } = api.ui;
  const players = Array.isArray(st.players) ? st.players : [];
  const me = st.me || {};
  const isHost = !!me.isHost;
  const host = players.find((p) => p.isHost);
  const byRole = {};
  players.forEach((p) => { if (p.role) byRole[p.role] = p; });

  const act = async (event, payload, failMsg) => {
    const res = await api.emit(event, payload);
    if (!res.ok) toast(res.message || failMsg, 'error');
    return res;
  };

  // ---- Oda kodu + LAN ----
  const copy = button({
    label: t('shell.lobby.copy'), variant: 'ghost', icon: 'copy',
    onClick: async () => {
      try { await navigator.clipboard.writeText(st.code); toast(t('shell.lobby.copied'), 'ok', 2000); }
      catch (e) { toast(t('shell.lobby.copyFail'), 'warn'); }
    }
  });
  copy.dataset.fk = 'copy';
  let lanBody;
  if (lan.status === 'ok' && lan.urls.length) {
    lanBody = h('ul', { class: 'lan-list' }, lan.urls.map((u) => h('li', { text: u })));
  } else if (lan.status === 'ok') {
    lanBody = h('p', { class: 'muted', text: t('shell.lobby.lanNone') });
  } else if (lan.status === 'error') {
    lanBody = h('div', { class: 'row' }, h('span', { class: 'muted', text: t('shell.lobby.lanError') }),
      button({ label: t('shell.common.retry'), variant: 'ghost', onClick: () => { lan.status = 'idle'; loadLan(rerender); } }));
  } else {
    lanBody = h('p', { class: 'muted', text: t('shell.lobby.lanLoading') });
  }
  const codePanel = panel({ title: t('shell.lobby.codePanel'), icon: 'link', active: true },
    h('div', { class: 'lobby__code' }, h('span', { class: 'big-code', 'aria-label': t('shell.lobby.codeAria', { code: (st.code || '').split('').join(' ') }), text: st.code || '—' }), copy),
    h('div', { class: 'stack lobby__lan' },
      h('span', { class: 'eyebrow', text: t('shell.lobby.lanHint') }), lanBody));

  // ---- Koltuklar ----
  const seats = h('div', { class: 'seats' }, ROLES.map((role) => {
    const p = byRole[role];
    const mine = me.role === role;
    const taken = p && !mine;
    const pick = h('button', {
      type: 'button', class: 'seat__pick', disabled: !!taken,
      'aria-pressed': mine ? 'true' : 'false',
      'aria-label': mine ? t('shell.lobby.seatRelease', { role: ROLE_NAMES[role] })
        : taken ? t('shell.lobby.seatTaken', { role: ROLE_NAMES[role], name: p.name })
        : t('shell.lobby.seatPick', { role: ROLE_NAMES[role] }),
      onClick: () => act('role:select', { role: mine ? null : role }, t('shell.lobby.roleFail'))
    },
    h('span', { class: 'seat__avatar' }, astronaut(72)),
    h('span', { class: 'seat__role', text: ROLE_SHORT[role] }),
    h('span', { class: 'seat__desc', text: roleDesc(role) }),
    h('span', { class: 'seat__who' },
      p ? [p.isHost ? icon('crown', 18) : null, h('span', { text: p.name + (mine ? t('shell.common.you') : '') })] : h('span', { class: 'muted', text: t('shell.lobby.empty') })),
    h('span', { class: 'seat__state' },
      p ? (p.connected === false ? statusPill('offline', t('shell.conn.offline')) : p.ready ? statusPill('ready', t('shell.lobby.ready')) : statusPill('wait', t('shell.lobby.notReady')))
        : h('span', { class: 'seat__cta', text: me.role ? t('shell.lobby.switchRole') : t('shell.lobby.pickRole') })));
    pick.dataset.fk = 'seat-' + role;

    let hostRow = null;
    if (isHost && p && !mine) {
      const kick = button({
        label: t('shell.lobby.kick'), variant: 'nogo',
        onClick: async () => {
          if (await confirmModal({ title: t('shell.lobby.kickTitle', { name: p.name }), body: t('shell.lobby.kickBody'), okLabel: t('shell.lobby.kick') })) {
            await act('host:kick', { seat: p.seat }, t('shell.lobby.kickFail'));
          }
        }
      });
      const transfer = button({
        label: t('shell.lobby.makeHost'), variant: 'ghost', disabled: p.connected === false, reason: p.connected === false ? t('shell.lobby.notConnected') : undefined,
        onClick: async () => {
          if (await confirmModal({ title: t('shell.lobby.transferTitle'), body: t('shell.lobby.transferBody', { name: p.name }), okLabel: t('shell.lobby.transferOk'), okVariant: 'primary' })) {
            await act('host:transfer', { seat: p.seat }, t('shell.lobby.transferFail'));
          }
        }
      });
      hostRow = h('div', { class: 'seat__host' }, kick, transfer);
    }
    return h('div', { class: 'seat', dataset: { role, mine: mine ? '1' : undefined, empty: p ? undefined : '1' } }, pick, hostRow);
  }));

  // ---- Durum ve eylemler ----
  const missing = ROLES.filter((r) => !byRole[r]);
  const notReady = players.filter((p) => p.role && (!p.ready || p.connected === false));
  const unassigned = players.filter((p) => !p.role);
  let statusText, statusKind;
  if (missing.length) {
    statusText = missing.length === 1 ? t('shell.lobby.oneEmpty', { role: ROLE_SHORT[missing[0]] }) : t('shell.lobby.manyEmpty', { n: missing.length });
    statusKind = 'warn';
  } else if (notReady.length) {
    statusText = notReady.length === 1 ? t('shell.lobby.oneNotReady', { name: notReady[0].name }) : t('shell.lobby.manyNotReady', { n: notReady.length });
    statusKind = 'warn';
  } else {
    statusText = t('shell.lobby.allReady');
    statusKind = 'ok';
  }
  const myP = players.find((p) => p.seat === me.seat) || {};
  const ready = button({
    label: myP.ready ? t('shell.lobby.imNotReady') : t('shell.lobby.imReady'), variant: myP.ready ? 'ghost' : 'go', size: 'lg', className: 'btn--block',
    icon: myP.ready ? 'cross' : 'check', disabled: !me.role, reason: !me.role ? t('shell.lobby.pickFirst') : undefined,
    onClick: () => act('player:ready', { ready: !myP.ready }, t('shell.lobby.readyFail'))
  });
  ready.dataset.fk = 'ready';
  const startReason = !isHost ? `${t('shell.lobby.onlyHost')}${host ? ' (' + host.name + ')' : ''}`
    : missing.length ? t('shell.lobby.allRoles') : notReady.length ? t('shell.lobby.allReadyReq') : undefined;
  const start = button({
    label: t('shell.lobby.start'), variant: 'primary', size: 'lg', className: 'btn--block', icon: 'rocket',
    disabled: !!startReason, reason: startReason,
    onClick: () => act('host:start', {}, t('shell.lobby.startFail'))
  });
  start.dataset.fk = 'start';

  const side = h('div', { class: 'lobby__side' },
    panel({ title: t('shell.lobby.statusPanel'), icon: 'users' },
      h('div', { class: 'stack' },
        h('p', { class: 'lobby__status', dataset: { status: statusKind }, role: 'status', text: statusText }),
        ready, start,
        h('p', { class: 'muted', text: isHost ? t('shell.lobby.youHost') : t('shell.lobby.otherHost', { name: host ? host.name : '—' }) }))),
    unassigned.length ? panel({ title: t('shell.lobby.waitingPanel'), icon: 'clock', accent: 'dim' },
      h('ul', { class: 'list' }, unassigned.map((p) => h('li', { class: 'list__item' },
        h('span', { class: 'list__main', text: p.name + (p.seat === me.seat ? t('shell.common.you') : '') }),
        isHost && p.seat !== me.seat ? button({
          label: t('shell.lobby.kick'), variant: 'nogo',
          onClick: async () => {
            if (await confirmModal({ title: t('shell.lobby.kickTitle', { name: p.name }), body: t('shell.lobby.kickBodyShort'), okLabel: t('shell.lobby.kick') })) {
              await act('host:kick', { seat: p.seat }, t('shell.lobby.kickFail'));
            }
          }
        }) : null)))) : null);

  root.append(
    h('div', { class: 'screen-head' }, h('span', { class: 'eyebrow', text: t('shell.lobby.eyebrow') }), h('h1', { class: 'screen-title', text: t('shell.phase.lobby') })),
    h('div', { class: 'lobby' }, h('div', { class: 'stack' }, codePanel, seats), side));
}

function rerender() {
  if (!rootEl || !apiRef) return;
  const st = apiRef.getState();
  if (!st || st.phase !== 'lobby') return;
  const fk = document.activeElement && rootEl.contains(document.activeElement) ? (document.activeElement.closest('[data-fk]') || {}).dataset : null;
  const key = fk && fk.fk;
  while (rootEl.firstChild) rootEl.removeChild(rootEl.firstChild);
  build(rootEl, st, apiRef);
  if (key) { const n = rootEl.querySelector(`[data-fk="${key}"]`); if (n && !n.disabled) n.focus(); }
}

const screen = {
  id: 'lobby',
  render(root, state, api) {
    rootEl = root;
    apiRef = api;
    build(root, state, api);
    loadLan(rerender);
  },
  update() { rerender(); },
  destroy() { rootEl = null; apiRef = null; }
};
export default screen;
