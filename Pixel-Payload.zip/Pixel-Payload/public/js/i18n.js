// İstemci i18n çekirdeği (PLAN 9.4). Dil oyuncu başına: 'en' | 'tr', varsayılan 'en'.
const KEY = 'pp.lang';
const LANGS = ['en', 'tr'];
const dicts = { en: {}, tr: {} };
const subs = new Set();

function readStored() {
  try {
    const v = localStorage.getItem(KEY);
    return LANGS.includes(v) ? v : 'en';
  } catch { return 'en'; }
}

let current = readStored();
if (typeof document !== 'undefined') document.documentElement.lang = current;

export function getLang() { return current; }

export function setLang(lang) {
  if (!LANGS.includes(lang)) return;
  try { localStorage.setItem(KEY, lang); } catch { /* özel pencere vb. */ }
  if (typeof document !== 'undefined') document.documentElement.lang = lang;
  if (lang === current) return;
  current = lang;
  for (const fn of [...subs]) {
    try { fn(lang); } catch (e) { console.error(e); }
  }
}

export function onLang(fn) {
  subs.add(fn);
  return () => subs.delete(fn);
}

export function register(dict) {
  for (const l of LANGS) if (dict && dict[l]) Object.assign(dicts[l], dict[l]);
}

// Bir sözlükte (çoğul varsa önce çoğul) ara
function pick(d, key, plural) {
  if (plural && (key + '_plural') in d) return d[key + '_plural'];
  return key in d ? d[key] : undefined;
}

// Geçerli dil → yoksa en → yoksa anahtarın kendisi. params.n ile basit çoğul.
export function t(key, params) {
  const plural = !!(params && typeof params.n === 'number' && params.n !== 1);
  let s = pick(dicts[current], key, plural);
  if (s === undefined) s = pick(dicts.en, key, plural);
  if (s === undefined) return key;
  if (!params) return s;
  return s.replace(/\{(\w+)\}/g, (m, p) => (params[p] === undefined || params[p] === null) ? m : String(params[p]));
}

export function locale() { return current === 'tr' ? 'tr-TR' : 'en-US'; }

export function fmtNum(v, digits = 0) {
  const n = Number(v);
  if (!Number.isFinite(n)) return String(v ?? '');
  return new Intl.NumberFormat(locale(), { minimumFractionDigits: digits, maximumFractionDigits: digits }).format(n);
}

export function upperL(s) { return String(s ?? '').toLocaleUpperCase(locale()); }
