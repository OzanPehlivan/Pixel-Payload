// Pixel Payload — ekran yönlendirici ve kabuk (Modül AC).
// Sunucu fazı varsa ekran fazdan, yoksa `nav`dan seçilir. Ekran modülü sözleşmesi:
//   export default { id, render(root, state, api), update?(state, prev, api), destroy?() }
import './lang/shell.js';
import { t, onLang } from './i18n.js';
import * as core from './core.js';
import * as ui from './ui.js';

const { h, icon, button, clear } = ui;
const COMMS_PHASES = ['design', 'review', 'simulation'];
const LOCAL_OVERLAYS = ['how', 'data', 'settings'];

// ---- Kabuk öğeleri ----
const $ = (id) => document.getElementById(id);
const el = {
  brand: $('brand'), tabs: $('tabs'), right: $('top-right'), banner: $('conn-banner'),
  back: $('back-btn'), backReason: $('back-reason'), backrowRight: $('backrow-right'),
  screen: $('screen'), commsFull: $('comms-full'), drawer: $('drawer'), drawerBody: $('drawer-body'), drawerClose: $('drawer-close'),
  foot: $('footbar'), debug: $('debug-state')
};

// ---- Ekranlara verilen api ----
const api = {
  emit: core.emit,
  nav: core.nav,
  ui,
  prefs: core.prefs,
  scene: async () => { try { return await import('/scene2d.js'); } catch (e) { return null; } },
  // ek (PLAN notlarında): anlık durum, olay dinleme, oturum bilgisi
  getState: core.getState,
  onEvent: core.onEvent,
  session: core.session
};

// ---- Yerel durum ----
let overlay = null;          // odadayken açılan fazsız ekran (how/data/settings)
let view = 'main';           // operatörde 'comms' = iletişim tam ekran
let drawerOpen = false;
let unread = 0;
let phaseSince = Date.now();
let lastPhase = null;

// ---- Hedef ekran ----
function phaseFile(st) {
  if (st.phase === 'design') return st.me && st.me.role === 'director' ? 'operator' : 'engineer';
  return st.phase;
}
function targetKey(st) {
  if (st && st.phase) return overlay || phaseFile(st);
  const cur = core.nav.current();
  return cur;
}
const inRoom = (st) => !!(st && st.phase);
const myRole = (st) => (st && st.me ? st.me.role : null);
const commsActive = (st) => inRoom(st) && COMMS_PHASES.includes(st.phase) && !!myRole(st);
// design ekranları (AD) iletişimi kendileri gösterir; kabuk çekmecesi yalnız review/simulation'da
const DRAWER_PHASES = ['review', 'simulation'];
const drawerActive = (st) => commsActive(st) && DRAWER_PHASES.includes(st.phase);

// ---- Modül yükleme (yoksa yer tutucu) ----
const cache = new Map();
function placeholder(key) {
  return {
    id: key,
    render(root) {
      root.appendChild(h('div', { class: 'placeholder' },
        ui.pixelRocket(72),
        h('h1', { class: 'placeholder__title', text: t('shell.placeholder.title') }),
        h('p', { class: 'muted', text: t('shell.placeholder.body') })));
    }
  };
}
async function load(file) {
  if (cache.has(file)) return cache.get(file);
  let mod;
  try {
    const m = await import(`./screens/${file}.js`);
    mod = m && m.default && typeof m.default.render === 'function' ? m.default : placeholder(file);
  } catch (e) {
    console.warn(`Ekran yüklenemedi: ${file}`, e && e.message);
    mod = placeholder(file);
  }
  cache.set(file, mod);
  return mod;
}

// ---- Ana ekran bağlama ----
const mounted = { key: null, mod: null };
let token = 0;
function safe(fn) { try { return fn(); } catch (e) { console.error(e); return undefined; } }

function renderError(root, e) {
  console.error(e);
  clear(root);
  root.appendChild(h('div', { class: 'placeholder' },
    h('h1', { class: 'placeholder__title', text: t('shell.renderErr.title') }),
    h('p', { class: 'muted', text: t('shell.renderErr.body') }),
    button({ label: t('shell.renderErr.reload'), variant: 'ghost', icon: 'back', onClick: () => location.reload() })));
}

let renderedOnce = false;
async function route(st, prev, fromState) {
  const key = targetKey(st);
  if (key === mounted.key && mounted.mod) {
    if (!fromState) return;   // yalnız sekme/gezinti: aynı ekran yeniden çizilmez
    if (typeof mounted.mod.update === 'function') {
      try { mounted.mod.update(st, prev, api); } catch (e) { renderError(el.screen, e); }
    } else {
      safe(() => mounted.mod.destroy && mounted.mod.destroy());
      clear(el.screen);
      try { mounted.mod.render(el.screen, st, api); } catch (e) { renderError(el.screen, e); }
    }
    return;
  }
  const my = ++token;
  if (mounted.mod) safe(() => mounted.mod.destroy && mounted.mod.destroy());
  mounted.key = key;
  mounted.mod = null;
  clear(el.screen);
  el.screen.setAttribute('aria-busy', 'true');
  el.screen.appendChild(h('div', { class: 'loading', role: 'status' }, h('span', { class: 'loading__bar' }), h('span', { text: t('shell.loading') })));
  const mod = await load(key);
  if (my !== token) return;
  clear(el.screen);
  el.screen.removeAttribute('aria-busy');
  el.screen.dataset.screen = key;
  el.screen.dataset.enter = '1';
  setTimeout(() => { if (mounted.key === key) delete el.screen.dataset.enter; }, 400);
  mounted.mod = mod;
  try { mod.render(el.screen, core.getState(), api); } catch (e) { renderError(el.screen, e); }
  el.screen.scrollTop = 0;
  window.scrollTo(0, 0);
  if (renderedOnce) el.screen.focus({ preventScroll: true });
  renderedOnce = true;
}

// ---- İletişim paneli (AD: screens/comms.js) ----
const comms = { root: h('div', { id: 'comms-root', class: 'comms-root' }), mod: null, loading: false };
// Kabukta iletişim modülü yalnız gerektiğinde bağlanır: operatör (tam ekran sekmesi) ya da review/simulation çekmecesi
const commsMounted = (st) => (commsActive(st) && myRole(st) === 'director') || drawerActive(st);
async function syncComms(st, prev) {
  if (!commsMounted(st)) {
    if (comms.mod) { safe(() => comms.mod.destroy && comms.mod.destroy()); comms.mod = null; }
    clear(comms.root);
    drawerOpen = false;
    view = 'main';
    unread = 0;
    return;
  }
  if (!comms.mod && !comms.loading) {
    comms.loading = true;
    const mod = await load('comms');
    comms.loading = false;
    if (!commsMounted(core.getState())) return;
    comms.mod = mod;
    clear(comms.root);
    try { mod.render(comms.root, core.getState(), api); } catch (e) { renderError(comms.root, e); }
  } else if (comms.mod && typeof comms.mod.update === 'function') {
    try { comms.mod.update(st, prev, api); } catch (e) { console.error(e); }
  } else if (comms.mod) {
    clear(comms.root);
    try { comms.mod.render(comms.root, st, api); } catch (e) { renderError(comms.root, e); }
  }
}
function commsVisible() { return view === 'comms' || drawerOpen; }
function placeComms() {
  const st = core.getState();
  const active = commsActive(st);
  const full = active && view === 'comms';
  el.screen.hidden = full;
  el.commsFull.hidden = !full;
  el.drawer.hidden = !(drawerActive(st) && drawerOpen && !full);
  const host = full ? el.commsFull : el.drawerBody;
  if (comms.root.parentNode !== host) host.appendChild(comms.root);
  comms.root.dataset.mode = full ? 'full' : 'drawer';
  if (commsVisible()) unread = 0;
}
function openDrawer(open) {
  drawerOpen = open;
  if (open) view = 'main';
  placeComms();
  renderChrome(core.getState());
  if (open) {
    const f = el.drawer.querySelector('textarea, input, button:not(#drawer-close)');
    (f || el.drawerClose).focus();
  }
}
el.drawerClose.addEventListener('click', () => { openDrawer(false); });

// ---- Üst çubuk sekmeleri ----
function tab(label, active, onClick, badge) {
  return h('button', { type: 'button', class: 'tab', 'aria-current': active ? 'page' : undefined, onClick },
    h('span', { text: label }), badge ? h('span', { class: 'badge', text: String(badge), 'aria-label': t('shell.tab.unread', { n: badge }) }) : null);
}
function goOverlay(id) {
  overlay = LOCAL_OVERLAYS.includes(id) ? id : null;
  view = 'main';
  refresh();
}
function renderTabs(st) {
  clear(el.tabs);
  if (!inRoom(st)) {
    const cur = core.nav.current();
    const startish = ['home', 'create', 'join'].includes(cur);
    el.tabs.append(
      tab(t('shell.tab.start'), startish, () => core.nav.go('home')),
      tab(t('shell.tab.how'), cur === 'how', () => core.nav.go('how')),
      tab(t('shell.tab.data'), cur === 'data', () => core.nav.go('data')),
      tab(t('shell.tab.settings'), cur === 'settings', () => core.nav.go('settings')));
    return;
  }
  const director = myRole(st) === 'director';
  el.tabs.append(tab(t('shell.tab.mission'), !overlay && view === 'main', () => { overlay = null; view = 'main'; refresh(); }));
  if (commsActive(st) && (director || drawerActive(st))) {
    el.tabs.append(tab(t('shell.tab.comms'), !overlay && (view === 'comms' || drawerOpen), () => {
      overlay = null;
      if (director) { view = 'comms'; drawerOpen = false; refresh(); } else openDrawer(!drawerOpen);
    }, commsVisible() ? 0 : unread));
  }
  el.tabs.append(
    tab(t('shell.tab.how'), overlay === 'how', () => goOverlay('how')),
    tab(t('shell.tab.settings'), overlay === 'settings', () => goOverlay('settings')));
}

// ---- Sağ üst: oda kodu, oyuncu sayısı, bağlantı, çıkış ----
const connText = (c) => t('shell.conn.' + c);
function connChip() {
  const c = core.connection();
  return h('span', { class: 'conn', dataset: { conn: c }, title: t('shell.conn.title') }, ui.statusDot(c), h('span', { class: 'conn__text', text: connText(c) }));
}
async function leaveRoom() {
  const ok = await ui.confirmModal({
    title: t('shell.leave.title'),
    body: t('shell.leave.body'),
    okLabel: t('shell.leave.ok')
  });
  if (!ok) return;
  await core.emit('room:leave', {});
  overlay = null;
  core.nav.reset('home');
}
function renderRight(st) {
  clear(el.right);
  if (!inRoom(st)) { el.right.append(connChip()); return; }
  const players = Array.isArray(st.players) ? st.players : [];
  el.right.append(
    h('span', { class: 'room-box', title: t('shell.top.roomCode') }, h('span', { class: 'room-box__k', text: t('shell.top.room') }), h('span', { class: 'room-box__v', text: st.code || '—' })),
    h('span', { class: 'count-box', title: t('shell.top.players') }, icon('users', 18), h('span', { text: `${players.length} / 4` })),
    connChip(),
    h('button', { type: 'button', class: 'icon-btn', 'aria-label': t('shell.top.leave'), title: t('shell.top.leave'), onClick: leaveRoom }, icon('exit', 20)));
}

// ---- GERİ düğmesi ----
function backInfo(st) {
  if (view === 'comms' && commsActive(st)) return { run: () => { view = 'main'; refresh(); } };
  if (inRoom(st) && overlay) return { run: () => { overlay = null; refresh(); } };
  if (!inRoom(st)) {
    return core.nav.canBack() ? { run: () => core.nav.back() } : { reason: t('shell.back.home') };
  }
  const role = myRole(st);
  const isHost = !!(st.me && st.me.isHost);
  const backEmit = (ev) => async () => {
    const res = await core.emit(ev, {});
    if (!res.ok) ui.toast(res.message || t('shell.back.failed'), 'error');
  };
  switch (st.phase) {
    case 'lobby': return { run: leaveRoom, label: t('shell.leave.ok') };
    case 'mission-select': return { reason: t('shell.back.msReason') };
    case 'briefing': return role === 'director' ? { run: backEmit('phase:back'), label: t('shell.back.toMissionSelect') } : { reason: t('shell.back.briefingReason') };
    case 'design': return { reason: t('shell.back.designReason') };
    case 'review': return role === 'director' ? { run: backEmit('review:back'), label: t('shell.back.toDesign') } : { reason: t('shell.back.reviewReason') };
    case 'simulation': return { reason: t('shell.back.simReason') };
    case 'debrief': return role === 'director' || isHost ? { run: backEmit('phase:back'), label: t('shell.back.toMissionSelect') } : { reason: t('shell.back.debriefReason') };
    default: return { reason: '' };
  }
}
let backRun = null;
function renderBack(st) {
  const b = backInfo(st);
  backRun = b.run || null;
  el.back.disabled = !b.run;
  el.back.querySelector('.back-btn__label').textContent = b.label ? `${t('shell.back.label')} · ${b.label}` : t('shell.back.label');
  el.backReason.textContent = b.run ? '' : (b.reason || '');
  el.back.title = b.reason || '';
}
el.back.addEventListener('click', async () => {
  if (!backRun || el.back.dataset.busy) return;
  el.back.dataset.busy = '1';
  try { await backRun(); } finally { delete el.back.dataset.busy; }
});

// Geri satırının sağı: iletişim çekmecesi düğmesi
function renderBackrowRight(st) {
  clear(el.backrowRight);
  if (!drawerActive(st) || view === 'comms') return;
  const b = h('button', { type: 'button', class: 'chip-btn', 'aria-expanded': drawerOpen ? 'true' : 'false', 'aria-controls': 'drawer', onClick: () => openDrawer(!drawerOpen) },
    icon('chat', 18), h('span', { text: myRole(st) === 'director' ? t('shell.backrow.messages') : t('shell.backrow.writeOperator') }),
    unread && !commsVisible() ? h('span', { class: 'badge', text: String(unread) }) : null);
  el.backrowRight.append(b);
}

// ---- Alt durum satırı ----
function renderFoot(st) {
  clear(el.foot);
  const c = core.connection();
  const parts = inRoom(st)
    ? [[t('shell.foot.room'), st.code || '—'], [t('shell.foot.role'), myRole(st) ? ui.ROLE_SHORT[myRole(st)] : t('shell.foot.noRole')], [t('shell.foot.phase'), ui.PHASE_NAMES[st.phase] || st.phase],
       [t('shell.foot.time'), ui.fmt.duration(Date.now() - phaseSince), 'time'], [t('shell.foot.link'), connText(c)]]
    : [['PIXEL PAYLOAD', t('shell.foot.mainMenu')], [t('shell.foot.link'), connText(c)]];
  parts.forEach(([k, v, id]) => el.foot.append(
    h('span', { class: 'foot__item', dataset: { k: id } }, h('span', { class: 'foot__k', text: k }), h('span', { class: 'foot__v', text: v }))));
}

// ---- Bağlantı şeridi ----
function renderBanner(st) {
  const c = core.connection();
  const show = c === 'offline' || (c === 'connecting' && inRoom(st));
  el.banner.hidden = !show;
  if (show) {
    el.banner.textContent = '';
    el.banner.append(icon('wifi', 18), h('span', {
      text: inRoom(st) || core.session.load() ? t('shell.banner.reconnecting') : t('shell.banner.connecting')
    }));
  }
}

function renderChrome(st) {
  renderTabs(st);
  renderRight(st);
  renderBack(st);
  renderBackrowRight(st);
  renderFoot(st);
  renderBanner(st);
  const role = myRole(st);
  if (role) document.documentElement.dataset.myrole = role; else delete document.documentElement.dataset.myrole;
  document.title = inRoom(st) ? `Pixel Payload · ${ui.PHASE_NAMES[st.phase] || ''}` : 'Pixel Payload';
  if (core.session.debug && el.debug) el.debug.textContent = st ? JSON.stringify(st, null, 2) : t('shell.debug.noState');
}

// ---- Yenile ----
function refresh(prev, fromState = false) {
  const st = core.getState();
  if (!commsActive(st)) { view = 'main'; drawerOpen = false; }
  if (!drawerActive(st)) drawerOpen = false;
  placeComms();
  renderChrome(st);
  route(st, prev, fromState);
}

core.subscribe((st, prev) => {
  const ph = st ? st.phase : null;
  if (ph !== lastPhase) { lastPhase = ph; phaseSince = Date.now(); }
  if (!st) overlay = null;
  syncComms(st, prev).then(placeComms);
  refresh(prev, true);
});
core.onEvent('nav', (id) => {
  // odadayken how/data/settings katman olarak açılır
  if (inRoom(core.getState()) && LOCAL_OVERLAYS.includes(id)) { overlay = id; view = 'main'; }
  refresh();
});
core.onEvent('connection', () => renderChrome(core.getState()));
core.onEvent('error', (res) => { if (res && res.message) ui.toast(res.message, 'error'); });
core.onEvent('chat:message', (m) => {
  const st = core.getState();
  if (!m || m.from === myRole(st) || commsVisible() || !drawerActive(st)) return;
  unread++;
  ui.toast(t('shell.chat.newMessage', { from: m.fromName || ui.ROLE_SHORT[m.from] || '' }), 'info', 2600);
  renderChrome(st);
});
core.onEvent('kicked', (p) => {
  overlay = null;
  core.nav.reset('home');
  ui.modal({ title: t('shell.kicked.title'), body: (p && p.reason) || t('shell.kicked.body'), actions: [{ label: t('shell.ui.ok'), variant: 'primary' }] });
});
core.onEvent('room:closed', (p) => {
  overlay = null;
  core.nav.reset('home');
  ui.toast(p && p.reason ? t('shell.closed.reason', { reason: p.reason }) : t('shell.closed.plain'), 'warn', 5000);
});
// ---- Dil: statik metinler + etkin ekranın baştan çizimi ----
function applyStatic() {
  document.querySelectorAll('[data-i18n]').forEach((n) => { n.textContent = t(n.dataset.i18n); });
  document.querySelectorAll('[data-i18n-aria]').forEach((n) => { n.setAttribute('aria-label', t(n.dataset.i18nAria)); });
}
onLang((lang) => {
  applyStatic();
  const st = core.getState();
  if (mounted.mod) {
    safe(() => mounted.mod.destroy && mounted.mod.destroy());
    clear(el.screen);
    try { mounted.mod.render(el.screen, st, api); } catch (e) { renderError(el.screen, e); }
  }
  if (comms.mod) {
    safe(() => comms.mod.destroy && comms.mod.destroy());
    clear(comms.root);
    try { comms.mod.render(comms.root, st, api); } catch (e) { renderError(comms.root, e); }
  }
  renderChrome(st);
  // odak: basılan dil düğmesi yeniden çizildi; aynı düğmeye geri ver
  const again = el.screen.querySelector(`.lang-switch__opt[data-lang="${lang}"]`);
  if (again) again.focus({ preventScroll: true });
});
applyStatic();

document.addEventListener('keydown', (e) => {
  if (e.key === 'Escape' && drawerOpen && !document.querySelector('.modal-wrap')) openDrawer(false);
});

// Marka: oda dışında ana menüye döner
el.brand.prepend(ui.pixelRocket(44));
el.brand.addEventListener('click', (e) => {
  e.preventDefault();
  if (inRoom(core.getState())) { overlay = null; view = 'main'; refresh(); } else core.nav.reset('home');
});
$('back-icon').append(icon('back', 20));

// Süre sayacı (yalnız alt satırın süre alanı)
setInterval(() => {
  const st = core.getState();
  const t = el.foot.querySelector('[data-k="time"] .foot__v');
  if (t && inRoom(st)) t.textContent = ui.fmt.duration(Date.now() - phaseSince);
}, 1000);

refresh();
core.connect();
