// Pixel Payload — Demo kontrol modu (Aşama 7 metinleri: Operatör / İtki / Uzay Aracı / Bilim; Ay ve Mars görevleri). Her panel gerçek bir oyuncudur (kendi iframe'i, kendi socket'i).
// Bu sayfa yalnızca iframe'leri kurar ve onlardan gelen 'pp-state' özetlerini (faz/kod/rol) gösterir.
(function () {
  'use strict';

  var ROLES = ['director', 'rocket', 'spacecraft', 'payload'];
  // ---- Dil (EN | TR): paneller de aynı origin'deki localStorage 'pp.lang'i okur ----
  var LANG_KEY = 'pp.lang';
  var TEXT = {
    en: {
      home: '← MAIN MENU', brandSub: 'ONE PLAYER, FOUR SCREENS', room: 'Room', reset: 'Reset', start: 'Set up demo room',
      panelsTitle: 'Checked roles become demo panels; unchecked roles join by phone', panels: 'Panels',
      'r.director': 'Operator', 'r.rocket': 'Propulsion', 'r.spacecraft': 'Spacecraft', 'r.payload': 'Science',
      existing: 'Existing room', codePh: 'CODE', codeAria: 'Existing room code', join: 'Join', layout: 'Layout', layoutAria: 'Panel layout',
      layoutDir: 'Operator large', layoutRow: 'Four columns', emptyAria: 'How to use demo mode', emptyTitle: 'DEMO MODE',
      emptyTag: 'ONE PLAYER · FOUR SCREENS · REAL PLAYERS',
      emptyText: 'The Operator and all three engineer screens open side by side on this page. Each panel is a real player; you drive them all.',
      missions: 'Missions', moon: 'CREWED MOON MISSION', moonSub: 'Liftoff, landing, surface, safe return',
      mars: 'MARS ROVER MISSION', marsSub: 'Cruise, EDL, landing, science, data downlink',
      step1: 'Press “Set up demo room” — the Operator panel opens the room.', step2: 'The other three panels join the room code automatically.',
      step3: 'Mark everyone “Ready” in the lobby, then start the mission from the Operator panel.',
      cardNote: 'To mix in phones, pick panels above and join an existing room.',
      'rl.director': 'Operator', 'rl.rocket': 'Propulsion', 'rl.spacecraft': 'Spacecraft', 'rl.payload': 'Science & Payload',
      'f.director': 'Operator panel', 'f.rocket': 'Propulsion engineer panel', 'f.spacecraft': 'Spacecraft engineer panel', 'f.payload': 'Science and payload engineer panel',
      langAria: 'Language', title: 'Pixel Payload — Demo mode',
      enlarge: 'Enlarge', shrink: 'Shrink', connecting: 'Connecting…', noPanels: 'No panels yet. Use “Set up demo room” or “Join” above.',
      phoneJoin: 'Join this role by phone:', waitCode: '(waiting for code)', phone: 'Phone', waitingCode: 'Waiting for room code…',
      codeTimeout: 'Room code did not arrive within {s} s. Is the server running? Try again with “Reset”.',
      pickRole: 'Pick at least one role for a panel.', badCode: 'Enter a valid 4-character room code.', connFail: 'Could not connect.',
      failed: 'Connection failed', entry: 'Sign-in', roleIs: ' · role: ', noRole: ' · no role taken', narrow: 'Panels may be narrow at this width',
      'p.lobby': 'Lobby', 'p.mission-select': 'Mission select', 'p.briefing': 'Briefing', 'p.design': 'Design', 'p.review': 'Review', 'p.simulation': 'Simulation', 'p.debrief': 'Debrief'
    },
    tr: {
      home: '← ANA MENÜ', brandSub: 'TEK KİŞİ, DÖRT EKRAN', room: 'Oda', reset: 'Sıfırla', start: 'Demo odası kur',
      panelsTitle: 'İşaretli roller demo paneli olur; işaretsiz roller telefonla katılır', panels: 'Paneller',
      'r.director': 'Operatör', 'r.rocket': 'İtki', 'r.spacecraft': 'Uzay Aracı', 'r.payload': 'Bilim',
      existing: 'Var olan oda', codePh: 'KOD', codeAria: 'Var olan oda kodu', join: 'Katıl', layout: 'Yerleşim', layoutAria: 'Panel yerleşimi',
      layoutDir: 'Operatör büyük', layoutRow: 'Dört sütun', emptyAria: 'Demo modu nasıl kullanılır', emptyTitle: 'DEMO MODU',
      emptyTag: 'TEK KİŞİ · DÖRT EKRAN · GERÇEK OYUNCULAR',
      emptyText: 'Operatör ve üç mühendisin ekranı bu sayfada yan yana açılır. Her panel gerçek bir oyuncudur; hepsini sen oynatırsın.',
      missions: 'Görevler', moon: 'İNSANLI AY GÖREVİ', moonSub: 'Kalkış, iniş, yüzey, güvenli dönüş',
      mars: 'MARS GEZGİN GÖREVİ', marsSub: 'Seyir, EDL, iniş, bilim, veri iletimi',
      step1: '“Demo odası kur”a bas — Operatör paneli odayı açar.', step2: 'Diğer üç panel oda koduna kendiliğinden katılır.',
      step3: 'Lobide herkesi “Hazır” yap, Operatör panelinden görevi başlat.',
      cardNote: 'Telefonlarla karışık oynamak için üstten panelleri seç ve var olan odaya katıl.',
      'rl.director': 'Operatör', 'rl.rocket': 'İtki', 'rl.spacecraft': 'Uzay Aracı', 'rl.payload': 'Bilim & Yük',
      'f.director': 'Operatör paneli', 'f.rocket': 'İtki mühendisi paneli', 'f.spacecraft': 'Uzay aracı mühendisi paneli', 'f.payload': 'Bilim ve faydalı yük mühendisi paneli',
      langAria: 'Dil', title: 'Pixel Payload — Demo modu',
      enlarge: 'Büyüt', shrink: 'Küçült', connecting: 'Bağlanıyor…', noPanels: 'Henüz panel yok. Üstten “Demo odası kur” ya da “Var olan odaya katıl”.',
      phoneJoin: 'Bu rol için telefonla katıl:', waitCode: '(kod bekleniyor)', phone: 'Telefon', waitingCode: 'Oda kodu bekleniyor…',
      codeTimeout: 'Oda kodu {s} sn içinde gelmedi. Sunucu açık mı? “Sıfırla” ile tekrar dene.',
      pickRole: 'En az bir rol için panel seç.', badCode: 'Geçerli bir 4 harfli oda kodu yaz.', connFail: 'Bağlanılamadı.',
      failed: 'Bağlanamadı', entry: 'Giriş', roleIs: ' · rol: ', noRole: ' · rol alınamadı', narrow: 'Bu genişlikte paneller dar olabilir',
      'p.lobby': 'Lobi', 'p.mission-select': 'Görev seçimi', 'p.briefing': 'Brifing', 'p.design': 'Tasarım', 'p.review': 'Hazırlık', 'p.simulation': 'Simülasyon', 'p.debrief': 'Sonuç'
    }
  };
  var lang = 'en';
  try { var stored = localStorage.getItem(LANG_KEY); if (stored === 'en' || stored === 'tr') lang = stored; } catch (e) { /* yok say */ }
  function T(key, params) {
    var s = (TEXT[lang] && TEXT[lang][key]) || TEXT.en[key] || key;
    if (params) s = s.replace(/\{(\w+)\}/g, function (m, k) { return params[k] !== undefined ? String(params[k]) : m; });
    return s;
  }
  // Panel oyuncu adı (yalnız yeni oyuncu oluşurken kullanılır) ve rol etiketi
  function playerName(r) { return T('r.' + r); }
  function roleLabel(r) { return T('rl.' + r); }
  var DEMO_KEY = 'pixelPayloadDemo';                 // demo'nun kendi kaydı
  var SESSION_PREFIX = 'pixelPayloadSession:demo-';  // panel (slot) oturumları
  var CODE_TIMEOUT_MS = 5000;

  function $(sel) { return document.querySelector(sel); }
  var el = {
    startBtn: $('#demo-start-btn'),
    resetBtn: $('#demo-reset-btn'),
    code: $('#demo-code'),
    joinCode: $('#demo-join-code'),
    joinBtn: $('#demo-join-btn'),
    error: $('#demo-error'),
    panels: $('#demo-panels'),
    roleChecks: document.querySelectorAll('input[type=checkbox][data-demo-role]'),
    layoutBtns: document.querySelectorAll('button[data-layout]'),
    focusBtns: document.querySelectorAll('button[data-focus]')
  };

  // Panel DOM'u rol başına
  var panels = {};
  ROLES.forEach(function (r) {
    var p = document.querySelector('.demo-panel[data-role="' + r + '"]');
    panels[r] = {
      root: p,
      iframe: p.querySelector('iframe'),
      status: p.querySelector('.demo-status'),
      placeholder: p.querySelector('.demo-placeholder')
    };
  });

  // Çalışma durumu: { mode: 'create'|'join', roles: [...], code, host }
  var run = null;
  var codeTimer = null;
  var view = { layout: 'grid', focus: null };

  // ---- Kayıt ----
  function save() {
    try {
      sessionStorage.setItem(DEMO_KEY, JSON.stringify({ run: run, layout: view.layout, focus: view.focus }));
    } catch (e) { /* yok say */ }
  }
  function load() {
    try { return JSON.parse(sessionStorage.getItem(DEMO_KEY)) || null; } catch (e) { return null; }
  }
  function clearStorage() {
    try {
      var keys = [];
      for (var i = 0; i < sessionStorage.length; i++) {
        var k = sessionStorage.key(i);
        if (k && k.indexOf(SESSION_PREFIX) === 0) keys.push(k);
      }
      keys.forEach(function (k) { sessionStorage.removeItem(k); });
      sessionStorage.removeItem(DEMO_KEY);
    } catch (e) { /* yok say */ }
  }

  function showError(msg) { el.error.textContent = msg || ''; }

  // ---- Yerleşim / odak (yalnızca CSS sınıfı; iframe'ler yeniden yüklenmez) ----
  function applyView() {
    el.panels.className = 'layout-' + view.layout + (view.focus ? ' has-focus' : '');
    el.layoutBtns.forEach(function (b) {
      b.setAttribute('aria-pressed', b.getAttribute('data-layout') === view.layout ? 'true' : 'false');
    });
    ROLES.forEach(function (r) {
      panels[r].root.classList.toggle('is-focused', view.focus === r);
    });
    el.focusBtns.forEach(function (b) {
      var on = b.getAttribute('data-focus') === view.focus;
      b.setAttribute('aria-pressed', on ? 'true' : 'false');
      b.textContent = on ? T('shrink') : T('enlarge');
    });
  }

  // ---- Paneller ----
  function frameUrl(role, params) {
    var q = 'embed=1&slot=demo-' + role + '&name=' + encodeURIComponent(playerName(role)) + '&role=' + role;
    Object.keys(params).forEach(function (k) { q += '&' + k + '=' + encodeURIComponent(params[k]); });
    return '/?' + q;
  }

  function setStatus(role, text, warn) {
    panels[role].status.textContent = text;
    panels[role].status.setAttribute('data-warn', warn ? 'true' : 'false');
  }

  function loadPanel(role, params) {
    panels[role].placeholder.hidden = true;
    setStatus(role, T('connecting'));
    panels[role].iframe.src = frameUrl(role, params);
  }

  function isDemoRole(role) { return !!(run && run.roles.indexOf(role) !== -1); }

  // İşaretsiz roller ve henüz yüklenmemiş paneller için yer tutucu
  function updatePlaceholders() {
    // Oda yokken paneller gizlenir, ortada açıklama kartı görünür
    document.body.classList.toggle('is-idle', !run);
    ROLES.forEach(function (r) {
      var ph = panels[r].placeholder;
      if (run && isDemoRole(r) && panels[r].iframe.getAttribute('src') !== 'about:blank') { ph.hidden = true; return; }
      ph.hidden = false;
      ph.textContent = '';
      var p = document.createElement('p'); // tek çocuk: flex ortalama metni bölmesin
      if (!run) {
        p.textContent = T('noPanels');
      } else if (!isDemoRole(r)) {
        p.appendChild(document.createTextNode(T('phoneJoin')));
        var s = document.createElement('strong');
        s.textContent = run.code || T('waitCode');
        p.appendChild(s);
        setStatus(r, T('phone'));
      } else {
        p.textContent = T('waitingCode');
      }
      ph.appendChild(p);
    });
  }

  function setCode(code) {
    el.code.textContent = code || '----';
    if (run) run.code = code || null;
    updatePlaceholders();
    save();
  }

  function selectedRoles() {
    var list = [];
    el.roleChecks.forEach(function (c) { if (c.checked) list.push(c.getAttribute('data-demo-role')); });
    return ROLES.filter(function (r) { return list.indexOf(r) !== -1; });
  }

  function blankAll() {
    if (codeTimer) clearTimeout(codeTimer);
    codeTimer = null;
    ROLES.forEach(function (r) {
      panels[r].iframe.src = 'about:blank';
      setStatus(r, '—');
    });
  }

  // Oda koduyla katılacak (henüz yüklenmemiş) panelleri yükle
  function loadJoiners() {
    run.roles.forEach(function (r) {
      if (r === run.host) return;
      if (panels[r].iframe.getAttribute('src') !== 'about:blank') return;
      loadPanel(r, { auto: 'join', code: run.code });
    });
    updatePlaceholders();
  }

  // Çalıştır: create modunda önce ev sahibi paneli, kod gelince diğerleri; join modunda hepsi birden
  function launch() {
    blankAll();
    showError('');
    run.errors = {};
    el.code.textContent = run.code || '----';
    if (run.mode === 'join') {
      run.host = null;
      loadJoiners();
    } else {
      run.host = run.roles.indexOf('director') !== -1 ? 'director' : run.roles[0];
      loadPanel(run.host, { auto: 'create' });
      updatePlaceholders();
      codeTimer = setTimeout(function () {
        codeTimer = null;
        if (!run || run.mode !== 'create' || run.codeFromHost) return;
        showError(T('codeTimeout', { s: CODE_TIMEOUT_MS / 1000 }));
      }, CODE_TIMEOUT_MS);
    }
    save();
  }

  function start(mode) {
    var roles = selectedRoles();
    if (!roles.length) { showError(T('pickRole')); return; }
    var code = null;
    if (mode === 'join') {
      code = el.joinCode.value.trim().toUpperCase();
      if (!/^[A-Z0-9]{4}$/.test(code)) { showError(T('badCode')); return; }
    }
    clearStorage(); // yeni demo: eski panel oturumları kullanılmasın
    run = { mode: mode, roles: roles, code: code, host: null, codeFromHost: false };
    launch();
  }

  function reset() {
    blankAll();
    clearStorage();
    run = null;
    el.code.textContent = '----';
    showError('');
    updatePlaceholders();
  }

  // ---- Panel katılma hataları (pp-error) ----
  function showPanelErrors() {
    var errs = run && run.errors ? run.errors : {};
    showError(ROLES.filter(function (r) { return errs[r]; })
      .map(function (r) { return roleLabel(r) + ': ' + errs[r]; }).join(' · '));
  }

  // Yanlış kod: panelleri kapat, kullanıcıyı kod alanına döndür
  function failToCodeField(msg) {
    blankAll();
    clearStorage();
    run = null;
    el.code.textContent = '----';
    updatePlaceholders();
    showError(msg);
    try { el.joinCode.focus(); el.joinCode.select(); } catch (e) { /* yok say */ }
  }

  function onPanelError(role, d) {
    var msg = typeof d.message === 'string' && d.message ? d.message.slice(0, 120) : T('connFail');
    if (d.error === 'ROOM_NOT_FOUND' && run.mode === 'join') {
      failToCodeField(roleLabel(role) + ': ' + msg);
      return;
    }
    if (!run.errors) run.errors = {};
    run.errors[role] = msg;
    setStatus(role, T('failed'), true);
    showPanelErrors();
  }

  // ---- Panellerden gelen özet ----
  window.addEventListener('message', function (event) {
    if (event.origin !== location.origin) return;
    var d = event.data;
    if (!d || typeof d !== 'object' || (d.type !== 'pp-state' && d.type !== 'pp-error') || typeof d.slot !== 'string') return;
    var role = d.slot.indexOf('demo-') === 0 ? d.slot.slice(5) : null;
    if (!run || !panels[role] || !isDemoRole(role)) return;
    if (event.source !== panels[role].iframe.contentWindow) return;

    if (d.type === 'pp-error') { onPanelError(role, d); return; }

    // Hatalı panel: oda + doğru rol gelene kadar "Bağlanamadı" kalır
    if (run.errors && run.errors[role]) {
      if (d.code && d.role === role) { delete run.errors[role]; showPanelErrors(); }
      else if (!d.code) return;
    }

    // Başlık: faz + oda kodu (+ rol uyuşmazlığı uyarısı)
    var phase = d.phase ? (TEXT.en['p.' + d.phase] ? T('p.' + d.phase) : d.phase) : T('entry');
    var text = phase + (d.code ? ' · ' + d.code : '');
    var warn = false;
    if (d.code && d.role !== role) {
      text += d.role ? T('roleIs') + (TEXT.en['rl.' + d.role] ? roleLabel(d.role) : d.role) : T('noRole');
      warn = true;
    }
    if (!d.code) warn = true;
    setStatus(role, text, warn);

    // Ev sahibi kodu bildirdi: diğer panelleri o koda bağla
    if (run.mode === 'create' && role === run.host && d.code) {
      if (!run.codeFromHost || run.code !== d.code) {
        var changed = run.code && run.code !== d.code;
        run.codeFromHost = true;
        if (codeTimer) { clearTimeout(codeTimer); codeTimer = null; }
        showPanelErrors();
        setCode(d.code);
        if (changed) {
          // Oda yeniden açıldı (ör. lobideyken yenileme): diğer panelleri yeni koda bağla
          run.roles.forEach(function (r) {
            if (r === run.host) return;
            panels[r].iframe.src = 'about:blank';
            try { sessionStorage.removeItem(SESSION_PREFIX + r); } catch (e) { /* yok say */ }
          });
        }
        loadJoiners();
      }
    } else if (run.mode === 'join' && d.code && !run.code) {
      setCode(d.code);
    }
  });

  // ---- Olaylar ----
  el.startBtn.addEventListener('click', function () { start('create'); });
  // Boş durum kartındaki büyük düğme aynı işi yapar
  var emptyStart = $('#demo-empty-start');
  if (emptyStart) emptyStart.addEventListener('click', function () { start('create'); });
  el.joinBtn.addEventListener('click', function () { start('join'); });
  el.joinCode.addEventListener('input', function () { el.joinCode.value = el.joinCode.value.toUpperCase(); });
  el.joinCode.addEventListener('keydown', function (e) { if (e.key === 'Enter') start('join'); });
  el.resetBtn.addEventListener('click', reset);
  el.layoutBtns.forEach(function (b) {
    b.addEventListener('click', function () {
      view.layout = b.getAttribute('data-layout');
      view.focus = null;
      applyView();
      save();
    });
  });
  el.focusBtns.forEach(function (b) {
    b.addEventListener('click', function () {
      var r = b.getAttribute('data-focus');
      view.focus = view.focus === r ? null : r;
      applyView();
      save();
    });
  });

  // ---- Dil: sabit metinler + EN|TR anahtarı ----
  function applyLang() {
    document.documentElement.lang = lang;
    document.title = T('title');
    document.querySelectorAll('[data-i18n]').forEach(function (n) { n.textContent = T(n.getAttribute('data-i18n')); });
    document.querySelectorAll('[data-i18n-title]').forEach(function (n) { n.title = T(n.getAttribute('data-i18n-title')); });
    document.querySelectorAll('[data-i18n-aria]').forEach(function (n) { n.setAttribute('aria-label', T(n.getAttribute('data-i18n-aria'))); });
    document.querySelectorAll('[data-i18n-ph]').forEach(function (n) { n.placeholder = T(n.getAttribute('data-i18n-ph')); });
    document.querySelectorAll('#demo-lang button[data-lang]').forEach(function (b) {
      b.setAttribute('aria-pressed', b.getAttribute('data-lang') === lang ? 'true' : 'false');
    });
    applyView();
    updatePlaceholders();
  }
  function setLang(next) {
    if ((next !== 'en' && next !== 'tr') || next === lang) return;
    lang = next;
    try { localStorage.setItem(LANG_KEY, lang); } catch (e) { /* yok say */ }
    applyLang();
    // Paneller aynı origin'de: yeniden yükleme yeni dili okur, slot oturumu (sessionStorage) ile odaya geri bağlanır
    ROLES.forEach(function (r) {
      var f = panels[r].iframe;
      if (f.getAttribute('src') === 'about:blank') return;
      try { f.contentWindow.location.reload(); } catch (e) { f.src = f.getAttribute('src'); }
    });
  }
  document.querySelectorAll('#demo-lang button[data-lang]').forEach(function (b) {
    b.addEventListener('click', function () { setLang(b.getAttribute('data-lang')); });
  });
  applyLang();

  // ---- Açılış: kayıt varsa paneller slot oturumlarıyla geri döner (rejoin) ----
  var saved = load();
  // Varsayılan 2×2; dar pencerede (< 1500 px) dört sütun sıkışık olduğu için yalnız kullanıcı seçerse uygulanır
  var NARROW_PX = 1500;
  view.layout = 'grid';
  if (saved && (saved.layout === 'grid' || saved.layout === 'director' || saved.layout === 'row')) view.layout = saved.layout;
  var rowBtn = document.querySelector('button[data-layout="row"]');
  if (rowBtn && window.innerWidth < NARROW_PX) rowBtn.title = T('narrow');
  if (saved && ROLES.indexOf(saved.focus) !== -1) view.focus = saved.focus;
  applyView();
  if (saved && saved.run && Array.isArray(saved.run.roles) && saved.run.roles.length) {
    var roles = ROLES.filter(function (r) { return saved.run.roles.indexOf(r) !== -1; });
    el.roleChecks.forEach(function (c) { c.checked = roles.indexOf(c.getAttribute('data-demo-role')) !== -1; });
    var mode = saved.run.mode === 'join' ? 'join' : 'create';
    var code = typeof saved.run.code === 'string' ? saved.run.code : null;
    if (mode === 'join' && code) el.joinCode.value = code;
    // create modunda kod ev sahibinden yeniden gelir (rejoin başarısızsa yeni oda açılır)
    run = { mode: mode, roles: roles, code: code, host: null, codeFromHost: false };
    launch();
  } else {
    updatePlaceholders();
  }
})();
