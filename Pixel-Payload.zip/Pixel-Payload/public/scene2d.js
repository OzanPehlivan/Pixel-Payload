// Pixel Payload — 2B araç sahnesi (Modül AE, Aşama 7)
// Arayüz: PLAN.md > "Aşama 7 — Arayüz" > createVehicleScene. Bağımlılıksız; her şey SVG ile kodla çizilir.
//
//   createVehicleScene(container) → {
//     setVehicle({ missionId, modules: [{ id, name, role }], items: state.vehicle, highlightModule? }),
//     onModuleClick(fn(moduleId)),
//     playPhase(phaseId, status, opts?) → Promise   // her zaman resolve; opts.instant = animasyonsuz son poz
//     reset(), dispose()
//   }
//
// Görev modülleri aşağıdan yukarı dikey yığın olarak çizilir (STACKS). Takılı parçalar modül üstünde
// rol renkli simgelerdir (item.icon → ICONS). Boş modül soluk + kesik çizgili.

import { t, upperL, getLang } from './js/i18n.js';
import './js/lang/command.js';

const NS = 'http://www.w3.org/2000/svg';
const W = 420;            // viewBox genişliği (etiketler için yanlarda pay)
const H = 640;            // viewBox yüksekliği
const CX = W / 2;
const BASE_Y = 596;       // yığının oturduğu çizgi (rampa)
const MAX_ANIM_MS = 2500;

// ---------------------------------------------------------------- renkler (PLAN görsel dili)
const C = {
  cyan: '#38c8ff', green: '#3dff8a', amber: '#ffc247', red: '#ff4d5e', text: '#e6f1ff', dim: '#8aa4c8',
  hull: '#12284a', hullLine: '#9fc2e6', seam: '#2b4a74', dark: '#071326', flame: '#ffb347', flameCore: '#fff1c4'
};
const ROLE_COLOR = { director: '#dff6ff', rocket: '#ff9f43', spacecraft: C.cyan, payload: C.green };
const GROUND = { lunar: { fill: '#3a4150', line: '#8c96a8' }, mars: { fill: '#5a2a1c', line: '#c8653f' } };

// ---------------------------------------------------------------- görev yığınları (aşağıdan yukarı)
// h: modül yüksekliği, w: çizim genişliği, draw: gövde çizimi. Ad/rol varsayılanı; setVehicle'daki modules üstün gelir.
const STACKS = {
  lunar: [
    { id: 'launch-vehicle', name: 'Fırlatma aracı', role: 'rocket', h: 226, w: 132, draw: drawLauncherLunar },
    { id: 'lander', name: 'İniş aracı', role: 'rocket', h: 106, w: 128, draw: drawLander },
    { id: 'surface-kit', name: 'Yüzey kiti', role: 'payload', h: 58, w: 96, draw: drawCargo },
    { id: 'crew-vehicle', name: 'Mürettebat aracı', role: 'spacecraft', h: 150, w: 104, draw: drawCrew }
  ],
  mars: [
    { id: 'launch-vehicle', name: 'Fırlatma aracı', role: 'rocket', h: 236, w: 120, draw: drawLauncherMars },
    { id: 'edl', name: 'EDL / aeroshell', role: 'spacecraft', h: 74, w: 168, draw: drawAeroshell },
    { id: 'rover', name: 'Gezgin', role: 'spacecraft', h: 104, w: 150, draw: drawRover },
    { id: 'cruise-stage', name: 'Seyir kademesi', role: 'rocket', h: 56, w: 160, draw: drawCruise }
  ]
};

// ---------------------------------------------------------------- küçük yardımcılar
function el(tag, attrs, parent) {
  const n = document.createElementNS(NS, tag);
  if (attrs) for (const k in attrs) if (attrs[k] !== undefined && attrs[k] !== null) n.setAttribute(k, attrs[k]);
  if (parent) parent.appendChild(n);
  return n;
}
function clear(node) { while (node.firstChild) node.removeChild(node.firstChild); }
function reducedMotion() {
  const root = document.documentElement;
  if (root.classList.contains('reduce-motion') || root.dataset.reduceMotion === '1' || root.dataset.reduceMotion === 'true') return true;
  try { return window.matchMedia('(prefers-reduced-motion: reduce)').matches; } catch (e) { return false; }
}
const sleep = (ms) => new Promise((r) => setTimeout(r, ms));
const roleColor = (r) => ROLE_COLOR[r] || C.cyan;

// ---------------------------------------------------------------- parça simgeleri (24×24, c = rol rengi)
const ICONS = {
  engine(g, c) { el('rect', { x: 8, y: 2, width: 8, height: 5, fill: c, 'fill-opacity': .45, stroke: c }, g); el('path', { d: 'M10 7H14L19 17H5Z', fill: c, 'fill-opacity': .2, stroke: c }, g); el('path', { d: 'M8 20L7 22M12 20V22M16 20L17 22', stroke: c }, g); },
  fuel(g, c) { el('rect', { x: 6, y: 2, width: 12, height: 20, rx: 6, fill: c, 'fill-opacity': .2, stroke: c }, g); el('path', { d: 'M6 9H18M6 15H18', stroke: c }, g); },
  power(g, c) { el('rect', { x: 5, y: 5, width: 14, height: 17, fill: c, 'fill-opacity': .15, stroke: c }, g); el('rect', { x: 9, y: 2, width: 6, height: 3, fill: c, stroke: c }, g); el('path', { d: 'M13 8L9 14H12L11 19L15 12H12Z', fill: c, stroke: 'none' }, g); },
  solar(g, c) { el('rect', { x: 2, y: 5, width: 20, height: 14, fill: c, 'fill-opacity': .15, stroke: c }, g); el('path', { d: 'M8.7 5V19M15.3 5V19M2 12H22', stroke: c }, g); },
  antenna(g, c) { el('path', { d: 'M3 8Q12 20 21 8Z', fill: c, 'fill-opacity': .25, stroke: c }, g); el('path', { d: 'M12 14V5M12 14V21M8 21H16', stroke: c }, g); el('circle', { cx: 12, cy: 4, r: 1.8, fill: c, stroke: 'none' }, g); },
  shield(g, c) { el('path', { d: 'M12 2L20 5V12C20 17 16.5 20 12 22C7.5 20 4 17 4 12V5Z', fill: c, 'fill-opacity': .22, stroke: c }, g); el('path', { d: 'M12 6V18', stroke: c }, g); },
  heatshield(g, c) { el('path', { d: 'M2 9Q12 21 22 9Z', fill: c, 'fill-opacity': .3, stroke: c }, g); el('path', { d: 'M6 4V7M12 3V7M18 4V7', stroke: c }, g); },
  thermo(g, c) { el('path', { d: 'M10 4A2 2 0 0 1 14 4V14A4 4 0 1 1 10 14Z', fill: c, 'fill-opacity': .15, stroke: c }, g); el('circle', { cx: 12, cy: 17, r: 2, fill: c, stroke: 'none' }, g); el('path', { d: 'M12 8V15', stroke: c }, g); },
  flask(g, c) { el('path', { d: 'M9 2H15M10 2V9L4 20H20L14 9V2', fill: c, 'fill-opacity': .15, stroke: c }, g); el('path', { d: 'M7 15H17', stroke: c }, g); },
  camera(g, c) { el('path', { d: 'M8 7L10 4H14L16 7', fill: c, 'fill-opacity': .4, stroke: c }, g); el('rect', { x: 3, y: 7, width: 18, height: 13, fill: c, 'fill-opacity': .15, stroke: c }, g); el('circle', { cx: 12, cy: 13.5, r: 4, fill: C.dark, stroke: c }, g); },
  crew(g, c) { el('circle', { cx: 12, cy: 8, r: 5, fill: c, 'fill-opacity': .2, stroke: c }, g); el('rect', { x: 9, y: 6.5, width: 6, height: 3, fill: c, stroke: 'none' }, g); el('path', { d: 'M4 22C4 16 8 14 12 14S20 16 20 22', fill: c, 'fill-opacity': .2, stroke: c }, g); },
  computer(g, c) { el('rect', { x: 6, y: 6, width: 12, height: 12, fill: c, 'fill-opacity': .15, stroke: c }, g); el('rect', { x: 9.5, y: 9.5, width: 5, height: 5, fill: c, stroke: 'none' }, g); el('path', { d: 'M9 2.5V6M15 2.5V6M9 18V21.5M15 18V21.5M2.5 9H6M2.5 15H6M18 9H21.5M18 15H21.5', stroke: c }, g); },
  satellite(g, c) { el('rect', { x: 9, y: 9, width: 6, height: 6, fill: c, 'fill-opacity': .35, stroke: c }, g); el('path', { d: 'M2 6L7 11M17 13L22 18M4 4L9 9M15 15L20 20', stroke: c }, g); el('path', { d: 'M15 9L18 6', stroke: c }, g); },
  rover(g, c) { el('rect', { x: 4, y: 9, width: 16, height: 6, fill: c, 'fill-opacity': .2, stroke: c }, g); el('path', { d: 'M15 9V4H18', stroke: c }, g); for (const x of [6, 12, 18]) el('circle', { cx: x, cy: 19, r: 2.5, fill: C.dark, stroke: c }, g); },
  wheel(g, c) { el('circle', { cx: 12, cy: 12, r: 9, fill: c, 'fill-opacity': .15, stroke: c }, g); el('circle', { cx: 12, cy: 12, r: 3, fill: c, stroke: 'none' }, g); el('path', { d: 'M12 3V9M12 15V21M3 12H9M15 12H21', stroke: c }, g); },
  parachute(g, c) { el('path', { d: 'M2 11A10 8 0 0 1 22 11Z', fill: c, 'fill-opacity': .25, stroke: c }, g); el('path', { d: 'M2 11L12 21L22 11M8 11L12 21L16 11', stroke: c }, g); },
  radar(g, c) { el('path', { d: 'M4 20A16 16 0 0 1 20 4', stroke: c }, g); el('path', { d: 'M8 20A12 12 0 0 1 20 8', stroke: c }, g); el('circle', { cx: 18, cy: 18, r: 3, fill: c, stroke: 'none' }, g); el('path', { d: 'M18 18L11 11', stroke: c }, g); },
  drill(g, c) { el('rect', { x: 8, y: 2, width: 8, height: 7, fill: c, 'fill-opacity': .3, stroke: c }, g); el('path', { d: 'M12 9V22M9 12L15 14M9 16L15 18', stroke: c }, g); },
  leg(g, c) { el('path', { d: 'M8 3L12 9L5 20M16 3L12 9L19 20M3 21H8M16 21H21', stroke: c }, g); },
  chart(g, c) { el('path', { d: 'M3 21H21M3 21V3', stroke: c }, g); el('path', { d: 'M6 17L10 11L14 14L20 6', stroke: c }, g); },
  gear(g, c) { el('circle', { cx: 12, cy: 12, r: 6, fill: c, 'fill-opacity': .2, stroke: c }, g); el('circle', { cx: 12, cy: 12, r: 2, fill: c, stroke: 'none' }, g); el('path', { d: 'M12 2V5M12 19V22M2 12H5M19 12H22M5 5L7 7M17 17L19 19M5 19L7 17M17 7L19 5', stroke: c }, g); },
  rocket(g, c) { el('path', { d: 'M12 2C16 6 16 12 15 17H9C8 12 8 6 12 2Z', fill: c, 'fill-opacity': .2, stroke: c }, g); el('path', { d: 'M9 14L5 19H9M15 14L19 19H15M10 20L12 23L14 20', stroke: c }, g); },
  box(g, c) { el('rect', { x: 4, y: 4, width: 16, height: 16, fill: c, 'fill-opacity': .18, stroke: c }, g); el('path', { d: 'M4 10H20', stroke: c }, g); }
};
// Veri dosyalarındaki olası farklı adlar → çizim
const ICON_ALIAS = {
  tank: 'fuel', propellant: 'fuel', battery: 'power', rtg: 'power', mmrtg: 'power', panel: 'solar', 'solar-panel': 'solar',
  dish: 'antenna', comms: 'antenna', radio: 'antenna', 'heat-shield': 'heatshield', aeroshell: 'heatshield', ablator: 'heatshield',
  instrument: 'flask', science: 'flask', spectrometer: 'flask', sample: 'drill', sampler: 'drill', arm: 'drill', moxie: 'flask',
  suit: 'crew', eva: 'crew', habitat: 'crew', eclss: 'crew', 'life-support': 'crew', capsule: 'crew', seat: 'crew',
  avionics: 'computer', chip: 'computer', nav: 'radar', sensor: 'radar', lidar: 'radar', chute: 'parachute',
  structure: 'box', frame: 'box', heater: 'thermo', thermal: 'thermo', radiator: 'thermo', mobility: 'wheel',
  booster: 'rocket', srb: 'rocket', station: 'satellite', generic: 'box', thruster: 'engine', 'landing-leg': 'leg', legs: 'leg'
};
function drawIcon(parent, name, color) {
  const key = ICONS[name] ? name : (ICON_ALIAS[name] || 'box');
  const g = el('g', { fill: 'none', 'stroke-width': 1.8, 'stroke-linejoin': 'round', 'stroke-linecap': 'round' }, parent);
  ICONS[key](g, color);
  return g;
}

// ---------------------------------------------------------------- modül gövde çizimleri
// Her çizim (g, box) alır: box = { x, y, w, h } (y = üst kenar). Çizgiler hullLine, dolgu hull.
const S = (extra) => ({ fill: C.hull, stroke: C.hullLine, 'stroke-width': 1.6, 'stroke-linejoin': 'round', ...extra });

function bell(g, cx, y, w, h) { el('path', { d: `M${cx - w * 0.3} ${y}H${cx + w * 0.3}L${cx + w / 2} ${y + h}H${cx - w / 2}Z`, ...S({ fill: '#1d2f4d' }) }, g); }

function drawLauncherLunar(g, b) {
  const cx = b.x + b.w / 2; const coreW = 58;
  // yan güçlendiriciler (SRB esinli)
  for (const sx of [-1, 1]) {
    const bx = cx + sx * (coreW / 2 + 14);
    el('path', { d: `M${bx - 12} ${b.y + b.h - 22}V${b.y + 54}Q${bx} ${b.y + 26} ${bx + 12} ${b.y + 54}V${b.y + b.h - 22}Z`, ...S({ fill: '#e6edf6', stroke: '#9fb3cf' }) }, g);
    el('path', { d: `M${bx - 12} ${b.y + 80}H${bx + 12}M${bx - 12} ${b.y + b.h - 50}H${bx + 12}`, stroke: '#7a8aa3', 'stroke-width': 1.2 }, g);
    bell(g, bx, b.y + b.h - 22, 18, 18);
  }
  // çekirdek kademe (turuncu yalıtımlı tank esinli)
  el('rect', { x: cx - coreW / 2, y: b.y, width: coreW, height: b.h - 24, ...S({ fill: '#7a4120', stroke: '#e0915a' }) }, g);
  el('path', { d: `M${cx - coreW / 2} ${b.y + 40}H${cx + coreW / 2}M${cx - coreW / 2} ${b.y + b.h - 70}H${cx + coreW / 2}`, stroke: '#a85a2c', 'stroke-width': 1.2 }, g);
  for (const dx of [-16, 0, 16]) bell(g, cx + dx, b.y + b.h - 24, 14, 22);
}
function drawLauncherMars(g, b) {
  const cx = b.x + b.w / 2; const coreW = 52;
  // faydalı yük kaplaması yok; tek çekirdek + 4 küçük güçlendirici (Atlas V esinli)
  el('rect', { x: cx - coreW / 2, y: b.y, width: coreW, height: b.h - 24, ...S({ fill: '#e6edf6', stroke: '#9fb3cf' }) }, g);
  el('rect', { x: cx - coreW / 2, y: b.y, width: coreW, height: 34, ...S({ fill: '#1a2c4a' }) }, g);
  el('path', { d: `M${cx - coreW / 2} ${b.y + 120}H${cx + coreW / 2}`, stroke: '#7a8aa3', 'stroke-width': 1.2 }, g);
  for (const sx of [-1, 1]) {
    for (const k of [0, 1]) {
      const bx = cx + sx * (coreW / 2 + 7 + k * 15);
      el('path', { d: `M${bx - 6} ${b.y + b.h - 26}V${b.y + b.h - 120}L${bx} ${b.y + b.h - 136}L${bx + 6} ${b.y + b.h - 120}V${b.y + b.h - 26}Z`, ...S({ fill: '#cfd8e6', stroke: '#8fa2bd', 'stroke-width': 1.2 }) }, g);
    }
  }
  bell(g, cx - 10, b.y + b.h - 24, 16, 22); bell(g, cx + 10, b.y + b.h - 24, 16, 22);
}
function drawLander(g, b) {
  const cx = b.x + b.w / 2; const top = b.y + 10; const bot = b.y + b.h - 22;
  // iniş bacakları (katlı)
  el('path', { d: `M${cx - 40} ${bot - 10}L${cx - 58} ${b.y + b.h}M${cx + 40} ${bot - 10}L${cx + 58} ${b.y + b.h}M${cx - 66} ${b.y + b.h}H${cx - 50}M${cx + 50} ${b.y + b.h}H${cx + 66}`, stroke: C.hullLine, 'stroke-width': 2, fill: 'none' }, g);
  el('path', { d: `M${cx - 46} ${bot}L${cx - 40} ${top}H${cx + 40}L${cx + 46} ${bot}Z`, ...S({ fill: '#2b2f3a', stroke: '#c9b26a' }) }, g); // altın folyo kenar
  el('rect', { x: cx - 18, y: top - 10, width: 36, height: 12, ...S() }, g);
  bell(g, cx, bot, 22, 14);
}
function drawCargo(g, b) {
  const cx = b.x + b.w / 2;
  el('path', { d: `M${cx - b.w / 2} ${b.y + b.h}V${b.y + 8}L${cx - b.w / 2 + 8} ${b.y}H${cx + b.w / 2 - 8}L${cx + b.w / 2} ${b.y + 8}V${b.y + b.h}Z`, ...S({ fill: '#16304f' }) }, g);
  el('path', { d: `M${cx - b.w / 2} ${b.y + b.h / 2}H${cx + b.w / 2}`, stroke: C.seam, 'stroke-width': 1.2 }, g);
}
function drawCrew(g, b) {
  const cx = b.x + b.w / 2; const smTop = b.y + b.h - 54; const capTop = b.y + 44;
  // servis modülü + güneş kanatları
  el('rect', { x: cx - 38, y: smTop, width: 76, height: 50, ...S() }, g);
  for (const sx of [-1, 1]) {
    el('rect', { x: sx < 0 ? cx - 38 - 46 : cx + 38 + 4, y: smTop + 14, width: 42, height: 14, fill: '#14305a', stroke: C.cyan, 'stroke-width': 1.2, 'stroke-opacity': .7 }, g);
    el('path', { d: `M${cx + sx * 38} ${smTop + 21}H${cx + sx * 42}`, stroke: C.hullLine, 'stroke-width': 1.4 }, g);
  }
  // kapsül (koni) + kaçış kulesi
  el('path', { d: `M${cx - 36} ${smTop}L${cx - 14} ${capTop}H${cx + 14}L${cx + 36} ${smTop}Z`, ...S({ fill: '#c9d3e1', stroke: '#e6f1ff' }) }, g);
  el('rect', { x: cx - 8, y: capTop + 18, width: 16, height: 8, fill: C.dark, stroke: 'none' }, g);
  el('path', { d: `M${cx - 9} ${capTop}L${cx} ${b.y + 8}L${cx + 9} ${capTop}Z`, ...S({ fill: '#2a3a57' }) }, g);
  el('path', { d: `M${cx} ${b.y + 8}V${b.y}`, stroke: C.hullLine, 'stroke-width': 2 }, g);
}
function drawAeroshell(g, b) {
  const cx = b.x + b.w / 2;
  // arka kabuk (konik) + ısı kalkanı (alt yay)
  el('path', { d: `M${cx - b.w / 2} ${b.y + b.h - 22}L${cx - 30} ${b.y + 6}H${cx + 30}L${cx + b.w / 2} ${b.y + b.h - 22}Z`, ...S({ fill: '#d9e1ec', stroke: '#9fb3cf' }) }, g);
  el('path', { d: `M${cx - b.w / 2} ${b.y + b.h - 22}Q${cx} ${b.y + b.h + 8} ${cx + b.w / 2} ${b.y + b.h - 22}Z`, ...S({ fill: '#5a3420', stroke: '#c8853f' }) }, g);
}
function drawRover(g, b) {
  const cx = b.x + b.w / 2; const deck = b.y + 40;
  el('path', { d: `M${cx - 18} ${deck}V${b.y + 10}M${cx - 26} ${b.y + 10}H${cx - 10}`, stroke: C.hullLine, 'stroke-width': 2.2, fill: 'none' }, g); // direk + kamera
  el('rect', { x: cx - 26, y: b.y + 4, width: 16, height: 9, ...S() }, g);
  el('path', { d: `M${cx - 58} ${deck + 30}L${cx - 50} ${deck}H${cx + 50}L${cx + 58} ${deck + 30}Z`, ...S({ fill: '#cfd8e6', stroke: '#e6f1ff' }) }, g);
  el('path', { d: `M${cx + 44} ${deck}L${cx + 52} ${deck - 18}`, stroke: C.hullLine, 'stroke-width': 3 }, g); // güç ünitesi
  el('path', { d: `M${cx - 52} ${deck + 32}L${cx - 40} ${b.y + b.h - 14}M${cx} ${deck + 32}V${b.y + b.h - 14}M${cx + 52} ${deck + 32}L${cx + 40} ${b.y + b.h - 14}`, stroke: C.hullLine, 'stroke-width': 2 }, g);
  for (const dx of [-46, 0, 46]) el('circle', { cx: cx + dx, cy: b.y + b.h - 10, r: 10, fill: '#1d2a40', stroke: C.hullLine, 'stroke-width': 1.6 }, g);
}
function drawCruise(g, b) {
  const cx = b.x + b.w / 2;
  el('path', { d: `M${cx - b.w / 2} ${b.y + b.h - 10}L${cx - b.w / 2 + 12} ${b.y + 14}H${cx + b.w / 2 - 12}L${cx + b.w / 2} ${b.y + b.h - 10}Z`, fill: '#14305a', stroke: C.cyan, 'stroke-width': 1.4, 'stroke-opacity': .8 }, g);
  for (let i = 1; i < 8; i++) el('path', { d: `M${cx - b.w / 2 + i * b.w / 8} ${b.y + 16}V${b.y + b.h - 12}`, stroke: '#2a5a8a', 'stroke-width': 1 }, g);
  el('rect', { x: cx - 26, y: b.y + b.h - 12, width: 52, height: 12, ...S() }, g);
  el('path', { d: `M${cx} ${b.y + 14}V${b.y}`, stroke: C.hullLine, 'stroke-width': 2 }, g);
}

// ---------------------------------------------------------------- sahne
export function createVehicleScene(container) {
  const svg = el('svg', { viewBox: `0 0 ${W} ${H}`, preserveAspectRatio: 'xMidYMid meet', class: 'vehicle-scene', role: 'group', 'aria-label': t('cmd.scene.aria') });
  svg.style.width = '100%'; svg.style.height = '100%'; svg.style.display = 'block'; svg.style.overflow = 'visible';
  const defs = el('defs', null, svg);
  const glow = el('radialGradient', { id: `vs-heat-${Math.random().toString(36).slice(2, 8)}` }, defs);
  el('stop', { offset: '0%', 'stop-color': '#fff1c4', 'stop-opacity': .95 }, glow);
  el('stop', { offset: '45%', 'stop-color': '#ff8a3a', 'stop-opacity': .7 }, glow);
  el('stop', { offset: '100%', 'stop-color': '#ff4d2e', 'stop-opacity': 0 }, glow);

  const layers = {};
  for (const id of ['sky', 'world', 'stack', 'fx']) layers[id] = el('g', { class: `vs-${id}` }, svg);
  const stackMove = layers.stack; // tüm yığının hareketi bu grupta
  container.appendChild(svg);

  // Kap genişse viewBox yatayda genişler (etiketlere yer); araç ölçeği yükseklikle sabit kalır.
  // Dikeyde: ayrılmış (soluk) modüller düşünce görünüm etkin yığına yakınlaşır.
  let labelSize = 17;
  let narrow = false;
  let fitting = false;
  function fit() {
    if (fitting) return;
    const r = container.getBoundingClientRect();
    if (!r.width || !r.height) return;
    let top = 0;
    let bottom = H;
    const act = Object.keys(moduleNodes || {}).filter((id) => !spent.has(id));
    if (act.length) {
      top = Math.max(0, Math.min(...act.map((id) => moduleNodes[id].box.y)) - 110);
      // Uzaydayken (yer yok) alt kısım da kırpılır: ayrılmış kademeler görünümden çıkar
      if (world === 'space') bottom = Math.min(H, Math.max(...act.map((id) => moduleNodes[id].box.y + moduleNodes[id].box.h)) + 90);
    }
    let span = bottom - top;
    if (span < 400) { const pad = (400 - span) / 2; top = Math.max(0, top - pad); bottom = Math.min(H, top + 400); span = bottom - top; }
    const aspect = r.width / r.height;
    // Etiketler kırpılmasın: yığının (etiketler dahil) yatay genişliği kadar yer aç; dar kapta araç küçülür
    let need = 0;
    try { const bb = stackMove.getBBox(); if (bb.width) need = Math.max(CX - bb.x, bb.x + bb.width - CX) + 10; } catch (e) { need = 0; }
    const half = Math.max(W / 2, need, Math.min(span * aspect / 2, 380));
    svg.setAttribute('viewBox', `${(CX - half).toFixed(1)} ${top.toFixed(1)} ${(half * 2).toFixed(1)} ${span.toFixed(1)}`);
    const nextNarrow = r.width < 440; // dar kap (çalışma alanı sütunu, telefon)
    const next = nextNarrow ? 20 : 18;
    if (next !== labelSize || nextNarrow !== narrow) {
      labelSize = next; narrow = nextNarrow;
      fitting = true; try { draw(); } finally { fitting = false; }
      fit(); // yeni etiket genişliğine göre viewBox
    }
  }
  let ro = null;
  try { ro = new ResizeObserver(() => fit()); ro.observe(container); } catch (e) { ro = null; }

  // Arka plan: seyrek yıldızlar (deterministik)
  let s = 7;
  const rnd = () => { s = (s * 9301 + 49297) % 233280; return s / 233280; };
  for (let i = 0; i < 48; i++) el('circle', { cx: (rnd() * (W + 360) - 180).toFixed(1), cy: (rnd() * H * 0.85).toFixed(1), r: rnd() < 0.15 ? 1.4 : 0.8, fill: '#cfe6ff', opacity: (0.25 + rnd() * 0.45).toFixed(2) }, layers.sky);

  let current = { missionId: 'lunar', modules: [], items: [], highlightModule: null };
  let clickFn = null;
  let moduleNodes = {};   // id → { g, body, box }
  let spent = new Set();  // ayrılmış/bitmiş modüller (soluk kalır)
  let world = 'pad';      // pad | space | ground | sea
  let running = [];
  let disposed = false;
  let lastKey = '';

  function stackFor(missionId) {
    const base = STACKS[missionId] || STACKS.lunar;
    return base;
  }

  // Deniz dalgası: -200…W+200 arası
  function wave() { let d = `M-200 ${BASE_Y}`; for (let x = -200; x < W + 200; x += 40) d += `Q${x + 20} ${BASE_Y - 5} ${x + 40} ${BASE_Y}`; return d; }

  // ---- dünya katmanı (rampa / yer / deniz)
  function drawWorld() {
    clear(layers.world);
    if (world === 'pad') {
      el('rect', { x: -200, y: BASE_Y, width: W + 400, height: H - BASE_Y, fill: '#0b1a30' }, layers.world);
      el('path', { d: `M-200 ${BASE_Y}H${W + 200}`, stroke: C.dim, 'stroke-width': 1.5, 'stroke-opacity': .6 }, layers.world);
      // fırlatma kulesi
      const tx = 40;
      el('path', { d: `M${tx} ${BASE_Y}V${BASE_Y - 330}M${tx + 22} ${BASE_Y}V${BASE_Y - 330}`, stroke: '#3f5878', 'stroke-width': 2 }, layers.world);
      for (let y = BASE_Y; y > BASE_Y - 330; y -= 22) el('path', { d: `M${tx} ${y}L${tx + 22} ${y - 22}M${tx} ${y - 22}H${tx + 22}`, stroke: '#2b4262', 'stroke-width': 1.2 }, layers.world);
    } else if (world === 'ground') {
      const gnd = GROUND[current.missionId] || GROUND.lunar;
      el('path', { d: `M-200 ${BASE_Y + 4}Q${W * .3} ${BASE_Y - 6} ${W * .55} ${BASE_Y + 2}T${W + 200} ${BASE_Y}V${H}H-200Z`, fill: gnd.fill, stroke: gnd.line, 'stroke-width': 1.5 }, layers.world);
      for (const [x, r] of [[60, 10], [270, 7], [320, 4]]) el('ellipse', { cx: x, cy: BASE_Y + 22, rx: r * 2, ry: r * .6, fill: 'none', stroke: gnd.line, 'stroke-opacity': .5 }, layers.world);
    } else if (world === 'sea') {
      el('rect', { x: -200, y: BASE_Y, width: W + 400, height: H - BASE_Y, fill: '#0c3a63' }, layers.world);
      el('path', { d: wave(), stroke: '#5fb4ff', fill: 'none', 'stroke-width': 1.5 }, layers.world);
    }
  }

  // ---- yığın çizimi
  function draw() {
    clear(stackMove);
    moduleNodes = {};
    const defsList = stackFor(current.missionId);
    const named = {};
    for (const m of current.modules || []) if (m && m.id) named[m.id] = m;
    const byModule = {};
    for (const v of current.items || []) {
      if (!v || !v.moduleId) continue;
      (byModule[v.moduleId] || (byModule[v.moduleId] = [])).push(v);
    }
    // Bilinmeyen modül kimlikleri (veri değişirse) üste basit kutu olarak eklenir
    const list = defsList.slice();
    const known = new Set(list.map((m) => m.id));
    for (const id of Object.keys(named).concat(Object.keys(byModule))) {
      if (!known.has(id)) { known.add(id); list.push({ id, name: (named[id] && named[id].name) || id, role: (named[id] && named[id].role) || 'spacecraft', h: 60, w: 100, draw: drawCargo }); }
    }
    const total = list.reduce((a, m) => a + m.h, 0);
    const scale = total > BASE_Y - 20 ? (BASE_Y - 20) / total : 1;
    let y = BASE_Y;
    list.forEach((m, idx) => {
      const h = m.h * scale; const w = m.w * Math.min(1, scale + 0.15);
      y -= h;
      const box = { x: CX - w / 2, y, w, h };
      const info = named[m.id] || {};
      const modKey = `cmd.scene.mod.${m.id}`;
      const name = info.name || (t(modKey) !== modKey ? t(modKey) : m.name);
      const role = info.role || m.role;
      const items = byModule[m.id] || [];
      const empty = items.length === 0;
      const hl = current.highlightModule;
      const isSpent = spent.has(m.id);

      const g = el('g', { class: 'vs-module', 'data-module': m.id, tabindex: clickFn ? 0 : -1, role: clickFn ? 'button' : 'img', 'aria-label': `${name}: ${empty ? t('cmd.scene.empty') : t('cmd.scene.parts', { n: items.length })}` }, stackMove);
      g.style.transition = 'opacity .25s';
      g.style.opacity = isSpent ? '0.12' : (hl && hl !== m.id ? '0.55' : (empty ? '0.5' : '1'));
      if (clickFn) g.style.cursor = 'pointer';
      el('title', null, g).textContent = name;
      const body = el('g', null, g);
      m.draw(body, box);
      if (empty) {
        // boş modül: kesik dış çizgi
        el('rect', { x: box.x - 4, y: box.y - 2, width: box.w + 8, height: box.h + 4, fill: 'none', stroke: C.dim, 'stroke-width': 1.4, 'stroke-dasharray': '6 5' }, g);
      }
      if (hl === m.id) el('rect', { x: box.x - 6, y: box.y - 4, width: box.w + 12, height: box.h + 8, fill: 'none', stroke: roleColor(role), 'stroke-width': 2.2 }, g);

      // takılı parça simgeleri: modülün üstünde ızgara
      const ICON = 26; const GAP = 4;
      const perRow = Math.max(1, Math.floor((Math.min(box.w, 132)) / (ICON + GAP)));
      const rows = Math.ceil(items.length / perRow);
      const gridH = rows * (ICON + GAP) - GAP;
      const startY = box.y + Math.max(4, (box.h - gridH) / 2);
      items.forEach((it, i) => {
        const r = Math.floor(i / perRow); const c = i % perRow;
        const inRow = Math.min(perRow, items.length - r * perRow);
        const rowW = inRow * (ICON + GAP) - GAP;
        const ix = CX - rowW / 2 + c * (ICON + GAP); const iy = startY + r * (ICON + GAP);
        const col = roleColor(it.role || (it.item && it.item.role));
        const ig = el('g', { transform: `translate(${ix.toFixed(1)} ${iy.toFixed(1)})`, class: 'vs-item' }, g);
        el('rect', { x: 0, y: 0, width: ICON, height: ICON, fill: C.dark, 'fill-opacity': .88, stroke: col, 'stroke-width': it.mine ? 2 : 1.2 }, ig);
        const inner = el('g', { transform: 'translate(3 3) scale(0.833)' }, ig);
        drawIcon(inner, (it.item && it.item.icon) || 'box', col);
        el('title', null, ig).textContent = (it.item && it.item.name) || t('cmd.scene.part');
      });

      // modül etiketi (sağda, kısa çizgiyle)
      const side = idx % 2 === 0 ? 1 : -1;
      const lx = side > 0 ? Math.max(box.x + box.w + 8, CX + 70) : Math.min(box.x - 8, CX - 70);
      const ly = box.y + h / 2;
      el('path', { d: `M${side > 0 ? box.x + box.w : box.x} ${ly}H${lx}`, stroke: roleColor(role), 'stroke-opacity': .45, 'stroke-width': 1 }, g);
      const label = upperL(name);
      // Dar kapta ad kelime kelime alt alta (kısa satır), parça sayısı gizli
      const lines = narrow ? label.split(/\s+/).filter(Boolean) : [label];
      const t = el('text', { x: lx + side * 4, y: ly + 5 - (lines.length - 1) * labelSize * 0.5, 'text-anchor': side > 0 ? 'start' : 'end', fill: hl === m.id ? roleColor(role) : C.dim, 'font-size': labelSize, 'font-family': 'Rajdhani, sans-serif', 'font-weight': 700, 'letter-spacing': '.06em' }, g);
      lines.forEach((ln, li) => { const ts = el('tspan', { x: lx + side * 4, dy: li ? labelSize : 0 }, t); ts.textContent = ln; });
      if (items.length && !narrow) {
        const n = el('text', { x: lx + side * 4, y: ly + 5 + labelSize, 'text-anchor': side > 0 ? 'start' : 'end', fill: C.text, 'font-size': labelSize - 3, 'font-family': 'Rajdhani, sans-serif', 'font-weight': 500, opacity: .7 }, g);
        n.textContent = t('cmd.scene.parts', { n: items.length });
      }

      if (clickFn) {
        g.addEventListener('click', () => clickFn && clickFn(m.id));
        g.addEventListener('keydown', (e) => { if ((e.key === 'Enter' || e.key === ' ') && clickFn) { e.preventDefault(); clickFn(m.id); } });
      }
      moduleNodes[m.id] = { g, body, box, role };
    });
    fit();
  }

  // ---- animasyon yardımcıları (WAAPI; reduce-motion'da anında son poz)
  function anim(node, frames, opts) {
    if (!node || !node.animate) return Promise.resolve();
    try {
      const a = node.animate(frames, { duration: 600, easing: 'cubic-bezier(.2,.8,.2,1)', fill: 'none', ...opts });
      running.push(a);
      return a.finished.catch(() => {}).then(() => { running = running.filter((x) => x !== a); });
    } catch (e) { return Promise.resolve(); }
  }
  function lowestActive() {
    const ids = Object.keys(moduleNodes).filter((id) => !spent.has(id));
    let best = null;
    for (const id of ids) if (!best || moduleNodes[id].box.y > moduleNodes[best].box.y) best = id;
    return best ? moduleNodes[best] : null;
  }
  function topModule() {
    let best = null;
    for (const id of Object.keys(moduleNodes)) if (!best || moduleNodes[id].box.y < moduleNodes[best].box.y) best = id;
    return best ? moduleNodes[best] : null;
  }
  function activeBox() {
    const ids = Object.keys(moduleNodes).filter((id) => !spent.has(id));
    if (!ids.length) return { x: CX - 40, y: BASE_Y - 200, w: 80, h: 200 };
    const ys = ids.map((id) => moduleNodes[id].box);
    const top = Math.min(...ys.map((b) => b.y)); const bot = Math.max(...ys.map((b) => b.y + b.h));
    return { x: CX - 60, y: top, w: 120, h: bot - top };
  }
  function flame(x, y, w, len) {
    const f = el('g', { class: 'vs-flame' }, layers.fx);
    el('path', { d: `M${x - w / 2} ${y}Q${x} ${y + len * 1.2} ${x + w / 2} ${y}Z`, fill: C.flame, opacity: .85 }, f);
    el('path', { d: `M${x - w / 4} ${y}Q${x} ${y + len * .7} ${x + w / 4} ${y}Z`, fill: C.flameCore }, f);
    return f;
  }
  function statusFx(status) {
    if (status !== 'warn' && status !== 'fail') return Promise.resolve();
    const b = activeBox();
    const col = status === 'fail' ? C.red : C.amber;
    const ring = el('rect', { x: b.x - 10, y: b.y - 10, width: b.w + 20, height: b.h + 20, fill: 'none', stroke: col, 'stroke-width': 3 }, layers.fx);
    if (status === 'fail') {
      for (let i = 0; i < 6; i++) el('rect', { x: CX - 3 + (i - 3) * 9, y: b.y + b.h / 2 + (i % 2) * 8, width: 5, height: 5, fill: col, class: 'vs-debris' }, layers.fx);
    }
    if (reducedMotion()) return Promise.resolve();
    const p = [anim(ring, [{ opacity: 0 }, { opacity: 1 }, { opacity: .3 }, { opacity: 1 }], { duration: 700 })];
    if (status === 'fail') p.push(anim(stackMove, [{ transform: 'translateX(0)' }, { transform: 'translateX(-4px)' }, { transform: 'translateX(4px)' }, { transform: 'translateX(-3px)' }, { transform: 'translateX(0)' }], { duration: 320 }));
    return Promise.all(p);
  }
  function setWorld(w) { world = w; drawWorld(); }
  function markSpent(id) { if (moduleNodes[id] && !spent.has(id)) { spent.add(id); moduleNodes[id].g.style.opacity = '0.12'; fit(); } }

  // Aşama kimliği → animasyon türü (veri kimlikleri değişebilir; anahtar kelimeyle eşlenir)
  function kindOf(phaseId) {
    const p = String(phaseId || '').toLowerCase();
    if (/recover|splash|kurtar/.test(p)) return 'recovery';
    if (/chute|parasut|paraşüt/.test(p)) return 'chute';
    if (/entry|edl|giris|giriş|reentry|aero/.test(p)) return 'entry';
    if (/land|descent|touch|inis|iniş/.test(p)) return 'landing';
    if (/return|tei|rendezvous|home|donus|dönüş|lunar-ascent|ascent-moon|liftoff-moon/.test(p)) return 'return';
    if (/^ascent/.test(p) && current.missionId === 'lunar') return 'return'; // Ay yüzeyinden kalkış
    if (/launch|liftoff|kalkis|kalkış|^ascent/.test(p)) return 'launch';
    if (/data|downlink|relay|comm|uplink|iletim|transmit/.test(p)) return 'transmit';
    if (/surface|eva|rover|drive|science|sample|explore|bilim|yuzey|yüzey|gezgin/.test(p)) return 'surface';
    if (/tli|loi|tcm|depart|approach|transit|cruise|orbit|separ|trans|coast|seyir|yorunge|yörünge|moon|lunar|mars/.test(p)) return 'separation';
    return 'generic';
  }

  // Animasyonsuz son poz: dünya/ayrılma durumu (rejoin ya da reduce-motion için)
  function settle(kind) {
    const lv = 'launch-vehicle';
    if (kind === 'launch') setWorld('space');
    if (['separation', 'entry', 'chute', 'transmit'].includes(kind)) { markSpent(lv); setWorld('space'); }
    if (kind === 'entry' && current.missionId === 'mars') markSpent('cruise-stage');
    if (kind === 'chute' && current.missionId === 'mars') markSpent('cruise-stage');
    if (kind === 'landing' || kind === 'surface') {
      markSpent(lv);
      if (current.missionId === 'mars') { markSpent('cruise-stage'); markSpent('edl'); }
      setWorld('ground');
    }
    if (kind === 'return') { for (const id of Object.keys(moduleNodes)) if (id !== 'crew-vehicle') markSpent(id); setWorld('space'); }
    if (kind === 'recovery') { for (const id of Object.keys(moduleNodes)) if (id !== 'crew-vehicle') markSpent(id); setWorld('sea'); }
    if (kind === 'transmit' && current.missionId === 'mars') { markSpent('cruise-stage'); markSpent('edl'); setWorld('ground'); }
  }

  async function runKind(kind) {
    const lv = moduleNodes['launch-vehicle'];
    if (kind === 'launch') {
      const b = lv ? lv.box : activeBox();
      const f = flame(CX, b.y + b.h, 54, 70);
      await Promise.all([
        anim(f, [{ opacity: 0, transform: 'scaleY(.3)' }, { opacity: 1, transform: 'scaleY(1)' }], { duration: 400, fill: 'forwards' }),
        anim(stackMove, [{ transform: 'translateY(0)' }, { transform: 'translateY(-2px)' }, { transform: 'translateY(1px)' }, { transform: 'translateY(-90px)' }], { duration: 1700, easing: 'cubic-bezier(.5,0,.8,.6)' }),
        anim(f, [{ transform: 'translateY(0)' }, { transform: 'translateY(0)' }, { transform: 'translateY(-90px)' }], { duration: 1700, delay: 0, easing: 'cubic-bezier(.5,0,.8,.6)' }),
        anim(layers.world, [{ transform: 'translateY(0)', opacity: 1 }, { transform: 'translateY(140px)', opacity: 0 }], { duration: 1800, easing: 'ease-in' })
      ]);
      f.remove();
      return;
    }
    if (kind === 'separation') {
      const node = lv && !spent.has('launch-vehicle') ? lv.g : null;
      if (node) await anim(node, [{ transform: 'translateY(0)', opacity: 1 }, { transform: 'translateY(60px)', opacity: 0.12 }], { duration: 1200, easing: 'ease-in' });
      else await anim(stackMove, [{ transform: 'translateY(0)' }, { transform: 'translateY(-10px)' }, { transform: 'translateY(0)' }], { duration: 1200 });
      return;
    }
    if (kind === 'entry') {
      const low = lowestActive(); const b = low ? low.box : activeBox();
      const gid = glow.getAttribute('id');
      const heat = el('ellipse', { cx: CX, cy: b.y + b.h, rx: Math.max(60, b.w * .7), ry: 34, fill: `url(#${gid})` }, layers.fx);
      await Promise.all([
        anim(heat, [{ opacity: 0 }, { opacity: 1 }, { opacity: .8 }, { opacity: 0 }], { duration: 2100 }),
        anim(stackMove, [{ transform: 'translate(0,0)' }, { transform: 'translate(-2px,1px)' }, { transform: 'translate(2px,-1px)' }, { transform: 'translate(-1px,1px)' }, { transform: 'translate(0,0)' }], { duration: 400, iterations: 4 })
      ]);
      heat.remove();
      return;
    }
    if (kind === 'chute' || kind === 'recovery') {
      const top = topModule(); const y = top ? top.box.y : 200;
      const chute = el('g', null, layers.fx);
      el('path', { d: `M${CX - 70} ${y - 90}A70 46 0 0 1 ${CX + 70} ${y - 90}Z`, fill: '#e6f1ff', 'fill-opacity': .18, stroke: C.text, 'stroke-width': 1.6 }, chute);
      el('path', { d: `M${CX - 70} ${y - 90}L${CX} ${y}M${CX + 70} ${y - 90}L${CX} ${y}M${CX - 24} ${y - 90}L${CX} ${y}M${CX + 24} ${y - 90}L${CX} ${y}`, stroke: C.dim, 'stroke-width': 1 }, chute);
      chute.style.transformBox = 'fill-box'; chute.style.transformOrigin = '50% 100%';
      await anim(chute, [{ transform: 'scale(.1)', opacity: 0 }, { transform: 'scale(1)', opacity: 1 }], { duration: 700 });
      await anim(stackMove, [{ transform: 'translateY(0)' }, { transform: 'translateY(16px)' }], { duration: 1100, easing: 'ease-out' });
      await anim(chute, [{ opacity: 1 }, { opacity: 0 }], { duration: 300 });
      chute.remove();
      return;
    }
    if (kind === 'landing') {
      const low = lowestActive(); const b = low ? low.box : activeBox();
      const f = flame(CX, b.y + b.h, 26, 30);
      await Promise.all([
        anim(stackMove, [{ transform: 'translateY(-70px)' }, { transform: 'translateY(0)' }], { duration: 1900, easing: 'cubic-bezier(.2,.8,.2,1)' }),
        anim(f, [{ transform: 'translateY(-70px)', opacity: 1 }, { transform: 'translateY(0)', opacity: .2 }], { duration: 1900, easing: 'cubic-bezier(.2,.8,.2,1)' }),
        anim(layers.world, [{ transform: 'translateY(80px)', opacity: 0 }, { transform: 'translateY(0)', opacity: 1 }], { duration: 1500 })
      ]);
      f.remove();
      return;
    }
    if (kind === 'surface') {
      const gnd = GROUND[current.missionId] || GROUND.lunar;
      const dot = el('g', null, layers.fx);
      if (current.missionId === 'mars') drawIcon(el('g', { transform: `translate(30 ${BASE_Y - 24})` }, dot), 'rover', C.green);
      else drawIcon(el('g', { transform: `translate(30 ${BASE_Y - 24})` }, dot), 'crew', C.green);
      const ping = el('circle', { cx: 60, cy: BASE_Y - 12, r: 30, fill: 'none', stroke: gnd.line, 'stroke-width': 1.5 }, layers.fx);
      await Promise.all([
        anim(dot, [{ transform: 'translateX(0)' }, { transform: 'translateX(90px)' }], { duration: 2000, easing: 'ease-in-out' }),
        anim(ping, [{ opacity: 0 }, { opacity: .8 }, { opacity: 0 }], { duration: 1000, iterations: 2 })
      ]);
      dot.remove(); ping.remove();
      return;
    }
    if (kind === 'transmit') {
      const top = topModule(); const y = top ? top.box.y : 200;
      const arcs = [];
      for (let i = 0; i < 3; i++) {
        const a = el('path', { d: `M${CX - 20 - i * 16} ${y - 10 - i * 12}Q${CX} ${y - 30 - i * 20} ${CX + 20 + i * 16} ${y - 10 - i * 12}`, stroke: C.cyan, 'stroke-width': 2, fill: 'none', opacity: 0 }, layers.fx);
        arcs.push(anim(a, [{ opacity: 0 }, { opacity: 1 }, { opacity: 0 }], { duration: 900, delay: i * 220, iterations: 2 }).then(() => a.remove()));
      }
      await Promise.all(arcs);
      return;
    }
    if (kind === 'return') {
      const cv = moduleNodes['crew-vehicle'];
      const f = cv ? flame(CX, cv.box.y + cv.box.h, 20, 30) : null;
      await Promise.all([
        anim(stackMove, [{ transform: 'translateY(0)' }, { transform: 'translateY(-60px)' }], { duration: 1600, easing: 'ease-in' }),
        f ? anim(f, [{ transform: 'translateY(0)' }, { transform: 'translateY(-60px)' }], { duration: 1600, easing: 'ease-in' }) : null
      ]);
      if (f) f.remove();
      return;
    }
    // generic: kısa nabız
    await anim(stackMove, [{ opacity: 1 }, { opacity: .7 }, { opacity: 1 }], { duration: 700 });
  }

  function cancelAll() {
    for (const a of running) { try { a.cancel(); } catch (e) { /* yok say */ } }
    running = [];
    clear(layers.fx);
  }

  const api = {
    setVehicle(v) {
      if (disposed || !v) return;
      // Aynı veriyle yeniden çizme (süren animasyonları bozmasın)
      const key = JSON.stringify([v.missionId, v.modules, (v.items || []).map((i) => i && [i.uid, i.moduleId, i.role, i.mine, i.item && i.item.icon]), v.highlightModule || null, getLang()]);
      if (key === lastKey) return;
      lastKey = key;
      const mission = v.missionId || current.missionId;
      if (mission !== current.missionId) { spent = new Set(); world = 'pad'; }
      current = { missionId: mission, modules: Array.isArray(v.modules) ? v.modules : [], items: Array.isArray(v.items) ? v.items : [], highlightModule: v.highlightModule || null };
      svg.setAttribute('data-mission', mission);
      drawWorld();
      draw();
    },
    onModuleClick(fn) { clickFn = typeof fn === 'function' ? fn : null; draw(); },
    playPhase(phaseId, status, opts) {
      if (disposed) return Promise.resolve();
      const kind = kindOf(phaseId);
      const instant = (opts && opts.instant) || reducedMotion();
      const work = (async () => {
        try {
          cancelAll();
          if (!instant) await runKind(kind);
          settle(kind);
          if (!instant || status === 'fail' || status === 'warn') {
            clear(layers.fx);
            await statusFx(status);
            if (!instant) await sleep(150);
          }
        } catch (e) { /* sahne hatası oyunu durdurmasın */ }
      })();
      // her zaman resolve: en geç MAX_ANIM_MS + pay
      return Promise.race([work, sleep(MAX_ANIM_MS + 1200)]).then(() => undefined);
    },
    reset() {
      if (disposed) return;
      cancelAll();
      spent = new Set();
      setWorld('pad');
      draw();
    },
    dispose() {
      disposed = true;
      cancelAll();
      clickFn = null;
      if (ro) { try { ro.disconnect(); } catch (e) { /* yok say */ } }
      if (svg.parentNode) svg.parentNode.removeChild(svg);
    }
  };
  drawWorld();
  draw();
  fit();
  return api;
}

export const supported = true;
export default createVehicleScene;
