'use strict';
// Modül AA: oda/host/akış testleri (sahte sim + sahte chat + sahte saat)
const test = require('node:test');
const assert = require('node:assert/strict');
const { createRoomManager } = require('../server/rooms');

// --- Sahteler -------------------------------------------------------------------
function fakeSim(opts = {}) {
  const items = {
    'r-engine': { id: 'r-engine', name: 'Motor', category: 'main-engine', role: 'rocket', module: 'lv', massKg: 1111, cost: 77 },
    's-panel': { id: 's-panel', name: 'Panel', category: 'power', role: 'spacecraft', module: 'cv', massKg: 2222, cost: 55 },
    'p-cam': { id: 'p-cam', name: 'Kamera', category: 'camera', role: 'payload', module: 'kit', massKg: 3333, cost: 33 },
    'r-bad': { id: 'r-bad', name: 'Uyumsuz', category: 'rcs', role: 'rocket', module: 'lv', massKg: 1, cost: 1 },
  };
  const state = { overall: 'PASS', criticalFail: false, simulateCalls: 0, debriefArgs: null, phases: 3 };
  const sim = {
    state,
    listMissions: () => [{ id: 'lunar', name: 'Ay', summary: 's' }, { id: 'mars', name: 'Mars', summary: 's' }],
    getMission: (id) => (['lunar', 'mars'].includes(id) ? { id, name: id, summary: 's', settings: [], modules: [], briefing: {} } : undefined),
    getItem: (id) => items[id],
    publicItem: (id) => { const it = items[id]; return { id, name: it.name, category: it.category, role: it.role, module: it.module, icon: '', desc: '' }; },
    catalogFor: (m, role) => Object.values(items).filter((i) => i.role === role),
    canAdd(build, missionId, role, itemId, moduleId) {
      const it = items[itemId];
      if (!it) return { ok: false, error: 'INVALID_ITEM', reason: 'Yok' };
      if (it.role !== role) return { ok: false, error: 'NOT_ALLOWED', reason: 'Başka rolün parçası' };
      if (itemId === 'r-bad') return { ok: false, error: 'INCOMPATIBLE', reason: 'Bilimsel gerekçe X' };
      if (moduleId !== it.module) return { ok: false, error: 'WRONG_MODULE', reason: 'Yanlış modül' };
      return { ok: true };
    },
    defaultSettings: () => ({ propellantLoad: 1 }),
    validateSetting: (m, role, key, value) => (key === 'propellantLoad' && role === 'rocket' && typeof value === 'number' && value >= 0.6 && value <= 1
      ? { ok: true, value } : { ok: false, error: 'BAD_SETTING' }),
    evaluate: (m, build, settings) => ({
      telemetry: { massKg: { total: build.length }, cost: 1, budget: 2 },
      readiness: state.criticalFail ? [{ id: 'x', system: 'Güç', role: 'spacecraft', status: 'FAIL', critical: true, text: 't' }] : [],
      overall: state.overall,
      needs: { rocket: [], spacecraft: [], payload: [] },
      unmetRequirements: [],
      _settings: settings,
    }),
    simulate: (m, build, settings, seed) => {
      state.simulateCalls++;
      return { phases: Array.from({ length: state.phases }, (_, i) => ({ id: `p${i}`, name: `P${i}`, status: 'ok', events: [] })), outcome: 'success', seed };
    },
    debrief: (m, ev, res, team) => { state.debriefArgs = { ev, res, team }; return { score: 90, stars: 3, outcome: res.outcome, sections: [] }; },
  };
  return Object.assign(sim, opts);
}

function setup(cfg = {}) {
  let t = 1000;
  const clock = { now: () => t, advance: (ms) => { t += ms; } };
  const sim = fakeSim();
  const mgr = createRoomManager({ sim, chat: {}, now: clock.now, rng: () => 0.5, config: { phaseMs: 100, reconnectGraceMs: 1000, emptyRoomMs: 5000, ...cfg } });
  return { mgr, sim, clock };
}

// 4 oyuncu, roller seçilmiş, hazır; lobide
function lobby4(mgr) {
  const { room, player: host } = mgr.createRoom('Ayşe', 's1');
  const b = mgr.joinRoom(room.code, 'Bora', 's2').player;
  const c = mgr.joinRoom(room.code, 'Cem', 's3').player;
  const d = mgr.joinRoom(room.code, 'Deniz', 's4').player;
  const ids = { director: host.id, rocket: b.id, spacecraft: c.id, payload: d.id };
  for (const [role, id] of Object.entries(ids)) {
    mgr.selectRole(room.code, id, role);
    mgr.setReady(room.code, id, true);
  }
  return { code: room.code, room, ids };
}

// Tasarım fazına kadar ilerlet
function toDesign(mgr) {
  const g = lobby4(mgr);
  mgr.startGame(g.code, g.ids.director);
  mgr.selectMission(g.code, g.ids.director, 'lunar');
  mgr.skipBriefing(g.code, g.ids.director);
  return g;
}

function err(code) {
  return (e) => e && e.code === code;
}

// --- Testler --------------------------------------------------------------------

test('tam akış: lobi → debrief → tekrar oyna (new / same)', () => {
  const { mgr, sim, clock } = setup();
  const g = lobby4(mgr);
  const { code, ids, room } = g;
  mgr.startGame(code, ids.director);
  assert.equal(room.phase, 'mission-select');
  mgr.selectMission(code, ids.director, 'lunar');
  assert.equal(room.phase, 'briefing');
  assert.ok(room.evaluation, 'görev seçilince değerlendirme önbellekte');
  for (const r of ['director', 'rocket', 'spacecraft']) mgr.ackBriefing(code, ids[r]);
  assert.equal(room.phase, 'briefing');
  mgr.ackBriefing(code, ids.payload);
  assert.equal(room.phase, 'design');

  const { uid } = mgr.addItem(code, ids.rocket, 'r-engine', 'lv');
  mgr.addItem(code, ids.spacecraft, 's-panel', 'cv');
  mgr.addItem(code, ids.payload, 'p-cam', 'kit');
  assert.equal(room.build.length, 3);
  assert.equal(room.evaluation.telemetry.massKg.total, 3, 'değerlendirme her değişimde yeniden hesaplanır');
  mgr.setSetting(code, ids.rocket, 'propellantLoad', 0.8);
  assert.equal(room.settings.propellantLoad, 0.8);
  assert.equal(room.evaluation._settings.propellantLoad, 0.8);
  mgr.removeItem(code, ids.rocket, uid);
  mgr.addItem(code, ids.rocket, 'r-engine', 'lv');

  clock.advance(5000);
  mgr.openReview(code, ids.director);
  assert.equal(room.phase, 'review');
  for (const r of ['rocket', 'spacecraft', 'payload']) mgr.signoff(code, ids[r], 'ok');
  mgr.launch(code, ids.director);
  assert.equal(room.phase, 'simulation');
  assert.equal(sim.state.simulateCalls, 1);
  assert.equal(room.sim.shownPhases, 0);

  clock.advance(100); assert.equal(mgr.tick(code), true); assert.equal(room.sim.shownPhases, 1);
  clock.advance(50); assert.equal(mgr.tick(code), false);
  clock.advance(50); mgr.tick(code); assert.equal(room.sim.shownPhases, 2);
  clock.advance(100); mgr.tick(code); assert.equal(room.sim.shownPhases, 3);
  assert.equal(room.phase, 'simulation');
  clock.advance(100); mgr.tick(code);
  assert.equal(room.phase, 'debrief');
  assert.equal(sim.state.simulateCalls, 1, 'simulate yalnız launch anında bir kez');
  assert.equal(room.debrief.score, 90);
  const team = sim.state.debriefArgs.team;
  assert.equal(team.designSec, 5);
  assert.equal(team.reviewRounds, 0);
  assert.deepEqual(team.chat, { rocket: 0, spacecraft: 0, payload: 0 });
  assert.equal(team.signoffs, 3);

  // aynı görev: tasarım korunur
  mgr.playAgain(code, ids.director, 'same');
  assert.equal(room.phase, 'design');
  assert.equal(room.missionId, 'lunar');
  assert.equal(room.build.length, 3);
  assert.equal(room.sim, null);
  assert.equal(room.debrief, null);

  // tekrar debrief'e git, sonra yeni görev
  mgr.openReview(code, ids.director);
  for (const r of ['rocket', 'spacecraft', 'payload']) mgr.signoff(code, ids[r], 'ok');
  mgr.launch(code, ids.director);
  clock.advance(1000); mgr.tick(code);
  assert.equal(room.phase, 'debrief');
  assert.throws(() => mgr.playAgain(code, ids.rocket, 'new'), err('NOT_ALLOWED'));
  assert.throws(() => mgr.playAgain(code, ids.director, 'x'), err('BAD_REQUEST'));
  mgr.playAgain(code, ids.director, 'new');
  assert.equal(room.phase, 'mission-select');
  assert.equal(room.missionId, null);
  assert.equal(room.build.length, 0);
});

test('host da tekrar oynatabilir; debrief GERİ → mission-select', () => {
  const { mgr, clock } = setup();
  const g = toDesign(mgr);
  // host'u roket mühendisine devret
  mgr.transferHost(g.code, g.ids.director, 2);
  assert.equal(g.room.hostId, g.ids.rocket);
  mgr.openReview(g.code, g.ids.director);
  for (const r of ['rocket', 'spacecraft', 'payload']) mgr.signoff(g.code, g.ids[r], 'ok');
  mgr.launch(g.code, g.ids.director);
  clock.advance(10000); mgr.tick(g.code);
  assert.equal(g.room.phase, 'debrief');
  assert.throws(() => mgr.goBack(g.code, g.ids.payload), err('NOT_ALLOWED'));
  mgr.goBack(g.code, g.ids.rocket);
  assert.equal(g.room.phase, 'mission-select');
});

test('geri geçişleri: briefing → mission-select, review → design (reviewRounds++, imzalar sıfır)', () => {
  const { mgr } = setup();
  const g = lobby4(mgr);
  mgr.startGame(g.code, g.ids.director);
  assert.throws(() => mgr.goBack(g.code, g.ids.director), err('WRONG_PHASE'));
  mgr.selectMission(g.code, g.ids.director, 'mars');
  assert.throws(() => mgr.goBack(g.code, g.ids.rocket), err('NOT_ALLOWED'));
  mgr.goBack(g.code, g.ids.director);
  assert.equal(g.room.phase, 'mission-select');
  assert.equal(g.room.missionId, null);
  mgr.selectMission(g.code, g.ids.director, 'lunar');
  mgr.skipBriefing(g.code, g.ids.director);
  assert.throws(() => mgr.goBack(g.code, g.ids.director), err('WRONG_PHASE'));
  mgr.openReview(g.code, g.ids.director);
  mgr.signoff(g.code, g.ids.rocket, 'ok');
  mgr.goBack(g.code, g.ids.director);
  assert.equal(g.room.phase, 'design');
  assert.equal(g.room.reviewRounds, 1);
  assert.deepEqual(g.room.signoff, { rocket: null, spacecraft: null, payload: null });
  // review:back ve DÜZELT
  mgr.openReview(g.code, g.ids.director);
  mgr.backToDesign(g.code, g.ids.director);
  assert.equal(g.room.reviewRounds, 2);
  mgr.openReview(g.code, g.ids.director);
  mgr.signoff(g.code, g.ids.spacecraft, 'ok');
  mgr.signoff(g.code, g.ids.payload, 'fix');
  assert.equal(g.room.phase, 'design');
  assert.equal(g.room.reviewRounds, 3);
  assert.deepEqual(g.room.signoff, { rocket: null, spacecraft: null, payload: null });
});

test('hazır şartı ve host yetkisi', () => {
  const { mgr } = setup();
  const { room, player: host } = mgr.createRoom('Ayşe', 's1');
  const b = mgr.joinRoom(room.code, 'Bora', 's2').player;
  assert.throws(() => mgr.startGame(room.code, b.id), err('NOT_HOST'));
  assert.throws(() => mgr.startGame(room.code, host.id), err('NOT_READY'));
  assert.throws(() => mgr.setReady(room.code, b.id, true), err('NO_ROLE'));
  const c = mgr.joinRoom(room.code, 'Cem', 's3').player;
  const d = mgr.joinRoom(room.code, 'Deniz', 's4').player;
  assert.throws(() => mgr.joinRoom(room.code, 'Ek', 's5'), err('ROOM_FULL'));
  const roles = [[host, 'director'], [b, 'rocket'], [c, 'spacecraft'], [d, 'payload']];
  for (const [p, r] of roles) mgr.selectRole(room.code, p.id, r);
  assert.throws(() => mgr.selectRole(room.code, b.id, 'director'), err('ROLE_TAKEN'));
  for (const [p] of roles.slice(0, 3)) mgr.setReady(room.code, p.id, true);
  assert.throws(() => mgr.startGame(room.code, host.id), err('NOT_READY'));
  mgr.setReady(room.code, d.id, true);
  // rol değişince hazır düşer
  mgr.selectRole(room.code, d.id, null);
  assert.equal(room.players.get(d.id).ready, false);
  mgr.selectRole(room.code, d.id, 'payload');
  mgr.setReady(room.code, d.id, true);
  // kopuk oyuncu varken başlatılamaz
  mgr.setConnected(room.code, d.id, false);
  assert.throws(() => mgr.startGame(room.code, host.id), err('NOT_READY'));
  mgr.rejoin(room.code, d.id, 's4b');
  mgr.startGame(room.code, host.id);
  assert.equal(room.phase, 'mission-select');
  assert.throws(() => mgr.selectRole(room.code, d.id, 'rocket'), err('WRONG_PHASE'));
});

test('host çıkarma / devretme / host ayrılınca devir', () => {
  const { mgr } = setup();
  const g = lobby4(mgr);
  const seatOf = (id) => g.room.players.get(id).seat;
  assert.throws(() => mgr.kick(g.code, g.ids.rocket, seatOf(g.ids.payload)), err('NOT_HOST'));
  assert.throws(() => mgr.kick(g.code, g.ids.director, seatOf(g.ids.director)), err('INVALID_TARGET'));
  assert.throws(() => mgr.kick(g.code, g.ids.director, 99), err('INVALID_TARGET'));
  const { kicked } = mgr.kick(g.code, g.ids.director, seatOf(g.ids.payload));
  assert.equal(kicked.id, g.ids.payload);
  assert.equal(g.room.players.has(g.ids.payload), false);
  // yeni gelen boşalan koltuğu alır
  const e = mgr.joinRoom(g.code, 'Ece', 's9').player;
  assert.equal(e.seat, 4);

  assert.throws(() => mgr.transferHost(g.code, g.ids.rocket, 1), err('NOT_HOST'));
  mgr.transferHost(g.code, g.ids.director, seatOf(g.ids.spacecraft));
  assert.equal(g.room.hostId, g.ids.spacecraft);

  // host koparsa bağlı ilk oyuncuya geçer
  mgr.setConnected(g.code, g.ids.spacecraft, false);
  assert.equal(g.room.hostId, g.ids.director);
  // host ayrılırsa geçer
  mgr.leave(g.code, g.ids.director);
  assert.equal(g.room.hostId, g.ids.rocket);
});

test('yetkisiz eylemler: yanlış rol / yanlış faz', () => {
  const { mgr } = setup();
  const g = lobby4(mgr);
  const { code, ids } = g;
  assert.throws(() => mgr.selectMission(code, ids.director, 'lunar'), err('WRONG_PHASE'));
  mgr.startGame(code, ids.director);
  assert.throws(() => mgr.selectMission(code, ids.rocket, 'lunar'), err('NOT_ALLOWED'));
  assert.throws(() => mgr.selectMission(code, ids.director, 'asteroid'), err('INVALID_MISSION'));
  assert.throws(() => mgr.addItem(code, ids.rocket, 'r-engine', 'lv'), err('WRONG_PHASE'));
  mgr.selectMission(code, ids.director, 'lunar');
  assert.throws(() => mgr.skipBriefing(code, ids.payload), err('NOT_ALLOWED'));
  mgr.skipBriefing(code, ids.director);
  assert.throws(() => mgr.addItem(code, ids.director, 'r-engine', 'lv'), err('NOT_ALLOWED'));
  assert.throws(() => mgr.addItem(code, ids.spacecraft, 'r-engine', 'lv'), (e) => e.code === 'NOT_ALLOWED' && e.message === 'Başka rolün parçası');
  assert.throws(() => mgr.addItem(code, ids.rocket, 'r-bad', 'lv'), (e) => e.code === 'INCOMPATIBLE' && e.message === 'Bilimsel gerekçe X');
  assert.throws(() => mgr.addItem(code, ids.rocket, 'r-engine', 'xx'), err('WRONG_MODULE'));
  assert.throws(() => mgr.addItem(code, ids.rocket, 42, 'lv'), err('BAD_REQUEST'));
  const { uid } = mgr.addItem(code, ids.rocket, 'r-engine', 'lv');
  assert.throws(() => mgr.removeItem(code, ids.payload, uid), err('NOT_ALLOWED'));
  assert.throws(() => mgr.removeItem(code, ids.rocket, 'yok'), err('ITEM_NOT_FOUND'));
  assert.throws(() => mgr.setSetting(code, ids.rocket, 'propellantLoad', 5), err('BAD_SETTING'));
  assert.throws(() => mgr.setSetting(code, ids.payload, 'propellantLoad', 0.8), err('BAD_SETTING'));
  assert.throws(() => mgr.signoff(code, ids.rocket, 'ok'), err('WRONG_PHASE'));
  assert.throws(() => mgr.openReview(code, ids.rocket), err('NOT_ALLOWED'));
  assert.throws(() => mgr.launch(code, ids.director), err('WRONG_PHASE'));
  mgr.openReview(code, ids.director);
  // review'da ekipman/ayar değişmez
  assert.throws(() => mgr.addItem(code, ids.payload, 'p-cam', 'kit'), err('WRONG_PHASE'));
  assert.throws(() => mgr.removeItem(code, ids.rocket, uid), err('WRONG_PHASE'));
  assert.throws(() => mgr.setSetting(code, ids.rocket, 'propellantLoad', 0.8), err('WRONG_PHASE'));
  assert.throws(() => mgr.signoff(code, ids.director, 'ok'), err('NOT_ALLOWED'));
  assert.throws(() => mgr.signoff(code, ids.rocket, 'maybe'), err('BAD_REQUEST'));
  assert.throws(() => mgr.ackBriefing(code, ids.rocket), err('WRONG_PHASE'));
  assert.throws(() => mgr.addItem('ZZZZ', ids.rocket, 'r-engine', 'lv'), err('ROOM_NOT_FOUND'));
  assert.throws(() => mgr.openReview(code, 'yabanci'), err('NOT_IN_ROOM'));
});

// Aşama 8: tek engel 3 onay; READY değilse confirm:true istenir (LAUNCH_CONFIRM)
test('launch: eksik onay engeller; FAIL/kritik FAIL yalnız onay ister (LAUNCH_CONFIRM)', () => {
  const { mgr, sim } = setup();
  const g = toDesign(mgr);
  const { code, ids } = g;
  mgr.setLang(code, ids.director, 'tr'); // Türkçe mesaj beklenir
  const review3 = () => {
    mgr.openReview(code, ids.director);
    for (const r of ['rocket', 'spacecraft', 'payload']) mgr.signoff(code, ids[r], 'ok');
  };
  mgr.openReview(code, ids.director);
  mgr.signoff(code, ids.rocket, 'ok');
  mgr.signoff(code, ids.spacecraft, 'ok');
  // onay eksikse confirm:true bile işe yaramaz
  assert.throws(() => mgr.launch(code, ids.director, { confirm: true }), (e) => e.code === 'LAUNCH_BLOCKED' && /Bilim & Faydalı Yük/.test(e.message));
  mgr.signoff(code, ids.payload, 'ok');
  assert.throws(() => mgr.launch(code, ids.rocket, { confirm: true }), err('NOT_ALLOWED'));

  // overall FAIL (launchStatus yok → türetilir) → onay ister
  mgr.backToDesign(code, ids.director);
  sim.state.overall = 'FAIL';
  mgr.addItem(code, ids.payload, 'p-cam', 'kit'); // değerlendirme yenilensin
  review3();
  assert.throws(() => mgr.launch(code, ids.director), (e) => e.code === 'LAUNCH_CONFIRM' && /hazır değil/.test(e.message) && /onayla/.test(e.message));
  assert.throws(() => mgr.launch(code, ids.director, { confirm: 'true' }), err('LAUNCH_CONFIRM'), 'yalnız boolean true');

  // kritik FAIL kalemi: mesajda sistem adı geçer
  mgr.backToDesign(code, ids.director);
  sim.state.overall = 'WARN';
  sim.state.criticalFail = true;
  mgr.setSetting(code, ids.rocket, 'propellantLoad', 0.9);
  review3();
  assert.throws(() => mgr.launch(code, ids.director), (e) => e.code === 'LAUNCH_CONFIRM' && /Güç/.test(e.message));
  assert.equal(sim.state.simulateCalls, 0);
  // onaylı fırlatma: kritik FAIL'e rağmen simülasyon başlar
  mgr.launch(code, ids.director, { confirm: true });
  assert.equal(g.room.phase, 'simulation');
  assert.equal(sim.state.simulateCalls, 1);
});

test('launch: sim.launchStatus önceliklidir (READY → onaysız, MISSING → onay)', () => {
  const { mgr, sim } = setup();
  let status = 'MISSING';
  const baseEval = sim.evaluate;
  sim.evaluate = (...a) => ({ ...baseEval(...a), launchStatus: status, readiness: [{ id: 'p', system: 'Paraşüt', role: 'spacecraft', status: 'FAIL', critical: true, kind: 'missing', text: 'x' }] });
  const g = toDesign(mgr);
  const { code, ids } = g;
  mgr.setLang(code, ids.director, 'tr');
  mgr.openReview(code, ids.director);
  for (const r of ['rocket', 'spacecraft', 'payload']) mgr.signoff(code, ids[r], 'ok');
  assert.throws(() => mgr.launch(code, ids.director), (e) => e.code === 'LAUNCH_CONFIRM' && /Eksik/.test(e.message) && /Paraşüt/.test(e.message));
  // READY: overall WARN olsa bile onaysız fırlatılır
  mgr.backToDesign(code, ids.director);
  status = 'READY';
  sim.state.overall = 'WARN';
  mgr.setSetting(code, ids.rocket, 'propellantLoad', 0.9);
  mgr.openReview(code, ids.director);
  for (const r of ['rocket', 'spacecraft', 'payload']) mgr.signoff(code, ids[r], 'ok');
  mgr.launch(code, ids.director);
  assert.equal(g.room.phase, 'simulation');
});

// --- Aşama 8: standart donanım ve harcama defteri ----------------------------------

function setupAuto() {
  const s = setup();
  s.sim.autoItems = (m) => (m === 'lunar' ? [{ itemId: 'r-struct', moduleId: 'lv', role: 'rocket' }, { itemId: 's-nav', moduleId: 'cv', role: 'spacecraft' }] : []);
  const base = s.sim.getItem;
  const extra = {
    'r-struct': { id: 'r-struct', name: 'Gövde', category: 'structure', role: 'rocket', module: 'lv', cost: 10 },
    's-nav': { id: 's-nav', name: 'Navigasyon', category: 'nav', role: 'spacecraft', module: 'cv', cost: 20 },
  };
  s.sim.getItem = (id) => extra[id] || base(id);
  return s;
}

test('standart donanım: görev seçilince eklenir, çıkarılamaz (LOCKED), same korur, new sıfırlar', () => {
  const { mgr, clock } = setupAuto();
  const g = toDesign(mgr);
  const { code, ids, room } = g;
  mgr.setLang(code, ids.rocket, 'tr');
  const autos = room.build.filter((b) => b.auto);
  assert.equal(autos.length, 2);
  assert.deepEqual(autos.map((b) => [b.itemId, b.moduleId, b.role, b.cost]), [['r-struct', 'lv', 'rocket', 10], ['s-nav', 'cv', 'spacecraft', 20]]);
  assert.equal(room.evaluation.telemetry.massKg.total, 2, 'değerlendirme standart donanımı içerir');
  assert.deepEqual(room.ledger.map((l) => [l.action, l.itemId, l.cost, l.playerName]), [['auto', 'r-struct', 10, 'Standard hardware'], ['auto', 's-nav', 20, 'Standard hardware']]);
  assert.throws(() => mgr.removeItem(code, ids.rocket, autos[0].uid), (e) => e.code === 'LOCKED' && e.message === 'Standart donanım çıkarılamaz.');
  assert.throws(() => mgr.removeItem(code, ids.payload, autos[1].uid), err('LOCKED'));
  // review → design dönüşü kopya eklemez
  mgr.openReview(code, ids.director);
  mgr.backToDesign(code, ids.director);
  assert.equal(room.build.filter((b) => b.auto).length, 2);
  // debrief → same: build ve defter korunur, kopya yok
  mgr.addItem(code, ids.rocket, 'r-engine', 'lv');
  mgr.openReview(code, ids.director);
  for (const r of ['rocket', 'spacecraft', 'payload']) mgr.signoff(code, ids[r], 'ok');
  mgr.launch(code, ids.director);
  clock.advance(10000); mgr.tick(code);
  assert.equal(room.phase, 'debrief');
  mgr.playAgain(code, ids.director, 'same');
  assert.equal(room.build.length, 3);
  assert.equal(room.ledger.length, 3);
  // 'new' → sıfır; yeni görev seçilince standart donanım tekrar
  mgr.openReview(code, ids.director);
  for (const r of ['rocket', 'spacecraft', 'payload']) mgr.signoff(code, ids[r], 'ok');
  mgr.launch(code, ids.director);
  clock.advance(10000); mgr.tick(code);
  mgr.playAgain(code, ids.director, 'new');
  assert.deepEqual(room.build, []);
  assert.deepEqual(room.ledger, []);
  mgr.selectMission(code, ids.director, 'mars');
  assert.equal(room.build.length, 0, 'autoItems [] dönerse eklenmez');
  // defter numarası yeni görevde baştan başlar
  mgr.skipBriefing(code, ids.director);
  mgr.addItem(code, ids.rocket, 'r-engine', 'lv');
  assert.equal(room.ledger[0].id, 1);
});

test('harcama defteri: ekle +cost, çıkar −cost (takma anındaki tutar), kim/ne, 300 sınırı', () => {
  const { mgr, sim } = setup();
  const g = toDesign(mgr);
  const { code, ids, room } = g;
  assert.deepEqual(room.ledger, [], 'autoItems yoksa (eski sim) defter boş');
  const { uid } = mgr.addItem(code, ids.rocket, 'r-engine', 'lv');
  const entry = room.build.find((b) => b.uid === uid);
  assert.equal(entry.cost, 77);
  assert.equal(entry.auto, undefined);
  // katalog maliyeti sonradan değişse bile iade takma anındaki tutar
  const orig = sim.getItem;
  sim.getItem = (id) => (id === 'r-engine' ? { ...orig(id), cost: 999 } : orig(id));
  mgr.removeItem(code, ids.rocket, uid);
  sim.getItem = orig;
  const [add, rem] = room.ledger;
  assert.deepEqual({ ...add, ts: 0 }, { id: 1, ts: 0, role: 'rocket', playerName: 'Bora', action: 'add', itemId: 'r-engine', itemName: 'Motor', moduleId: 'lv', cost: 77 });
  assert.equal(rem.action, 'remove');
  assert.equal(rem.cost, -77);
  assert.equal(rem.id, 2);
  for (let i = 0; i < 200; i++) {
    const r = mgr.addItem(code, ids.payload, 'p-cam', 'kit');
    mgr.removeItem(code, ids.payload, r.uid);
  }
  assert.equal(room.ledger.length, 300);
  assert.equal(room.ledger[room.ledger.length - 1].id, 402, 'en yeniler tutulur');
});

test('NO_SPACE: canAdd hatası ve gerekçesi aynen geçer; gerekçe yoksa Türkçe varsayılan', () => {
  const { mgr, sim } = setup();
  const g = toDesign(mgr);
  mgr.setLang(g.code, g.ids.rocket, 'tr');
  sim.canAdd = () => ({ ok: false, error: 'NO_SPACE', reason: 'Modülde yer yok: kullanılan 34/40 U, parça 8 U' });
  assert.throws(() => mgr.addItem(g.code, g.ids.rocket, 'r-engine', 'lv'), (e) => e.code === 'NO_SPACE' && /34\/40 U/.test(e.message));
  sim.canAdd = () => ({ ok: false, error: 'NO_SPACE' });
  assert.throws(() => mgr.addItem(g.code, g.ids.rocket, 'r-engine', 'lv'), (e) => e.code === 'NO_SPACE' && e.message === 'Modülde yer yok.');
  assert.equal(g.room.build.length, 0);
  assert.equal(g.room.ledger.length, 0);
});

test('yeniden bağlanma: rol korunur, süre aşımında rol boşalır; lobi dışı katılım', () => {
  const { mgr, clock } = setup();
  const g = toDesign(mgr);
  const { code, ids, room } = g;
  mgr.setConnected(code, ids.rocket, false, 's2');
  assert.equal(room.players.get(ids.rocket).connected, false);
  assert.equal(room.players.get(ids.rocket).role, 'rocket');
  // başka socket'in disconnect'i güncel bağlantıyı etkilemez
  mgr.rejoin(code, ids.rocket, 's2b');
  mgr.setConnected(code, ids.rocket, false, 's2');
  assert.equal(room.players.get(ids.rocket).connected, true);
  mgr.setConnected(code, ids.rocket, false, 's2b');
  // rol doluyken (süre içinde) yeni katılımcı alamaz
  assert.throws(() => mgr.joinRoom(code, 'Yeni', 's7'), err('ROOM_FULL'));
  clock.advance(999); mgr.tick(code);
  assert.ok(room.players.has(ids.rocket));
  mgr.rejoin(code, ids.rocket, 's2c');
  assert.equal(room.players.get(ids.rocket).connected, true);
  // tekrar kop, süre aşımı
  mgr.setConnected(code, ids.rocket, false);
  clock.advance(1000);
  assert.equal(mgr.tick(code), true);
  assert.equal(room.players.has(ids.rocket), false);
  assert.throws(() => mgr.rejoin(code, ids.rocket, 's2d'), err('NOT_IN_ROOM'));
  // lobi dışı katılım boş rolü alır
  const { player } = mgr.joinRoom(code, 'Yeni', 's7');
  assert.equal(player.role, 'rocket');
  assert.equal(room.phase, 'design');
});

test('boş oda emptyRoomMs sonra silinir; son oyuncu ayrılınca hemen silinir', () => {
  const { mgr, clock } = setup({ reconnectGraceMs: 60000 });
  const g = lobby4(mgr);
  for (const id of Object.values(g.ids)) mgr.setConnected(g.code, id, false);
  mgr.tick(g.code);
  clock.advance(4999); mgr.tick(g.code);
  assert.ok(mgr.getRoom(g.code));
  clock.advance(1); assert.equal(mgr.tick(g.code), true);
  assert.equal(mgr.getRoom(g.code), undefined);

  const { room, player } = mgr.createRoom('Tek', 'x');
  mgr.leave(room.code, player.id);
  assert.equal(mgr.getRoom(room.code), undefined);
});

test('brifing: rolü olmayan/ayrılan oyuncu akışı kilitlemez', () => {
  const { mgr } = setup();
  const g = lobby4(mgr);
  mgr.startGame(g.code, g.ids.director);
  mgr.selectMission(g.code, g.ids.director, 'lunar');
  for (const r of ['director', 'rocket', 'spacecraft']) mgr.ackBriefing(g.code, g.ids[r]);
  mgr.leave(g.code, g.ids.payload);
  assert.equal(g.room.phase, 'design');
});

test('isim ve kod doğrulama', () => {
  const { mgr } = setup();
  assert.throws(() => mgr.createRoom(''), err('NAME_REQUIRED'));
  assert.throws(() => mgr.createRoom('x'.repeat(40)), err('NAME_REQUIRED'));
  assert.throws(() => mgr.joinRoom(123, 'a'), err('BAD_REQUEST'));
  const { room } = mgr.createRoom('A');
  assert.match(room.code, /^[A-HJ-NP-Z]{4}$/);
  assert.ok(mgr.joinRoom(room.code.toLowerCase(), 'B'));
});

// --- Aşama 9: oyuncu dili ---------------------------------------------------------

test('dil: varsayılan en; create/join lang; setLang sonrası hata mesajı dili; geçersiz dil BAD_REQUEST', () => {
  const { mgr } = setup();
  const { room, player: a } = mgr.createRoom('Ayşe', 's1');
  assert.equal(a.lang, 'en');
  const b = mgr.joinRoom(room.code, 'Bora', 's2', 'tr').player;
  assert.equal(b.lang, 'tr');
  assert.throws(() => mgr.startGame(room.code, b.id), (e) => e.code === 'NOT_HOST' && e.message === 'Bunu yalnız host yapabilir.');
  assert.throws(() => mgr.selectRole(room.code, a.id, 'zzz'), (e) => e.code === 'INVALID_ROLE' && e.message === 'Invalid role.');
  mgr.setLang(room.code, a.id, 'tr');
  assert.throws(() => mgr.selectRole(room.code, a.id, 'zzz'), (e) => e.message === 'Geçersiz rol.');
  assert.throws(() => mgr.setLang(room.code, a.id, 'de'), err('BAD_REQUEST'));
  assert.equal(room.players.get(a.id).lang, 'tr');
  // create/join hatası verilen dilde
  assert.throws(() => mgr.createRoom('', 'x', 'tr'), (e) => /İsim/.test(e.message));
  assert.throws(() => mgr.createRoom('', 'x'), (e) => /Name must be/.test(e.message));
  assert.throws(() => mgr.joinRoom('QQQQ', 'X', 's', 'tr'), (e) => e.message === 'Oda bulunamadı.');
  // rejoin lang günceller
  mgr.setConnected(room.code, b.id, false);
  mgr.rejoin(room.code, b.id, 's2b', 'en');
  assert.equal(room.players.get(b.id).lang, 'en');
});

test('dil: LAUNCH_BLOCKED rol adları oyuncunun dilinde', () => {
  const { mgr } = setup();
  const g = toDesign(mgr);
  mgr.openReview(g.code, g.ids.director);
  assert.throws(() => mgr.launch(g.code, g.ids.director), (e) => e.code === 'LAUNCH_BLOCKED' && /Propulsion Engineer/.test(e.message));
  mgr.setLang(g.code, g.ids.director, 'tr');
  assert.throws(() => mgr.launch(g.code, g.ids.director), (e) => /İtki Mühendisi/.test(e.message));
});
