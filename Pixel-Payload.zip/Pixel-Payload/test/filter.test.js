'use strict';
// Modül AA: görünüm filtresi (gizlilik) testleri — sahte sim + sahte chat
const test = require('node:test');
const assert = require('node:assert/strict');
const { createRoomManager } = require('../server/rooms');
const { viewFor } = require('../server/filter');

// Ayırt edici "gizli" sayılar: her biri yalnız tek role ait
const SECRET = {
  rocketMass: 11111, rocketThrust: 12121, spacecraftMass: 22222, payloadMass: 33333, payloadData: 34343,
  cost: 77777, budget: 99999, needValue: 43210, cascadeValue: 88888, scLimit: 56565,
  useFactor: 0.8765, scienceFactor: 1.4321, phaseDv: 54321,
  // Aşama 8
  remaining: 21212, roleCostR: 71717, roleCostS: 72727, roleCostP: 73737, goalValue: 45454, otherU: 61616,
};

function fakeSim(extra = {}) {
  const items = {
    'r-eng': { id: 'r-eng', name: 'Motor', category: 'main-engine', role: 'rocket', module: 'lv', massKg: SECRET.rocketMass, thrustN: SECRET.rocketThrust, cost: SECRET.cost, volumeU: 8, refs: { massKg: { src: 'nasa-x', class: 'measured' }, cost: { src: 'g', class: 'game', note: 'gizli maliyet' } } },
    's-pan': { id: 's-pan', name: 'Panel', category: 'power', role: 'spacecraft', module: 'cv', massKg: SECRET.spacecraftMass, cost: SECRET.cost, volumeU: 5 },
    'p-cam': { id: 'p-cam', name: 'Kamera', category: 'camera', role: 'payload', module: 'kit', massKg: SECRET.payloadMass, dataGenMbPerSol: SECRET.payloadData, cost: SECRET.cost },
  };
  const mission = {
    id: 'lunar', name: 'Ay', summary: 'özet', educationalNote: 'eğitsel', budget: SECRET.budget, crew: 4, durationDays: 9,
    modules: [
      { id: 'lv', name: 'Fırlatma', role: 'rocket', categories: [{ category: 'main-engine', min: 1, max: 2 }] },
      { id: 'cv', name: 'Mürettebat aracı', role: 'spacecraft', categories: [{ category: 'power', min: 1, max: 3 }] },
      { id: 'kit', name: 'Yüzey', role: 'payload', categories: [{ category: 'camera', min: 2, max: 3 }] },
    ],
    phases: [{ id: 'launch', name: 'Kalkış', dvMs: SECRET.phaseDv, checks: ['readiness'] }, { id: 'orbit', name: 'Yörünge', dvMs: 0, carries: ['lv'] }],
    objectives: [{ id: 'gizli-hedef', name: 'GIZLI_HEDEF_METNI', type: 'primary', critical: true }],
    briefing: { director: ['OPERATOR_BRIFING'], rocket: ['ROKET_BRIFING'], spacecraft: ['UZAYARACI_BRIFING'], payload: ['BILIM_BRIFING'] },
    settings: [
      { key: 'propellantLoad', role: 'rocket', label: 'Yakıt', type: 'number', min: 0.6, max: 1, step: 0.05, default: 1, help: 'YAKIT_YARDIM' },
      { key: 'powerMode', role: 'spacecraft', label: 'Güç', type: 'enum', options: ['eco', 'normal', 'max'], default: 'normal',
        optionInfo: { eco: { label: 'Tasarruf', useFactor: SECRET.useFactor, note: 'ISITICI_KISILIR' }, normal: { label: 'Normal', useFactor: 1 }, max: { label: 'Tam güç', useFactor: 1.2, desc: 'TAM_GUC_ACIKLAMA' } } },
      { key: 'instrumentMode', role: 'payload', label: 'Alet', type: 'enum', options: ['survey', 'intensive'], default: 'survey',
        optionInfo: { survey: { label: 'Keşif', dutyFactor: 0.7, scienceFactor: SECRET.scienceFactor, dataFactor: 0.7 }, intensive: { label: 'Yoğun', dutyFactor: 1.5 } } },
    ],
    limits: { maxLaunchMassKg: 123456 },
    nasaReality: 'NASA_GERCEK',
  };
  const sim = {
    listMissions: () => [{ id: 'lunar', name: 'Ay', summary: 'özet', educationalNote: 'eğitsel' }, { id: 'mars', name: 'Mars', summary: 'm', educationalNote: 'e' }],
    getMission: (id) => (id === 'lunar' ? mission : id === 'mars' ? { ...mission, id: 'mars', name: 'Mars' } : undefined),
    getItem: (id) => items[id],
    publicItem: (id) => { const it = items[id]; return { id, name: it.name, category: it.category, role: it.role, module: it.module, icon: 'i', desc: 'd', massKg: 1 }; },
    catalogFor: (m, role) => Object.values(items).filter((i) => i.role === role),
    canAdd: (build, m, role, itemId) => (items[itemId] && items[itemId].role === role ? { ok: true } : { ok: false, error: 'NOT_ALLOWED', reason: 'r' }),
    defaultSettings: () => ({ propellantLoad: 1, powerMode: 'normal' }),
    validateSetting: (m, role, key, value) => ({ ok: true, value }),
    evaluate: () => ({
      telemetry: {
        massKg: { total: 66666, byModule: { lv: SECRET.rocketMass }, byRole: { rocket: SECRET.rocketMass, spacecraft: SECRET.spacecraftMass, payload: SECRET.payloadMass } },
        cost: SECRET.cost, budget: SECRET.budget, twr: 1.5, stages: [{ id: 's1', dvMs: 3000 }], dv: { launch: { available: 9500, required: 9400 } },
        power: { genW: 500, useW: 400, batteryWh: 1000, marginW: 100 }, thermal: { status: 'ok', note: '' },
        comms: { relayBps: 1, directBps: 2, delayS: 1.3, dataMbPerSol: SECRET.payloadData, downlinkMbPerSol: 5 },
        lifeSupport: { crew: 4, days: 9, o2Days: 12, waterDays: 11, co2Days: 10 }, edl: null,
        science: { value: 40, max: 100, instruments: 1 },
        capacity: {
          lv: { name: 'Fırlatma', usedU: 8, capacityU: 50, freeU: 42, byRole: { rocket: 8, spacecraft: 0, payload: 0 } },
          lander: { name: 'İniş aracı', usedU: 30, capacityU: 40, freeU: 10, byRole: { rocket: 0, spacecraft: 17, payload: 13, director: SECRET.otherU } },
          kit: { name: 'Kit', usedU: 2, capacityU: null, freeU: null, byRole: { payload: 2 } },
        },
        scienceGoals: [
          { id: 'g1', name: 'Su buzu', desc: 'Kutup', value: SECRET.goalValue, status: 'partial', missingTags: ['drill'], secret: 'GIZLI_ALAN' },
          { id: 'g2', name: 'Sismik', desc: 'Ağ', value: 10, status: 'ready', missingTags: [] },
        ],
        budget: { budget: SECRET.budget, spent: SECRET.cost, remaining: SECRET.remaining, byRole: { rocket: SECRET.roleCostR, spacecraft: SECRET.roleCostS, payload: SECRET.roleCostP } },
      },
      launchStatus: 'INSUFFICIENT',
      readiness: [
        { id: 'twr', system: 'İtki', role: 'rocket', status: 'PASS', critical: true, kind: 'ok', text: 'TWR yeterli', value: 1.5, limit: 1.2 },
        { id: 'power', system: 'Güç', role: 'spacecraft', status: 'FAIL', critical: true, kind: 'physical', text: 'Güç açığı', value: -100, limit: SECRET.scLimit },
        { id: 'comms-cascade', system: 'İletişim', role: 'payload', status: 'WARN', critical: false, kind: 'risky', text: 'Güç açığı nedeniyle iletişim kısıtlı', value: SECRET.cascadeValue, cascadeFrom: ['spacecraft'] },
        // kötü niyetli sahte: bütçe kalemi bir mühendis rolüne atanmış olsa bile mühendise gitmemeli
        { id: 'budget', system: 'Bütçe', role: 'rocket', status: 'FAIL', critical: false, kind: 'budget', text: `Bütçe aşıldı ${SECRET.cost}`, value: SECRET.cost, limit: SECRET.budget },
      ],
      overall: 'FAIL',
      needs: { rocket: [{ id: 'payload-mass', label: 'Faydalı yük kütlesi', value: SECRET.needValue, unit: 'kg', fromRole: 'payload' }], spacecraft: [], payload: [] },
      unmetRequirements: [],
    }),
    simulate: () => ({ phases: [{ id: 'launch', name: 'Kalkış', status: 'ok', events: [{ id: 'e', severity: 'info', text: 'ok', roles: [] }] }, { id: 'orbit', name: 'Yörünge', status: 'ok', events: [] }], outcome: 'success', reason: 'SIM_SONUC' }),
    debrief: () => ({ budget: { budget: SECRET.budget, spent: SECRET.cost, overrun: 0, overrunPct: 0 }, scienceGoals: [{ id: 'g1', name: 'Su buzu', done: false, reason: 'Matkap yok' }], score: 1234, stars: 2, outcome: 'success', sections: [{ id: 'budget', title: 'Bütçe', score: 1, max: 2, lines: [`Bütçe ${SECRET.budget}`] }], lessons: [], nasaReality: 'N', sources: [] }),
  };
  sim.items = items;
  return Object.assign(sim, extra);
}

// Sahte sohbet: PLAN arayüzü (viewFor) — mühendise yanlışlıkla fazladan thread verse bile filtre atmalı
function fakeChat({ leaky = false } = {}) {
  return {
    viewFor(room, pid) {
      const p = room.players.get(pid);
      if (!p || !p.role) return null;
      const t = room.chat.threads;
      if (p.role === 'director') return { threads: { ...t } };
      return leaky ? { threads: { mine: t[p.role], broadcast: t.broadcast, rocket: t.rocket, spacecraft: t.spacecraft, payload: t.payload } }
        : { threads: { mine: t[p.role], broadcast: t.broadcast } };
    },
  };
}

function game({ leaky, simExtra } = {}) {
  let t = 0;
  const sim = fakeSim(simExtra);
  const chat = fakeChat({ leaky });
  const mgr = createRoomManager({ sim, chat, now: () => t, rng: () => 0.3, config: { phaseMs: 10 } });
  const { room, player: host } = mgr.createRoom('Ayşe', 's1');
  const others = ['Bora', 'Cem', 'Deniz'].map((n, i) => mgr.joinRoom(room.code, n, `s${i + 2}`).player);
  const ids = { director: host.id, rocket: others[0].id, spacecraft: others[1].id, payload: others[2].id };
  for (const [role, id] of Object.entries(ids)) { mgr.selectRole(room.code, id, role); mgr.setReady(room.code, id, true); }
  // her mühendis thread'ine ayırt edici mesaj
  room.chat.threads.rocket.push({ id: 'm1', ts: 1, thread: 'rocket', from: 'rocket', fromName: 'Bora', text: 'ROKET_OZEL_MESAJ' });
  room.chat.threads.spacecraft.push({ id: 'm2', ts: 2, thread: 'spacecraft', from: 'spacecraft', fromName: 'Cem', text: 'UZAYARACI_OZEL_MESAJ' });
  room.chat.threads.payload.push({ id: 'm3', ts: 3, thread: 'payload', from: 'payload', fromName: 'Deniz', text: 'BILIM_OZEL_MESAJ' });
  room.chat.threads.broadcast.push({ id: 'm4', ts: 4, thread: 'broadcast', from: 'director', fromName: 'Ayşe', text: 'YAYIN' });
  return { mgr, sim, chat, room, code: room.code, ids, advance: (ms) => { t += ms; } };
}

function toDesign(g) {
  g.mgr.startGame(g.code, g.ids.director);
  g.mgr.selectMission(g.code, g.ids.director, 'lunar');
  g.mgr.skipBriefing(g.code, g.ids.director);
  g.mgr.addItem(g.code, g.ids.rocket, 'r-eng', 'lv');
  g.mgr.addItem(g.code, g.ids.spacecraft, 's-pan', 'cv');
  g.mgr.addItem(g.code, g.ids.payload, 'p-cam', 'kit');
}

const json = (v) => JSON.stringify(v);
const has = (s, needle) => s.includes(String(needle));

// JSON'da bir anahtar adı geçiyor mu ("key":)
const hasKey = (s, k) => s.includes(`"${k}":`);

test('ortak alanlar: seat kullanılır, başka oyuncunun playerId’si gitmez', () => {
  const g = game();
  for (const [role, id] of Object.entries(g.ids)) {
    const v = viewFor(g.room, id, g.sim, g.chat);
    const s = json(v);
    assert.equal(v.phase, 'lobby');
    assert.equal(v.code, g.code);
    assert.equal(v.me.role, role);
    assert.equal(v.me.isHost, role === 'director');
    assert.equal(v.players.length, 4);
    assert.deepEqual(Object.keys(v.players[0]).sort(), ['connected', 'isHost', 'name', 'ready', 'role', 'seat']);
    assert.equal(v.missionOptions.length, 2);
    for (const other of Object.values(g.ids)) assert.equal(has(s, other), false, 'hiçbir playerId görünümde olmamalı');
  }
  assert.equal(viewFor(g.room, 'yabanci', g.sim, g.chat), null);
});

test('GİZLİLİK: mühendis görünümünde yasak anahtar/değer yok', () => {
  const g = game();
  toDesign(g);
  const cases = {
    rocket: { mine: [SECRET.rocketMass, SECRET.rocketThrust, 'ROKET_BRIFING', 'ROKET_OZEL_MESAJ'], others: [SECRET.spacecraftMass, SECRET.payloadMass, SECRET.payloadData, 'UZAYARACI_BRIFING', 'BILIM_BRIFING', 'UZAYARACI_OZEL_MESAJ', 'BILIM_OZEL_MESAJ', SECRET.scLimit] },
    spacecraft: { mine: [SECRET.spacecraftMass, 'UZAYARACI_BRIFING', 'UZAYARACI_OZEL_MESAJ', SECRET.scLimit], others: [SECRET.rocketMass, SECRET.rocketThrust, SECRET.payloadMass, SECRET.payloadData, 'ROKET_BRIFING', 'BILIM_BRIFING', 'ROKET_OZEL_MESAJ', 'BILIM_OZEL_MESAJ'] },
    payload: { mine: [SECRET.payloadMass, SECRET.payloadData, 'BILIM_BRIFING', 'BILIM_OZEL_MESAJ'], others: [SECRET.rocketMass, SECRET.rocketThrust, SECRET.spacecraftMass, 'ROKET_BRIFING', 'UZAYARACI_BRIFING', 'ROKET_OZEL_MESAJ', 'UZAYARACI_OZEL_MESAJ', SECRET.cascadeValue, SECRET.scLimit] },
  };
  const forbiddenEverywhere = [SECRET.cost, SECRET.budget, SECRET.needValue, 'GIZLI_HEDEF_METNI', 'OPERATOR_BRIFING', 'gizli maliyet', 'NASA_GERCEK', 123456, 66666,
    SECRET.remaining, SECRET.roleCostR, SECRET.roleCostS, SECRET.roleCostP, SECRET.goalValue, SECRET.otherU, 'GIZLI_ALAN', 'Bütçe aşıldı'];
  for (const [role, c] of Object.entries(cases)) {
    const v = viewFor(g.room, g.ids[role], g.sim, g.chat);
    assert.equal(v.director, null);
    assert.ok(v.engineer);
    const s = json(v);
    for (const x of c.mine) assert.ok(has(s, x), `${role} kendi verisini görmeli: ${x}`);
    for (const x of [...c.others, ...forbiddenEverywhere]) assert.equal(has(s, x), false, `${role} görmemeli: ${x}`);
    // dataMbPerSol yalnız bilim mühendisinin kendi verisi
    const keys = ['cost', 'budget', 'objectives', 'limits', 'byRole', 'byModule', 'unmetRequirements', 'nasaReality',
      'ledger', 'spent', 'remaining', 'playerName', 'costs', 'overrun'];
    if (role !== 'payload') keys.push('dataMbPerSol');
    for (const k of keys) {
      assert.equal(hasKey(s, k), false, `${role} görünümünde '${k}' anahtarı olmamalı`);
    }
    // needs: yalnız id/label/fromRole
    for (const n of v.engineer.needs) assert.deepEqual(Object.keys(n).sort(), ['fromRole', 'id', 'label']);
    // hazırlık yalnız kendi rolü
    for (const r of v.engineer.readiness) assert.equal(r.role, role);
    // diğer rollerin parçaları sayısız publicItem
    for (const veh of v.vehicle) {
      assert.deepEqual(Object.keys(veh.item).sort(), ['category', 'desc', 'icon', 'id', 'module', 'name', 'role']);
      assert.equal(veh.mine, veh.role === role);
    }
    // sohbet: yalnız mine + broadcast
    assert.deepEqual(Object.keys(v.chat.threads).sort(), ['broadcast', 'mine']);
    // ayarlar: yalnız kendi rolünün
    for (const d of v.engineer.settingDefs) assert.equal(d.role, role);
  }
  const rv = viewFor(g.room, g.ids.rocket, g.sim, g.chat);
  assert.equal(rv.engineer.needs[0].label, 'Faydalı yük kütlesi');
  assert.deepEqual(Object.keys(rv.engineer.settings), ['propellantLoad']);
  assert.equal(rv.engineer.catalog[0].canAdd.ok, true);
  // zincirli kalem: sayısız metin, cascadeFrom var
  const pv = viewFor(g.room, g.ids.payload, g.sim, g.chat);
  const cas = pv.engineer.readiness.find((r) => r.id === 'comms-cascade');
  assert.deepEqual(cas.cascadeFrom, ['spacecraft']);
  assert.equal('value' in cas, false);
});

test('GİZLİLİK: sızdıran sohbet modülünde bile başka mühendis thread’i gitmez', () => {
  const g = game({ leaky: true });
  const s = json(viewFor(g.room, g.ids.rocket, g.sim, g.chat));
  assert.equal(has(s, 'UZAYARACI_OZEL_MESAJ'), false);
  assert.equal(has(s, 'BILIM_OZEL_MESAJ'), false);
  assert.ok(has(s, 'YAYIN'));
});

test('operatör: tam görev, telemetri, hazırlık, değerli needs, ilerleme, katalog, tüm sohbetler', () => {
  const g = game();
  g.mgr.startGame(g.code, g.ids.director);
  const sel = viewFor(g.room, g.ids.director, g.sim, g.chat);
  assert.equal(sel.director.missionDetails.length, 2, 'görev seçiminde ayrıntılar operatörde');
  assert.equal(sel.director.missionDetails[0].objectives[0].name, 'GIZLI_HEDEF_METNI');
  const eng = viewFor(g.room, g.ids.rocket, g.sim, g.chat);
  assert.equal(has(json(eng), 'GIZLI_HEDEF_METNI'), false);

  g.mgr.selectMission(g.code, g.ids.director, 'lunar');
  g.mgr.skipBriefing(g.code, g.ids.director);
  g.mgr.addItem(g.code, g.ids.payload, 'p-cam', 'kit');
  const v = viewFor(g.room, g.ids.director, g.sim, g.chat);
  assert.equal(v.engineer, null);
  assert.equal(v.director.mission.budget, SECRET.budget);
  assert.deepEqual(v.director.mission.briefing, ['OPERATOR_BRIFING']);
  assert.equal(has(json(v), 'ROKET_BRIFING'), false, 'operatör diğer brifingleri görmez');
  assert.equal(v.director.telemetry.cost, SECRET.cost);
  assert.equal(v.director.readiness.length, 4);
  assert.equal(v.director.needs.rocket[0].value, SECRET.needValue);
  assert.equal(v.director.progress.payload.items, 1);
  assert.deepEqual(v.director.progress.payload.missingCategories, [{ moduleId: 'kit', category: 'camera', min: 2, have: 1 }]);
  assert.equal(v.director.progress.rocket.missingCategories.length, 1);
  assert.equal(v.director.catalog.rocket[0].massKg, SECRET.rocketMass);
  assert.deepEqual(Object.keys(v.chat.threads).sort(), ['broadcast', 'payload', 'rocket', 'spacecraft']);
  assert.equal(v.overall, 'FAIL');
});

test('simülasyon yalnız açılan aşamaları gösterir; debrief’te herkes tam sonucu görür', () => {
  const g = game();
  toDesign(g);
  // değerlendirme FAIL; launch için sahte sonucu PASS'e çevir
  g.room.evaluation.overall = 'PASS';
  g.room.evaluation.readiness = g.room.evaluation.readiness.filter((r) => r.status !== 'FAIL');
  g.mgr.openReview(g.code, g.ids.director);
  for (const r of ['rocket', 'spacecraft', 'payload']) g.mgr.signoff(g.code, g.ids[r], 'ok');
  g.mgr.launch(g.code, g.ids.director, { confirm: true });
  let v = viewFor(g.room, g.ids.payload, g.sim, g.chat, { phaseMs: 10 });
  assert.equal(v.simulation.phases.length, 0);
  assert.equal(has(json(v), 'SIM_SONUC'), false);
  g.advance(10); g.mgr.tick(g.code);
  v = viewFor(g.room, g.ids.payload, g.sim, g.chat, { phaseMs: 10 });
  assert.equal(v.simulation.phases.length, 1);
  assert.equal(v.simulation.phases[0].events[0].severity, 'info');
  assert.equal(v.result, null);
  g.advance(100); g.mgr.tick(g.code);
  assert.equal(g.room.phase, 'debrief');
  for (const id of Object.values(g.ids)) {
    const d = viewFor(g.room, id, g.sim, g.chat);
    assert.equal(d.result.debrief.score, 1234);
    assert.equal(d.result.simulation.reason, 'SIM_SONUC');
    assert.equal(d.result.needs.rocket[0].value, SECRET.needValue);
    assert.equal(d.simulation.phases.length, 2);
  }
});

test('GİZLİLİK: settingDefs optionInfo yalnız metin alanları taşır, help geçer; sayısal faktör sızmaz', () => {
  const g = game();
  toDesign(g);
  const sc = viewFor(g.room, g.ids.spacecraft, g.sim, g.chat).engineer.settingDefs;
  assert.equal(sc.length, 1);
  assert.deepEqual(sc[0].optionInfo, { eco: { label: 'Tasarruf', note: 'ISITICI_KISILIR' }, normal: { label: 'Normal' }, max: { label: 'Tam güç', desc: 'TAM_GUC_ACIKLAMA' } });
  const pl = viewFor(g.room, g.ids.payload, g.sim, g.chat).engineer.settingDefs;
  assert.deepEqual(pl[0].optionInfo, { survey: { label: 'Keşif' }, intensive: { label: 'Yoğun' } });
  const rk = viewFor(g.room, g.ids.rocket, g.sim, g.chat).engineer.settingDefs;
  assert.equal(rk[0].help, 'YAKIT_YARDIM');
  assert.equal('optionInfo' in rk[0], false);
  for (const role of ['rocket', 'spacecraft', 'payload']) {
    const s = json(viewFor(g.room, g.ids[role], g.sim, g.chat));
    for (const k of ['useFactor', 'dutyFactor', 'scienceFactor', 'dataFactor']) assert.equal(hasKey(s, k), false, `${role}: ${k} sızmamalı`);
    for (const x of [SECRET.useFactor, SECRET.scienceFactor]) assert.equal(has(s, x), false, `${role}: ${x} sızmamalı`);
  }
  // başka rolün ayar metni de gitmez
  assert.equal(has(json(viewFor(g.room, g.ids.rocket, g.sim, g.chat)), 'TAM_GUC_ACIKLAMA'), false);
});

test('simulation.phaseList: herkese yalnız {id,name}; yalnız simulation/debrief fazında', () => {
  const g = game();
  toDesign(g);
  assert.equal(viewFor(g.room, g.ids.rocket, g.sim, g.chat).simulation, null);
  g.room.evaluation.overall = 'PASS';
  g.room.evaluation.readiness = g.room.evaluation.readiness.filter((r) => r.status !== 'FAIL');
  g.mgr.openReview(g.code, g.ids.director);
  for (const r of ['rocket', 'spacecraft', 'payload']) g.mgr.signoff(g.code, g.ids[r], 'ok');
  g.mgr.launch(g.code, g.ids.director, { confirm: true });
  assert.equal(g.room.phase, 'simulation');
  const expected = [{ id: 'launch', name: 'Kalkış' }, { id: 'orbit', name: 'Yörünge' }];
  for (const [role, id] of Object.entries(g.ids)) {
    const v = viewFor(g.room, id, g.sim, g.chat, { phaseMs: 10 });
    assert.deepEqual(v.simulation.phaseList, expected, role);
    for (const p of v.simulation.phaseList) assert.deepEqual(Object.keys(p).sort(), ['id', 'name']);
    if (role !== 'director') assert.equal(has(json(v), SECRET.phaseDv), false, `${role}: aşama dvMs sızmamalı`);
  }
  g.advance(100); g.mgr.tick(g.code);
  assert.equal(g.room.phase, 'debrief');
  assert.deepEqual(viewFor(g.room, g.ids.payload, g.sim, g.chat).simulation.phaseList, expected);
});

// --- Aşama 8: kapasite, bütçe bandı, defter, bilim hedefleri, launchStatus ---------

test('Aşama 8 herkese: launchStatus, capacity (mineU yalnız kendi rolü), vehicle auto/volumeU', () => {
  const g = game();
  toDesign(g);
  for (const [role, id] of Object.entries(g.ids)) {
    const v = viewFor(g.room, id, g.sim, g.chat);
    assert.equal(v.launchStatus, 'INSUFFICIENT', role);
    assert.deepEqual(Object.keys(v.capacity).sort(), ['kit', 'lander', 'lv']);
    for (const c of Object.values(v.capacity)) assert.deepEqual(Object.keys(c).sort(), ['capacityU', 'freeU', 'mineU', 'name', 'usedU']);
    const mine = { director: [0, 0], rocket: [8, 0], spacecraft: [0, 17], payload: [0, 13] }[role];
    assert.deepEqual([v.capacity.lv.mineU, v.capacity.lander.mineU], mine, `${role} mineU`);
    assert.deepEqual(v.capacity.lander, { name: 'İniş aracı', usedU: 30, capacityU: 40, freeU: 10, mineU: mine[1] });
    assert.equal(v.capacity.kit.capacityU, null, 'capacityU yoksa null (sınırsız)');
    const eng = v.vehicle.find((x) => x.item.id === 'r-eng');
    assert.equal(eng.volumeU, 8);
    assert.equal(eng.auto, false);
    assert.equal(v.vehicle.find((x) => x.item.id === 'p-cam').volumeU, 0, 'volumeU yoksa 0');
  }
});

test('Aşama 8 launchStatus: sim vermezse overall ve kind ile türetilir; değerlendirme yoksa null', () => {
  const g = game();
  g.mgr.startGame(g.code, g.ids.director);
  assert.equal(viewFor(g.room, g.ids.rocket, g.sim, g.chat).launchStatus, null);
  g.mgr.selectMission(g.code, g.ids.director, 'lunar');
  delete g.room.evaluation.launchStatus;
  assert.equal(viewFor(g.room, g.ids.rocket, g.sim, g.chat).launchStatus, 'INSUFFICIENT', 'kritik physical FAIL');
  g.room.evaluation.readiness = [{ id: 'x', status: 'FAIL', critical: true, kind: 'missing' }];
  assert.equal(viewFor(g.room, g.ids.rocket, g.sim, g.chat).launchStatus, 'MISSING');
  g.room.evaluation.readiness = [{ id: 'x', status: 'WARN', critical: false }];
  g.room.evaluation.overall = 'WARN';
  assert.equal(viewFor(g.room, g.ids.rocket, g.sim, g.chat).launchStatus, 'RISKY');
  g.room.evaluation.readiness = [];
  g.room.evaluation.overall = 'PASS';
  assert.equal(viewFor(g.room, g.ids.rocket, g.sim, g.chat).launchStatus, 'READY');
});

test('Aşama 8 mühendis: budgetBand sayısız, katalogda volumeU + NO_SPACE, readiness kind, bütçe kalemi yok', () => {
  const g = game();
  toDesign(g);
  const rv = viewFor(g.room, g.ids.rocket, g.sim, g.chat);
  assert.equal(rv.engineer.budgetBand, 'ok'); // 77777 / 99999 < %90
  assert.equal(rv.engineer.catalog[0].volumeU, 8);
  assert.equal(rv.engineer.readiness.find((r) => r.id === 'twr').kind, 'ok');
  assert.equal(rv.engineer.readiness.some((r) => r.id === 'budget'), false, 'bütçe kalemi mühendise gitmez');
  assert.equal('scienceGoals' in rv.engineer, false, 'bilim hedefleri yalnız payload');
  const pv = viewFor(g.room, g.ids.payload, g.sim, g.chat);
  assert.equal(pv.engineer.readiness.find((r) => r.id === 'comms-cascade').kind, 'risky');
  assert.deepEqual(pv.engineer.scienceGoals, [
    { id: 'g1', name: 'Su buzu', desc: 'Kutup', status: 'partial', missingTags: ['drill'] },
    { id: 'g2', name: 'Sismik', desc: 'Ağ', status: 'ready', missingTags: [] },
  ]);
  // bant eşikleri (harcanan sayı mühendise asla gitmez)
  const tel = g.room.evaluation.telemetry;
  tel.budget.spent = 95000;
  assert.equal(viewFor(g.room, g.ids.rocket, g.sim, g.chat).engineer.budgetBand, 'tight');
  tel.budget.spent = 100000;
  const over = viewFor(g.room, g.ids.spacecraft, g.sim, g.chat);
  assert.equal(over.engineer.budgetBand, 'over');
  assert.equal(has(json(over), 100000), false, 'harcanan sayı sızmaz');
  // eski sim: telemetry.budget sayı (nesne değil) → cost/budget alanlarından
  tel.budget = SECRET.budget;
  assert.equal(viewFor(g.room, g.ids.rocket, g.sim, g.chat).engineer.budgetBand, 'ok');
  // NO_SPACE canAdd gerekçesiyle katalogda
  g.sim.canAdd = () => ({ ok: false, error: 'NO_SPACE', reason: 'Modülde yer yok: kullanılan 34/40 U, parça 8 U' });
  const nv = viewFor(g.room, g.ids.rocket, g.sim, g.chat);
  assert.deepEqual(nv.engineer.catalog[0].canAdd, { ok: false, error: 'NO_SPACE', reason: 'Modülde yer yok: kullanılan 34/40 U, parça 8 U' });
});

test('Aşama 8 operatör: budget, ledger (yeni→eski), capacity, scienceGoals (value dahil), launchStatus', () => {
  const g = game();
  toDesign(g);
  const uid = g.room.build.find((b) => b.itemId === 'p-cam').uid;
  g.mgr.removeItem(g.code, g.ids.payload, uid);
  const d = viewFor(g.room, g.ids.director, g.sim, g.chat).director;
  assert.equal(d.launchStatus, 'INSUFFICIENT');
  assert.deepEqual(d.budget, { budget: SECRET.budget, spent: SECRET.cost, remaining: SECRET.remaining, byRole: { rocket: SECRET.roleCostR, spacecraft: SECRET.roleCostS, payload: SECRET.roleCostP } });
  assert.equal(d.ledger.length, 4);
  assert.deepEqual(d.ledger.map((l) => [l.action, l.itemId, l.role, l.playerName, l.cost]), [
    ['remove', 'p-cam', 'payload', 'Deniz', -SECRET.cost],
    ['add', 'p-cam', 'payload', 'Deniz', SECRET.cost],
    ['add', 's-pan', 'spacecraft', 'Cem', SECRET.cost],
    ['add', 'r-eng', 'rocket', 'Bora', SECRET.cost],
  ]);
  assert.deepEqual(Object.keys(d.ledger[0]).sort(), ['action', 'cost', 'id', 'itemId', 'itemName', 'moduleId', 'playerName', 'role', 'ts']);
  assert.equal(d.telemetry.capacity.lander.byRole.spacecraft, 17);
  assert.equal(d.telemetry.scienceGoals[0].value, SECRET.goalValue);
  assert.equal('secret' in d.telemetry.scienceGoals[0], false, 'beyaz liste dışı alan atılır');
  assert.equal(d.readiness.find((r) => r.id === 'power').kind, 'physical');
  assert.equal(d.costs[g.room.build[0].uid], SECRET.cost);
  // O-2: operatör kataloğunda fiyat var; mühendis kataloğunda ASLA
  for (const r of ['rocket', 'spacecraft', 'payload']) {
    for (const it of d.catalog[r]) assert.equal(it.cost, SECRET.cost, `operatör ${r} kataloğunda cost`);
    const ev = viewFor(g.room, g.ids[r], g.sim, g.chat);
    for (const it of ev.engineer.catalog) assert.equal('cost' in it, false, `${r} kataloğunda cost olmamalı`);
    assert.equal(has(json(ev), SECRET.cost), false);
  }
  // eski sim: telemetry.budget sayı ve byRole yok → build maliyetlerinden türetilir; hiç yoksa görev bütçesi
  g.room.evaluation.telemetry.budget = SECRET.budget;
  assert.deepEqual(viewFor(g.room, g.ids.director, g.sim, g.chat).director.budget.byRole, { rocket: SECRET.cost, spacecraft: SECRET.cost, payload: 0 });
  delete g.room.evaluation.telemetry.budget;
  const d2 = viewFor(g.room, g.ids.director, g.sim, g.chat).director;
  assert.deepEqual(d2.budget, { budget: SECRET.budget, spent: SECRET.cost, remaining: SECRET.budget - SECRET.cost, byRole: { rocket: SECRET.cost, spacecraft: SECRET.cost, payload: 0 } });
});

test('Aşama 8 standart donanım görünümü: vehicle auto, operatör defterinde auto kaydı', () => {
  const g = game({ simExtra: { autoItems: () => [{ itemId: 's-pan', moduleId: 'cv', role: 'spacecraft' }] } });
  g.mgr.startGame(g.code, g.ids.director);
  g.mgr.selectMission(g.code, g.ids.director, 'lunar');
  g.mgr.skipBriefing(g.code, g.ids.director);
  g.mgr.setLang(g.code, g.ids.director, 'tr');
  for (const id of Object.values(g.ids)) {
    const v = viewFor(g.room, id, g.sim, g.chat);
    assert.equal(v.vehicle.length, 1);
    assert.equal(v.vehicle[0].auto, true);
    assert.equal(v.vehicle[0].volumeU, 5);
  }
  const d = viewFor(g.room, g.ids.director, g.sim, g.chat).director;
  assert.deepEqual(d.ledger.map((l) => [l.action, l.itemId, l.playerName]), [['auto', 's-pan', 'Standart donanım']]);
});

test('Tur 1: launchNote herkese, thermal.label operatör+spacecraft, requiresNames operatöre; debrief sectionTotal/adjustments geçer', () => {
  const g = game();
  const baseEval = g.sim.evaluate;
  g.sim.evaluate = (...a) => {
    const ev = baseEval(...a);
    ev.launchNote = 'Güç sistemi yetersiz.';
    ev.telemetry.thermal.label = 'Uyarı';
    ev.unmetRequirements = [{ itemId: 'p-cam', requires: ['power-bus'], requiresNames: ['Güç barası'], text: 'Gereksinim eksik' }];
    return ev;
  };
  const baseDebrief = g.sim.debrief;
  g.sim.debrief = (...a) => ({ ...baseDebrief(...a), sectionTotal: 900, adjustments: [{ id: 'overrun', label: 'Bütçe aşımı', points: -50 }] });
  toDesign(g);
  for (const [role, id] of Object.entries(g.ids)) assert.equal(viewFor(g.room, id, g.sim, g.chat).launchNote, 'Güç sistemi yetersiz.', role);
  const d = viewFor(g.room, g.ids.director, g.sim, g.chat).director;
  assert.equal(d.telemetry.thermal.label, 'Uyarı');
  assert.deepEqual(d.unmetRequirements[0].requiresNames, ['Güç barası']);
  assert.equal(viewFor(g.room, g.ids.spacecraft, g.sim, g.chat).engineer.telemetry.thermal.label, 'Uyarı');
  assert.equal(has(json(viewFor(g.room, g.ids.rocket, g.sim, g.chat)), 'Güç barası'), false, 'requiresNames mühendise gitmez');
  g.mgr.openReview(g.code, g.ids.director);
  for (const r of ['rocket', 'spacecraft', 'payload']) g.mgr.signoff(g.code, g.ids[r], 'ok');
  g.mgr.launch(g.code, g.ids.director, { confirm: true });
  g.advance(100); g.mgr.tick(g.code);
  for (const id of Object.values(g.ids)) {
    const r = viewFor(g.room, id, g.sim, g.chat).result;
    assert.equal(r.debrief.sectionTotal, 900);
    assert.deepEqual(r.debrief.adjustments, [{ id: 'overrun', label: 'Bütçe aşımı', points: -50 }]);
  }
});

test('Aşama 8 debrief: result.debrief.budget ve scienceGoals herkese', () => {
  const g = game();
  toDesign(g);
  g.mgr.openReview(g.code, g.ids.director);
  for (const r of ['rocket', 'spacecraft', 'payload']) g.mgr.signoff(g.code, g.ids[r], 'ok');
  assert.throws(() => g.mgr.launch(g.code, g.ids.director), (e) => e.code === 'LAUNCH_CONFIRM');
  g.mgr.launch(g.code, g.ids.director, { confirm: true });
  g.advance(100); g.mgr.tick(g.code);
  assert.equal(g.room.phase, 'debrief');
  for (const id of Object.values(g.ids)) {
    const r = viewFor(g.room, id, g.sim, g.chat).result;
    assert.equal(r.debrief.budget.budget, SECRET.budget);
    assert.deepEqual(r.debrief.scienceGoals, [{ id: 'g1', name: 'Su buzu', done: false, reason: 'Matkap yok' }]);
  }
});

// --- Aşama 9: oyuncu dili ---------------------------------------------------------

// Dil duyarlı sahte sim: metinler lang'a göre, sayılar aynı
function langSim() {
  const nm = (lang, tr, en) => (lang === 'en' ? en : tr);
  const calls = { evaluate: [], simulate: [], debrief: [] };
  const extra = {
    calls,
    getItem: (id, lang) => ({ ...fakeSim().items[id], name: nm(lang, `${id}-TR`, `${id}-EN`) }),
    publicItem: (id, lang) => ({ id, name: nm(lang, `${id}-TR`, `${id}-EN`), category: 'c', role: 'rocket', module: 'lv', icon: '', desc: '' }),
    evaluate: (m, b, s, o = {}) => {
      calls.evaluate.push(o.lang);
      const ev = fakeSim().evaluate();
      ev.launchNote = nm(o.lang, 'NOT_TR', 'NOTE_EN');
      return ev;
    },
    simulate: (m, b, s, seed, o = {}) => {
      calls.simulate.push([o.lang, seed]);
      return { phases: [{ id: 'launch', name: nm(o.lang, 'Kalkış', 'Launch'), status: 'ok', events: [] }], outcome: 'success', seed };
    },
    debrief: (m, ev, res, team, o = {}) => {
      calls.debrief.push(o.lang);
      return { score: 500, outcome: res.outcome, sections: [], title: nm(o.lang, 'BAŞARI', 'SUCCESS'), seed: res.seed };
    },
  };
  return extra;
}

test('dil: varsayılan en, me.lang; iki oyuncu aynı odada farklı dilde görür (sonuç aynı tohum)', () => {
  const g = game({ simExtra: { ...langSim(), autoItems: () => [{ itemId: 's-pan', moduleId: 'cv', role: 'spacecraft' }] } });
  g.mgr.setLang(g.code, g.ids.payload, 'tr');
  g.mgr.startGame(g.code, g.ids.director);
  g.mgr.selectMission(g.code, g.ids.director, 'lunar');
  g.mgr.skipBriefing(g.code, g.ids.director);
  g.mgr.addItem(g.code, g.ids.rocket, 'r-eng', 'lv');
  const en = viewFor(g.room, g.ids.rocket, g.sim, g.chat);
  const tr = viewFor(g.room, g.ids.payload, g.sim, g.chat);
  assert.equal(en.me.lang, 'en');
  assert.equal(tr.me.lang, 'tr');
  assert.equal(en.launchNote, 'NOTE_EN');
  assert.equal(tr.launchNote, 'NOT_TR');
  assert.equal(en.vehicle[0].item.name, 's-pan-EN');
  assert.equal(tr.vehicle[0].item.name, 's-pan-TR');
  assert.equal(en.launchStatus, tr.launchStatus);
  // operatör defteri: itemName ve standart donanım dilde
  let d = viewFor(g.room, g.ids.director, g.sim, g.chat).director;
  assert.deepEqual(d.ledger.map((l) => [l.itemName, l.playerName]), [['r-eng-EN', 'Bora'], ['s-pan-EN', 'Standard hardware']]);
  g.mgr.setLang(g.code, g.ids.director, 'tr');
  d = viewFor(g.room, g.ids.director, g.sim, g.chat).director;
  assert.deepEqual(d.ledger.map((l) => [l.itemName, l.playerName]), [['r-eng-TR', 'Bora'], ['s-pan-TR', 'Standart donanım']]);
  // simülasyon + debrief: her dil aynı tohumla
  g.mgr.openReview(g.code, g.ids.director);
  for (const r of ['rocket', 'spacecraft', 'payload']) g.mgr.signoff(g.code, g.ids[r], 'ok');
  g.mgr.launch(g.code, g.ids.director, { confirm: true });
  g.advance(100); g.mgr.tick(g.code);
  assert.equal(g.room.phase, 'debrief');
  const rEn = viewFor(g.room, g.ids.rocket, g.sim, g.chat).result;
  const rTr = viewFor(g.room, g.ids.payload, g.sim, g.chat).result;
  assert.equal(rEn.debrief.title, 'SUCCESS');
  assert.equal(rTr.debrief.title, 'BAŞARI');
  assert.equal(rEn.simulation.phases[0].name, 'Launch');
  assert.equal(rTr.simulation.phases[0].name, 'Kalkış');
  assert.equal(rEn.debrief.score, rTr.debrief.score);
  assert.equal(rEn.simulation.seed, rTr.simulation.seed, 'aynı tohum');
  const seeds = new Set(g.sim.calls.simulate.map((c) => c[1]));
  assert.equal(seeds.size, 1);
  // önbellek: tekrar görünüm yeni simulate/debrief çağırmaz
  const n = g.sim.calls.simulate.length + g.sim.calls.debrief.length;
  viewFor(g.room, g.ids.payload, g.sim, g.chat);
  assert.equal(g.sim.calls.simulate.length + g.sim.calls.debrief.length, n);
});
