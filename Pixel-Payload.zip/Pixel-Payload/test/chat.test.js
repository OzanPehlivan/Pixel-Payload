'use strict';
// Modül AB: sohbet yetkileri birim testleri (node:test)
const test = require('node:test');
const assert = require('node:assert/strict');
const { createChat } = require('../server/chat');

// Sahte oda: 4 rol dolu + rolsüz bir oyuncu
function makeRoom({ withRoles = ['director', 'rocket', 'spacecraft', 'payload'] } = {}) {
  const players = new Map();
  const add = (id, role, name, connected = true) => players.set(id, { id, name, role, ready: true, connected, socketId: 's-' + id, lastSeen: 0 });
  for (const r of withRoles) add('p-' + r, r, 'Ad ' + r);
  add('p-none', null, 'Rolsüz');
  return { code: 'ABCD', players };
}

function makeClock(start = 1000) {
  const c = { t: start, now: () => c.t };
  return c;
}

const ROLES = ['director', 'rocket', 'spacecraft', 'payload'];
const TARGETS = ['director', 'rocket', 'spacecraft', 'payload', 'engineers', 'all'];

test('izin tablosu: 4 rol x tüm hedefler', () => {
  for (const role of ROLES) {
    for (const to of TARGETS) {
      const chat = createChat({ now: () => 0 });
      const room = makeRoom();
      const r = chat.send(room, 'p-' + role, { to, text: 'merhaba' });
      let allowed;
      if (role === 'director') allowed = ['rocket', 'spacecraft', 'payload', 'engineers'].includes(to);
      else allowed = to === 'director';
      if (allowed) {
        assert.equal(r.ok, true, `${role} -> ${to} izinli olmalı`);
      } else {
        assert.equal(r.ok, false, `${role} -> ${to} yasak olmalı`);
        assert.equal(r.error, 'FORBIDDEN', `${role} -> ${to}`);
      }
    }
  }
});

test('thread ve alıcılar: özel mesaj', () => {
  const chat = createChat({ now: () => 5 });
  const room = makeRoom();
  const a = chat.send(room, 'p-rocket', { to: 'director', text: 'kütle?' });
  assert.equal(a.message.thread, 'rocket');
  assert.equal(a.message.from, 'rocket');
  assert.equal(a.message.fromName, 'Ad rocket');
  assert.equal(a.message.ts, 5);
  assert.deepEqual([...a.recipients].sort(), ['p-director', 'p-rocket']);

  const b = chat.send(room, 'p-director', { to: 'rocket', text: '12 ton' });
  assert.equal(b.message.thread, 'rocket');
  assert.deepEqual([...b.recipients].sort(), ['p-director', 'p-rocket']);
  assert.notEqual(a.message.id, b.message.id);
  assert.equal(room.chat.threads.rocket.length, 2);
});

test('yayın: üç mühendis + operatör, broadcast thread', () => {
  const chat = createChat({ now: () => 0 });
  const room = makeRoom();
  const r = chat.send(room, 'p-director', { to: 'engineers', text: 'herkes dinlesin' });
  assert.equal(r.message.thread, 'broadcast');
  assert.deepEqual([...r.recipients].sort(), ['p-director', 'p-payload', 'p-rocket', 'p-spacecraft']);
  assert.ok(!r.recipients.includes('p-none'));
});

test('bağlı olmayan alıcılar da listelenir', () => {
  const chat = createChat({ now: () => 0 });
  const room = makeRoom();
  room.players.get('p-rocket').connected = false;
  const r = chat.send(room, 'p-director', { to: 'rocket', text: 'orada mısın' });
  assert.equal(r.ok, true);
  assert.ok(r.recipients.includes('p-rocket'));
});

test('sahte istemci: mühendisin geçersiz hedef denemeleri', () => {
  const chat = createChat({ now: () => 0 });
  const room = makeRoom();
  const send = (to) => chat.send(room, 'p-spacecraft', { to, text: 'x' });
  assert.equal(send('rocket').error, 'FORBIDDEN');
  assert.equal(send('engineers').error, 'FORBIDDEN');
  assert.equal(send('all').error, 'FORBIDDEN');
  assert.equal(send('spacecraft').error, 'FORBIDDEN');
  assert.equal(send('zxq-rastgele').error, 'BAD_TARGET');
  assert.equal(send('').error, 'BAD_TARGET');
  assert.equal(send({ role: 'director' }).error, 'BAD_TARGET');
  assert.equal(send(['director']).error, 'BAD_TARGET');
  assert.equal(send(42).error, 'BAD_TARGET');
  assert.equal(send(undefined).error, 'BAD_TARGET');
  // İstemcinin gönderdiği sahte rol/oda alanları yok sayılır
  const r = chat.send(room, 'p-spacecraft', { to: 'director', text: 'y', role: 'director', from: 'director', room: 'ZZZZ', thread: 'rocket' });
  assert.equal(r.ok, true);
  assert.equal(r.message.from, 'spacecraft');
  assert.equal(r.message.thread, 'spacecraft');
  // Hiçbir yasak deneme thread'e yazılmamış olmalı
  assert.equal(room.chat.threads.rocket.length, 0);
  assert.equal(room.chat.threads.broadcast.length, 0);
});

test('payload nesne değilse BAD_TARGET, text string değilse EMPTY', () => {
  const chat = createChat({ now: () => 0 });
  const room = makeRoom();
  assert.equal(chat.send(room, 'p-rocket', null).error, 'BAD_TARGET');
  assert.equal(chat.send(room, 'p-rocket', 'director').error, 'BAD_TARGET');
  assert.equal(chat.send(room, 'p-rocket', undefined).error, 'BAD_TARGET');
  assert.equal(chat.send(room, 'p-rocket', { to: 'director', text: 5 }).error, 'EMPTY');
  assert.equal(chat.send(room, 'p-rocket', { to: 'director', text: { a: 1 } }).error, 'EMPTY');
});

test('oda dışı ve rolsüz oyuncu', () => {
  const chat = createChat({ now: () => 0 });
  const room = makeRoom();
  assert.equal(chat.send(room, 'yabanci', { to: 'director', text: 'hi' }).error, 'NOT_IN_ROOM');
  assert.equal(chat.send(room, 'p-none', { to: 'director', text: 'hi' }).error, 'NO_ROLE');
  assert.equal(chat.viewFor(room, 'yabanci'), null);
  assert.equal(chat.viewFor(room, 'p-none'), null);
});

test('hedef rol boşsa TARGET_EMPTY', () => {
  const chat = createChat({ now: () => 0 });
  const noPayload = makeRoom({ withRoles: ['director', 'rocket'] });
  assert.equal(chat.send(noPayload, 'p-director', { to: 'payload', text: 'a' }).error, 'TARGET_EMPTY');
  const r = chat.send(noPayload, 'p-director', { to: 'engineers', text: 'a' });
  assert.equal(r.ok, true);
  assert.deepEqual([...r.recipients].sort(), ['p-director', 'p-rocket']);
  const noDirector = makeRoom({ withRoles: ['rocket'] });
  assert.equal(chat.send(noDirector, 'p-rocket', { to: 'director', text: 'a' }).error, 'TARGET_EMPTY');
  const onlyDirector = makeRoom({ withRoles: ['director'] });
  assert.equal(chat.send(onlyDirector, 'p-director', { to: 'engineers', text: 'a' }).error, 'TARGET_EMPTY');
});

test('uzunluk, boş metin, kontrol karakterleri', () => {
  const chat = createChat({ now: () => 0, maxLen: 10, rate: { count: 100, perMs: 1000 } });
  const room = makeRoom();
  const s = (text) => chat.send(room, 'p-rocket', { to: 'director', text });
  assert.equal(s('').error, 'EMPTY');
  assert.equal(s('    ').error, 'EMPTY');
  assert.equal(s('\u0000\u0007‮⁦').error, 'EMPTY');
  assert.equal(s('12345678901').error, 'TOO_LONG');
  assert.equal(s('1234567890').ok, true);
  assert.equal(s('  1234567890  ').ok, true, 'trim sonrası uzunluk sayılır');
  const r = s(' a\u0000b\u007Fc‮d⁩e ');
  assert.equal(r.message.text, 'abcde');
  assert.equal(s('a\nb').message.text, 'a b');
  // Kesme yok: uzun metin saklanmaz
  assert.ok(room.chat.threads.rocket.every((m) => m.text.length <= 10));
});

test('hız sınırı: kayan pencere, sahte saat', () => {
  const clock = makeClock(0);
  const chat = createChat({ now: clock.now, rate: { count: 3, perMs: 1000 } });
  const room = makeRoom();
  const s = () => chat.send(room, 'p-rocket', { to: 'director', text: 'x' });
  assert.equal(s().ok, true);
  clock.t = 100; assert.equal(s().ok, true);
  clock.t = 200; assert.equal(s().ok, true);
  clock.t = 300; assert.equal(s().error, 'RATE_LIMIT');
  // Başka oyuncu etkilenmez
  assert.equal(chat.send(room, 'p-director', { to: 'rocket', text: 'y' }).ok, true);
  clock.t = 999; assert.equal(s().error, 'RATE_LIMIT');
  clock.t = 1000; assert.equal(s().ok, true, 'ilk mesaj pencereden çıktı');
  clock.t = 1050; assert.equal(s().error, 'RATE_LIMIT');
  // rate kaydı görünümde yok
  assert.equal(chat.viewFor(room, 'p-director').rate, undefined);
});

test('geçmiş sınırı: eskiler düşer', () => {
  const clock = makeClock(0);
  const chat = createChat({ now: clock.now, historyLimit: 3, rate: { count: 1000, perMs: 1 } });
  const room = makeRoom();
  for (let i = 1; i <= 5; i++) { clock.t = i * 10; chat.send(room, 'p-payload', { to: 'director', text: 'm' + i }); }
  assert.deepEqual(room.chat.threads.payload.map((m) => m.text), ['m3', 'm4', 'm5']);
  assert.deepEqual(chat.viewFor(room, 'p-payload').threads.mine.map((m) => m.text), ['m3', 'm4', 'm5']);
});

test('viewFor gizliliği: mühendis başka thread görmez, kopya döner', () => {
  const chat = createChat({ now: () => 0 });
  const room = makeRoom();
  chat.send(room, 'p-rocket', { to: 'director', text: 'roket gizli' });
  chat.send(room, 'p-director', { to: 'spacecraft', text: 'araç gizli' });
  chat.send(room, 'p-director', { to: 'engineers', text: 'yayın' });

  const vr = chat.viewFor(room, 'p-rocket');
  assert.deepEqual(Object.keys(vr.threads).sort(), ['broadcast', 'mine']);
  assert.deepEqual(vr.threads.mine.map((m) => m.text), ['roket gizli']);
  assert.deepEqual(vr.threads.broadcast.map((m) => m.text), ['yayın']);
  assert.ok(!JSON.stringify(vr).includes('araç gizli'));

  const vs = chat.viewFor(room, 'p-spacecraft');
  assert.deepEqual(vs.threads.mine.map((m) => m.text), ['araç gizli']);
  assert.ok(!JSON.stringify(vs).includes('roket gizli'));

  const vp = chat.viewFor(room, 'p-payload');
  assert.equal(vp.threads.mine.length, 0);

  const vd = chat.viewFor(room, 'p-director');
  assert.deepEqual(Object.keys(vd.threads).sort(), ['broadcast', 'payload', 'rocket', 'spacecraft']);
  assert.equal(vd.threads.rocket.length, 1);
  assert.equal(vd.threads.spacecraft.length, 1);

  // Kopya: dönen diziyi bozmak odayı etkilemez
  vr.threads.mine.push({ text: 'sahte' });
  vr.threads.broadcast[0].text = 'değişti';
  assert.equal(room.chat.threads.rocket.length, 1);
  assert.equal(room.chat.threads.broadcast[0].text, 'yayın');
});

test('yeniden bağlanma: aynı playerId geçmişi görür', () => {
  const chat = createChat({ now: () => 0 });
  const room = makeRoom();
  chat.send(room, 'p-director', { to: 'payload', text: 'bilim önce' });
  const p = room.players.get('p-payload');
  p.connected = false; p.socketId = null;
  // Koptuğu sırada gelen mesaj da saklanır
  chat.send(room, 'p-director', { to: 'payload', text: 'koptun mu' });
  p.connected = true; p.socketId = 's-yeni';
  const v = chat.viewFor(room, 'p-payload');
  assert.deepEqual(v.threads.mine.map((m) => m.text), ['bilim önce', 'koptun mu']);
});

test('reset ve room.chat yokken başlatma', () => {
  const chat = createChat({ now: () => 0 });
  const room = makeRoom();
  assert.deepEqual(chat.viewFor(room, 'p-rocket'), { threads: { mine: [], broadcast: [] } });
  chat.send(room, 'p-rocket', { to: 'director', text: 'a' });
  chat.reset(room);
  assert.deepEqual(room.chat, { threads: { rocket: [], spacecraft: [], payload: [], broadcast: [] }, rate: {} });
});

test('Aşama 9: sohbet hata kodlarının iki dilde mesajı var', () => {
  const { CHAT_ERROR_MESSAGES } = require('../server/constants');
  for (const code of ['NOT_IN_ROOM', 'NO_ROLE', 'FORBIDDEN', 'BAD_TARGET', 'EMPTY', 'TOO_LONG', 'RATE_LIMIT', 'TARGET_EMPTY']) {
    assert.ok(CHAT_ERROR_MESSAGES.en[code], `en ${code}`);
    assert.ok(CHAT_ERROR_MESSAGES.tr[code], `tr ${code}`);
    assert.notEqual(CHAT_ERROR_MESSAGES.en[code], CHAT_ERROR_MESSAGES.tr[code]);
  }
});
