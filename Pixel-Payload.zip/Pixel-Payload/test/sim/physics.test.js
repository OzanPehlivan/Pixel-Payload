'use strict';
const test = require('node:test');
const assert = require('node:assert/strict');
const P = require('../../server/sim/physics');

const near = (a, b, tol) => assert.ok(Math.abs(a - b) <= tol, `${a} ≈ ${b} (±${tol})`);

test('Tsiolkovsky: Δv ve ters çevrimi tutarlı', () => {
  const dv = P.deltaV(300, 9.80665, 1000, 500);
  near(dv, 300 * 9.80665 * Math.log(2), 1e-6);
  const mp = P.propellantFor(dv, 300, 9.80665, 1000);
  near(mp, 500, 1e-6);
  assert.equal(P.deltaV(300, 9.80665, 1000, 1000), 0);
  assert.equal(P.deltaV(0, 9.80665, 1000, 500), 0);
  assert.equal(P.propellantFor(100, 0, 9.8, 1000), Infinity);
});

test('etkin Isp itki ağırlıklı harmonik ortalamadır', () => {
  assert.equal(P.effectiveIsp([{ thrustN: 100, ispS: 300 }]), 300);
  near(P.effectiveIsp([{ thrustN: 100, ispS: 300 }, { thrustN: 100, ispS: 450 }]), 200 / (100 / 300 + 100 / 450), 1e-9);
  assert.equal(P.effectiveIsp([]), 0);
});

test('TWR, yerçekimi, yörünge ve kaçış hızı', () => {
  near(P.twr(19.6133, 1, 9.80665), 2, 1e-9);
  assert.equal(P.twr(100, 0, 9.8), 0);
  near(P.surfaceGravity(3.986e14, 6371000), 9.82, 0.01);
  near(P.orbitalVelocity(3.986e14, 6771000), 7672, 5);
  near(P.escapeVelocity(4.9e12, 1737400), 2375, 5);
});

test('ışık gecikmesi ve üstel atmosfer', () => {
  near(P.lightDelay(384400000, 299792458), 1.282, 0.001);
  near(P.atmosphereDensity(0.016, 11000, 11000), 0.016 / Math.E, 1e-9);
  assert.equal(P.atmosphereDensity(0.016, 0, 10), 0);
});

test('EDL ısı akısı kütleyle artar; terminal hız ve enerji dengesi', () => {
  const base = { dragAreaM2: 26.7, entryMs: 5400, gammaDeg: 15.5, scaleH: 11000, rho0: 0.016, noseRadiusM: 1.1, k: 1.9027e-4 };
  const a = P.entryPeakHeat(Object.assign({ massKg: 2000 }, base));
  const b = P.entryPeakHeat(Object.assign({ massKg: 4000 }, base));
  assert.ok(a.peakHeatWcm2 > 10 && a.peakHeatWcm2 < 500);
  assert.ok(b.peakHeatWcm2 > a.peakHeatWcm2);
  assert.equal(P.entryPeakHeat(Object.assign({ massKg: 0 }, base)).peakHeatWcm2, 0);
  near(P.terminalVelocity(1000, 3.73, 0.016, 200), Math.sqrt((2 * 1000 * 3.73) / (0.016 * 200)), 1e-9);
  assert.equal(P.terminalVelocity(1, 1, 0, 1), Infinity);
  const e = P.energyBalance(100, 150, 500);
  assert.equal(e.marginW, -50);
  assert.equal(e.batteryHours, 10);
  assert.equal(P.energyBalance(200, 100, 0).batteryHours, Infinity);
  assert.match(P.EDUCATIONAL_LABEL, /eğitsel/);
});
