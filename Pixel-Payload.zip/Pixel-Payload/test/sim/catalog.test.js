'use strict';
const test = require('node:test');
const assert = require('node:assert/strict');
const fs = require('fs');
const os = require('os');
const path = require('path');
const { createSim } = require('../../server/sim');
const F = require('../fixtures/mini');

const sim = createSim(F.data());

test('listMissions / getMission / getItem', () => {
  const list = sim.listMissions();
  assert.deepEqual(list.map((m) => m.id).sort(), ['lunar', 'mars']);
  for (const m of list) assert.deepEqual(Object.keys(m).sort(), ['educationalNote', 'id', 'name', 'summary']);
  const m = sim.getMission('lunar');
  assert.equal(m.crew, 2);
  m.crew = 99; // kopya: iç durumu bozmaz
  assert.equal(sim.getMission('lunar').crew, 2);
  assert.equal(sim.getMission('yok'), undefined);
  assert.equal(sim.getItem('l-core').massKg, 30000);
  assert.equal(sim.getItem('yok'), undefined);
});

test('ayar tanımları birleşir; Mars\'ta sarf yedeği yok', () => {
  const keys = (id) => sim.getMission(id).settings.map((s) => s.key);
  assert.ok(keys('lunar').includes('consumableMarginDays'));
  assert.ok(!keys('mars').includes('consumableMarginDays'));
  assert.deepEqual(sim.defaultSettings('lunar'), { propellantLoad: 1, consumableMarginDays: 3, powerMode: 'normal', instrumentMode: 'balanced' });
  assert.deepEqual(sim.defaultSettings('yok'), {});
});

test('catalogFor yalnız rolün ve görevin parçaları; publicItem sayısız', () => {
  const rocket = sim.catalogFor('lunar', 'rocket');
  assert.ok(rocket.length > 0);
  assert.ok(rocket.every((i) => i.role === 'rocket' && i.missions.includes('lunar')));
  assert.ok(rocket.some((i) => typeof i.massKg === 'number'));
  assert.deepEqual(sim.catalogFor('yok', 'rocket'), []);
  const p = sim.publicItem('l-core');
  assert.deepEqual(Object.keys(p).sort(), ['category', 'desc', 'icon', 'id', 'module', 'name', 'role']);
  assert.equal(sim.publicItem('yok'), null);
});

test('canAdd hata kodları', () => {
  const b = [{ uid: 'a', itemId: 'l-core', moduleId: 'launch-vehicle', role: 'rocket' }];
  assert.deepEqual(sim.canAdd([], 'lunar', 'rocket', 'l-core', 'launch-vehicle'), { ok: true });
  assert.equal(sim.canAdd([], 'lunar', 'rocket', 'yok', 'launch-vehicle').error, 'INVALID_ITEM');
  assert.equal(sim.canAdd([], 'lunar', 'spacecraft', 'l-core', 'launch-vehicle').error, 'NOT_ALLOWED');
  assert.equal(sim.canAdd([], 'lunar', 'director', 'l-core', 'launch-vehicle').error, 'NOT_ALLOWED');
  assert.equal(sim.canAdd([], 'mars', 'rocket', 'l-core', 'launch-vehicle').error, 'WRONG_MISSION');
  assert.equal(sim.canAdd([], 'yok', 'rocket', 'l-core', 'launch-vehicle').error, 'WRONG_MISSION');
  assert.equal(sim.canAdd([], 'lunar', 'rocket', 'l-core', 'lander').error, 'WRONG_MODULE');
  assert.equal(sim.canAdd(b, 'lunar', 'rocket', 'l-core', 'launch-vehicle').error, 'DUPLICATE');
  assert.equal(sim.canAdd(b, 'lunar', 'rocket', 'l-core-small', 'launch-vehicle').error, 'CATEGORY_FULL');
  const drill = [{ uid: 'd', itemId: 's-drill', moduleId: 'surface-kit', role: 'payload' }];
  const inc = sim.canAdd(drill, 'lunar', 'payload', 's-seismo', 'surface-kit');
  assert.equal(inc.error, 'INCOMPATIBLE');
  assert.match(inc.reason, /sismometre/i);
  // gereksinim eksikliği takmayı engellemez
  assert.deepEqual(sim.canAdd([], 'lunar', 'rocket', 'd-engine', 'lander'), { ok: true });
  // moduleId verilmezse parçanın modülü kullanılır; bozuk girdi istisna atmaz
  assert.deepEqual(sim.canAdd(null, 'lunar', 'rocket', 'l-core'), { ok: true });
  for (const r of [sim.canAdd([], 'lunar', 'rocket', 'yok'), inc]) assert.equal(typeof r.reason, 'string');
});

test('validateSetting: aralık, adım, rol, enum', () => {
  assert.deepEqual(sim.validateSetting('lunar', 'rocket', 'propellantLoad', 0.87), { ok: true, value: 0.85 });
  assert.deepEqual(sim.validateSetting('lunar', 'rocket', 'propellantLoad', '0.9'), { ok: true, value: 0.9 });
  assert.equal(sim.validateSetting('lunar', 'rocket', 'propellantLoad', 0.5).error, 'BAD_SETTING');
  assert.equal(sim.validateSetting('lunar', 'rocket', 'propellantLoad', 'abc').error, 'BAD_SETTING');
  assert.equal(sim.validateSetting('lunar', 'spacecraft', 'propellantLoad', 1).error, 'BAD_SETTING');
  assert.deepEqual(sim.validateSetting('lunar', 'spacecraft', 'powerMode', 'eco'), { ok: true, value: 'eco' });
  assert.equal(sim.validateSetting('lunar', 'spacecraft', 'powerMode', 'turbo').error, 'BAD_SETTING');
  assert.equal(sim.validateSetting('mars', 'spacecraft', 'consumableMarginDays', 2).error, 'BAD_SETTING');
  assert.equal(sim.validateSetting('yok', 'rocket', 'propellantLoad', 1).error, 'BAD_SETTING');
  assert.equal(sim.validateSetting('lunar', 'rocket', 'bilinmeyen', 1).error, 'BAD_SETTING');
});

test('yükleyici dizinden glob ile okur, eksik alanlara dayanıklıdır', () => {
  const dir = fs.mkdtempSync(path.join(os.tmpdir(), 'pp-sim-'));
  const d = F.data();
  for (const sub of ['equipment', 'missions', 'physics', 'science']) fs.mkdirSync(path.join(dir, sub));
  fs.writeFileSync(path.join(dir, 'equipment', 'a.json'), JSON.stringify({ items: d.equipment.slice(0, 10) }));
  fs.writeFileSync(path.join(dir, 'equipment', 'b.json'), JSON.stringify({ items: d.equipment.slice(10).concat([{ id: 'bare', name: 'Çıplak', role: 'rocket', module: 'launch-vehicle', category: 'core', missions: ['lunar'] }]) }));
  fs.writeFileSync(path.join(dir, 'equipment', 'bozuk.json'), '{bozuk');
  fs.writeFileSync(path.join(dir, 'missions', 'lunar.json'), JSON.stringify(d.missions[0]));
  fs.writeFileSync(path.join(dir, 'missions', 'mars.json'), JSON.stringify(d.missions[1]));
  fs.writeFileSync(path.join(dir, 'physics', 'constants.json'), JSON.stringify(d.constants));
  fs.writeFileSync(path.join(dir, 'science', 'sources.json'), JSON.stringify(d.sources));
  const s2 = createSim({ dataDir: dir });
  assert.equal(s2.listMissions().length, 2);
  assert.ok(s2.getItem('bare'));
  // alan eksik parça: değerlendirme istisnasız çalışır
  const e = s2.evaluate('lunar', [{ uid: 'q', itemId: 'bare', moduleId: 'launch-vehicle' }], {});
  assert.ok(Array.isArray(e.readiness));
  // boş dizin: boş ama çalışır
  const empty = createSim({ dataDir: path.join(dir, 'yok') });
  assert.deepEqual(empty.listMissions(), []);
  assert.equal(empty.evaluate('lunar', [], {}).error, 'INVALID_MISSION');
  fs.rmSync(dir, { recursive: true, force: true });
});
