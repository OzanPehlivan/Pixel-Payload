'use strict';
const test = require('node:test');
const assert = require('node:assert/strict');
const { createSim } = require('../../server/sim');
const F = require('../fixtures/mini');

const sim = createSim(F.data());

test('determinizm: aynı girdi + tohum → aynı sonuç', () => {
  for (const seed of [1, 42, 'oda-ABCD', 987654]) {
    const a = sim.simulate('mars', F.GOOD_MARS, {}, seed);
    const b = sim.simulate('mars', F.GOOD_MARS, {}, seed);
    assert.deepEqual(a, b);
  }
});

test('sonuç biçimi ve olay rolleri', () => {
  const r = sim.simulate('lunar', F.GOOD_LUNAR, {}, 3);
  assert.ok(['success', 'partial', 'failure'].includes(r.outcome));
  assert.equal(typeof r.reason, 'string');
  for (const p of r.phases) {
    assert.ok(['ok', 'warn', 'fail'].includes(p.status));
    assert.equal(typeof p.name, 'string');
    assert.equal(typeof p.note, 'string');
    for (const e of p.events) {
      assert.ok(['info', 'warn', 'critical'].includes(e.severity));
      assert.ok(Array.isArray(e.roles));
      assert.equal(typeof e.id, 'string');
    }
  }
  assert.ok(r.objectives.every((o) => typeof o.done === 'boolean' && o.name));
  assert.equal(typeof r.landing.ok, 'boolean');
  assert.equal(typeof r.science.score, 'number');
});

test('iyi yapılandırma çoğu tohumda başarılı', () => {
  let ok = 0;
  for (let s = 0; s < 20; s++) if (sim.simulate('lunar', F.GOOD_LUNAR, {}, s).outcome === 'success') ok++;
  assert.ok(ok >= 15, `başarılı: ${ok}/20`);
});

test('Ay: mürettebat güvenliği bozulursa failure ve ilk kritik hatada durur', () => {
  const b = F.swap(F.GOOD_LUNAR, 'c-eclss', 'c-eclss-small');
  const r = sim.simulate('lunar', b, {}, 5);
  assert.equal(r.outcome, 'failure');
  const last = r.phases[r.phases.length - 1];
  assert.equal(last.status, 'fail');
  assert.ok(r.phases.length < sim.getMission('lunar').phases.length);
  assert.ok(last.events.some((e) => e.severity === 'critical' && e.roles.includes('spacecraft')));
  assert.equal(r.objectives.find((o) => o.id === 'crew-return').done, false);
});

test('Mars: iniş başarılı ama bilim zayıf → partial', () => {
  const b = F.without(F.GOOD_MARS, 'm-spec');
  const ev = sim.evaluate('mars', b, { instrumentMode: 'survey' });
  assert.equal(ev.readiness.find((r) => r.id === 'science').status, 'WARN');
  const r = sim.simulate('mars', b, { instrumentMode: 'survey' }, 11);
  assert.equal(r.landing.ok, true);
  assert.equal(r.outcome, 'partial');
  assert.equal(r.objectives.find((o) => o.id === 'science').done, false);
});

test('Mars: kalkan yetersizse iniş öncesi failure', () => {
  const r = sim.simulate('mars', F.swap(F.GOOD_MARS, 'm-shield', 'm-shield-weak'), {}, 2);
  assert.equal(r.outcome, 'failure');
  assert.equal(r.landing.ok, false);
  assert.equal(r.phases[r.phases.length - 1].id, 'entry');
});

test('Mars: iniş sonrası kritik hata → partial (gezgin indi)', () => {
  const d = F.data();
  d.missions[1].phases.find((p) => p.id === 'downlink').checks = ['comms-link'];
  const s2 = createSim(d);
  const b = F.without(F.without(F.GOOD_MARS, 'm-uhf'), 'm-xband'); // veri bağlantısı yok (kritik)
  const r = s2.simulate('mars', b, {}, 4);
  assert.equal(r.landing.ok, true);
  assert.equal(r.outcome, 'partial');
});

test('bilinmeyen görev hata kodu döner', () => {
  const r = sim.simulate('yok', [], {}, 1);
  assert.equal(r.error, 'INVALID_MISSION');
  assert.equal(r.outcome, 'failure');
  assert.deepEqual(r.phases, []);
});
