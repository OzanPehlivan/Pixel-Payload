'use strict';
// Gerçek veriyle (data/) Modül Y'nin aday çözümleri. Veri yoksa atlanır.
const test = require('node:test');
const assert = require('node:assert/strict');
const fs = require('fs');
const path = require('path');
const { createSim } = require('../../server/sim');
const S = require('../fixtures/solutions');

const dataDir = path.join(__dirname, '..', '..', 'data');
const has = fs.existsSync(path.join(dataDir, 'missions', 'lunar.json')) && fs.existsSync(path.join(dataDir, 'missions', 'mars.json'));
const sim = has ? createSim({ dataDir }) : null;
const crit = (ev) => ev.readiness.filter((r) => r.status === 'FAIL' && r.critical).map((r) => r.id);
const opt = { skip: !has && 'gerçek veri yok' };

test('gerçek veri: Ay B, Mars A, Mars B kritik FAIL içermez', opt, () => {
  for (const [m, b, st] of [['lunar', S.lunarB, { consumableMarginDays: 2 }], ['mars', S.marsA, {}], ['mars', S.marsB, { powerMode: 'eco' }]]) {
    const ev = sim.evaluate(m, b, st);
    assert.deepEqual(crit(ev), [], `${m}: ${crit(ev).join(', ')}`);
  }
});

test('gerçek veri: Ay A kritik FAIL içermez (RL10 sınıfı iniş motoru, iniş TWR ≥ 1,5)', opt, () => {
  const ev = sim.evaluate('lunar', S.lunarA, { consumableMarginDays: 3 });
  assert.deepEqual(crit(ev), []);
});

test('gerçek veri: açgözlü yapılandırmalar kalır', opt, () => {
  const lunarGreedy = S.lunarA.map((x) => (x.itemId === 'lv-icps' ? Object.assign({}, x, { itemId: 'lv-eus' })
    : x.itemId === 'cv-sm-esm' ? Object.assign({}, x, { itemId: 'cv-sm-xl' }) : x));
  const lg = sim.evaluate('lunar', lunarGreedy, {});
  assert.ok(crit(lg).includes('capacity-launch-vehicle'));
  assert.equal(lg.readiness.find((r) => r.id === 'budget').status, 'FAIL');
  const marsGreedy = S.marsA.concat(S.build([['in-moxie', 'rover'], ['in-caching', 'rover']]).map((x, i) => Object.assign(x, { uid: `g${i}` })));
  assert.ok(crit(sim.evaluate('mars', marsGreedy, {})).includes('instrument-capacity'));
  // yakıt doluluğu 0,85'te Ay B fırlatma Δv'si yetmez
  const low = sim.evaluate('lunar', S.lunarB, { propellantLoad: 0.85 });
  assert.ok(crit(low).some((id) => id.startsWith('dv-')));
});
