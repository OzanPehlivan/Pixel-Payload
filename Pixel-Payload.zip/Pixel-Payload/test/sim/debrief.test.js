'use strict';
const test = require('node:test');
const assert = require('node:assert/strict');
const { createSim } = require('../../server/sim');
const F = require('../fixtures/mini');

const sim = createSim(F.data());
const IDS = ['objectives', 'engineering', 'fuel', 'power', 'comms', 'science', 'scienceGoals', 'budget', 'events', 'failed', 'team'];
const team = { designSec: 600, reviewRounds: 1, chat: { rocket: 4, spacecraft: 2, payload: 0 }, signoffs: 4 };

function run(mission, build, settings, seed, t = team) {
  const ev = sim.evaluate(mission, build, settings);
  const sr = sim.simulate(mission, build, settings, seed);
  return { ev, sr, d: sim.debrief(mission, ev, sr, t) };
}

test('debrief alanları, bölümler ve puan aralığı', () => {
  const { sr, d } = run('mars', F.GOOD_MARS, {}, 1);
  assert.equal(d.outcome, sr.outcome);
  assert.deepEqual(d.sections.map((s) => s.id), IDS);
  for (const s of d.sections) {
    assert.equal(typeof s.title, 'string');
    assert.ok(s.score >= 0 && s.score <= s.max);
    assert.ok(Array.isArray(s.lines));
  }
  assert.ok(d.score >= 0 && d.score <= 1000);
  assert.ok([0, 1, 2, 3].includes(d.stars));
  assert.ok(d.lessons.length > 0 && d.lessons.every((l) => typeof l === 'string'));
  assert.match(d.nasaReality, /NASA/);
  assert.ok(d.sources.length > 0 && d.sources.every((s) => s.title && s.url));
  assert.equal(d.sources.length, 1); // yalnız görevde kullanılan kaynak (src-b)
});

test('ekip koordinasyonu sohbet, inceleme turu ve onaylardan', () => {
  const { d } = run('mars', F.GOOD_MARS, {}, 1);
  const t = d.sections.find((s) => s.id === 'team');
  assert.ok(t.lines.some((l) => /İtki ↔ Operatör: 4 mesaj/.test(l)));
  assert.ok(t.lines.some((l) => /İnceleme turu: 1/.test(l)));
  const quiet = run('mars', F.GOOD_MARS, {}, 1, { designSec: 4000, reviewRounds: 5, chat: {}, signoffs: 0 }).d;
  assert.ok(quiet.sections.find((s) => s.id === 'team').score < t.score);
  assert.ok(quiet.lessons.some((l) => /Operatör/.test(l)));
});

test('başarısızlık 0 yıldız; tetiklenen kurallardan dersler', () => {
  const { sr, d } = run('lunar', F.swap(F.GOOD_LUNAR, 'c-eclss', 'c-eclss-small'), {}, 5);
  assert.equal(sr.outcome, 'failure');
  assert.equal(d.stars, 0);
  assert.ok(d.lessons.some((l) => /Yaşam desteği/.test(l)));
  const good = run('lunar', F.GOOD_LUNAR, {}, 3).d;
  assert.ok(good.score > d.score);
});

test('bozuk girdiye dayanıklı', () => {
  assert.equal(sim.debrief('yok', null, null, null).error, 'INVALID_MISSION');
  const d = sim.debrief('lunar', null, null, null);
  assert.equal(d.outcome, 'failure');
  assert.deepEqual(d.sections.map((s) => s.id), IDS);
});
