'use strict';
// Grup 2 dengelemesi: gerçek veriyle dört aday çözüm geçer, açgözlü yapılandırmalar kalır.
const test = require('node:test');
const assert = require('node:assert/strict');
const fs = require('fs');
const path = require('path');
const { createSim } = require('../../server/sim');
const S = require('../fixtures/solutions');

const dataDir = path.join(__dirname, '..', '..', 'data');
const has = ['lunar', 'mars'].every((m) => fs.existsSync(path.join(dataDir, 'missions', `${m}.json`)));
const sim = has ? createSim({ dataDir }) : null;
const opt = { skip: !has && 'gerçek veri yok' };
const crit = (ev) => ev.readiness.filter((r) => r.status === 'FAIL' && r.critical).map((r) => r.id);
const SEED = 42;

// [ad, görev, yapılandırma, ayarlar, kabul edilen sim sonuçları]
const CANDIDATES = [
  ['Ay A', 'lunar', S.lunarA, { consumableMarginDays: 3 }, ['success']],
  ['Ay B', 'lunar', S.lunarB, { consumableMarginDays: 2 }, ['success']],
  ['Mars A', 'mars', S.marsA, {}, ['success', 'partial']],
  ['Mars B', 'mars', S.marsB, { powerMode: 'eco' }, ['success', 'partial']],
];

for (const [name, mission, build, settings, okOutcomes] of CANDIDATES) {
  test(`çözüm ${name}: evaluate kritik FAIL içermez`, opt, () => {
    const ev = sim.evaluate(mission, build, settings);
    assert.deepEqual(crit(ev), [], `${name}: ${crit(ev).join(', ')}`);
    assert.notEqual(ev.overall, 'FAIL');
  });
  test(`çözüm ${name}: simulate (tohum ${SEED}) ${okOutcomes.join('/')}`, opt, () => {
    const r = sim.simulate(mission, build, settings, SEED);
    assert.ok(okOutcomes.includes(r.outcome), `${name}: ${r.outcome} (${r.reason || ''})`);
    // aynı tohum → aynı sonuç
    assert.equal(sim.simulate(mission, build, settings, SEED).outcome, r.outcome);
  });
}

test('Ay iniş TWR ≥ minLanderTWR (A ve B)', opt, () => {
  for (const [b, st] of [[S.lunarA, { consumableMarginDays: 3 }], [S.lunarB, { consumableMarginDays: 2 }]]) {
    const item = sim.evaluate('lunar', b, st).readiness.find((r) => r.id === 'twr-landing');
    assert.ok(item && item.status !== 'FAIL', JSON.stringify(item));
  }
});

test('açgözlü Ay: fırlatma aracı alanı kritik FAIL + bütçe aşımı (kritik değil)', opt, () => {
  const ev = sim.evaluate('lunar', S.lunarGreedy, {});
  assert.ok(crit(ev).includes('capacity-launch-vehicle'));
  const b = ev.readiness.find((r) => r.id === 'budget');
  assert.equal(b.status, 'FAIL');
  assert.equal(b.critical, false);
  assert.equal(ev.launchStatus, 'INSUFFICIENT');
});

test('açgözlü Mars: alet yuvası ve gezgin alanı kritik FAIL', opt, () => {
  const c = crit(sim.evaluate('mars', S.marsGreedy, {}));
  assert.ok(c.includes('instrument-capacity') && c.includes('capacity-rover'), c.join(','));
});

test('çözümler: standart donanım dahil, kapasiteye sığar, 1–2 bilim hedefi hazır, üçü birden değil', opt, () => {
  for (const [name, mission, build, settings] of CANDIDATES) {
    for (const a of sim.autoItems(mission)) assert.ok(build.some((b) => b.itemId === a.itemId && b.moduleId === a.moduleId), `${name}: ${a.itemId}`);
    const ev = sim.evaluate(mission, build, settings);
    for (const [id, c] of Object.entries(ev.telemetry.capacity)) assert.ok(c.freeU >= 0, `${name}/${id}: ${c.usedU}/${c.capacityU}`);
    const ready = ev.telemetry.scienceGoals.filter((g) => g.status === 'ready').length;
    assert.ok(ready >= 1 && ready <= 2, `${name}: ${ready} hedef hazır`);
    assert.equal(ev.telemetry.budget.remaining >= 0, true, name);
    assert.ok(['READY', 'RISKY'].includes(ev.launchStatus), `${name}: ${ev.launchStatus}`);
  }
});
