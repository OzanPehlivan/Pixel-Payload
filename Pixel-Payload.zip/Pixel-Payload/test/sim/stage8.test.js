'use strict';
// Aşama 8: alan (U), standart donanım, bütçe defteri verisi, hazırlık türleri, bilim hedefleri, yeni ayarlar.
const test = require('node:test');
const assert = require('node:assert/strict');
const fs = require('fs');
const path = require('path');
const { createSim } = require('../../server/sim');
const F = require('../fixtures/mini');
const S = require('../fixtures/solutions');

const s8 = createSim(F.stage8Data());
const mini = createSim(F.data());
const dataDir = path.join(__dirname, '..', '..', 'data');
const has = ['lunar', 'mars'].every((m) => fs.existsSync(path.join(dataDir, 'missions', `${m}.json`)));
const real = has ? createSim({ dataDir }) : null;
const opt = { skip: !has && 'gerçek veri yok' };
const byId = (ev, id) => ev.readiness.find((r) => r.id === id);

test('autoItems: auto kategoriler, bilinmeyen görev ve eski veri → []', () => {
  assert.deepEqual(s8.autoItems('mars'), [{ itemId: 'm-computer', moduleId: 'rover', role: 'spacecraft' }]);
  assert.deepEqual(s8.autoItems('yok'), []);
  assert.deepEqual(mini.autoItems('mars'), []);
});

test('canAdd: NO_SPACE gerekçesiyle; alan boşalınca takılır; kapasitesiz modül sınırsız', () => {
  const r = s8.canAdd(F.GOOD_MARS, 'mars', 'payload', 'm-bigdata', 'rover');
  assert.equal(r.ok, false);
  assert.equal(r.error, 'NO_SPACE');
  assert.match(r.reason, /kullanılan 10\/10 U, parça 1 U/);
  assert.deepEqual(s8.canAdd(F.without(F.GOOD_MARS, 'm-spec'), 'mars', 'payload', 'm-bigdata', 'rover'), { ok: true });
  // auto parça (bilgisayar) da alan sayar: o çıkarılırsa yer açılır
  assert.deepEqual(s8.canAdd(F.without(F.GOOD_MARS, 'm-computer'), 'mars', 'payload', 'm-bigdata', 'rover'), { ok: true });
  assert.deepEqual(mini.canAdd(F.GOOD_MARS, 'mars', 'payload', 'm-bigdata', 'rover'), { ok: true });
});

test('telemetry.capacity / budget ve taşma kalemi', () => {
  const ev = s8.evaluate('mars', F.GOOD_MARS, {});
  assert.deepEqual(ev.telemetry.capacity.rover, { name: 'Gezgin', usedU: 10, capacityU: 10, freeU: 0, byRole: { rocket: 0, spacecraft: 8, payload: 2 } });
  assert.equal(ev.telemetry.capacity.edl.capacityU, null);
  assert.equal(ev.telemetry.capacity.edl.freeU, null);
  const b = ev.telemetry.budget;
  assert.equal(b.budget, 900);
  assert.equal(b.spent, ev.telemetry.cost);
  assert.equal(b.remaining, 900 - b.spent);
  assert.equal(b.byRole.rocket + b.byRole.spacecraft + b.byRole.payload, b.spent);
  const over = s8.evaluate('mars', F.withItem(F.GOOD_MARS, 'm-bigdata', 'rover'), {});
  const c = byId(over, 'capacity-rover');
  assert.equal(c.status, 'FAIL');
  assert.equal(c.critical, true);
  assert.equal(c.kind, 'physical');
});

test('hazırlık türleri ve launchStatus: READY / RISKY / MISSING / INSUFFICIENT', () => {
  const good = s8.evaluate('mars', F.GOOD_MARS, {});
  assert.equal(good.launchStatus, 'READY');
  assert.ok(good.readiness.every((r) => r.kind === 'ok'));
  const kinds = ['ok', 'missing', 'physical', 'risky', 'budget'];
  const noComp = s8.evaluate('mars', F.without(F.GOOD_MARS, 'm-computer'), {});
  assert.equal(noComp.launchStatus, 'MISSING');
  assert.equal(byId(noComp, 'cat-rover-rover-computer').kind, 'missing');
  const noLink = s8.evaluate('mars', F.without(F.without(F.GOOD_MARS, 'm-uhf'), 'm-xband'), {});
  assert.equal(byId(noLink, 'comms-link').kind, 'missing');
  const weak = mini.evaluate('lunar', F.swap(F.GOOD_LUNAR, 'l-core', 'l-core-small'), {});
  assert.equal(weak.launchStatus, 'INSUFFICIENT');
  assert.ok(weak.readiness.filter((r) => r.id.startsWith('dv-') && r.status === 'FAIL').every((r) => r.kind === 'physical'));
  const risky = mini.evaluate('lunar', F.GOOD_LUNAR, { consumableMarginDays: 8 });
  assert.equal(risky.launchStatus, 'RISKY');
  for (const ev of [good, noComp, noLink, weak, risky]) for (const r of ev.readiness) assert.ok(kinds.includes(r.kind), r.id);
  assert.equal(mini.evaluate('yok', [], {}).launchStatus, 'INSUFFICIENT');
});

test('bilim hedefleri: ready / partial / missing + eksik etiket adları + öncelik', () => {
  const g = (ev) => Object.fromEntries(ev.telemetry.scienceGoals.map((x) => [x.id, x]));
  const ev = g(s8.evaluate('mars', F.GOOD_MARS, {}));
  assert.equal(ev['g-img'].status, 'ready');
  assert.equal(ev['g-chem'].status, 'ready');
  assert.equal(ev['g-big'].status, 'missing');
  assert.deepEqual(ev['g-big'].missingTags, ['bigdata']);
  assert.deepEqual(ev['g-big'].missingNames, ['Büyük veri']);
  assert.equal(ev['g-big'].value, 25);
  const part = g(s8.evaluate('mars', F.without(F.GOOD_MARS, 'm-spec'), {}));
  assert.equal(part['g-chem'].status, 'partial');
  assert.deepEqual(part['g-chem'].missingTags, ['chem']);
  const ex = g(s8.evaluate('mars', F.GOOD_MARS, { samplePriority: 'explore' }));
  assert.equal(ex['g-img'].status, 'partial');
  assert.ok(ex['g-img'].limitedBy.includes('priority'));
  // öncelik genel bilimi değiştirir: explore > balanced > goals
  const sv = (p) => s8.evaluate('mars', F.GOOD_MARS, { samplePriority: p }).telemetry.science.value;
  assert.ok(sv('explore') > sv('balanced') && sv('balanced') > sv('goals'));
  assert.deepEqual(mini.evaluate('mars', F.GOOD_MARS, {}).telemetry.scienceGoals, []);
});

test('simulate: bilim hedefi sonuçları ve eksik sistem olasılıklı (kesin değil)', () => {
  const r = s8.simulate('mars', F.GOOD_MARS, {}, 1);
  const sg = Object.fromEntries(r.scienceGoals.map((x) => [x.id, x]));
  assert.equal(sg['g-img'].done, true);
  assert.equal(sg['g-big'].done, false);
  assert.match(sg['g-big'].reason, /Eksik ekipman: Büyük veri/);
  const ex = s8.simulate('mars', F.GOOD_MARS, { samplePriority: 'explore' }, 1);
  assert.ok(ex.scienceGoals.every((x) => !x.done));
  // zorunlu ama fiziksel olmayan eksik → bazı tohumlarda aşama kaybı, bazılarında yalnız hasar
  let fail = 0, ok = 0;
  for (let i = 0; i < 30; i++) {
    const s = s8.simulate('mars', F.without(F.GOOD_MARS, 'm-computer'), {}, i);
    if (s.phases.some((p) => p.status === 'fail')) fail++; else ok++;
  }
  assert.ok(fail > 0 && ok > 0, `fail ${fail}, ok ${ok}`);
  // bütçe aşımı simülasyonu etkilemez
  const d = F.data();
  d.missions[1].budget = 10;
  assert.deepEqual(createSim(d).simulate('mars', F.GOOD_MARS, {}, 7).phases, mini.simulate('mars', F.GOOD_MARS, {}, 7).phases);
});

test('debrief: bölüm toplamı 1000, bilim hedefleri, bütçe aşımı cezası + ders', () => {
  const ev = s8.evaluate('mars', F.GOOD_MARS, {});
  const d = s8.debrief('mars', ev, s8.simulate('mars', F.GOOD_MARS, {}, 1), {});
  assert.equal(d.sections.reduce((a, s) => a + s.max, 0), 1000);
  assert.deepEqual(d.budget, { budget: 900, spent: ev.telemetry.budget.spent, overrun: 0, overrunPct: 0, penalty: 0 });
  assert.deepEqual(d.scienceGoals.map((x) => [x.id, x.done]), [['g-img', true], ['g-chem', true], ['g-big', false]]);
  const dd = F.data();
  dd.missions[0].budget = 800;
  const ps = createSim(dd);
  const pe = ps.evaluate('lunar', F.GOOD_LUNAR, {});
  const pd = ps.debrief('lunar', pe, ps.simulate('lunar', F.GOOD_LUNAR, {}, 3), {});
  assert.ok(pd.budget.overrun > 0 && pd.budget.penalty > 0);
  assert.equal(pd.sections.find((s) => s.id === 'budget').score, 0);
  assert.ok(pd.lessons.some((l) => /Bütçe aşımı/.test(l)));
  const base = mini.debrief('lunar', mini.evaluate('lunar', F.GOOD_LUNAR, {}), mini.simulate('lunar', F.GOOD_LUNAR, {}, 3), {});
  assert.ok(pd.score <= base.score - pd.budget.penalty);
});

test('gerçek veri: yeni ayarlar evaluate\'i gerçekten değiştirir', opt, () => {
  const A = (st) => real.evaluate('lunar', S.lunarA, Object.assign({ consumableMarginDays: 3 }, st));
  const dvL = (p) => A({ ascentProfile: p }).telemetry.dv.launch.required;
  assert.ok(dvL('lofted') > dvL('standard') && dvL('standard') > dvL('depressed'));
  const r0 = A({ landingReservePct: 0 }), r10 = A({ landingReservePct: 10 });
  assert.ok(r10.telemetry.dv.landing.required > r0.telemetry.dv.landing.required);
  assert.ok(r10.telemetry.landing.hazard < r0.telemetry.landing.hazard);
  const M = (st) => real.evaluate('mars', S.marsA, st);
  const lo = M({ commsPlan: 'minimal' }), hi = M({ commsPlan: 'continuous' });
  assert.ok(hi.telemetry.comms.downlinkMbPerSol > lo.telemetry.comms.downlinkMbPerSol);
  assert.ok(hi.telemetry.power.useW > lo.telemetry.power.useW);
  const sci = (p) => M({ samplePriority: p }).telemetry.science.value;
  assert.ok(sci('explore') > sci('goals'));
  // yeni ayarlar görevde tanımlı, Türkçe etiketli
  for (const m of ['lunar', 'mars']) {
    const defs = real.getMission(m).settings;
    for (const [key, role] of [['landingReservePct', 'rocket'], ['ascentProfile', 'rocket'], ['commsPlan', 'spacecraft'], ['samplePriority', 'payload']]) {
      const d = defs.find((s) => s.key === key);
      assert.ok(d && d.role === role && d.label, `${m}/${key}`);
      if (d.type === 'enum') for (const o of d.options) assert.ok(d.optionInfo[o].label && d.optionInfo[o].desc, `${m}/${key}/${o}`);
    }
  }
});

test('gerçek veri: her parçada volumeU, her modülde capacityU; auto kategoriler tek seçenekli; 3 hedef', opt, () => {
  for (const m of ['lunar', 'mars']) {
    const mission = real.getMission(m);
    assert.equal(mission.scienceGoals.length, 3);
    for (const mod of mission.modules) {
      assert.ok(mod.capacityU > 0, mod.id);
      for (const c of mod.categories.filter((x) => x.auto)) {
        const opts = ['rocket', 'spacecraft', 'payload'].flatMap((r) => real.catalogFor(m, r)).filter((i) => i.module === mod.id && i.category === c.category);
        assert.equal(opts.length, 1, `${mod.id}/${c.category}`);
      }
    }
    for (const r of ['rocket', 'spacecraft', 'payload']) for (const it of real.catalogFor(m, r)) assert.ok(Number.isInteger(it.volumeU) && it.volumeU >= 0, it.id);
    assert.ok(real.autoItems(m).length > 0);
  }
  // Ay: matkap ve sismometre birlikte takılamaz; Mars: önbellek A çözümüne sığmaz
  assert.equal(real.canAdd(S.lunarA, 'lunar', 'payload', 'sk-sci-station', 'surface-kit').error, 'INCOMPATIBLE');
  assert.equal(real.canAdd(S.marsA, 'mars', 'payload', 'in-caching', 'rover').error, 'NO_SPACE');
});

test('Tur 1: debrief skoru = bölüm toplamı + düzeltmeler (başarısızlık ve bütçe aşımı görünür)', () => {
  const dd = F.data();
  dd.missions[0].budget = 800;
  const ps = createSim(dd);
  const cases = [
    [mini, 'mars', F.GOOD_MARS, 1],
    [ps, 'lunar', F.GOOD_LUNAR, 3],                                   // aşım, başarı
    [mini, 'lunar', F.swap(F.GOOD_LUNAR, 'c-eclss', 'c-eclss-small'), 5], // başarısız
    [ps, 'lunar', F.swap(F.GOOD_LUNAR, 'c-eclss', 'c-eclss-small'), 5],   // başarısız + aşım
  ];
  for (const [s, m, b, seed] of cases) {
    const ev = s.evaluate(m, b, {});
    const d = s.debrief(m, ev, s.simulate(m, b, {}, seed), {});
    const total = d.sections.reduce((a, x) => a + x.score, 0);
    assert.equal(d.sectionTotal, total);
    assert.equal(d.score, total + d.adjustments.reduce((a, x) => a + x.points, 0), `${m}/${seed}`);
    assert.ok(d.score >= 0);
    for (const a of d.adjustments) assert.ok(a.points < 0 && a.title && a.text);
    if (d.outcome === 'failure') assert.ok(d.adjustments.some((a) => a.id === 'mission-failure'));
    if (d.budget.overrun > 0) assert.ok(d.adjustments.some((a) => a.id === 'budget-overrun'));
  }
});

test('Tur 1: gereksinim metninde Türkçe adlar, launchNote ve ısı etiketi', () => {
  const ev = mini.evaluate('lunar', F.without(F.GOOD_LUNAR, 'd-tank'), {});
  const r = ev.readiness.find((x) => x.id === 'req-d-engine');
  assert.ok(!r.text.includes('propellant-x') && r.text.includes('İniş tankı'), r.text);
  assert.deepEqual(ev.unmetRequirements[0].requires, ['propellant-x']);
  assert.equal(typeof ev.launchNote, 'string');
  assert.ok(['Uygun', 'Uyarı'].includes(ev.telemetry.thermal.label));
});

test('Tur 1: gerçek veride ham İngilizce etiket ve "yakış" yok; READY Ay A başarısızlığı ≲%10', opt, () => {
  const all = [];
  for (const [itemId] of [['ld-eng-hydrolox']]) {
    const ev = real.evaluate('lunar', S.lunarA.filter((b) => b.itemId !== 'ld-tank-hydrolox' && b.itemId !== 'ld-power-solar'), {});
    const t = ev.readiness.filter((x) => x.id.startsWith('req-')).map((x) => x.text).join(' ');
    assert.ok(t.length > 0 && !/propellant-|surface-power-supply/.test(t), t);
    all.push(itemId);
  }
  for (const m of ['lunar', 'mars']) assert.ok(!/yakış/.test(JSON.stringify(real.getMission(m))));
  let fail = 0;
  for (let i = 0; i < 200; i++) if (real.simulate('lunar', S.lunarA, { consumableMarginDays: 3 }, i).outcome === 'failure') fail++;
  assert.ok(fail / 200 <= 0.1, `başarısız ${fail}/200`);
});
