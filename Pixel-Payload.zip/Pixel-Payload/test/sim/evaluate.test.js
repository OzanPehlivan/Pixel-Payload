'use strict';
const test = require('node:test');
const assert = require('node:assert/strict');
const { createSim } = require('../../server/sim');
const F = require('../fixtures/mini');

const sim = createSim(F.data());
const byId = (ev, id) => ev.readiness.find((r) => r.id === id);
const noDigits = (s) => !/\d/.test(s);

test('iyi yapılandırmalar: biçim ve kritik FAIL yok', () => {
  for (const [m, b] of [['lunar', F.GOOD_LUNAR], ['mars', F.GOOD_MARS]]) {
    const ev = sim.evaluate(m, b, {});
    assert.equal(ev.overall, 'PASS', JSON.stringify(ev.readiness.filter((r) => r.status !== 'PASS')));
    const t = ev.telemetry;
    for (const k of ['massKg', 'cost', 'budget', 'twr', 'stages', 'dv', 'power', 'thermal', 'comms', 'lifeSupport', 'edl', 'science']) assert.ok(k in t, k);
    assert.ok(t.massKg.total > 0 && t.massKg.byModule && t.massKg.byRole);
    assert.ok(t.stages.every((s) => typeof s.id === 'string' && typeof s.dvMs === 'number'));
    for (const r of ev.readiness) {
      assert.ok(['PASS', 'WARN', 'FAIL'].includes(r.status));
      assert.equal(typeof r.critical, 'boolean');
      assert.equal(typeof r.text, 'string');
      assert.ok(['director', 'rocket', 'spacecraft', 'payload'].includes(r.role));
    }
    assert.deepEqual(Object.keys(ev.needs).sort(), ['payload', 'rocket', 'spacecraft']);
    assert.deepEqual(ev.unmetRequirements, []);
    assert.match(t.model, /eğitsel/);
  }
  const lunar = sim.evaluate('lunar', F.GOOD_LUNAR, {});
  assert.equal(lunar.telemetry.edl, null);
  assert.deepEqual(Object.keys(lunar.telemetry.lifeSupport).sort(), ['co2Days', 'crew', 'days', 'o2Days', 'waterDays']);
  const mars = sim.evaluate('mars', F.GOOD_MARS, {});
  assert.equal(mars.telemetry.lifeSupport, null);
  assert.deepEqual(Object.keys(mars.telemetry.edl).sort(), ['chuteMach', 'entryMs', 'hazard', 'landingVms', 'peakHeatWcm2', 'shieldMaxWcm2']);
});

test('seri kademe: kalkış TWR deniz seviyesi itkisiyle, aşama Δv\'leri sırayla', () => {
  const ev = sim.evaluate('lunar', F.GOOD_LUNAR, {});
  // (8e6 + 3.5e6) / (kalkış kütlesi × g0)
  const expected = 11.5e6 / (ev.telemetry.massKg.launch * 9.80665);
  assert.ok(Math.abs(ev.telemetry.twr - expected) < 0.01);
  // iniş aracı ayrı fırlatılır: kalkış kütlesi toplamdan küçük
  assert.ok(ev.telemetry.massKg.launch < ev.telemetry.massKg.total);
  assert.ok(ev.telemetry.stages.some((s) => s.id === 'launch-vehicle:3'));
  assert.ok(ev.telemetry.dv.tli.available >= ev.telemetry.dv.tli.required);
  // doluluk oranı düşünce Δv düşer
  const low = sim.evaluate('lunar', F.GOOD_LUNAR, { propellantLoad: 0.6 });
  assert.ok(low.telemetry.dv.launch.available < ev.telemetry.dv.launch.available);
  assert.equal(byId(low, 'dv-tli').status, 'FAIL');
});

test('zincir: kütle fazlası → itki Δv (cascadeFrom, sayısız metin)', () => {
  const ev = sim.evaluate('lunar', F.swap(F.GOOD_LUNAR, 'l-core', 'l-core-small'), {});
  const own = ev.readiness.find((r) => r.id.startsWith('dv-') && r.status === 'FAIL');
  assert.ok(own && own.critical && own.role === 'rocket');
  const c = byId(ev, 'mass-dv');
  assert.equal(c.role, 'rocket');
  assert.ok(c.cascadeFrom.includes('spacecraft'));
  assert.ok(noDigits(c.text), c.text);
  assert.equal(ev.overall, 'FAIL');
});

test('zincir: güç açığı → uzay aracı + bilim (+ yaşam desteği)', () => {
  const ev = sim.evaluate('lunar', F.withItem(F.GOOD_LUNAR, 's-heater-hog', 'surface-kit'), {});
  const p = byId(ev, 'power');
  assert.ok(['WARN', 'FAIL'].includes(p.status));
  assert.equal(p.role, 'spacecraft');
  const ps = byId(ev, 'power-science');
  assert.equal(ps.role, 'payload');
  assert.deepEqual(ps.cascadeFrom, ['spacecraft']);
  assert.ok(noDigits(ps.text));
  assert.match(ps.text, /güç alamıyor/);
  assert.ok(byId(ev, 'power-comms').cascadeFrom.includes('payload')); // açığı aletler yarattı
  // kabin barası açığı → yaşam desteği zinciri
  const ev2 = sim.evaluate('lunar', F.swap(F.GOOD_LUNAR, 'c-solar', 'c-solar-tiny'), {});
  const pl = byId(ev2, 'power-life');
  assert.ok(pl && pl.cascadeFrom.length && noDigits(pl.text));
  assert.ok(ev2.telemetry.lifeSupport.co2Days < sim.evaluate('lunar', F.GOOD_LUNAR, {}).telemetry.lifeSupport.co2Days);
  // güç modu tüketimi değiştirir
  const max = sim.evaluate('lunar', F.GOOD_LUNAR, { powerMode: 'max' });
  assert.ok(max.telemetry.power.useW > sim.evaluate('lunar', F.GOOD_LUNAR, {}).telemetry.power.useW);
});

test('zincir: iletişim < veri → bilim uyarısı; ısı → batarya', () => {
  const ev = sim.evaluate('lunar', F.swap(F.GOOD_LUNAR, 'd-comm', 'd-comm-slow'), {});
  assert.equal(byId(ev, 'comms-capacity').status, 'WARN');
  const cs = byId(ev, 'comms-science');
  assert.deepEqual(cs.cascadeFrom, ['spacecraft']);
  assert.equal(cs.role, 'payload');
  assert.ok(noDigits(cs.text));
  assert.ok(ev.telemetry.science.value < sim.evaluate('lunar', F.GOOD_LUNAR, {}).telemetry.science.value);

  const hot = sim.evaluate('lunar', F.without(F.GOOD_LUNAR, 'c-radiator'), {});
  assert.equal(byId(hot, 'thermal').status, 'WARN');
  const tb = byId(hot, 'thermal-battery');
  assert.ok(tb && noDigits(tb.text));
  const base = sim.evaluate('lunar', F.GOOD_LUNAR, {}).telemetry.power.buses.find((b) => b.id === 'crew-vehicle');
  assert.ok(hot.telemetry.power.buses.find((b) => b.id === 'crew-vehicle').batteryWh < base.batteryWh);
});

test('zincir: iniş radarı yok → itki iniş kalemi WARN', () => {
  const ev = sim.evaluate('lunar', F.without(F.GOOD_LUNAR, 'd-radar'), {});
  assert.equal(byId(ev, 'landing-sensor').status, 'WARN');
  const r = byId(ev, 'landing-sensor-rocket');
  assert.equal(r.role, 'rocket');
  assert.deepEqual(r.cascadeFrom, ['spacecraft']);
  assert.ok(noDigits(r.text));
  assert.ok(ev.telemetry.landing.hazard > sim.evaluate('lunar', F.GOOD_LUNAR, {}).telemetry.landing.hazard);
});

test('needs: başka rolün değerleri value+unit+fromRole ile', () => {
  const ev = sim.evaluate('lunar', F.GOOD_LUNAR, {});
  const find = (role, id) => ev.needs[role].find((n) => n.id === id);
  for (const role of ['rocket', 'spacecraft', 'payload']) {
    for (const n of ev.needs[role]) {
      assert.equal(typeof n.label, 'string');
      assert.equal(typeof n.unit, 'string');
      assert.equal(typeof n.value, 'number');
      assert.notEqual(n.fromRole, role);
    }
  }
  assert.equal(find('rocket', 'upper-mass-spacecraft').value, ev.telemetry.massKg.byRole.spacecraft);
  assert.equal(find('rocket', 'upper-mass-payload').fromRole, 'payload');
  assert.ok(find('spacecraft', 'payload-power').value > 0);
  assert.equal(find('spacecraft', 'payload-data').value, 1000);
  assert.equal(find('spacecraft', 'landing-thrust').value, 60000);
  assert.ok(find('payload', 'available-power').value > 0);
  assert.equal(find('payload', 'downlink-capacity').fromRole, 'spacecraft');
});

test('gereksinim eksikliği: parça devre dışı + unmetRequirements', () => {
  const ev = sim.evaluate('lunar', F.without(F.GOOD_LUNAR, 'd-tank'), {});
  assert.equal(byId(ev, 'req-d-engine').status, 'FAIL');
  assert.ok(ev.unmetRequirements.some((u) => u.itemId === 'd-engine' && u.requires.includes('propellant-x')));
  assert.equal(byId(ev, 'cat-lander-lander-tank').critical, true);
  assert.equal(byId(ev, 'dv-landing').status, 'FAIL');
});

test('yaşam desteği, bütçe, dönüş kalkanı', () => {
  const ev = sim.evaluate('lunar', F.swap(F.GOOD_LUNAR, 'c-eclss', 'c-eclss-small'), {});
  for (const id of ['life-o2', 'life-water', 'life-co2']) assert.equal(byId(ev, id).status, 'FAIL');
  assert.equal(byId(ev, 'life-o2').critical, true);
  // yedek gün kapasiteyi aşarsa WARN
  const tight = sim.evaluate('lunar', F.GOOD_LUNAR, { consumableMarginDays: 8 });
  assert.equal(byId(tight, 'life-water').status, 'WARN');
  const noShield = sim.evaluate('lunar', F.swap(F.GOOD_LUNAR, 'c-capsule', 'c-capsule-noshield'), {});
  assert.equal(byId(noShield, 'reentry-shield').status, 'FAIL');
  const d = F.data();
  d.missions[0].budget = 100;
  const poor = createSim(d).evaluate('lunar', F.GOOD_LUNAR, {});
  const bud = byId(poor, 'budget');
  assert.equal(bud.status, 'FAIL');
  assert.equal(bud.role, 'director');
  // Aşama 8: bütçe aşımı kritik değil (kind: budget), fırlatma durumu bütçeden etkilenmez
  assert.equal(bud.critical, false);
  assert.equal(bud.kind, 'budget');
  assert.equal(poor.overall, 'WARN');
  assert.equal(poor.launchStatus, 'READY');
});

test('Mars EDL: kalkan, paraşüt Mach, alet yuvası, iniş TWR', () => {
  const weak = sim.evaluate('mars', F.swap(F.GOOD_MARS, 'm-shield', 'm-shield-weak'), {});
  assert.equal(byId(weak, 'edl-shield').status, 'FAIL');
  const slow = sim.evaluate('mars', F.swap(F.GOOD_MARS, 'm-chute', 'm-chute-slow'), {});
  assert.equal(byId(slow, 'edl-chute').status, 'FAIL');
  const heavy = sim.evaluate('mars', F.withItem(F.GOOD_MARS, 'm-heavy', 'rover'), {});
  assert.equal(byId(heavy, 'instrument-capacity').status, 'FAIL');
  const good = sim.evaluate('mars', F.GOOD_MARS, {});
  assert.equal(byId(good, 'twr-powered-descent').status, 'PASS');
  assert.ok(good.telemetry.edl.peakHeatWcm2 > 0 && good.telemetry.edl.peakHeatWcm2 < 250);
  assert.equal(good.telemetry.edl.chuteMach, 1.75);
  // güneş paneli toz çarpanıyla
  const solar = sim.evaluate('mars', F.swap(F.GOOD_MARS, 'm-rtg', 'm-solar'), {});
  assert.equal(solar.telemetry.power.genW, 105);
});

test('girdi doğrulama: bilinmeyen görev/parça istisna atmaz', () => {
  const bad = sim.evaluate('yok', [], {});
  assert.equal(bad.ok, false);
  assert.equal(bad.error, 'INVALID_MISSION');
  const ev = sim.evaluate('lunar', F.GOOD_LUNAR.concat([{ uid: 'zz', itemId: 'olmayan', moduleId: 'lander' }, null]), {});
  assert.ok(ev.readiness.some((r) => r.id.startsWith('invalid-')));
  assert.notEqual(ev.overall, 'FAIL');
  assert.doesNotThrow(() => sim.evaluate('lunar', 'çöp', 42));
});
