'use strict';
// Aşama 9: dil seçimi sonucu değiştirmez; İngilizce çıktıda Türkçe kalmaz.
const test = require('node:test');
const assert = require('node:assert/strict');
const fs = require('fs');
const path = require('path');
const { createSim } = require('../../server/sim');
const { CATALOG, msg } = require('../../server/sim/i18n');
const S = require('../fixtures/solutions');

const TR_RX = /[çğıöşüÇĞİÖŞÜ]/;
const dataDir = path.join(__dirname, '..', '..', 'data');
const has = fs.existsSync(path.join(dataDir, 'missions', 'lunar.json'));
const hasOverlay = fs.existsSync(path.join(dataDir, 'i18n', 'en', 'missions-lunar.json'));

test('EN katalog metinlerinde Türkçe karakter yok; eksik anahtar TR\'ye düşer', () => {
  for (const [k, v] of Object.entries(CATALOG.en)) {
    const s = typeof v === 'function' ? v({ name: 'X', n: 1, seats: 2, crew: 2, endurance: 3, days: 3, margin: 1, h: '1', hazard: '1' }) : v;
    assert.ok(!TR_RX.test(s), `${k}: ${s}`);
  }
  for (const k of Object.keys(CATALOG.tr)) assert.ok(k in CATALOG.en, `EN eksik: ${k}`);
  assert.equal(msg('xx', 'add.duplicate'), 'Bu parça zaten takılı.');
});

test('aynı tohum, farklı dil → aynı durum/sonuç/puan', { skip: !has && 'gerçek veri yok' }, () => {
  const sim = createSim({ dataDir });
  for (const [m, b] of [['lunar', S.lunarA], ['mars', S.marsA], ['mars', S.marsB]]) {
    const st = sim.defaultSettings(m);
    for (const seed of [1, 42, 'abc']) {
      const et = sim.evaluate(m, b, st), ee = sim.evaluate(m, b, st, { lang: 'en' });
      const rt = sim.simulate(m, b, st, seed), re = sim.simulate(m, b, st, seed, { lang: 'en' });
      const dt = sim.debrief(m, et, rt, {}), de = sim.debrief(m, ee, re, {}, { lang: 'en' });
      assert.equal(ee.launchStatus, et.launchStatus);
      assert.deepEqual(ee.readiness.map((r) => r.status), et.readiness.map((r) => r.status));
      assert.deepEqual(re.phases.map((p) => p.status), rt.phases.map((p) => p.status));
      assert.equal(re.outcome, rt.outcome);
      assert.equal(de.score, dt.score);
      assert.deepEqual(ee.telemetry.massKg, et.telemetry.massKg);
    }
  }
});

test('İngilizce çıktıda Türkçe kalmaz (bindirme varsa ad/açıklamalar dahil)', { skip: !has && 'gerçek veri yok' }, () => {
  const sim = createSim({ dataDir });
  for (const [m, b] of [['lunar', S.lunarA], ['mars', S.marsA]]) {
    const st = sim.defaultSettings(m);
    const ev = sim.evaluate(m, b, st, { lang: 'en' });
    const r = sim.simulate(m, b, st, 3, { lang: 'en' });
    const d = sim.debrief(m, ev, r, {}, { lang: 'en' });
    // Bindirme yoksa veri adları Türkçe kalabilir: yalnız katalogdan gelen alanlar denetlenir
    const generated = [ev.launchNote, ...ev.readiness.filter((x) => !x.id.startsWith('req-') && !x.id.startsWith('cat-')).map((x) => x.system.replace(/^.*: /, '')),
      ...Object.values(ev.needs).flat().map((n) => n.label), ...d.lessons, ...d.sections.map((s) => s.title)];
    for (const s of generated) assert.ok(hasOverlay || !TR_RX.test(s) || /: /.test(s), s);
    if (hasOverlay) {
      const txt = JSON.stringify([ev, r, d, sim.getMission(m, 'en'), sim.listMissions('en'), sim.catalogFor(m, 'payload', 'en'), sim.catalogFor(m, 'rocket', 'en'), sim.catalogFor(m, 'spacecraft', 'en')]);
      const bad = txt.match(/[^"]{0,25}[çğıöşüÇĞİÖŞÜ][^"]{0,25}/g);
      assert.equal(bad, null, bad && bad.slice(0, 5).join(' | '));
    }
  }
  assert.equal(sim.canAdd([], 'lunar', 'rocket', 'yok', undefined, 'en').reason, 'No such part.');
});
