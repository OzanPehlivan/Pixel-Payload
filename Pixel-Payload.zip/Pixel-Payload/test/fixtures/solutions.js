'use strict';
// Modül Y'nin docs/VERI_KAYNAKLARI.md'deki aday çözümleri (gerçek veriyle denge kontrolü için).
// Aşama 8: standart donanım (auto) dahil, modül kapasitelerine (U) sığar; her çözüm 1–2 bilim hedefini hazırlar.
function build(list) {
  return list.map(([itemId, moduleId], i) => ({ uid: `u${i}`, itemId, moduleId }));
}
const LV = 'launch-vehicle', CV = 'crew-vehicle', LD = 'lander', SK = 'surface-kit';
const lunarA = build([
  ['lv-srb5', LV], ['lv-rs25x4', LV], ['lv-core', LV], ['lv-icps', LV], ['lv-sep', LV], ['lv-tvc', LV], ['lv-rcs', LV],
  ['cv-capsule-orion', CV], ['cv-sm-esm', CV], ['cv-las', CV], ['cv-eclss-amine', CV], ['cv-o2-large', CV], ['cv-water-tank', CV],
  ['cv-thermal-loop', CV], ['cv-rad-monitor', CV], ['cv-ant-sband', CV], ['cv-nav', CV], ['cv-fc-rad', CV], ['cv-solar-2w', CV],
  ['cv-battery', CV], ['cv-emergency-power', CV],
  ['ld-eng-hydrolox', LD], ['ld-tank-hydrolox', LD], ['ld-legs-4', LD], ['ld-cabin-airlock', LD], ['ld-radar-ka', LD],
  ['ld-hazard-lidar', LD], ['ld-avionics', LD], ['ld-comm-sband', LD], ['ld-power-solar', LD], ['ld-power-battery', LD],
  ['sk-suit-axemu', SK], ['sk-cam-hd', SK], ['sk-scoop', SK], ['sk-drill', SK], ['sk-env-station', SK], ['sk-rad-detector', SK],
]);
const lunarB = build([
  ['lv-srb5', LV], ['lv-rs25x3', LV], ['lv-core', LV], ['lv-icps', LV], ['lv-sep', LV], ['lv-tvc', LV], ['lv-rcs', LV],
  ['cv-capsule-lite', CV], ['cv-sm-esm', CV], ['cv-las', CV], ['cv-eclss-lioh', CV], ['cv-o2-large', CV], ['cv-water-tank', CV],
  ['cv-thermal-passive', CV], ['cv-rad-monitor', CV], ['cv-ant-sband', CV], ['cv-nav', CV], ['cv-fc-rad', CV], ['cv-solar-2w', CV],
  ['cv-battery', CV], ['cv-emergency-power', CV],
  ['ld-eng-methalox', LD], ['ld-tank-methalox', LD], ['ld-legs-4', LD], ['ld-cabin-simple', LD], ['ld-radar-sband', LD],
  ['ld-hazard-lidar', LD], ['ld-avionics', LD], ['ld-comm-relay', LD], ['ld-power-solar', LD],
  ['sk-suit-light', SK], ['sk-eva-o2', SK], ['sk-eva-battery', SK], ['sk-cam-hd', SK], ['sk-scoop', SK], ['sk-sci-station', SK],
  ['sk-env-station', SK], ['sk-rad-detector', SK],
]);
const CS = 'cruise-stage', ED = 'edl', RV = 'rover';
const marsA = build([
  ['mv-srb4', LV], ['mv-me-rd180', LV], ['mv-core-rp1', LV], ['mv-centaur-1', LV], ['mv-attitude', LV], ['mv-fairing', LV],
  ['cs-prop-hydrazine', CS], ['cs-solar', CS], ['cs-hrs', CS], ['cs-comms-mga', CS],
  ['edl-backshell', ED], ['edl-hs-pica', ED], ['edl-chute-21', ED], ['edl-radar-tds', ED], ['edl-imu', ED], ['edl-trn', ED],
  ['edl-skycrane', ED], ['edl-de-8', ED], ['edl-tank', ED],
  ['rv-chassis', RV], ['rv-wheels-al', RV], ['rv-mmrtg', RV], ['rv-battery', RV], ['rv-thermal-rtg', RV], ['rv-computer-dual', RV],
  ['rv-uhf', RV], ['rv-xband', RV], ['rv-arm', RV], ['rv-mast', RV],
  ['in-mastcamz', RV], ['in-supercam', RV], ['in-pixl', RV], ['in-sherloc', RV], ['in-meda', RV], ['in-rimfax', RV],
]);
const marsB = build([
  ['mv-srb2', LV], ['mv-me-rd180', LV], ['mv-core-rp1', LV], ['mv-centaur-1', LV], ['mv-attitude', LV], ['mv-fairing', LV],
  ['cs-prop-hydrazine', CS], ['cs-solar', CS], ['cs-thermal-passive', CS], ['cs-comms-mga', CS],
  ['edl-backshell', ED], ['edl-hs-pica', ED], ['edl-chute-21', ED], ['edl-radar-tds', ED], ['edl-imu', ED],
  ['edl-skycrane', ED], ['edl-de-8', ED], ['edl-tank', ED],
  ['rv-chassis-lite', RV], ['rv-wheels-al', RV], ['rv-solar', RV], ['rv-battery-xl', RV], ['rv-thermal-heaters', RV], ['rv-computer-dual', RV],
  ['rv-uhf', RV], ['rv-arm', RV], ['rv-mast', RV],
  ['in-mastcamz', RV], ['in-pixl', RV], ['in-sherloc', RV], ['in-meda', RV],
]);
// Açgözlü yapılandırmalar: kalmalı (Ay: fırlatma aracı alanı + bütçe aşımı; Mars: gezgin alanı + alet yuvası).
const swap = (list, map) => list.map((x) => (map[x.itemId] ? Object.assign({}, x, { itemId: map[x.itemId] }) : x));
const lunarGreedy = swap(lunarA, { 'lv-icps': 'lv-eus', 'cv-sm-esm': 'cv-sm-xl' });
const marsGreedy = marsA.concat(build([['in-moxie', RV], ['in-caching', RV]]).map((x, i) => Object.assign(x, { uid: `g${i}` })));
module.exports = { lunarA, lunarB, marsA, marsB, lunarGreedy, marsGreedy, build };
