'use strict';
// Küçük ama gerçekçi test verisi (PLAN şeması + Modül Y ek alanları). Gerçek veriden bağımsızdır.
// İyi yapılandırmalar: GOOD_LUNAR, GOOD_MARS (hazırlıkta kritik FAIL yok).

const v = (x, unit = '') => ({ v: x, unit, src: 'src-a', class: 'measured' });
const constants = {
  g0: v(9.80665, 'm/s2'),
  earth: { muM3s2: v(3.986e14), radiusM: v(6371000), surfaceGravity: v(9.8) },
  moon: { muM3s2: v(4.9e12), radiusM: v(1737400), surfaceGravity: v(1.62) },
  mars: { muM3s2: v(4.2828e13), radiusM: v(3389500), surfaceGravity: v(3.73),
    atmosphere: { surfaceDensityKgM3: v(0.016), scaleHeightM: v(11000), speedOfSoundMs: v(240) } },
  lightSpeedMs: v(299792458),
  distances: { earthMoonM: v(384400000), earthMarsMinM: v(54600000000), earthMarsMaxM: v(401400000000) },
};
const sources = [
  { id: 'src-a', title: 'Kaynak A', publisher: 'NASA', url: 'https://example.org/a', accessed: '2026-11-15' },
  { id: 'src-b', title: 'Kaynak B', publisher: 'NASA', url: 'https://example.org/b', accessed: '2026-11-15' },
];

const it = (o) => Object.assign({ icon: 'part', desc: 'Kısa açıklama', reliability: 0.995, tags: [], provides: [], requires: [] }, o);
const L = ['lunar'], M = ['mars'];
const equipment = [
  // --- Ay: fırlatma aracı (seri kademe 1/2/3)
  it({ id: 'l-booster', name: 'Yan itici', category: 'booster', role: 'rocket', module: 'launch-vehicle', missions: L, stage: 1, massKg: 50000, propellantKg: 400000, thrustN: 8e6, thrustSlN: 8e6, ispS: 270, cost: 150, refs: { massKg: { src: 'src-b', class: 'estimated' } } }),
  it({ id: 'l-core', name: 'Çekirdek kademe', category: 'core', role: 'rocket', module: 'launch-vehicle', missions: L, stage: 2, massKg: 30000, propellantKg: 350000, thrustN: 4e6, thrustSlN: 3.5e6, ispS: 440, cost: 200 }),
  it({ id: 'l-core-small', name: 'Küçük çekirdek', category: 'core', role: 'rocket', module: 'launch-vehicle', missions: L, stage: 2, massKg: 20000, propellantKg: 150000, thrustN: 2e6, thrustSlN: 1.8e6, ispS: 440, cost: 120 }),
  it({ id: 'l-upper', name: 'Üst kademe', category: 'upper-stage', role: 'rocket', module: 'launch-vehicle', missions: L, stage: 3, massKg: 3000, propellantKg: 30000, thrustN: 100000, ispS: 460, cost: 60 }),
  // --- Ay: mürettebat aracı
  it({ id: 'c-capsule', name: 'Kapsül', category: 'capsule', role: 'spacecraft', module: 'crew-vehicle', missions: L, massKg: 8000, powerW: 1000, crewCapacity: 2, maxMissionDays: 20, provides: ['crew-habitat', 'reentry-heat-shield'], requires: ['life-support-eclss'], cost: 150 }),
  it({ id: 'c-capsule-noshield', name: 'Kalkansız kapsül', category: 'capsule', role: 'spacecraft', module: 'crew-vehicle', missions: L, massKg: 7000, powerW: 1000, crewCapacity: 2, maxMissionDays: 20, provides: ['crew-habitat'], cost: 100 }),
  it({ id: 'c-sm', name: 'Servis modülü', category: 'service-module', role: 'spacecraft', module: 'crew-vehicle', missions: L, massKg: 5000, propellantKg: 6000, thrustN: 25000, ispS: 316, cost: 80 }),
  it({ id: 'c-las', name: 'Kaçış kulesi', category: 'abort', role: 'spacecraft', module: 'crew-vehicle', missions: L, massKg: 3000, tags: ['jettison-after-launch'], cost: 20 }),
  it({ id: 'c-eclss', name: 'ECLSS', category: 'eclss', role: 'spacecraft', module: 'crew-vehicle', missions: L, massKg: 500, powerW: 500, provides: ['life-support-eclss'], lifeSupport: { o2Kg: 30, waterKg: 70, co2ScrubPersonDays: 40 }, cost: 40 }),
  it({ id: 'c-eclss-small', name: 'Küçük ECLSS', category: 'eclss', role: 'spacecraft', module: 'crew-vehicle', missions: L, massKg: 300, powerW: 300, provides: ['life-support-eclss'], lifeSupport: { o2Kg: 10, waterKg: 30, co2ScrubPersonDays: 10 }, cost: 20 }),
  it({ id: 'c-solar', name: 'Güneş paneli', category: 'solar-array', role: 'spacecraft', module: 'crew-vehicle', missions: L, massKg: 300, powerGenW: 4000, tags: ['solar'], cost: 30 }),
  it({ id: 'c-solar-tiny', name: 'Küçük güneş paneli', category: 'solar-array', role: 'spacecraft', module: 'crew-vehicle', missions: L, massKg: 100, powerGenW: 500, tags: ['solar'], cost: 10 }),
  it({ id: 'c-radiator', name: 'Radyatör', category: 'thermal', role: 'spacecraft', module: 'crew-vehicle', missions: L, massKg: 100, heatRejectW: 3000, provides: ['heat-rejection'], cost: 10 }),
  it({ id: 'c-nav', name: 'Navigasyon', category: 'navigation', role: 'spacecraft', module: 'crew-vehicle', missions: L, massKg: 50, powerW: 100, provides: ['deep-space-nav'], cost: 10 }),
  it({ id: 'c-battery', name: 'Batarya', category: 'battery', role: 'spacecraft', module: 'crew-vehicle', missions: L, massKg: 100, batteryWh: 10000, tempRangeC: [0, 40], cost: 5 }),
  // --- Ay: iniş aracı
  it({ id: 'd-engine', name: 'İniş motoru', category: 'lander-engine', role: 'rocket', module: 'lander', missions: L, massKg: 500, thrustN: 60000, ispS: 350, provides: ['lander-propulsion'], requires: ['propellant-x'], cost: 40 }),
  it({ id: 'd-engine-weak', name: 'Zayıf iniş motoru', category: 'lander-engine', role: 'rocket', module: 'lander', missions: L, massKg: 300, thrustN: 15000, ispS: 350, provides: ['lander-propulsion'], requires: ['propellant-x'], cost: 20 }),
  it({ id: 'd-tank', name: 'İniş tankı', category: 'lander-tank', role: 'rocket', module: 'lander', missions: L, massKg: 2000, propellantKg: 12000, provides: ['propellant-x'], cost: 20 }),
  it({ id: 'd-radar', name: 'İniş radarı', category: 'landing-radar', role: 'spacecraft', module: 'lander', missions: L, massKg: 20, powerW: 80, provides: ['landing-radar'], tags: ['radar'], cost: 10 }),
  it({ id: 'd-solar', name: 'Yüzey güneş paneli', category: 'surface-power', role: 'spacecraft', module: 'lander', missions: L, massKg: 200, powerGenW: 2000, provides: ['surface-power-supply'], tags: ['solar'], cost: 15 }),
  it({ id: 'd-solar-tiny', name: 'Mini yüzey paneli', category: 'surface-power', role: 'spacecraft', module: 'lander', missions: L, massKg: 50, powerGenW: 100, provides: ['surface-power-supply'], tags: ['solar'], cost: 5 }),
  it({ id: 'd-comm', name: 'Yüzey vericisi', category: 'surface-comms', role: 'spacecraft', module: 'lander', missions: L, massKg: 20, powerW: 100, dataRateBps: 1e6, provides: ['surface-data-link'], cost: 10 }),
  it({ id: 'd-comm-slow', name: 'Yavaş verici', category: 'surface-comms', role: 'spacecraft', module: 'lander', missions: L, massKg: 10, powerW: 20, dataRateBps: 10, provides: ['surface-data-link'], cost: 5 }),
  // --- Ay: yüzey kiti
  it({ id: 's-suit', name: 'EVA giysisi', category: 'eva-suit', role: 'payload', module: 'surface-kit', missions: L, massKg: 150, evaHours: 6, provides: ['eva-capability'], cost: 30 }),
  it({ id: 's-camera', name: 'Kamera', category: 'instrument', role: 'payload', module: 'surface-kit', missions: L, massKg: 5, powerW: 20, dutyCycle: 0.5, dataGenMbPerSol: 1000, scienceValue: 15, requires: ['surface-data-link'], cost: 5 }),
  it({ id: 's-drill', name: 'Matkap', category: 'instrument', role: 'payload', module: 'surface-kit', missions: L, massKg: 40, powerW: 300, dutyCycle: 0.1, scienceValue: 25, requires: ['eva-capability'], tags: ['vibration'], incompatibleWith: [{ tag: 'seismic', reason: 'Titreşim sismometreyi bozar' }], cost: 15 }),
  it({ id: 's-seismo', name: 'Sismometre', category: 'instrument', role: 'payload', module: 'surface-kit', missions: L, massKg: 30, powerW: 50, scienceValue: 20, tags: ['seismic'], incompatibleWith: [{ tag: 'vibration', reason: 'Titreşim sismometreyi bozar' }], cost: 10 }),
  it({ id: 's-heater-hog', name: 'Yoğun ısıtmalı spektrometre', category: 'instrument', role: 'payload', module: 'surface-kit', missions: L, massKg: 20, powerW: 3000, scienceValue: 10, cost: 10 }),

  // --- Mars: fırlatma aracı
  it({ id: 'm-srb', name: 'Yan iticiler', category: 'booster', role: 'rocket', module: 'launch-vehicle', missions: M, stage: 1, massKg: 16300, propellantKg: 170500, thrustN: 6750000, thrustSlN: 6750000, ispS: 275, cost: 60 }),
  it({ id: 'm-core', name: 'Çekirdek', category: 'core', role: 'rocket', module: 'launch-vehicle', missions: M, stage: 2, massKg: 26480, propellantKg: 284000, thrustN: 4152000, thrustSlN: 3827000, ispS: 338, cost: 130 }),
  it({ id: 'm-upper', name: 'Centaur esinli', category: 'upper-stage', role: 'rocket', module: 'launch-vehicle', missions: M, stage: 3, massKg: 2500, propellantKg: 20800, thrustN: 101800, ispS: 449, cost: 55 }),
  // --- Mars: seyir kademesi
  it({ id: 'm-cruise-prop', name: 'Seyir iticisi', category: 'cruise-propulsion', role: 'rocket', module: 'cruise-stage', missions: M, massKg: 120, propellantKg: 75, thrustN: 35, ispS: 220, cost: 15 }),
  it({ id: 'm-cruise-solar', name: 'Seyir paneli', category: 'cruise-power', role: 'spacecraft', module: 'cruise-stage', missions: M, massKg: 70, powerGenW: 1000, tags: ['solar'], cost: 12 }),
  // --- Mars: EDL
  it({ id: 'm-backshell', name: 'Arka kabuk', category: 'aeroshell', role: 'spacecraft', module: 'edl', missions: M, massKg: 575, tags: ['jettison-before-powered-descent'], cost: 40 }),
  it({ id: 'm-shield', name: 'PICA kalkan', category: 'heat-shield', role: 'spacecraft', module: 'edl', missions: M, massKg: 440, maxEntryMassKg: 3500, edl: { maxHeatFluxWcm2: 250, dragArea: 26.7 }, tags: ['jettison-before-powered-descent'], cost: 55 }),
  it({ id: 'm-shield-weak', name: 'Zayıf kalkan', category: 'heat-shield', role: 'spacecraft', module: 'edl', missions: M, massKg: 200, maxEntryMassKg: 3500, edl: { maxHeatFluxWcm2: 20, dragArea: 26.7 }, tags: ['jettison-before-powered-descent'], cost: 10 }),
  it({ id: 'm-chute', name: 'Paraşüt', category: 'parachute', role: 'spacecraft', module: 'edl', missions: M, massKg: 80, edl: { dragArea: 218, maxMach: 2.2 }, tags: ['jettison-before-powered-descent'], cost: 20 }),
  it({ id: 'm-chute-slow', name: 'Ses altı paraşüt', category: 'parachute', role: 'spacecraft', module: 'edl', missions: M, massKg: 40, edl: { dragArea: 150, maxMach: 1.2 }, tags: ['jettison-before-powered-descent'], cost: 8 }),
  it({ id: 'm-radar', name: 'İniş radarı', category: 'landing-radar', role: 'spacecraft', module: 'edl', missions: M, massKg: 25, powerW: 100, dutyCycle: 0.01, provides: ['edl-radar'], tags: ['radar'], cost: 20 }),
  it({ id: 'm-imu', name: 'IMU', category: 'nav-sensors', role: 'spacecraft', module: 'edl', missions: M, massKg: 12, provides: ['edl-nav'], cost: 10 }),
  it({ id: 'm-descent', name: 'İniş motorları', category: 'descent-engine', role: 'rocket', module: 'edl', missions: M, massKg: 180, thrustN: 24800, ispS: 220, provides: ['descent-propulsion'], requires: ['propellant-hydrazine'], cost: 35 }),
  it({ id: 'm-descent-tank', name: 'Hidrazin tankı', category: 'descent-tank', role: 'rocket', module: 'edl', missions: M, massKg: 220, propellantKg: 400, provides: ['propellant-hydrazine'], cost: 18 }),
  // --- Mars: gezgin
  it({ id: 'm-chassis', name: 'Şasi', category: 'chassis', role: 'spacecraft', module: 'rover', missions: M, massKg: 650, powerW: 200, dutyCycle: 0.1, instrumentCapacityKg: 45, cost: 120 }),
  it({ id: 'm-rtg', name: 'MMRTG', category: 'rover-power', role: 'spacecraft', module: 'rover', missions: M, massKg: 45, powerGenW: 110, cost: 90, tags: ['rtg'] }),
  it({ id: 'm-solar', name: 'Gezgin paneli', category: 'rover-power', role: 'spacecraft', module: 'rover', missions: M, massKg: 80, powerGenW: 150, tags: ['solar'], cost: 25 }),
  it({ id: 'm-battery', name: 'Gezgin bataryası', category: 'rover-battery', role: 'spacecraft', module: 'rover', missions: M, massKg: 52, batteryWh: 2400, tempRangeC: [-20, 40], cost: 8 }),
  it({ id: 'm-heaters', name: 'Isıtıcılar', category: 'rover-thermal', role: 'spacecraft', module: 'rover', missions: M, massKg: 25, powerW: 10, provides: ['rover-thermal'], cost: 8 }),
  it({ id: 'm-computer', name: 'Bilgisayar', category: 'rover-computer', role: 'spacecraft', module: 'rover', missions: M, massKg: 30, powerW: 35, provides: ['nav-computer'], cost: 25 }),
  it({ id: 'm-uhf', name: 'UHF röle anteni', category: 'comms-uhf', role: 'spacecraft', module: 'rover', missions: M, massKg: 8, powerW: 15, dutyCycle: 0.05, dataRateBps: 2e6, linkSecPerSol: 300, provides: ['relay-link'], tags: ['antenna-uhf'], cost: 10 }),
  it({ id: 'm-xband', name: 'X bandı anten', category: 'comms-x', role: 'spacecraft', module: 'rover', missions: M, massKg: 30, powerW: 100, dutyCycle: 0.1, dataRateBps: 2000, linkSecPerSol: 7200, provides: ['direct-link'], cost: 18 }),
  it({ id: 'm-cam', name: 'Mastcam esinli', category: 'instrument', role: 'payload', module: 'rover', missions: M, massKg: 4, powerW: 17.4, dutyCycle: 0.15, dataGenMbPerSol: 148, scienceValue: 18, tempRangeC: [-90, 30], cost: 15 }),
  it({ id: 'm-spec', name: 'Spektrometre', category: 'instrument', role: 'payload', module: 'rover', missions: M, massKg: 7, powerW: 25, dutyCycle: 0.1, dataGenMbPerSol: 16, scienceValue: 24, cost: 22 }),
  it({ id: 'm-heavy', name: 'Ağır alet', category: 'instrument', role: 'payload', module: 'rover', missions: M, massKg: 40, powerW: 300, dutyCycle: 0.04, dataGenMbPerSol: 1, scienceValue: 12, cost: 30 }),
  it({ id: 'm-bigdata', name: 'Yüksek veri kamerası', category: 'instrument', role: 'payload', module: 'rover', missions: M, massKg: 3, powerW: 10, dutyCycle: 0.2, dataGenMbPerSol: 5000, scienceValue: 10, cost: 12 }),
];

const cat = (category, min, max, role) => Object.assign({ category, min, max }, role ? { role } : {});
const lunar = {
  id: 'lunar', name: 'Test Ay Görevi', summary: 'Kısa özet', educationalNote: 'Basitleştirilmiş eğitsel senaryo.',
  budget: 1000, crew: 2, durationDays: 10,
  modules: [
    { id: 'launch-vehicle', name: 'Fırlatma aracı', role: 'rocket', categories: [cat('booster', 0, 1), cat('core', 1, 1), cat('upper-stage', 1, 1)] },
    { id: 'crew-vehicle', name: 'Mürettebat aracı', role: 'spacecraft', categories: [cat('capsule', 1, 1), cat('service-module', 1, 1), cat('abort', 0, 1),
      cat('eclss', 1, 1), cat('solar-array', 1, 1), cat('thermal', 0, 1), cat('navigation', 0, 1), cat('battery', 0, 1)] },
    { id: 'lander', name: 'İniş aracı', role: 'rocket', roles: ['rocket', 'spacecraft'], categories: [cat('lander-engine', 1, 1, 'rocket'), cat('lander-tank', 1, 1, 'rocket'),
      cat('landing-radar', 0, 1, 'spacecraft'), cat('surface-power', 1, 2, 'spacecraft'), cat('surface-comms', 0, 1, 'spacecraft')] },
    { id: 'surface-kit', name: 'Yüzey kiti', role: 'payload', categories: [cat('eva-suit', 0, 1), cat('instrument', 1, 3)] },
  ],
  phases: [
    { id: 'prep', name: 'Hazırlık', dvMs: 0, checks: ['budget'] },
    { id: 'launch', name: 'Kalkış', dvMs: 9000, dvFrom: 'launch-vehicle', carries: ['launch-vehicle', 'crew-vehicle'], checks: ['twr', 'dv'] },
    { id: 'tli', name: 'TLI', dvMs: 2900, dvFrom: 'launch-vehicle', carries: ['launch-vehicle', 'crew-vehicle'], excludeTags: ['jettison-after-launch'], checks: ['dv'] },
    { id: 'loi', name: 'Ay yörüngesi', dvMs: 500, dvFrom: 'crew-vehicle', carries: ['crew-vehicle'], checks: ['dv'] },
    { id: 'landing', name: 'Ay inişi', dvMs: 2000, dvFrom: 'lander', carries: ['lander', 'surface-kit'], checks: ['dv', 'lander-twr'] },
    { id: 'surface-ops', name: 'Yüzey keşfi', dvMs: 0, checks: ['eva', 'science'] },
    { id: 'ascent', name: 'Ay\'dan kalkış', dvMs: 1800, dvFrom: 'lander', carries: ['lander'], checks: ['dv'] },
    { id: 'return-transfer', name: 'Dönüş', dvMs: 500, dvFrom: 'crew-vehicle', carries: ['crew-vehicle'], checks: ['dv'] },
    { id: 'entry', name: 'Atmosfere giriş', dvMs: 0, checks: ['heat-shield'] },
    { id: 'recovery', name: 'Kurtarma', dvMs: 0 },
  ],
  objectives: [
    { id: 'landing', name: 'Ay\'a in', type: 'primary', critical: false },
    { id: 'surface-eva', name: 'Yüzey yürüyüşü', type: 'secondary', critical: false },
    { id: 'science', name: 'Bilim hedefi', type: 'science', critical: false },
    { id: 'crew-return', name: 'Mürettebatı döndür', type: 'primary', critical: true },
  ],
  briefing: { director: ['Operatör brifingi'], rocket: ['İtki brifingi'], spacecraft: ['Uzay aracı brifingi'], payload: ['Bilim brifingi'] },
  settings: [
    { key: 'propellantLoad', role: 'rocket', label: 'Yakıt doluluk oranı', type: 'number', min: 0.6, max: 1, step: 0.05, default: 1, unit: '' },
    { key: 'consumableMarginDays', role: 'spacecraft', label: 'Sarf yedeği', type: 'number', min: 0, max: 10, step: 1, default: 3, unit: 'gün' },
    { key: 'powerMode', role: 'spacecraft', label: 'Güç modu', type: 'enum', options: ['eco', 'normal', 'max'], default: 'normal',
      optionInfo: { eco: { useFactor: 0.85 }, normal: { useFactor: 1 }, max: { useFactor: 1.2 } } },
    { key: 'instrumentMode', role: 'payload', label: 'Alet modu', type: 'enum', options: ['survey', 'balanced', 'intensive'], default: 'balanced',
      optionInfo: { survey: { dutyFactor: 0.7, scienceFactor: 0.75, dataFactor: 0.7 }, balanced: { dutyFactor: 1, scienceFactor: 1, dataFactor: 1 }, intensive: { dutyFactor: 1.5, scienceFactor: 1.3, dataFactor: 1.5 } } },
  ],
  limits: { maxLaunchMassKg: 1000000, minTWR: 1.2, minLanderTWR: 1.2, landingMaxVms: 3, o2PerCrewDayKg: 0.84, waterPerCrewDayKg: 2.5, minEvaHours: 4, minScience: 20, maxLanderMassKg: 20000 },
  nasaReality: 'Gerçekte NASA Artemis ile...',
  refs: { budget: { src: 'src-a', class: 'game' } },
};

const mars = {
  id: 'mars', name: 'Test Mars Görevi', summary: 'Kısa özet', educationalNote: 'Basitleştirilmiş eğitsel senaryo.',
  budget: 900, crew: 0, durationDays: 200,
  modules: [
    { id: 'launch-vehicle', name: 'Fırlatma aracı', role: 'rocket', categories: [cat('booster', 0, 1), cat('core', 1, 1), cat('upper-stage', 1, 1)] },
    { id: 'cruise-stage', name: 'Seyir kademesi', role: 'rocket', roles: ['rocket', 'spacecraft'], categories: [cat('cruise-propulsion', 1, 1, 'rocket'), cat('cruise-power', 1, 1, 'spacecraft')] },
    { id: 'edl', name: 'EDL', role: 'spacecraft', roles: ['spacecraft', 'rocket'], categories: [cat('aeroshell', 1, 1), cat('heat-shield', 1, 1), cat('parachute', 1, 1),
      cat('landing-radar', 0, 1), cat('nav-sensors', 0, 1), cat('descent-engine', 1, 1, 'rocket'), cat('descent-tank', 1, 1, 'rocket')] },
    { id: 'rover', name: 'Gezgin', role: 'spacecraft', roles: ['spacecraft', 'payload'], categories: [cat('chassis', 1, 1), cat('rover-power', 1, 2), cat('rover-battery', 0, 1),
      cat('rover-thermal', 0, 1), cat('rover-computer', 1, 1), cat('comms-uhf', 0, 1), cat('comms-x', 0, 1), cat('instrument', 1, 4, 'payload')] },
  ],
  phases: [
    { id: 'prep', name: 'Hazırlık', dvMs: 0 },
    { id: 'launch', name: 'Kalkış', dvMs: 9300, dvFrom: 'launch-vehicle', carries: ['launch-vehicle', 'cruise-stage', 'edl', 'rover'] },
    { id: 'earth-departure', name: 'Dünya\'dan ayrılış', dvMs: 3700, dvFrom: 'launch-vehicle', carries: ['launch-vehicle', 'cruise-stage', 'edl', 'rover'] },
    { id: 'cruise', name: 'Seyir', dvMs: 0 },
    { id: 'tcm', name: 'Yörünge düzeltme', dvMs: 30, dvFrom: 'cruise-stage', carries: ['cruise-stage', 'edl', 'rover'] },
    { id: 'entry', name: 'Atmosfere giriş', dvMs: 0 },
    { id: 'parachute', name: 'Paraşüt', dvMs: 0 },
    { id: 'powered-descent', name: 'Motorlu iniş', dvMs: 450, dvFrom: 'edl', carries: ['edl', 'rover'], excludeTags: ['jettison-before-powered-descent'] },
    { id: 'landing', name: 'İniş', dvMs: 0 },
    { id: 'surface-ops', name: 'Yüzey operasyonu', dvMs: 0 },
    { id: 'science', name: 'Bilim', dvMs: 0 },
    { id: 'downlink', name: 'Veri iletimi', dvMs: 0 },
  ],
  objectives: [
    { id: 'landing', name: 'Güvenli iniş', type: 'primary', critical: true },
    { id: 'science', name: 'Bilim hedefi', type: 'science', critical: false },
    { id: 'data-return', name: 'Veriyi Dünya\'ya gönder', type: 'science', critical: false },
  ],
  briefing: { director: ['Operatör'], rocket: ['İtki'], spacecraft: ['Uzay aracı'], payload: ['Bilim'] },
  settings: [
    { key: 'propellantLoad', role: 'rocket', label: 'Yakıt doluluk oranı', type: 'number', min: 0.6, max: 1, step: 0.05, default: 1, unit: '' },
    { key: 'powerMode', role: 'spacecraft', label: 'Güç modu', type: 'enum', options: ['eco', 'normal', 'max'], default: 'normal' },
    { key: 'instrumentMode', role: 'payload', label: 'Alet modu', type: 'enum', options: ['survey', 'balanced', 'intensive'], default: 'balanced' },
  ],
  limits: { maxLaunchMassKg: 600000, minTWR: 1.2, entryVelocityMs: 5400, entryFlightPathDeg: -15.5, chuteDeployMach: 1.75, landingMaxVms: 0.75, minDescentTWR: 1.5, minScience: 30, solarDustFactor: 0.7 },
  nasaReality: 'Gerçekte NASA Perseverance ile...',
  refs: { budget: { src: 'src-b', class: 'game' } },
};

const b = (list) => list.map(([itemId, moduleId], i) => ({ uid: `u${i}`, itemId, moduleId }));
const GOOD_LUNAR = b([
  ['l-booster', 'launch-vehicle'], ['l-core', 'launch-vehicle'], ['l-upper', 'launch-vehicle'],
  ['c-capsule', 'crew-vehicle'], ['c-sm', 'crew-vehicle'], ['c-las', 'crew-vehicle'], ['c-eclss', 'crew-vehicle'], ['c-solar', 'crew-vehicle'],
  ['c-radiator', 'crew-vehicle'], ['c-nav', 'crew-vehicle'], ['c-battery', 'crew-vehicle'],
  ['d-engine', 'lander'], ['d-tank', 'lander'], ['d-radar', 'lander'], ['d-solar', 'lander'], ['d-comm', 'lander'],
  ['s-suit', 'surface-kit'], ['s-camera', 'surface-kit'], ['s-drill', 'surface-kit'],
]);
const GOOD_MARS = b([
  ['m-srb', 'launch-vehicle'], ['m-core', 'launch-vehicle'], ['m-upper', 'launch-vehicle'],
  ['m-cruise-prop', 'cruise-stage'], ['m-cruise-solar', 'cruise-stage'],
  ['m-backshell', 'edl'], ['m-shield', 'edl'], ['m-chute', 'edl'], ['m-radar', 'edl'], ['m-imu', 'edl'], ['m-descent', 'edl'], ['m-descent-tank', 'edl'],
  ['m-chassis', 'rover'], ['m-rtg', 'rover'], ['m-battery', 'rover'], ['m-heaters', 'rover'], ['m-computer', 'rover'], ['m-uhf', 'rover'], ['m-xband', 'rover'],
  ['m-cam', 'rover'], ['m-spec', 'rover'],
]);

function data() {
  return JSON.parse(JSON.stringify({ equipment, missions: [lunar, mars], constants, sources }));
}

// Bir yapılandırmada parçayı değiştir/çıkar/ekle (testler için)
function swap(build, fromId, toId) {
  return build.map((x) => (x.itemId === fromId ? Object.assign({}, x, { itemId: toId }) : x)).filter((x) => x.itemId);
}
function without(build, id) { return build.filter((x) => x.itemId !== id); }
function withItem(build, itemId, moduleId) { return build.concat({ uid: `x${build.length}`, itemId, moduleId }); }

// Aşama 8 eki: Mars görevine alan (U), standart donanım (auto), bilim hedefleri ve yeni ayarlar.
// GOOD_MARS gezgini tam doldurur (10/10 U); m-bigdata takılırsa NO_SPACE.
const STAGE8_VOL = { 'm-chassis': 3, 'm-rtg': 1, 'm-battery': 1, 'm-heaters': 0, 'm-computer': 1, 'm-uhf': 1, 'm-xband': 1, 'm-cam': 1, 'm-spec': 1, 'm-bigdata': 1, 'm-heavy': 2, 'm-solar': 2 };
const STAGE8_TAGS = { 'm-cam': ['img'], 'm-spec': ['chem'], 'm-bigdata': ['bigdata'] };
const STAGE8_SETTINGS = [
  { key: 'landingReservePct', role: 'rocket', label: 'İniş yakıt rezervi', type: 'number', min: 0, max: 15, step: 1, default: 0, unit: '%' },
  { key: 'ascentProfile', role: 'rocket', label: 'Kalkış profili', type: 'enum', options: ['lofted', 'standard', 'depressed'], default: 'standard' },
  { key: 'commsPlan', role: 'spacecraft', label: 'İletişim planı', type: 'enum', options: ['minimal', 'standard', 'continuous'], default: 'standard' },
  { key: 'samplePriority', role: 'payload', label: 'Bilim önceliği', type: 'enum', options: ['goals', 'balanced', 'explore'], default: 'balanced' },
];
function stage8Data() {
  const d = data();
  for (const it of d.equipment) {
    if (it.id in STAGE8_VOL) it.volumeU = STAGE8_VOL[it.id];
    if (STAGE8_TAGS[it.id]) it.provides = it.provides.concat(STAGE8_TAGS[it.id]);
  }
  const m = d.missions[1];
  m.modules.find((x) => x.id === 'rover').capacityU = 10;
  m.modules.find((x) => x.id === 'rover').categories.find((c) => c.category === 'rover-computer').auto = true;
  m.settings.push(...JSON.parse(JSON.stringify(STAGE8_SETTINGS)));
  m.scienceGoals = [
    { id: 'g-img', name: 'Görüntü hedefi', desc: 'Kamera ister.', requiresTags: ['img'], value: 20 },
    { id: 'g-chem', name: 'Kimya hedefi', desc: 'Kamera + spektrometre.', requiresTags: ['chem', 'img'], value: 30 },
    { id: 'g-big', name: 'Büyük veri hedefi', desc: 'Yüksek veri kamerası.', requiresTags: ['bigdata'], value: 25 },
  ];
  m.scienceTags = { img: 'Görüntü', chem: 'Kimya', bigdata: 'Büyük veri' };
  return d;
}

module.exports = { data, stage8Data, GOOD_LUNAR, GOOD_MARS, swap, without, withItem };
