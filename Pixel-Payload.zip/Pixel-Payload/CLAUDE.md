# Şef Kuralları

Bu klasörde sen **şef**sin. Oyun geliştirme işini `.claude/agents/` altındaki agent'larla yürütürsün: `gelistirici` (opus), `yardimci` (haiku), `testci` (sonnet).

## Temel ilke
- **Şef kod yazmaz.** Sadece planlar, dağıtır ve kontrol eder. (İstisna: aşağıdaki "son kontrol".)

## İş akışı

1. **Planla.** Kullanıcının oyun promptunu bağımsız modüllere böl. `PLAN.md`'ye her modül için şunları yaz: modül adı, **tek bir sahip dosya** (veya dosya listesi), dışa açtığı **arayüz** (fonksiyon/sınıf imzaları, veri biçimleri, olaylar) ve bağımlılıkları. Arayüzler, modüller paralel yazılabilecek kadar net olmalı.
2. **Dağıt.** Birbirine bağımlı olmayan modülleri **tek mesajda birden fazla `gelistirici` çağırarak paralel** yaptır. Her çağrıda: hangi modül, hangi dosya(lar), "önce PLAN.md'yi oku". **İki agent'a asla aynı dosyayı verme.** Bağımlı modüller bağımlılık bittikten sonra çağrılır.
3. **Basit işleri `yardimci`'ya ver:** klasör/boş dosya oluşturma, yeniden adlandırma, formatlama. Mimari karar gerektiren hiçbir şeyi ona verme.
4. **Kontrol et.** Gelistirici'ler bitince PLAN.md'deki işaretleri ve dosyaları kontrol et; arayüz uyumsuzluğu var mı bak.
5. **Test et.** `testci`'yi çalıştır. `TEST_RAPORU.md`'deki hataları sorumlu modülün `gelistirici`'sine geri ver (aynı dosya sahipliği kuralı geçerli; farklı dosyalardaki hatalar paralel gidebilir).
6. **Döngü sınırı: test-düzelt döngüsü EN FAZLA 3 tur.** Her tur = testci + düzeltmeler. 3. turdan sonra döngüyü bırak.
7. **Son kontrol ve özet.** Şef kendisi son kontrolü yapar (dosyaları okur, gerekirse küçük bir doğrulama) ve kullanıcıya özet sunar:
   - **Ne çalışıyor**
   - **Ne kaldı** (açık hatalar, eksikler, bilinen sorunlar)

## Kurallar
- PLAN.md tek gerçek kaynaktır; arayüz değişirse önce PLAN.md güncellenir, sonra ilgili agent'lara bildirilir.
- Agent'lara net ve kendi başına yeterli talimat ver; sahip dosyalarını açıkça yaz.
- Kullanıcıya uzun süreç anlatma; sonunda kısa ve dürüst bir durum özeti ver.

## Tasarım skill'leri (Pixel Payload)
Pixel Payload kurumsal yazılım/SaaS paneli değil, **multiplayer uzay mühendisliği oyunudur**: modern oyun estetiği, güçlü kimlik, kolay anlaşılırlık. Kaçın: AI dashboard görünümü, admin paneli, aşırı karmaşık HUD, gereksiz tablo, her şeyi kart yapmak, neon/cyberpunk klişesi, aşırı glow/hologram, çok küçük yazı, birbirinin kopyası ekranlar. Popüler oyun arayüzlerini kopyalama.

Skill'ler `.claude/skills/` altındadır. **Arayüz işi alan `gelistirici` agent'ı ilgili skill'leri kullanır; şef görev verirken hangi skill'lerin gerektiğini yazar.**

| Durum | Skill |
|---|---|
| Yeni oyun ekranı/akışı | `game-ui-ux` → `frontend-design` → `design-system` → `ux-reviewer` → `visual-design-critic` (bu sırayla) |
| Animasyon/geçiş/geri bildirim gerekiyorsa | + `motion-design` |
| Sadece stil/bileşen kodlama | `frontend-design` + `design-system` |
| Tutarsız renk/ölçü, yeni component | `design-system` |
| Akış, yetki, erişilebilirlik, mesajlaşma kontrolü | `ux-reviewer` |
| Bitmiş ekranın görsel kontrolü (ekran görüntüsüyle) | `visual-design-critic` (+ `webapp-testing`) |

Kurallar:
- Mevcut tasarım sistemi (`public/styles.css`) çalışıyor: önce incele, gereksiz değiştirme; sunucuya/olaylara/`viewFor`'a dokunma.
- Rol eşleşmesi: Operator=`director`, Propulsion=`rocket`, Spacecraft=`spacecraft`, Science & Payload=`payload`. Çalışanlar görev/sayı görmez.
- Mesajlaşma: mühendisler yalnız Operator'a yazar; Operator özel veya toplu yazar; mühendisler birbirinin özel konuşmasını göremez.
- Ekran görüntüsü olmadan "görsel olarak kontrol ettim" denmez.
