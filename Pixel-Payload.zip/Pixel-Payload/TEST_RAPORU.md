# TEST RAPORU — Aşama 8, Tur 1 (2026-11-15)

Eski içerik (Aşama 7) bu raporla değiştirildi.

## Yöntem
- `npm test`: 100/100 geçti.
- Sunucu PORT=3900, PP_PHASE_MS=300. 4 ayrı Chromium bağlamı (Operatör + İtki + Uzay Aracı + Bilim), gerçek istemci (`core.emit` ile protokol, bazı adımlar gerçek UI tıklamasıyla: TAK/ÇIKAR, FIRLAT, risk modalı).
- Ay: boş tasarım (fiziksel yetersiz) risk onayıyla fırlatıldı → başarısız debrief; AYNI GÖREV; Ay A → başarılı debrief (3 çalıştırmada 900 puan, 1 çalıştırmada rastgele iniş motoru arızası); bütçe aşımlı Ay → debrief.
- Mars: Mars A (READY), parça çıkarma taraması (MISSING/RISKY), yeni ayarlar, fazladan parça (NO_SPACE), eksik paraşüt, TEKRAR OYNA → yeni görev.
- Ek: sohbet kuralları, GERİ, yetki denemeleri, sayfa yenileme ile yeniden bağlanma, demo sayfası. Ekran görüntüleri 1366×768 ve 390×844 (scratchpad `shots/`).
- Konsol hatası, pageerror, başarısız ağ isteği: **hiçbiri** (tüm koşularda).

## Bulgular (önem sırasıyla)

### Kritik
Yok.

### Orta
**O-1. Debrief puanı bölüm toplamıyla uyuşmuyor (başarısız görevlerde)**
- Adımlar: Ay boş/aşımlı tasarım ya da Mars bozuk tasarım fırlat → debrief.
- Gözlenen: Mars başarısız: bölümler toplamı 329, skor 230 (bütçe cezası 0). Ay aşımlı: bölümler 580, ceza 36, skor 381 (580−36=544 olmalı). Başarılı görevde toplam=skor (900=900). Ekranda PUAN DÖKÜMÜ toplamı gösterilen puanla bağdaşmıyor, oyuncu açıklama bulamaz.
- Beklenen: skor = bölüm toplamı − ceza; ek bir çarpan/üst sınır varsa debrief'te satır olarak görünmeli.
- Sorumlu: `server/sim/debrief.js` (gerekirse `public/js/screens/debrief.js` ek satır).

**O-2. Hiçbir rol, parça fiyatını takmadan göremiyor**
- Operatör kataloğunda (`director.catalog`) maliyet alanı yok; maliyet yalnız takıldıktan sonra `director.costs[uid]` ve defterde görünüyor. Bütçeyi yönetmesi gereken Operatör bir seçeneğin fiyatını deneme-yanılma ile öğrenebiliyor. Spec'e aykırı değil ama bütçe mekaniğinin kullanılabilirliğini düşürüyor.
- Sorumlu: `server/filter.js` (director.catalog'a maliyet), isteğe bağlı UI `operator.js`.

### Düşük
**D-1. READY tasarım rastgele başarısız olabiliyor.** Ay A (READY, aynı tasarım) 4 koşunun 1'inde "Ay inişi: iniş motoru arızalandı ve yedeği yoktu", 364 puan. Tek nokta arıza olasılıksal tasarım gereği olabilir; ama "Hazır" etiketi garanti sanılabilir. Sorumlu: `server/sim/simulate.js` / hazır etiketinin metni (`public/js/widgets/telemetry.js` LAUNCH).

**D-2. `room.ledgerSeq` yeni görevde sıfırlanmıyor.** TEKRAR OYNA (new) + yeni görev sonrası defter 10 kayıtla başlıyor ama ilk kayıt id'si 47 (plan: defter sıfırlanır). Görünür etkisi yok. Sorumlu: `server/rooms.js`.

**D-3. İngilizce ham tanımlayıcılar kullanıcıya görünüyor.** Gereksinim kalemleri "...şunlara ihtiyaç duyuyor: surface-power-supply, propellant-lox-lh2" (Bilim hazırlığı, risk modalı); Uzay aracı telemetrisinde "Durum PASS". Sorumlu: `server/sim/evaluate.js` (metin) + `public/js/widgets/util.js` (`tagName` kullanılabilir).

**D-4. Yazım hataları.** "İniş yakışına ayrılan ek pay" (rocket `landingReservePct` help), "Ay'a geçiş yakışı (TLI)" (yakıt/yakıtı). Sorumlu: `data/missions/lunar.json`, `data/missions/mars.json`, `server/sim/evaluate.js`.

**D-5. Telefonda (390 px) üst başlıkta logo yazısı oda kodu çipiyle örtüşüyor** ("PIXEL PAYLOAD" ikinci satırı "PAYLOAD" çip altında kesiliyor). Tüm ekranlarda. Sorumlu: `public/css/` (başlık çubuğu, base/ui CSS; `public/index.html`).

**D-6. Mühendis ekranında araç sahnesi altındaki koyu "zemin" şeridi sahne kutusunun dışına taşıyor** ve "Aşama Δv" satırlarının etiketini ("Kalkış") çiziyor (1366×768, İtki ekranı, özellikle Mars/Ay'da sahne alt kenarında). Sahne ile MODÜL ALANI bölümü arası sınır belirsiz. Sorumlu: `public/scene2d.js` / `public/js/widgets/vehicle.js`, `public/css/work.css`.

**D-7. "Mühendis ekranında İLETİŞİM yüzen düğmesi içeriği örtüyor"** (1366×768 hazırlık listesi sağ altı; AH'nin bilinen notu, hâlâ var). Sorumlu: `public/js/screens/comms.js`, CSS.

## Doğrulananlar (çalışıyor)
1. **Kapasite:** Alan çubukları gerçek veriyle çiziliyor (Ay: 40/44/44/14 U; Mars: 32/8/20/30 U). Takınca kullanılan +hacim, boş −hacim; çıkarınca geri geliyor (Ay fırlatma aracı 15→25→15). Sığmayan parça `NO_SPACE` ("Modülde yer yok: kullanılan 33/40 U, parça 8 U", Mars gezgin 29/30, parça 3 ve 4 U). Karışık modül: Ay iniş aracı byRole {rocket 18, spacecraft 14}, Mars gezgin {spacecraft 22, payload 7}; `mineU` rol başına doğru. Bilim hedeflerinin üçü birden sığmıyor (Ay: matkap↔sismometre INCOMPATIBLE + 14 U; Mars: sample-cache NO_SPACE → mg-cache partial).
2. **Standart donanım:** Ay 14, Mars 10 parça otomatik, çıkarma `LOCKED`, karar şeridinden/katalogtan çıkıyor (`categories[].auto`), ledger'da `auto` kaydı; AYNI GÖREV'de kopya yok.
3. **Bütçe:** ekle +420 / çıkar −420 doğru iade, çift takma `DUPLICATE` ile reddedilip ücret yok; byRole güncelleniyor; defter kim/ne/maliyet/saat gösteriyor (UI TAK/ÇIKAR dahil). Mühendis ham state'inde cost/spent/ledger/budget sayısı/director YOK, yalnız `budgetBand` (ok/tight/over doğrulandı). Aşım (4.344/4.300): bütçe kalemi kritik olmayan FAIL `kind:'budget'`, fırlatma engellenmedi, debrief: aşım 44, %1,02, ceza 36, bütçe bölümü 0, ders metni var.
4. **Fırlatma özgürlüğü:** READY, RISKY (Mars UHF çıkarınca), MISSING (Mars gezgin şasi/batarya/ısı, EDL çekme vb.), INSUFFICIENT (boş tasarım, paraşütsüz) hepsi görüldü. READY'de kısa onay modalı; READY değilken `LAUNCH_CONFIRM` + RİSK ONAYI modalı → YİNE DE FIRLAT çalışıyor. Yalnız 0/3 ve 2/3 onayda `LAUNCH_BLOCKED`. `confirm` boolean değilse BAD_REQUEST. Yetersiz tasarım simülasyonda gerçek başarısızlık (Ay: başarısız debrief 381 puan; Mars bozuk tasarım: Δv eksik, başarısız 230 puan). Kısmi sonuç (partial) debrief'i bu turda üretilemedi (aşağıya bak).
5. **Yeni ayarlar** arayüzde çiziliyor; değer değişimi etkiliyor: `landingReservePct` 10 → iniş Δv gereksinimi 459→495, arazi tehlikesi 0,021→0,016; `ascentProfile lofted` → kalkış Δv 9300→9672, kalan yakıt 981→431; `commsPlan continuous` → güç marjı 9,3→0,7 W, iletişim 614→983 Mb/sol, durum RISKY; `samplePriority goals/explore` → bilim değeri 114→96,9/131,1, explore'da 2 hedef partial.
6. **Komuta merkezi:** durum (4 basamaklı ölçek), kalan bütçe + rol renkli çubuk, kütle/sınır, enerji marjı, TWR + en dar Δv, ekip sistemleri, araç/kapasite, defter; 1366 ve 390'da okunaklı, yatay taşma yok.
7. **Simülasyon bütçe satırı** hata vermedi (konsol temiz; sim ekranı 1366/390 çekildi).
8. **Gerileme:** sohbet (mühendis→mühendis/yayın FORBIDDEN, BAD_TARGET, TOO_LONG, EMPTY; özel kanal sızıntısı yok), asimetrik bilgi (diğer rolün sayıları yok), GERİ (brifing/inceleme yalnız Operatör; mühendis NOT_ALLOWED), DÜZELT tasarıma döner, AYNI GÖREV (defter 14=14, build 14=14 korundu), YENİ (defter 0, build 0; yeni görevde 10 auto, harcanan 185), sayfa yenileyince yeniden bağlanma (rol/faz/build korundu), yetkisiz takma/ayar/fırlatma reddi, demo sayfası (4 panel, tasarım fazına geçti, hata yok).
9. **Görsel:** 1366 ve 390'da yatay taşma yok (tüm kontrol edilen ekranlarda). Okunabilirlik iyi. Sorunlar D-5, D-6, D-7.

## Test edilemeyenler / doğrulanamayanlar
- **Kısmi (partial) debrief ekranı** üretilemedi: Mars A bu tohumlarda başarılı; kısmi sonuç için bilinen bir tasarım yok.
- **Tekrar oyna sonrası tam ikinci tur** yalnız protokol düzeyinde (Mars yeni görev tasarım fazına kadar); Mars başarılı/kısmi debrief ekranı tam hâliyle ikinci kez gezilmedi.
- Ay B (RISKY, kapsül dayanımı WARN) ve Mars B tam oyun oynanmadı (RISKY durumu Mars UHF çıkarma ile doğrulandı).
- "Her mühendis için ≈10 karar" sayısal olarak sayılmadı.
- Ekran görüntüleri çekildi ama 390 px tam sayfa görüntüler çok uzun olduğundan satır satır incelenmedi; yatay taşma otomatik ölçümle (scrollWidth) doğrulandı.
- Operatör UI'sinde defter satırlarının tek tek okunması (yalnız üst bant ve kartlar incelendi).
- Bağlantı kopması (ağ kesme) ve grace süresi denenmedi; yalnız sayfa yenileme.

## Özet
Çalışan: kapasite, standart donanım, bütçe/defter, bant, fırlatma 4 durum ve onay modalı, yeni ayarlar, komuta merkezi, sohbet/asimetrik bilgi, GERİ, AYNI GÖREV/YENİ, yeniden bağlanma, demo. Bozuk: kritik yok; orta 2 (debrief puan uyuşmazlığı, fiyat görünmezliği), düşük 7 (kozmetik/metin/rastgelelik).
