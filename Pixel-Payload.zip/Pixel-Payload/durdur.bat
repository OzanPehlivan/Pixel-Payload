@echo off
rem Pixel Payload - port 3000'i dinleyen sureci kapatir. Baska node sureclerine dokunmaz.
chcp 65001 >nul
title Pixel Payload - Durdur
setlocal EnableDelayedExpansion
set "PP_PORT=3000"
if defined PORT set "PP_PORT=%PORT%"

set "BULUNDU="
set "SON_PID="
for /f "tokens=5" %%P in ('netstat -ano ^| findstr /R /C:":%PP_PORT% .*LISTENING"') do (
  rem IPv4 ve IPv6 icin ayni PID iki kez gelebilir; tekrarini atla
  if not "%%P"=="!SON_PID!" if not "%%P"=="0" (
    set "SON_PID=%%P"
    taskkill /PID %%P /F >nul 2>nul
    if errorlevel 1 (
      echo  [HATA] PID %%P kapatilamadi.
    ) else (
      echo  Oyun kapatildi ^(PID %%P^).
      set "BULUNDU=1"
    )
  )
)

if not defined SON_PID echo  Oyun zaten kapali.

rem 2 sn sonra pencere kendiliginden kapanir
ping -n 3 127.0.0.1 >nul
endlocal
