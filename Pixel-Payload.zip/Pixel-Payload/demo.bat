@echo off
rem Pixel Payload - demo kontrol modu: dort oyuncu ekrani tek sayfada (/demo.html).
rem Cift tiklayarak calistir; sunucuyu baslat.bat ile ayni sekilde acar.
set "PP_DEMO=1"
call "%~dp0baslat.bat"
