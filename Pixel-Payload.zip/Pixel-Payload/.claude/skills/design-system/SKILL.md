---
name: design-system
description: Pixel Payload için merkezi tasarım sistemini yönetir: renk/tipografi/spacing token'ları, radius, gölge, buton, kart, input, modal, navigasyon, ikon, durum göstergeleri, breakpoint'ler. Yeni component eklerken, tutarsızlık düzeltirken veya rastgele renk/ölçü gördüğünde kullan. Mevcut sistemi önce inceler, gereksiz değiştirmez.
---

# Design System (Pixel Payload)

## Kural 0: Önce mevcut sistemi incele, değiştirme
Projede çalışan bir sistem var: `public/styles.css` `:root` bloğu ve oradaki sınıflar. Token'ları ve sınıfları **oku**, sonra uzat.
- Çalışan bir token'ın adını/değerini, kullanıcı istemedikçe değiştirme.
- Yeni component önce mevcut sınıflarla çözülsün; yoksa mevcut dile uygun yenisini ekle.
- Büyük refaktör (yeniden adlandırma, dosya bölme) yalnızca açık istekle yapılır; yoksa öner, yapma.
- Sunucuya/olaylara dokunma; bu skill yalnızca istemci stilini kapsar.

## Mevcut token'lar (kaynak: `public/styles.css`; kod ile çelişirse kod kazanır)
**Renk**
| Token | Değer | Kullanım |
|---|---|---|
| `--bg` | `#05080f` | sayfa zemini |
| `--bg-strip` | `#070c18` | üst/alt şerit |
| `--panel` / `--panel2` | `#0a1120` / `#0d1729` | yüzeyler |
| `--line` / `--line2` | `#1b2a44` / `#2a3f63` | çerçeve, ayraç |
| `--text` / `--muted` | `#e3ecf8` / `#7f93b0` | metin / soluk metin |
| `--cyan` `--amber` `--green` `--red` `--gray` | `#4fd1ff` `#ffb347` `#4dff9a` `#ff5a6a` `#3a4252` | vurgu ve durum |
| `--c-director/rocket/spacecraft/payload` | açık metin / amber / camgöbeği / yeşil | rol kimliği |
| `--me` | oyuncunun rol rengi (`html[data-myrole]`) | kişisel vurgu |

**Tipografi:** `--sans` (Segoe UI yığını) gövde/başlık, `--mono` (JetBrains Mono, yerel) sayı/kod. Ölçek: 13 / 16 / 20 / 25 / 31 / 39 / 49 px. Başlık BÜYÜK HARF.
**Spacing:** 4 tabanlı: 4, 8, 12, 16, 24, 32, 48, 64. Mevcut: `--pad: 24px`, `--head-h: 60px`, `--foot-h: 38px`, `--cut: 16px` (köşe çentiği).
**Radius:** oyun dili çentik/keskin köşe; yuvarlak yok. Kullanılacaksa tek ölçek: 0 (varsayılan), 4px (küçük kontrol), 999px (yalnızca durum noktası/rozet).
**Gölge/glow:** minimal. Katman için `0 8px 24px rgba(0,0,0,.45)`; etkin öğe için tek renkli ince halka `0 0 0 2px <renk>`. Neon yayılımlı glow yok.
**Breakpoint (min-width, mobile-first):** 480 / 768 / 1100 / 1440 px.
**Z-index:** içerik 0 · yapışkan çubuk 10 · çekmece 20 · modal 30 · toast 40.

Yeni token gerekiyorsa `:root`'a ekle, burada tabloya da işle. Gerçek değerler farklıysa önce bu dosyayı güncelle.

## Component sözleşmeleri
Her biri: boyut, durumlar (varsayılan/hover/focus-visible/active/disabled/loading/hata) ve erişilebilirlik gereksinimi tek yerde tanımlı olmalı.

- **Buton:** yükseklik ≥ 48px, BÜYÜK HARF etiket. Üç tür: birincil (dolu, ekranda tek), ikincil (çerçeveli), üçüncül (metin). Disabled nedenini yanında söyler. Tehlikeli eylem (odadan çık) ayrı ve onaylı.
- **Kart:** 2px rol/vurgu rengi çerçeve, ~%12 saydam dolgu, köşe çentiği/işaretleri, büyük soluk numara, başlık + `[KÖŞELİ PARANTEZ]` açıklama. Yalnızca gerçekten gruplanan içerik için kart kullan.
- **Input:** yükseklik ≥ 48px, görünür `label`, `:focus-visible` halkası, hata mesajı alanın altında, Türkçe. Oda kodu: 4 harf, büyük harf, mono.
- **Modal / çekmece:** `role="dialog"`, odak tuzağı, Esc ile kapanma, arka plan karartması, tek birincil eylem. Kapatma düğmesi her zaman görünür.
- **Navigasyon:** ince üst çubuk (solda marka, sağda bağlantı durumu + yardım), ince alt durum satırı (oda · rol · faz). Sekmeli yapı gerekmez; akış fazlara göre ilerler.
- **İkon:** tek stil: satır kalınlığı sabit (2px), SVG, `currentColor`, 24px taban. Dekoratif ise `aria-hidden`. Hazır ikon paketi/CDN yok; kodla çiz.
- **Durum göstergeleri:** her durum renk + şekil/ikon + etiket üçlüsü. Bağlı = yeşil nokta, bağlantı yok = kırmızı, bekliyor = amber, hazır = yeşil onay, engel = kırmızı çarpı. Nabız yalnız acil durumda.
- **Rozet (rol/görev):** rol rengi + kısa ad; yazı rengi yeterli kontrastlı.

## Tutarlılık denetimi
Aynı işlevdeki bileşenler aynı görünmeli. Denetim için:
```bash
grep -nE "#[0-9a-fA-F]{3,8}\b" public/*.css public/*.html public/client.js | grep -v ":root"   # token dışı hex
grep -nE "[0-9]+px" public/styles.css | grep -vE "var\(--|: ?(1|2|4|8|12|16|24|32|48|64)px"      # ölçek dışı piksel
```
Bulunan her sapmayı ya token'a bağla ya da gerekçesiyle token olarak ekle. Tek seferlik ayrıntı (ince SVG çizim koordinatı) sapma sayılmaz.

## Yeni component ekleme akışı
1. Mevcut sınıf/token ile çözülebilir mi? Evet → çöz, bitir.
2. Hayır → en yakın mevcut component'i bul, onun varyantı yap (aynı çerçeve, boşluk, durum seti).
3. Yeni token gerekiyorsa `:root`'a ekle + bu dosyaya işle.
4. Tüm durumlarını ve 360px'te davranışını kontrol et.
5. `ux-reviewer` ve `visual-design-critic` ile gözden geçir.

## Yasaklar
Rastgele hex, rastgele px, satır içi `style=` ile renk/ölçü, aynı işlev için iki farklı buton stili, yeni font ailesi, CDN stil/ikon, token dışı gölge/glow.
