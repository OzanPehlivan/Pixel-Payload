---
name: frontend-design
description: Üretim kalitesinde, özgün frontend arayüzü tasarlama ve kodlama (HTML/CSS/JS): görsel hiyerarşi, tipografi, renk, spacing, layout, component, responsive, CSS kalitesi. Pixel Payload'un yeni ekran, panel veya bileşenini yazarken veya mevcut görünümü iyileştirirken kullan. Designs distinctive, non-templated UI; avoids default AI-dashboard looks.
---

# Frontend Design (Pixel Payload)

Pixel Payload bir **multiplayer uzay mühendisliği oyunudur**; kurumsal yazılım, SaaS paneli veya yönetim konsolu DEĞİLDİR. Bu skill, ekranın nasıl *görüneceğini ve kodlanacağını* belirler. Ekranın *ne içereceği* için `game-ui-ux`, token'lar için `design-system`, hareket için `motion-design` skill'lerine bak.

## Önce incele (zorunlu)
1. `public/styles.css` `:root` token'larını, `public/index.html` yapısını ve `public/client.js`'in nasıl çizim yaptığını oku. Çalışan bir dil var: numaralı, köşe çentikli kartlar; ince üst çubuk; ince alt durum satırı; rol renkleri; JetBrains Mono sayılar.
2. Varsa `docs/stil-referans.jpg` ve `docs/demo-modu.png` dosyalarına bak.
3. Mevcut dili **uzat**, sıfırdan yeni bir stil icat etme. Yeni ekran mevcut ekranın akrabası olmalı ama kopyası değil.
4. Sunucuya, socket olaylarına, `viewFor` çıktısına DOKUNMA. İstemci sadece gelen görünümü çizer; oyun kuralı hesaplamaz. Gizlilik: çalışan rolleri görev ve sayı görmez, bunu UI'da sızdırma (ipucu, tooltip, gizli DOM dahil).

## Tasarım anayasası (kısa)
Hedef: modern oyun estetiği, güçlü görsel kimlik, kolay anlaşılırlık, akıcı etkileşim.
Kaçın: sıradan AI dashboard'ı, kurumsal admin paneli, aşırı karmaşık HUD, gereksiz tablo, her şeyi karta çevirmek, neon/cyberpunk klişesi, aşırı hologram/glow, gereksiz süs, çok küçük yazı, birbirinin kopyası ekranlar. Hiçbir popüler oyunun arayüzünü birebir kopyalama; ilham al, özgün üret.

## Süreç
1. **Konu:** Bu ekran hangi anı yaşatıyor? (fırlatma öncesi gerilim, parça seçimi, GO/NO-GO oylaması...) Tek cümleyle yaz.
2. **Tek ana iş:** Ekranın tek birincil eylemi ve ona giden net bir yol olsun. İkincil bilgiyi düğme arkasına (`<details>`, çekmece) al.
3. **Hero:** İlk bakışta görülen şey ekranın en karakteristik öğesi olsun (roket, görev kartı, geri sayım). Metin duvarı veya tablo değil.
4. **Kompozisyon:** Büyük öğeler, belirgin ölçek farkı, asimetrik denge. Aynı kart ızgarasını tekrar etme; ekranlar arasında düzen çeşitlendir (yan hero, tam genişlik sahne, merkezi odak).
5. **Yaz, tarayıcıda gör, düzelt.** Mümkünse `webapp-testing` ile ekran görüntüsü al ve `visual-design-critic`'e ver.

## Görsel hiyerarşi
- Üç seviye: **birincil** (en büyük/en kontrastlı, ekranda 1 tane), **ikincil** (bağlam), **üçüncül** (soluk, küçük).
- Hiyerarşiyi önce boyut ve ağırlıkla, sonra kontrast ve boşlukla kur; renkle en son. Her şey vurgulanırsa hiçbir şey vurgulanmamıştır.
- Göz akışı: sol-üst → hero → birincil eylem. Eylem düğmesi hero'ya yakın ve ekranın en belirgin kontrastı olsun.

## Tipografi
- Mevcut: gövde/başlık sistem sans (`Segoe UI` yığını), sayı ve kodlar `JetBrains Mono` (yerel, `/vendor/fonts/...`). **CDN yok, dış font indirme yok.**
- Ölçek (yaklaşık 1.25 oran): 13 / 16 / 20 / 25 / 31 / 39 / 49 px. Gövde ≥ 16px, en küçük yazı 13px ve yalnızca üçüncül bilgi.
- Başlıklar BÜYÜK HARF + harf aralığı (`letter-spacing: .04–.08em`); gövde sentence case. Satır uzunluğu 45–75 karakter, satır yüksekliği gövdede 1.5, başlıkta 1.1–1.2.
- Sayılar `font-variant-numeric: tabular-nums`; değişen değerler zıplamasın.
- Türkçe karakterleri (İ, ı, ş, ğ) test et; `text-transform: uppercase` Türkçe `i` için `lang="tr"` ister.

## Renk
- Token'lar `:root`'ta; rastgele hex yazma. Mevcut palet: zemin `#05080f`, panel `#0a1120`, çerçeve `#1b2a44`, metin `#e3ecf8`, soluk `#7f93b0`; vurgu camgöbeği/amber/yeşil/kırmızı.
- Kural: ekran başına **en çok 3 vurgu rengi**. Rol renkleri (rocket amber, spacecraft camgöbeği, payload yeşil, director açık metin) yalnızca rolü anlatır, başka anlam yüklenmez.
- Anlam renkleri sabit: yeşil = hazır/başarılı, kırmızı = engel/hata, amber = dikkat. Rengi tek başına anlam taşıyıcı yapma; ikon, etiket veya şekil ekle (renk körlüğü).
- Kontrast: metin ≥ 4.5:1, büyük metin ve UI sınırları ≥ 3:1. Glow'u tutumlu kullan: yalnızca etkin/kritik öğede, neon halo olarak değil.

## Spacing ve layout
- 4px tabanlı ölçek: 4, 8, 12, 16, 24, 32, 48, 64. Yakın öğeler yakın, ilgisiz öğeler uzak (yakınlık ilkesi). Bölümler arası boşluk > bölüm içi boşluk.
- Mevcut: `--pad: 24px`, düğme yüksekliği ≥ 48px, kart çentiği `--cut: 16px`.
- Layout için `grid` / `flex` + `gap`; sabit piksel yükseklik ve `position: absolute` ile hizalama yok. `min-height: 100dvh` kullan, mobil adres çubuğunu hesaba kat.
- Aynı ekranda hizalama çizgilerini azalt: sol kenar ortak, sayı sütunları sağa hizalı.

## Component tasarımı
- Her bileşenin durumları tasarlanmış olsun: varsayılan, hover, `:focus-visible`, active, disabled, loading, hata, boş.
- Dokunma hedefi ≥ 44×44px. Disabled düğme neden devre dışı olduğunu söylesin (yanında tek satır).
- Kart sadece gerçekten gruplanan içerik için; sayfayı kartlara bölme. Düz yüzey, ince çizgi veya boşluk çoğu zaman daha iyi gruplar.
- Boş durum ve hata durumu bir sonraki adımı söylesin ("Henüz rol seçilmedi → bir rol seç").

## Responsive
- Mobile-first yaz, `min-width` breakpoint'leri (token'lara bak: `design-system`). Oyuncular telefonda da girer: 360px genişlikte yatay kaydırma olmasın, `overflow-x: clip` mevcut.
- Hero ve eylem düğmesi küçük ekranda da ilk ekranda görünsün. Çok sütunlu düzenler tek sütuna indiğinde öncelik sırası bozulmasın.
- `clamp()` ile akışkan tipografi; sabit genişlik yerine `min()`/`max()`.

## CSS kalitesi
- Düz CSS (framework yok). Token'lar custom property; magic number yok. Seçici özgüllüğü düşük, `!important` yok (`[hidden]` kuralı hariç).
- Bileşen başına tek sınıf kökü (`.card`, `.card__title` gibi mevcut adlandırmayı sürdür). Ölü CSS bırakma, ekran kaldırıldıysa stilini de sil.
- Animasyon için `transform`/`opacity`; layout özelliklerini canlandırma. `prefers-reduced-motion` desteği `motion-design`'dadır.
- Semantik HTML: `button`, `nav`, `main`, `h1–h3` sırası, `label` ilişkilendirmesi. Dekoratif SVG `aria-hidden="true"`.

## Özgün dil nasıl kurulur
Ortak dili (çentikli çerçeve, numaralı kart, BÜYÜK HARF başlık, köşeli parantezli açıklama) imza olarak koru; her ekrana **ekrana özgü bir sahne** ver: SVG ile çizilmiş roket kesiti, yörünge çizgisi, görev rozeti, geri sayım halkası. Süs değil bilgi taşısın. Hazır ikon paketi / stok görsel yok; kod ile çiz (SVG/CSS), kullanıcının PNG çizimleri gelirse yerine koy.

## Bitirmeden önce
- [ ] Mevcut token'ları kullandım, yeni sabit renk/ölçü eklemedim (ya da `design-system` kuralıyla ekledim)
- [ ] Tek ana eylem net; ekran 3 saniyede okunuyor
- [ ] 360px, 768px, 1280px'te taşma yok
- [ ] Klavye ile gezilebiliyor, `:focus-visible` görünüyor
- [ ] Gizlilik: çalışan görünümünde yasak veri yok
- [ ] Ekran görüntüsüyle kontrol ettim, ya da kontrol edemediğimi açıkça söyledim

Önceki upstream skill metni `references/anthropic-original.md` dosyasında saklıdır (lisans: `LICENSE.txt`); gerekirse ilham için oku.
