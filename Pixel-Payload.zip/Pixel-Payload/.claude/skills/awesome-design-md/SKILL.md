---
name: awesome-design-md
description: 84 ünlü markanın tasarım dili analizini (renk, tipografi, spacing, component, do/don't) DESIGN.md biçiminde içeren referans koleksiyonu (VoltAgent/awesome-design-md, MIT). Pixel Payload için ilham ve token kalıbı gerekirse kullan; örn. SpaceX, PlayStation, Nintendo, Linear, Figma. Birebir kopyalama için değil, ilham ve yapı için.
---

# Awesome DESIGN.md (referans koleksiyonu)

Kaynak: https://github.com/VoltAgent/awesome-design-md (MIT, `LICENSE` dosyası burada). Bu klasör bir skill değil **referans kütüphanesidir**; bu `SKILL.md` projeye eklenmiş kısa kullanım notudur (upstream'de yoktur).

## Nerede
`references/<marka>.md`: her biri bir markanın "inspired design analysis" dosyası. Üstte YAML front matter (`colors`, `typography`, `spacing`, `rounded`, `components`...), altta prose: görsel tema, renk rolleri, tipografi, component stilleri, layout, derinlik, do/don't, responsive.

Pixel Payload için en ilgili olanlar: `spacex.md` (havacılık, siyah zemin, tam ekran sahne), `playstation.md`, `nintendo-2001.md` (oyun markaları), `linear.app.md` (sakin, net hiyerarşi), `figma.md`, `apple.md`.
Tam liste: `ls references/`.

## Nasıl kullanılır
1. İhtiyaca uyan 1–2 dosyayı oku (hepsini değil; bağlamı şişirir).
2. **Yapıyı ve ilkeleri** al: renk rolleri nasıl adlandırılmış, tipografi ölçeği, boşluk ritmi, component durumları, "ne yapma" listesi.
3. Pixel Payload'a uyarla: mevcut token'lar (`public/styles.css`) ve `design-system` skill'i önceliklidir. Yeni değer eklenecekse oradaki kurallarla ekle.
4. **Hiçbir markanın arayüzünü birebir kopyalama**; renk paletini, fontunu, logosunu ve imza düzenini taşıma. Ham ilham olarak kullan, özgün bir dil üret (proje anayasası).
5. Fontlar ve görseller bu dosyalarda bulunmaz/lisanslı olabilir; CDN yok, yalnızca yerel font kuralı geçerli.

## İlgili skill'ler
`game-ui-ux` (ne tasarlanacağı), `frontend-design` (nasıl kodlanacağı), `design-system` (token uyumu), `ui-ux-pro-max` (stil/palet/font arama verisi).
