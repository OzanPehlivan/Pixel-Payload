---
name: motion-design
description: Pixel Payload arayüzlerine anlamlı ve performanslı hareket kazandırır: micro-interaction, hover, buton geri bildirimi, sayfa/modal geçişleri, yükleme, ilerleme, başarı/hata geri bildirimi, oyun durumu geçişleri. prefers-reduced-motion'a uyar. Animasyon eklerken veya değiştirirken kullan.
---

# Motion Design (Pixel Payload)

Hareket süs değil **bilgidir**: bir şeyin değiştiğini, neyin önemli olduğunu ve eylemin kabul edildiğini söyler. Soru: "Bu hareket oyuncuya ne anlatıyor?" Cevap yoksa ekleme.

## Anayasa (kısa)
Oyun estetiği, akıcı etkileşim, profesyonel kalite. Kaçın: aşırı glow/hologram, sürekli yanıp sönen süs, anlamsız dönen/titreyen öğeler, neon klişeleri. Mevcut proje kuralı: **yalnız acil durumlar nabız atar** (son 30 sn, bekleme, kilit); tarama çizgisi, süs yanıp sönmesi yok.

## İlkeler
1. **Anlamlı:** Hareket neden-sonuç gösterir (tıkladım → kabul edildi, faz değişti, hata oldu).
2. **Ekonomik:** Aynı anda tek odak hareket. Ekran başına en çok 1 sürekli animasyon (nabız dahil).
3. **Hızlı:** Oyuncuyu bekletme; eylem geri bildirimi hemen başlar.
4. **Performanslı:** Yalnızca `transform` ve `opacity` canlandır. `width/height/top/left/box-shadow` canlandırma (layout/paint tetikler). `will-change` yalnızca etkin animasyonda ve sonra kaldır.
5. **Saygılı:** `prefers-reduced-motion` zorunlu.

## Süre ve eğri (token olarak `:root`'a koy, `design-system` kuralı)
| Amaç | Süre | Eğri |
|---|---|---|
| Hover/focus, buton basma | 100–150ms | `ease-out` |
| Küçük geçiş (toast, rozet, çekmece) | 180–250ms | `cubic-bezier(.2,.8,.2,1)` |
| Modal / ekran geçişi | 250–400ms | `cubic-bezier(.2,.8,.2,1)` giriş, `ease-in` çıkış (çıkış girişten kısa) |
| Faz geçişi, sonuç açılışı | 400–700ms | sahneye özel, tek seferlik |
Bu sınırın üstü yalnızca fırlatma/sonuç gibi sinematik anlarda ve atlanabilir olsun. Eğri: `linear` yalnız sürekli dönen yükleme/ilerleme için.

```css
:root {
  --dur-fast: 120ms; --dur-base: 220ms; --dur-slow: 360ms;
  --ease-out: cubic-bezier(.2,.8,.2,1);
}
@media (prefers-reduced-motion: reduce) {
  *, *::before, *::after {
    animation-duration: .01ms !important; animation-iteration-count: 1 !important;
    transition-duration: .01ms !important; scroll-behavior: auto !important;
  }
}
```
Reduced-motion'da **bilgi kaybolmamalı**: hareket yerine anlık renk/ikon/metin değişimi kalır (ör. nabız yerine sabit kırmızı çerçeve + "SÜRE DOLUYOR").

## Kataloğ

**Micro-interaction / hover:** Kart ve düğme `:hover` → çerçeve parlaklığı artar, 1–2px `translateY(-1px)`; `:active` → `scale(.98)`. Dokunmatikte hover'a bağımlı bilgi yok (`@media (hover:hover)` içine al).
**Buton geri bildirimi:** Basınca anlık tepki (≤ 100ms) + gönderim sırasında `loading` (dönen halka, metin korunur, genişlik sabit). Çift tıklamayı engelle.
**Sayfa/faz geçişi:** Lobi → inşa → anket → fırlatma → sonuç: çıkan ekran kısa solar, giren ekran `opacity+translateY(8px)` ile gelir; hero öğeler (roket, rozet) geçişte sabit kalıp bağlamı taşır. Yön oyun akışını anlatır (ileri = sağdan/aşağıdan).
**Modal/çekmece:** Giriş `opacity + scale(.98→1)` veya kenardan `translateX`; arka plan karartması ayrı fade. Kapanış girişten hızlı. Odak yönetimi hareketten bağımsız doğru çalışmalı.
**Yükleme:** Bağlanıyor/bekleniyor için iskelet veya tek küçük döngü; metinle ne beklendiğini söyle. 300ms'den kısa beklemede gösterme (flaş yapar).
**İlerleme:** Çubuk `transform: scaleX()` ile dolar (width değil); değer değişimi 200–300ms yumuşar; sayı değişiminde tabular rakamlar, gerekirse kısa yukarı-aşağı kayma.
**Başarı:** Küçük, net: yeşil onay çizilir (SVG `stroke-dashoffset`), 1 kez, ~400ms. Konfeti/patlama yok; büyük kutlama yalnızca görev başarısı sonuç ekranında ve atlanabilir.
**Hata:** Kısa yatay sarsıntı (±4px, 2 salınım, ~250ms) + kırmızı çerçeve + metin; sarsıntı tek başına bilgi değil, mesaj şart. Sürekli titreme yok.
**Oyun durumu geçişleri:** Parça yerleşti → slot rengiyle kısa halka; `ok`/`blocked` vurgusu yumuşak geçişle değişir; GO/NO-GO oyu → rozet dolar; geri sayım → rakam değişiminde ölçek vuruşu; fırlatma/sonuç → `playLaunch(outcome)` sahnesi (her zaman resolve olur, takılı kalmaz; mevcut sözleşmeyi bozma).

## Uygulama notları
- Önce CSS `transition`/`@keyframes`; JS animasyonu (Web Animations API) yalnızca sıralama/dinamik değer gerektiğinde. Framework/animasyon kütüphanesi ekleme (CDN yok).
- Giriş/çıkışta `display:none` geçişi animasyonlanmaz; `hidden` yerine sınıf + `transitionend`/`animationend` ile yönet (projede `[hidden]` kuralı var, uyumlu çalış).
- SVG sahnede (`scene2d.js`) `requestAnimationFrame` döngüsü sekme gizliyken dursun (`document.hidden`) ve `dispose()` temizlesin.
- Düşük güç/mobilde yüzlerce eleman canlandırma; gölge ve filtre animasyonu yok.

## Bitirmeden önce
- [ ] Her animasyonun anlattığı bir şey var
- [ ] Yalnızca `transform`/`opacity` canlandı
- [ ] `prefers-reduced-motion` açıkken test ettim; bilgi kaybolmuyor
- [ ] Aynı anda tek odak hareket; sürekli animasyon ≤ 1 ve acil durum için
- [ ] Hareket hızlı; eylemi geciktirmiyor
- [ ] 60 fps'yi bozan yok (gerekirse DevTools Performance ile baktım, bakamadıysam söyledim)
