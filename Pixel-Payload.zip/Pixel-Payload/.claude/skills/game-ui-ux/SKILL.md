---
name: game-ui-ux
description: Pixel Payload için profesyonel oyun arayüzü tasarımı: HUD, ana menü, çok oyunculu lobi, görev seçimi, görev brifingi, envanter/ekipman seçimi, ilerleme, oyuncu rolleri, görev simülasyonu, bildirimler, geri bildirim ve navigasyon. Yeni oyun ekranı veya akışı tasarlarken ilk bu skill'i kullan.
---

# Game UI/UX (Pixel Payload)

Bu bir **oyun**. Oyuncu bir şey *yapmak* ister; panel okumak istemez. Her ekranda önce "oyuncu şimdi ne yapacak?" sorusuna cevap ver.

## Oyun bağlamı
Dört oyuncu farklı uzay mühendisliği rollerini üstlenip birlikte görev yapar. Aynı odada sesli konuşurlar; arayüz sohbet penceresi değil, ortak masadaki ekran gibidir.

| Kullanıcı terimi | Kod kimliği (`role`) | Renk | Not |
|---|---|---|---|
| Operator | `director` | açık metin | Görevi ve tüm sayıları görür, parçaya dokunamaz |
| Propulsion Engineer | `rocket` | amber | Roket & Yakıt tarafı |
| Spacecraft Engineer | `spacecraft` | camgöbeği | Uzay aracı tarafı |
| Science & Payload Engineer | `payload` | yeşil | Bilimsel yük/enstrüman |

Görevler: **Human Lunar Mission** ve **Mars Rover Mission**. Projede şu an `data/missions.json` farklı kartlar içerebilir (ör. Ay Röle Uydusu); kod kimliklerini ve içeriği oradan al, kendin uydurma. İki görev arasındaki kimlik farkını (Ay: insanlı, yaşam desteği, güvenli dönüş; Mars: iniş, enerji, bilim yükü) arayüzde renk, rozet ve sahne ile belirgin kıl.

**Gizlilik kuralı (oyun mekaniği):** Çalışanlar görev bilgisini ve sayısal değerleri GÖRMEZ; yalnızca Operator görür. Hiçbir ekran bunu UI'da sızdırmaz (tooltip, ipucu, renk kodu, ilerleme çubuğu oranı dahil). Çalışan ekranı "ne yapabilirim"i gösterir, "doğru cevap"ı değil. Bilmen gereken veri `server/filter.js` `viewFor()` çıktısıdır; alan yoksa ekran uydurmaz.

## Tasarım anayasası (kısa)
Modern oyun estetiği, güçlü görsel kimlik, kolay anlaşılırlık, oyuncu odaklılık, akıcı etkileşim. Kaçın: SaaS/admin paneli, aşırı karmaşık HUD, gereksiz tablo, her şeyi karta çevirmek, neon/cyberpunk klişesi, aşırı hologram/glow, süs, çok küçük yazı, birbirinin kopyası ekranlar. Popüler oyun UI'larını kopyalama.

## Ekran ilkeleri
1. **Bir sonraki adım görünür.** Her ekranda birincil eylem tek ve büyük. Oyuncu 3 saniyede "şimdi ne" bilir. Beklemesi gerekiyorsa neyi beklediğini söyle ("Roket Mühendisi parça seçiyor").
2. **Göster, anlatma.** Sayı ve paragraf yerine ikon, çizim, ölçek, ilerleme çubuğu. Ekran başına en fazla ~3 satırlık metin; gerisi `<details>`/çekmece.
3. **Büyük öğeler.** Düğmeler ≥ 48px, başlıklar büyük, en küçük yazı 13px. Okunacak şey uzaktan da okunmalı (aynı odada ortak ekran olabilir).
4. **Ekran başına tek ana iş, en çok 3 vurgu rengi.** Rol rengi oyuncunun kimliğidir; her ekranda kendi rengini küçük ama tutarlı biçimde görsün.
5. **Her ekran farklı bir kompozisyon.** Aynı kart ızgarasını tekrar etme: lobi = koltuk/rol sahnesi, brifing = görev posteri, inşa = roket kesiti, fırlatma = tam ekran sahne, sonuç = rozet + hikâye.
6. **Her eylemin geri bildirimi var:** tıklama, kabul, ret, bekleme, hata. (Hareket için `motion-design`.)

## Ekran kataloğu

### Ana menü
Büyük numaralı kartlar (Oda Aç / Odaya Katıl / Demo), sağda hero alan (roket veya görev sahnesi). İsim girişi minimum sürtünme. `NASIL OYNANIR` tek düğme arkasında.

### Çok oyunculu lobi
Dört koltuk görseli; her koltukta rol rozeti, oyuncu adı, bağlantı durumu. Seçilebilir roller **ne yaptığını tek satırda** anlatır ("Roketi ve yakıtı sen kurarsın"). Dolu rol soluk ve kilitli, nedeni görünür. Oda kodu büyük ve kopyalanabilir. 4 rol dolunca otomatik başlar: geri sayım ya da net geçiş göster. Eksik rolleri "1 kişi daha lazım" gibi söyle.

### Görev seçimi ve brifing
Yalnızca Operator görevin ayrıntısını görür (hedef, bütçe, süre). Çalışanlar "GİZLİ" brifing posteri görür; kendi rollerinin görevini (ne kurar, hangi araca dokunur) görür. Brifing posteri: rozet, hedef gök cismi çizimi, 3 anahtar bilgi. NASA bilgisi (nasaFact) kısa, sonuç ekranında genişler.

### HUD (inşa/simülasyon sırasında)
- Üst: görev adı/zaman (Operator), kendi rolün. Alt: oda · rol · faz tek satır, soluk.
- Orta: hero = roket/araç sahnesi (SVG). Parça ve slotlar doğrudan sahnede seçilir.
- Yan çekmece: katalog/kayıt/ham durum, kapalı başlar.
- Sayısal göstergeler yalnız Operator'da; birkaç büyük gösterge (yeşil/amber/kırmızı + ikon), tablo değil.
- Kritik durum (son 30 sn, bekleme, kilit) nabız atar; başka bir şey atmaz.

### Envanter ve ekipman seçimi
Parçalar görsel kart değil **nesne** gibi: çizim + ad + 1–2 özellik simgesi. Sürükle-bırak yerine tıkla-yerleştir öncelikli (dokunmatik uyumlu); uyumsuz yuva nedenini söyleyerek soluk gösterilir. Seçili parça sahnede önizlenir. Sepet/maliyet gibi sayılar Operator'a özgü olabilir; çalışana veri sızdırma.

### GO/NO-GO ve fırlatma
Anket ekranı: her rolün oyu büyük rozetle (oy verdi/vermedi; oyun içeriği gizli kalmaz). Fırlatma sahnesi tam ekran, minimum UI. Sonuç: başarı/başarısızlık net, nedeni tek cümle, sonra NASA gerçeği.

### İlerleme ve rol deneyimi
Oyuncu kendi aşamasını ve ekibin aşamasını tek bakışta görsün (aşama noktaları). Roller arası bağımlılık görünür ("Faydalı Yük parçaları bekleniyor").

### Bildirimler ve geri bildirim
- Toast: kısa (≤ 8 kelime), 3–4 sn, eylem varsa düğmeli. Aynı anda en çok 2.
- Hata: ne oldu + ne yapmalı. Suçlayıcı dil yok.
- Başarı: abartma; küçük, net onay.

### Navigasyon
Oyun akışı doğrusal; geri dönüş yolu belli. Yanlışlıkla odadan çıkmayı onayla. Yeniden bağlanma durumu görünür ("Bağlantı koptu, dönüyor...").

## İletişim (UI'da mesajlaşma tasarlanıyorsa)
- Mühendisler **yalnızca Operator'a** mesaj gönderebilir.
- Operator **her mühendise özel** mesaj gönderebilir ve **herkese toplu** mesaj gönderebilir.
- Mühendisler birbirinin özel konuşmalarını **göremez**; arayüz, sekme, rozet sayısı veya "yazıyor..." göstergesi ile de sızdırmaz.
- Alıcı seçimi mühendis tarafında yoktur (hep Operator); Operator tarafında "Herkese / Roket / Uzay Aracı / Faydalı Yük" büyük seçici.
Bu kuralları ihlal eden öneri yapma. Şu an PLAN'da sohbet yoksa (sesli iletişim), ekle önermeden önce şefe sor.

## Bitirmeden önce
`frontend-design` (görsel yapı) → `design-system` (token uyumu) → `ux-reviewer` (akış ve yetki) → `visual-design-critic` (ekran görüntüsüyle) sırasını izle; animasyon gerekiyorsa `motion-design`.
