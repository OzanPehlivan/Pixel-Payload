# PLAN — Pixel Payload

## Oyun özeti
NASA Space Apps hackathonu için gerçek zamanlı, 4 oyunculu, tarayıcıda çalışan, asimetrik bilgi oyunu.
1 YÖNETİCİ (görevi ve tüm sayıları görür, parçaya dokunamaz) + 3 ÇALIŞAN (roket, uzay aracı, faydalı yük;
görevi ve sayıları GÖRMEZ) birlikte roket + uzay aracı kurar. Oyuncular aynı odada sesli konuşur.

- **Teknoloji:** Node.js + Express + Socket.io (CommonJS, `require`). Frontend: sade HTML/CSS/JS, framework yok.
- **Tek gerçek kaynak sunucudur.** İstemci hiçbir oyun kuralı hesaplamaz, sadece gelen `state` görünümünü çizer.
- **GÜVENLİK:** İstemciye giden her veri `server/filter.js` içindeki `viewFor()` üzerinden geçer.
  Çalışanlara görev bilgisi ve sayısal değer HİÇ gönderilmez. Ham `room` nesnesi asla emit edilmez.

## Aşamalar (her aşamadan sonra kullanıcı test eder)
1. **Oda sistemi + 4 rol + role göre filtrelenmiş durum (sadece metin, tasarımsız)** ← ŞU AN
2. Parça takma/çıkarma + hesaplamalar + yönetici göstergeleri
3. Görev kartları + GO/NO-GO + fırlatma/sonuç ekranı
4. Zaman baskısı, rastgele olaylar, geri alma
5. Pixel-art arayüz ve animasyonlar

## Dosya yapısı
```
package.json            (Modül B)
server/
  index.js              (Modül B)  Express + Socket.io bağlama
  constants.js          (Modül A)  ROLES, PHASES, GameError
  rooms.js              (Modül A)  oda/oyuncu/rol mantığı (socket bilmez)
  filter.js             (Modül A)  viewFor(room, playerId) — role göre filtre
data/
  missions.json         (Modül A)  görev kartları
  parts.json            (Aşama 2)
public/
  index.html            (Modül C)
  client.js             (Modül C)
test/
  stage1.test.js        (Modül A)  node:test ile rooms + filter birim testleri
```

## Sabitler (herkes aynen kullanır)
- Rol kimlikleri: `'director'` (Yönetici), `'rocket'` (Roket & Yakıt), `'spacecraft'` (Uzay Aracı), `'payload'` (Faydalı Yük)
- Çalışan rolleri: `['rocket','spacecraft','payload']`
- Fazlar: `'lobby'` → `'building'` (→ ileride `'poll'`, `'launch'`, `'result'`)
- Oda kodu: 4 büyük harf, karışmasın diye `I` ve `O` hariç (A–Z).
- İsim: trim edilir, 1–16 karakter.
- Port: `process.env.PORT || 3000`, `0.0.0.0` üzerinde dinler.

## Sunucu durumu (state şeması) — sadece sunucuda yaşar
```js
room = {
  code: 'KXQZ',
  phase: 'lobby',                 // 'lobby' | 'building' | ...
  createdAt: 1700000000000,
  players: {                      // playerId -> player (en fazla 4)
    [playerId]: { id, name, role: null | roleId, connected: true }
  },
  mission: null,                  // 'building' başlarken missions.json'dan rastgele bir kart (TAM nesne)
  build: { rocket: [], spacecraft: [], payload: [] },   // Aşama 2: [{ uid, partId }]
  telemetry: {                    // Aşama 2'de hesaplanır; Aşama 1'de sıfırlarla durur
    massKg: 0, twr: 0, deltaV: 0, powerGenW: 0, powerUseW: 0, heat: 0, spent: 0
  },
  log: [],                        // { t: epochMs, playerId, role, text }
  undoLeft: 3                     // Aşama 4
}
```
`playerId`: sunucunun ürettiği tahmin edilemez kimlik (`crypto.randomUUID()`), aynı zamanda yeniden bağlanma anahtarı.
Başka oyunculara ASLA tam `playerId` gönderilmez (görünümlerde oyuncular `seat` ile anılır, aşağıya bak).

### Görev kartı biçimi (`data/missions.json` → dizi, en az 3 kart)
```json
{ "id": "lunar-relay", "title": "...", "target": "...", "requiredDeltaV": 4100,
  "requiredInstruments": ["partId", "..."], "budget": 1000, "durationSec": 300,
  "nasaFact": "1–2 cümle gerçek NASA bilgisi", "nasaReal": "Sonuç ekranı için: gerçekte NASA bunu şöyle yapıyor..." }
```
Kartlar: Ay yörüngesine haberleşme uydusu, Mars'a rover indirme, asteroitten örnek getirme.
`requiredInstruments` Aşama 2'deki payload parça kimliklerine denk gelecek; şimdilik anlamlı kimlikler yaz
(`relay-antenna`, `rover`, `sample-capsule`, `camera`, `spectrometer`, `drill` ...).

## İstemci görünümü (`viewFor` çıktısı) — istemciye giden TEK veri biçimi
Ortak alanlar (herkes):
```js
{
  code, phase,
  you: { id, name, role },                       // kendi playerId'si sadece kendisine
  players: [ { seat, name, role, connected, isYou } ],   // seat: 0..3 katılma sırası; playerId YOK
  roles: { director: seat|null, rocket: seat|null, spacecraft: seat|null, payload: seat|null }
}
```
Yönetici (`you.role === 'director'`) ve `phase !== 'lobby'` ise ek olarak:
```js
{ mission: {...tam kart}, telemetry: {...}, build: {...}, log: [...], undoLeft }
```
Görünümdeki `log` girdileri `{ t, role, text }` biçimindedir (`playerId` çıkarılır; sistem mesajında `role` null).
Çalışan (rolü director olmayan herkes, rolsüzler dahil) için ek olarak:
```js
{ missionLabel: 'GİZLİ' }      // phase !== 'lobby' ise
```
**Kesin kural:** Çalışan görünümünde `mission`, `telemetry`, `log`, `undoLeft` anahtarları HİÇ bulunmaz (null bile değil).
Lobide (`phase === 'lobby'`) kimseye mission/telemetry gitmez (zaten `mission` null'dur).
`viewFor` beyaz liste ile kurar (yeni nesne oluşturur), room'dan alan silerek değil.

## Socket.io olayları
İstemci → sunucu (hepsi ack callback'li: `socket.emit(ev, payload, (res) => ...)`):
| Olay | Payload | Ack (başarı) |
|---|---|---|
| `room:create` | `{ name }` | `{ ok:true, code, playerId }` |
| `room:join` | `{ code, name }` | `{ ok:true, code, playerId }` |
| `room:rejoin` | `{ code, playerId }` | `{ ok:true, code, playerId }` |
| `role:select` | `{ role }` (`null` = rolü bırak) | `{ ok:true }` |
| `room:leave` | `{}` | `{ ok:true }` |

Hata ack'i her zaman: `{ ok:false, error: 'KOD', message: 'Türkçe açıklama' }`.
Hata kodları: `NAME_REQUIRED`, `ROOM_NOT_FOUND`, `ROOM_FULL`, `GAME_STARTED`, `ROLE_TAKEN`, `INVALID_ROLE`, `NOT_IN_ROOM`, `BAD_REQUEST`.

Sunucu → istemci:
| Olay | Payload |
|---|---|
| `state` | o oyuncuya özel `viewFor(room, playerId)` çıktısı. Her değişiklikte odadaki HER oyuncuya ayrı ayrı gönderilir (oda yayını YOK). |
| `room:closed` | `{ reason }` — oyuncu odadan çıkarıldıysa / oda silindiyse |

Kurallar:
- Lobide rol seçilir/değiştirilir/bırakılır. Her rol tek kişi. 4 rol dolunca oyun OTOMATİK başlar
  (`phase='building'`, rastgele görev atanır, log'a "Oyun başladı" düşer). Başladıktan sonra rol değişmez.
- Lobide bağlantı koparsa / `room:leave`: oyuncu odadan silinir (rolü boşalır).
- Oyun başladıktan sonra bağlantı koparsa: `connected=false`, koltuk ve rol korunur; `room:rejoin` ile döner.
- Başlamış oyuna yeni oyuncu katılamaz (`GAME_STARTED`). 4 oyuncu doluysa `ROOM_FULL`.
- Hiç bağlı oyuncusu kalmayan oda 5 dk sonra silinir (lobide boş kalan oda hemen silinir).

## Modüller

### Modül A: Oyun çekirdeği (oda mantığı + filtre + görev verisi)
- [x] Durum: tamamlandı
- **Sahip dosya(lar):** `server/constants.js`, `server/rooms.js`, `server/filter.js`, `data/missions.json`, `test/stage1.test.js`
- **Sorumluluk:** Socket'ten bağımsız saf oyun mantığı. Oda oluşturma/katılma/rol seçme/başlatma, role göre görünüm üretme, görev kartları.
- **Arayüz:**
  - `server/constants.js` → `module.exports = { ROLES, WORKER_ROLES, PHASES, MAX_PLAYERS, GameError }`
    - `ROLES = ['director','rocket','spacecraft','payload']`, `PHASES = { LOBBY:'lobby', BUILDING:'building' }`, `MAX_PLAYERS = 4`
    - `class GameError extends Error { constructor(code, message) }` → `.code` hata kodu, `.message` Türkçe açıklama
  - `server/rooms.js` → `module.exports = { createRoomManager }`
    - `createRoomManager({ missions, rng = Math.random })` → manager nesnesi. Hatalarda `GameError` fırlatır.
    - `manager.createRoom(name)` → `{ room, player }`
    - `manager.joinRoom(code, name)` → `{ room, player }` (code büyük/küçük harf duyarsız, trim'li)
    - `manager.getRoom(code)` → `room | undefined`
    - `manager.getPlayer(code, playerId)` → `player | undefined`
    - `manager.selectRole(code, playerId, role)` → `room` (role `null` ise bırakır; 4 rol dolunca oyunu başlatır)
    - `manager.setConnected(code, playerId, connected)` → `room | undefined`
      (lobide `connected=false` oyuncuyu SİLER; oda boşaldıysa odayı siler ve `undefined` döner)
    - `manager.removePlayer(code, playerId)` → `room | undefined` (lobide siler; oyundayken `connected=false` yapar)
    - `manager.deleteRoom(code)` → `void`
    - `manager.playerIds(code)` → `string[]`
  - `server/filter.js` → `module.exports = { viewFor }`
    - `viewFor(room, playerId)` → yukarıdaki "İstemci görünümü" nesnesi; oyuncu odada değilse `null`.
- **Bağımlılıklar:** yok (sadece Node çekirdeği)
- **Test:** `test/stage1.test.js` — `node --test` ile çalışır; en az: oda/katılma/rol çakışması/otomatik başlama,
  ve **çalışan görünümünün JSON'unda görev başlığı, `requiredDeltaV`, `telemetry`, başka oyuncuların `playerId`'si geçmediği** doğrulanır.
- **Atanan agent:** gelistirici
- **Notlar:** 13 test geçti. Yönetici görünümündeki `log` girdileri `{ t, role, text }` (playerId çıkarıldı, sızmasın diye). Node 24'te `node --test test/` dizini modül sanıp hata veriyor; `node --test "test/**/*.test.js"` kullanın.

### Modül B: Sunucu bağlama (Express + Socket.io)
- [x] Durum: tamam
- **Sahip dosya(lar):** `package.json`, `server/index.js`, `.gitignore`
- **Sorumluluk:** `public/` klasörünü statik sunar, Socket.io olaylarını Modül A'nın manager'ına bağlar, her değişiklikte
  her oyuncuya kendi `viewFor` görünümünü gönderir. Başlarken LAN IP adreslerini konsola yazar (telefonla bağlanmak için).
- **Arayüz:** Yukarıdaki "Socket.io olayları" tablosu birebir. `npm start` → `node server/index.js`. `npm test` → `node --test "test/**/*.test.js"` (Node 24'te `node --test test/` çalışmıyor).
  - socket ↔ oyuncu eşlemesi `socket.data = { code, playerId }` ile tutulur; `playerId -> socket.id` haritası index.js içindedir.
  - Aynı `playerId` ile ikinci bir socket `room:rejoin` yaparsa eski socket düşürülür (yeni olan geçerli).
  - `GameError` → hata ack'i; beklenmeyen hata → `{ ok:false, error:'BAD_REQUEST', message }` (sunucu çökmez). Payload/ack eksikse de çökmez.
  - `missions` → `require('../data/missions.json')`.
  - Boş oda temizliği (5 dk) burada zamanlanır, `manager.deleteRoom` çağrılır.
  - `module.exports = { app, server, io }` ve dosya doğrudan çalıştırıldığında (`require.main === module`) dinlemeye başlar.
- **Bağımlılıklar:** Modül A arayüzü (`createRoomManager`, `viewFor`, `GameError`). npm: `express`, `socket.io`.
- **Atanan agent:** gelistirici
- **Notlar:** test script `node --test "test/**/*.test.js"` (Node 24). `room:leave` odada değilken de `{ok:true}` döner. Ack önce, `state` sonra gönderilir. Rejoin'de eski socket'e `room:closed` gidip bağlantısı kesilir. 4 istemcili duman testi geçti.

### Modül C: İstemci (metin tabanlı, tasarımsız)
- [x] Durum: tamam
- **Sahip dosya(lar):** `public/index.html`, `public/client.js`
- **Sorumluluk:** Aşama 1 için çıplak, işlevsel arayüz (pixel-art Aşama 5'te). Mobilde kullanılabilir olsun (viewport meta, büyük butonlar) ama süsleme yok.
- **Arayüz / davranış:**
  - Socket.io istemcisi `/socket.io/socket.io.js` üzerinden; yukarıdaki olay tablosu birebir.
  - Ekranlar (tek sayfa, `state`'e göre göster/gizle):
    1. **Giriş:** isim alanı, "Oda Aç" butonu, 4 harfli kod alanı + "Katıl" butonu, hata mesajı alanı.
    2. **Lobi** (`phase==='lobby'`): oda kodu (büyük), oyuncu listesi, 4 rol butonu (dolu olan devre dışı ve kimin aldığı yazılı; kendi rolüne tekrar basınca bırakır), "Odadan çık".
    3. **Oyun** (`phase==='building'`): rol adı; yönetici ise görev kartı + telemetri + log metin olarak; çalışan ise sadece "Görev: GİZLİ" ve oyuncu listesi.
    4. Geliştirme yardımı: sayfanın altında `<details>` içinde ham `state` JSON'u (`<pre id="debug-state">`) — filtrelemeyi gözle doğrulamak için.
  - `{ code, playerId }` **`sessionStorage`**'da tutulur (aynı tarayıcıda 4 sekmeyle test edilebilsin diye localStorage DEĞİL).
    Sayfa açılışında/yeniden bağlanmada (`connect` olayı) kayıt varsa `room:rejoin` dener; başarısızsa kaydı siler ve giriş ekranına döner.
  - `room:closed` gelince kaydı sil, giriş ekranına dön.
  - İstemci hiçbir oyun kuralı hesaplamaz; sadece son `state`'i çizer.
  - Test kolaylığı için sabit id'ler: `#name-input`, `#create-btn`, `#code-input`, `#join-btn`, `#error-msg`, `#room-code`,
    `#player-list`, rol butonları `[data-role="director|rocket|spacecraft|payload"]`, `#leave-btn`, `#screen-entry`, `#screen-lobby`,
    `#screen-game`, `#role-name`, `#mission-box`, `#telemetry-box`, `#log-box`, `#debug-state`.
- **Bağımlılıklar:** Modül B'nin socket olayları ve "İstemci görünümü" biçimi.
- **Atanan agent:** gelistirici
- **Notlar:** `#room-code` ve `#player-list` lobi ile oyunda ortak `#room-info` bölümünde (id'ler tekil kalsın diye); `#error-msg` ekranlardan bağımsız, her zaman görünür. `node --check` geçti; uçtan uca denenmedi.

## Paralel dağıtım
- **Grup 1 (paralel):** Modül A, Modül B, Modül C (arayüzler yukarıda sabit; hiçbiri diğerinin dosyasına dokunmaz)

## Yardımcı işler
- (yok — klasörleri gelistirici'ler kendi dosyalarıyla oluşturur)

## Test-düzelt turları (en fazla 3)
- [x] Tur 1 (Aşama 1) — 11/11 madde geçti, yalnızca düşük önemde kozmetik bulgular; düzeltme turu gerekmedi
- [ ] Tur 2
- [ ] Tur 3

## Son durum (şef doldurur) — Aşama 1
- **Çalışanlar:** oda açma/katılma (4 harfli kod), 4 rol seçimi, 4 rol dolunca otomatik başlama, role göre filtrelenmiş
  durum (çalışanlara görev/sayı/başka playerId gitmiyor — ham WebSocket çerçevelerinde doğrulandı), oyunda yeniden bağlanma,
  bozuk payload dayanıklılığı, mobil görünüm. `npm test` 13/13.
- **Kalanlar:** (düşük) yönetici log'unda sistem mesajı "[rol yok]" etiketiyle görünüyor; lobide sayfa yenileyen oyuncu odadan
  düşüyor ve "Bu odada değilsin." görüyor (PLAN kuralı, istenirse değişir). Test edilmeyen: gerçek telefon, 5 dk boş oda temizliği.
  Aşama 2–5 yapılmadı.

---

# AŞAMA 2 — Parça takma/çıkarma + hesaplamalar + yönetici göstergeleri  ← ŞU AN

Aşama 1'deki her şey geçerli kalır; aşağıdakiler EKLENİR. Çelişki olursa bu bölüm geçerlidir.
Kapsam dışı (sonraki aşamalar): GO/NO-GO, fırlatma, sayaç, 2 sn telemetri gecikmesi, olaylar, geri alma, pixel-art.

## Yeni/değişen dosyalar
```
data/parts.json          (Modül D)  parça kataloğu + fizik sabitleri
data/missions.json       (Modül D)  dengeleme için D'ye devredildi
server/physics.js        (Modül D)  saf hesaplama
test/physics.test.js     (Modül D)
server/constants.js, server/rooms.js, server/filter.js, test/stage1.test.js, test/stage2.test.js   (Modül E)
server/index.js, package.json   (Modül F)
public/index.html, public/client.js   (Modül G)
```

## Parça kataloğu (`data/parts.json`)
```json
{
  "constants": { "g0": 9.81, "minTwr": 1.2 },
  "parts": [
    { "id": "engine-kestrel", "role": "rocket", "category": "engine",
      "name": "Kerkenez Motoru", "icon": "🔥", "desc": "Sayı içermeyen kısa açıklama",
      "massKg": 0, "cost": 0, "powerGenW": 0, "powerUseW": 0,
      "thrustKN": 0, "isp": 0, "heat": 0, "heatShield": 0, "fuelKg": 0,
      "ispMult": 1, "max": 4, "requires": ["tank"] }
  ]
}
```
- `role`: `'rocket' | 'spacecraft' | 'payload'`. Her rol için 6–8 parça.
- `category` (D belirler, en az): rocket → `engine`, `tank`, `fuel`; spacecraft → `solar`, `battery`, `shield`, `antenna`, `structure`, `computer`; payload → `instrument`.
- Tüm sayısal alanlar her parçada bulunur (kullanılmıyorsa 0; `ispMult` kullanılmıyorsa 1). `heat`: ürettiği ısı, `heatShield`: karşıladığı ısı.
  `fuelKg`: tankın taşıdığı yakıt kütlesi (`massKg` tankın BOŞ kütlesidir). `max`: aynı parçadan en fazla kaç adet takılabilir.
- `fuel` kategorisi yakıt tipidir: aynı anda en fazla 1 adet (kategori bazında tekil), `ispMult` ile motor Isp'sini çarpar (ve D isterse maliyet/kütle etkisi).
- `requires`: bu parçanın KENDİ rolünün build'inde bulunması gereken kategoriler (durum ışığı için). Boş dizi olabilir.
- `desc` ve `name` içinde SAYI/BİRİM YOK (çalışanlara gider). `icon` şimdilik emoji (Aşama 5'te sprite'a çevrilecek).
- Dengeleme: her görevin en az 2 farklı geçerli çözümü olmalı; `test/physics.test.js` bunu kanıtlar (her görev için 2 farklı build → tüm kontroller yeşil).
  Ayrıca "saf açgözlü" build'ler (her şeyin en büyüğü) bütçeyi aşmalı ki ödünleşim olsun.

## Fizik (`server/physics.js`) — saf, durumsuz
`module.exports = { createPhysics }`; `createPhysics(catalog)` (catalog = parts.json içeriği) şu nesneyi döndürür:
- `getPart(partId)` → tam parça nesnesi | `undefined`
- `fullCatalog()` → `{ rocket: [tam parça...], spacecraft: [...], payload: [...] }` (yalnızca yöneticiye gider)
- `publicCatalog(role)` → `[{ id, name, icon, desc, category }]` — SAYI YOK (çalışana gider)
- `canAdd(build, role, partId)` → `{ ok: true }` | `{ ok: false, error: 'INVALID_PART' | 'NOT_ALLOWED' | 'PART_LIMIT' }`
  (`INVALID_PART`: böyle parça yok; `NOT_ALLOWED`: parça bu role ait değil; `PART_LIMIT`: `max` ya da tekil kategori sınırı dolu)
- `computeTelemetry(build, mission)` → telemetri nesnesi (aşağıda). `mission` null olabilir (o zaman göreve bağlı kontroller false).
- `partStatuses(build, role)` → `{ [uid]: 'green' | 'yellow' | 'red' }` — yalnızca o rolün KENDİ parçalarına bakar (bütüne değil):
  `red` = `requires` kategorilerinden biri kendi rolünde yok; `yellow` = çalışır ama yerel bir uyarı var (D tanımlar, ör. yakıt tipi seçilmemiş tank,
  bataryasız panel); `green` = kendi içinde sorunsuz. Görev, bütçe, toplam kütle, TWR, Δv bu ışığı ETKİLEMEZ.

`build` biçimi: `{ rocket: [{ uid, partId }], spacecraft: [...], payload: [...] }`.

Telemetri nesnesi (tüm sayılar sonlu; boş build'de 0, NaN/Infinity YOK):
```js
{
  massKg,        // dolu toplam kütle (tüm parçalar + yakıt)
  dryMassKg,     // yakıtsız kütle
  fuelKg,
  thrustKN,      // motorların toplamı
  isp,           // etkin Isp (itkiye göre ağırlıklı ortalama × yakıt tipinin ispMult'u)
  twr,           // thrustKN*1000 / (massKg*g0)
  deltaV,        // isp * g0 * ln(massKg / dryMassKg)   (Tsiolkovsky)
  powerGenW, powerUseW,
  heat,          // üretilen toplam ısı
  heatShield,    // karşılanan ısı kapasitesi
  spent,         // toplam maliyet
  checks: {      // yönetici göstergeleri
    twr: bool,       // twr >= constants.minTwr
    deltaV: bool,    // deltaV >= mission.requiredDeltaV
    power: bool,     // powerGenW >= powerUseW  (ve en az bir parça takılı)
    payload: bool,   // mission.requiredInstruments'ın hepsi takılı VE spent <= mission.budget
    heat: bool       // heatShield >= heat
  },
  missing: [partId...],   // takılmamış zorunlu aletler
  overBudget: bool,
  ready: bool             // tüm checks true
}
```
Not: Kullanıcının 4 göstergesine ek olarak ısı 5. gösterge (`checks.heat`) olarak eklendi.

## Sunucu durumu ekleri
- `room.build[role]` → `[{ uid, partId }]` (uid: kısa rastgele string, oda içinde benzersiz).
- `room.telemetry` → her değişiklikte `physics.computeTelemetry(room.build, room.mission)` ile yeniden hesaplanır (oyun başlarken de).
- `room.log` girdisi: `{ t, playerId, role, kind: 'system' | 'part', text }`. Parça metinleri SAYISAL DEĞER içermez:
  `"<Rol adı>: <parça adı> taktı"` / `"... çıkardı"` (Rol adları: Roket & Yakıt, Uzay Aracı, Faydalı Yük). Log en fazla son 200 girdiyi tutar.

## Oda mantığı ekleri (`server/rooms.js`)
- `createRoomManager({ missions, physics, rng = Math.random })` — `physics` zorunlu (createPhysics çıktısı ya da testte sahte nesne).
- `manager.addPart(code, playerId, partId)` → `room`
- `manager.removePart(code, playerId, uid)` → `room`
- Hatalar (`GameError`): `NOT_IN_ROOM`, `WRONG_PHASE` (phase 'building' değil), `NOT_ALLOWED` (yönetici ya da rolsüz; ya da parça/uid başka role ait),
  `INVALID_PART`, `PART_LIMIT`, `PART_NOT_FOUND` (uid kendi build'inde yok). Oyuncu yalnızca KENDİ rolünün build'ine dokunabilir.
- `constants.js`: `ROLE_NAMES = { director:'Yönetici', rocket:'Roket & Yakıt', spacecraft:'Uzay Aracı', payload:'Faydalı Yük' }` eklenir.

## Görünüm ekleri (`server/filter.js`) — `viewFor(room, playerId, physics)`
İmza değişti: 3. parametre `physics`. Yalnızca `phase !== 'lobby'` iken:

Yönetici görünümü (Aşama 1 alanlarına ek / değişen):
```js
{
  telemetry: {...yukarıdaki tam nesne},
  build: { rocket: [{ uid, partId, name, icon }], spacecraft: [...], payload: [...] },
  catalog: physics.fullCatalog(),          // sayılarla — yönetici talimat verebilsin
  log: [{ t, role, kind, text }]
}
```
Çalışan görünümü (rolü olan 3 çalışan):
```js
{
  missionLabel: 'GİZLİ',
  catalog: physics.publicCatalog(myRole),                 // sayısız
  myParts: [{ uid, partId, name, icon, status }],         // status: 'green'|'yellow'|'red'
  others: { <diğer iki çalışan rolü>: [{ name, icon }] }, // küçük önizleme — sayısız, uid/partId yok
  feed: [{ t, role, text }]                               // log'un kind==='part' olan son 12 girdisi
}
```
**Kesin kural (değişmedi):** çalışan görünümünde `mission`, `telemetry`, `log`, `undoLeft`, `build` anahtarları ve hiçbir parça sayısal alanı
(`massKg`, `cost`, `thrustKN`, `isp`, `powerGenW`, `powerUseW`, `heat`, `heatShield`, `fuelKg`, `ispMult`, `max`, `requires`) bulunmaz. Beyaz listeyle kur.

## Socket olayı ekleri
| Olay | Payload | Ack (başarı) |
|---|---|---|
| `part:add` | `{ partId }` | `{ ok:true }` |
| `part:remove` | `{ uid }` | `{ ok:true }` |
Yeni hata kodları: `WRONG_PHASE`, `NOT_ALLOWED`, `INVALID_PART`, `PART_LIMIT`, `PART_NOT_FOUND`. Her başarılı değişiklikte odadaki herkese yeni `state`.

## Modüller (Aşama 2)

### Modül D: Fizik + parça kataloğu + dengeleme
- [x] Durum: tamam
- **Sahip dosya(lar):** `data/parts.json`, `data/missions.json`, `server/physics.js`, `test/physics.test.js`
- **Sorumluluk:** Katalog (rol başına 6–8 parça), fizik hesapları, durum ışıkları, görev dengesi (her görev ≥2 çözüm; `requiredInstruments` gerçek parça id'leri).
- **Arayüz:** yukarıdaki "Parça kataloğu" ve "Fizik" bölümleri birebir.
- **Bağımlılıklar:** yok
- **Atanan agent:** gelistirici
- **Notlar:** `node --test test/physics.test.js` 20/20. Kategoriler: rocket → `engine`, `tank`, `fuel`; spacecraft → `solar`, `battery`, `shield`, `antenna`, `structure`, `computer` (`computer-backup`); payload → `instrument`.
  Yakıt tipi seçilmezse etkin Isp = 0 → Δv = 0 (TWR yine hesaplanır). Görevler (Δv / bütçe): lunar-relay 4200 / 800, mars-rover 4600 / 1400, asteroid-sample 5200 / 1350; açgözlü build hepsinde bütçeyi aşar.
  Işık: `red` = `requires` kategorisi kendi rolünde yok (motor/yakıt → tank; tüm uzay aracı parçaları → `structure`). `yellow`: motor yakıt tipsiz; tank yakıt tipsiz ya da motorsuz;
  yakıt motorsuz; panel bataryasız; batarya panelsiz; anten/bilgisayar uzay aracının kendi üretimi < kendi tüketimi; `drill` rover'sız. Ek: fizik nesnesi `constants` alanını da döndürür.

### Modül E: Oda mantığı + filtre (parça işlemleri)
- [x] Durum: tamam
- **Sahip dosya(lar):** `server/constants.js`, `server/rooms.js`, `server/filter.js`, `test/stage1.test.js`, `test/stage2.test.js`
- **Sorumluluk:** addPart/removePart, telemetri yenileme, log, yeni görünüm alanları. Testlerde SAHTE physics nesnesi kullan (Modül D'ye bağımlı olmadan çalışsın).
- **Arayüz:** yukarıdaki "Sunucu durumu ekleri", "Oda mantığı ekleri", "Görünüm ekleri" birebir.
- **Bağımlılıklar:** Modül D'nin `createPhysics` çıktısının arayüzü (enjekte edilir)
- **Atanan agent:** gelistirici
- **Notlar:** stage1+stage2 25/25 geçti (sahte physics). `physics` verilmezse `createRoomManager` TypeError fırlatır. uid = 8 hex. Lobide `room.telemetry` hâlâ Aşama 1 sıfır nesnesi; oyun başlayınca computeTelemetry ile değişir. Bilinmeyen partStatuses değeri → 'green'. Rolsüz çalışan yalnızca `missionLabel` alır.

### Modül F: Sunucu bağlama (parça olayları)
- [x] Durum: tamam
- **Sahip dosya(lar):** `server/index.js`, `package.json`
- **Sorumluluk:** `createPhysics(require('../data/parts.json'))` oluşturup manager'a ve `viewFor(room, pid, physics)`'e vermek; `part:add` / `part:remove` olayları.
- **Bağımlılıklar:** Modül D ve E arayüzleri
- **Atanan agent:** gelistirici
- **Notlar:** package.json değişmedi. part:add/part:remove `requireRoom` sonrası tip kontrolü (string değilse BAD_REQUEST), ack önce sonra state. Gerçek D+E dosyalarıyla 4 istemcili duman testi geçti (ekle/çıkar, PART_NOT_FOUND, yöneticiye NOT_ALLOWED, çalışan görünüm anahtarları temiz).

### Modül G: İstemci (parça arayüzü + yönetici göstergeleri, hâlâ tasarımsız)
- [x] Durum: tamam
- **Sahip dosya(lar):** `public/index.html`, `public/client.js`
- **Sorumluluk / davranış:**
  - Çalışan: `#catalog` içinde kendi kataloğu (ikon + ad + açıklama; her parçada `button[data-add="<partId>"]`), `#my-parts` içinde takılı parçalar
    (durum ışığı 🟢/🟡/🔴 `[data-status="green|yellow|red"]`, `button[data-remove="<uid>"]`), `#others` içinde diğer iki çalışanın önizlemesi (rol adı + ikonlar/adlar),
    `#feed` içinde son hareketler. Hiçbir sayı gösterilmez (zaten gelmez).
  - Yönetici: `#gauges` içinde 5 gösterge (`[data-check="twr|deltaV|power|payload|heat"]`, `data-ok="true|false"`, yanında değer/hedef: ör. "İtki/Ağırlık 1.34 / ≥1.2",
    "Δv 4350 / 4100 m/s", "Güç 300 / 220 W", "Aletler+Bütçe: eksik …; 640 / 1000", "Isı 40 / 60"), `#telemetry-box` (kütle vb.), `#build-box` (üç rolün takılı parçaları),
    `#director-catalog` (`<details>` içinde sayılarla tam katalog tablosu), `#log-box`, `#mission-box`. Yöneticide ekle/çıkar butonu YOK.
  - Ack hataları `#error-msg`'de. Aşama 1 id'leri korunur.
- **Bağımlılıklar:** "Görünüm ekleri" ve "Socket olayı ekleri"
- **Atanan agent:** gelistirici
- **Notlar:** Çalışan bölümü `#worker-view`, yönetici bölümü `#director-view` içinde; `#director-catalog` bir `<details>` içindeki div (rol başına `.table-scroll` tablo). `data-status` ışık emojisini taşıyan span'de. `#ready-line` ayrıca `data-ready="true|false"` taşır. Görünümde minTwr yok → TWR hedefi `telemetry.minTwr` yoksa gösterim için 1.2 yazılır. Sahte state ile Playwright'ta doğrulandı (375px'te yatay taşma yok); gerçek sunucuyla uçtan uca denenmedi. Test düzeltmesi: `#log-box`/`#feed` satırları rol öneki olmadan "SS:DD:SS  metin" biçiminde, en yeni üstte; `#log-box ul` max-height 40vh + dikey kaydırma.

## Paralel dağıtım (Aşama 2)
- **Grup 1 (paralel):** Modül D, E, F, G

## Test-düzelt turları — Aşama 2 (en fazla 3)
- [x] Tur 1 — kritik/orta hata yok; yönetici logunda 3 okunabilirlik düzeltmesi yapıldı (Modül G), e2e yeniden 130/130
- [ ] Tur 2
- [ ] Tur 3

## Son durum — Aşama 2 (şef doldurur)
- **Çalışanlar:** parça takma/çıkarma (rol başına 7–8 parça), durum ışıkları, diğer çalışan önizlemesi + hareket akışı, fizik (kütle, TWR,
  Tsiolkovsky Δv, güç, ısı, bütçe), yöneticinin 5 göstergesi + canlı log + sayılı katalog, 3 görevin ikişer çözümü, çalışanlara sayı/görev
  sızıntısı yok (ham WebSocket'te doğrulandı). `npm test` 45/45, `test/e2e/stage2.e2e.js` 130/130.
- **Kalanlar:** `test/e2e/stage1.e2e.js` iki doğrulamada eskidi (betik, oyun hatası değil). Boş build'de ısı göstergesi yeşil. Kazanan çözümlerde
  sarı ışık kalabiliyor (ör. bataryasız panel). Yakıt tipi seçilmezse Δv 0 (çalışanın ipucu yalnızca sarı ışık). Isı, kullanıcının 4 göstergesine
  ek 5. gösterge olarak eklendi. Gerçek telefonda test edilmedi. Aşama 3–5 yapılmadı.

---

# AŞAMA 3 — GO/NO-GO + fırlatma + sonuç ekranı + puan  ← ŞU AN

Aşama 1–2'deki her şey geçerli kalır; aşağıdakiler EKLENİR. Çelişki olursa bu bölüm geçerlidir.
Kapsam dışı: geri sayım sayacı, telemetri gecikmesi, rastgele olaylar, geri alma (Aşama 4); pixel-art ve gerçek animasyon (Aşama 5).

## Akış
`building` → (yönetici `poll:start`) → `poll` → herkes GO → `result` (kalıcı; yönetici `game:restart` ile yeni tur)
                                              ↘ biri NO-GO ya da yönetici `poll:cancel` → `building`'e geri
- Yönetici anketi göstergeler yeşil OLMASA DA başlatabilir (risk ona ait). Koşullar sağlanmadan fırlatılırsa başarısızlık + nedeni.
- `poll` fazında parça eklenemez/çıkarılamaz (`WRONG_PHASE`).
- 3 çalışanın hepsi `go` verdiği anda fırlatma çözülür: `resolveLaunch` + `computeScore` → `room.result`, `phase='result'`.
- Herhangi bir `nogo` anketi hemen bitirir → `building`. Log: `"<Rol adı> NO-GO dedi — anket iptal"` (kind `'poll'`).
- `result` fazında oyun bitmiştir: görev ve sayılar HERKESE açılır (yalnızca `result` nesnesi içinde).
- `game:restart` (yalnızca yönetici, yalnızca `result`): build boşalır, poll/result temizlenir, log sıfırlanır + "Yeni tur başladı", mümkünse
  öncekinden FARKLI rastgele görev atanır, telemetri yeniden hesaplanır, `undoLeft=3`, `undoUsed=0`, `phase='building'`. Roller aynı kalır.

## Fırlatma çözümü (`server/launch.js`) — saf
`module.exports = { resolveLaunch }`
`resolveLaunch(telemetry, mission)` →
```js
{ success: bool,
  outcome: 'success' | 'no-liftoff' | 'out-of-fuel' | 'power-loss' | 'overheat' | 'mission-failed',
  title: 'kısa Türkçe başlık',           // ör. "Roket rampadan kalkamadı"
  reasonText: 'Türkçe açıklama',         // nedeni sayılarla açıklar (oyun bitti, sayı serbest)
  failedChecks: ['twr', ...] }           // false olan tüm checks anahtarları
```
`outcome`, false olan İLK kontrole göre şu öncelikle seçilir: `twr` → `no-liftoff`; `deltaV` → `out-of-fuel`; `power` → `power-loss`;
`heat` → `overheat`; `payload` → `mission-failed` (eksik alet ve/veya bütçe aşımı; reasonText hangisi olduğunu söyler). Hepsi true → `success`.

## Puanlama (`server/scoring.js`) — saf
`module.exports = { computeScore }`
`computeScore({ success, mission, telemetry, undoUsed, timeLeftSec })` →
```js
{ total: int >= 0, stars: 0..3,
  breakdown: [ { key: 'base'|'time'|'budget'|'mass'|'undo', label: 'Türkçe', points: int } ] }   // her zaman 5 kalem, bu sırada
```
- Başarısızlıkta `total = 0`, `stars = 0` (breakdown yine 5 kalem, puanlar 0).
- `budget`: artan bütçe oranına göre bonus. `mass`: `mission.parMassKg` üstündeki fazla kütleye göre ceza (par altı tam bonus).
  `undo`: kullanılan her geri alma için ceza. `time`: `timeLeftSec` null/undefined ise 0 puan (Aşama 4'te dolacak).
- `data/missions.json` her karta `parMassKg` (sayı) eklenir: o görevin iyi bir çözümünün dolu kütlesinin biraz üstü.

## Sunucu durumu ekleri
```js
room.poll = null | { startedAt, votes: { rocket: null|'go'|'nogo', spacecraft: ..., payload: ... } }
room.result = null | {
  success, outcome, title, reasonText, failedChecks,
  score: { total, stars, breakdown },
  mission: {...tam kart},  telemetry: {...anlık kopya},
  build: { rocket: [{ name, icon }], spacecraft: [...], payload: [...] },
  endedAt }
room.undoUsed = 0
```
Log `kind` değerlerine `'poll'` eklendi (anket başladı / iptal / NO-GO / fırlatma sonucu).

## Oda mantığı ekleri (`server/rooms.js`)
- `createRoomManager({ missions, physics, resolveLaunch, computeScore, rng })` — `resolveLaunch` ve `computeScore` enjekte edilir (zorunlu).
- `manager.startPoll(code, playerId)` → room   (yalnızca yönetici, yalnızca `building`)
- `manager.cancelPoll(code, playerId)` → room  (yalnızca yönetici, yalnızca `poll`)
- `manager.vote(code, playerId, vote)` → room  (yalnızca çalışanlar, yalnızca `poll`; `vote` `'go'|'nogo'`, değilse `BAD_REQUEST`; oy değiştirilebilir)
- `manager.restart(code, playerId)` → room     (yalnızca yönetici, yalnızca `result`)
- Hatalar: `NOT_IN_ROOM`, `NOT_ALLOWED`, `WRONG_PHASE`, `BAD_REQUEST`.
- `constants.js`: `PHASES` → `{ LOBBY:'lobby', BUILDING:'building', POLL:'poll', RESULT:'result' }`.
- Fırlatmada `computeScore({ success, mission, telemetry, undoUsed: room.undoUsed, timeLeftSec: null })`.

## Görünüm ekleri (`server/filter.js`)
- `phase==='poll'`: Aşama 2'deki `building` alanlarının aynısı + herkese `poll: { votes: { rocket, spacecraft, payload } }` (değerler `'go'|'nogo'|null`);
  çalışanlara ek `poll.myVote`.
- `phase==='building'` ve `'poll'`: çalışan `feed`'i artık `kind` `'part'` VEYA `'poll'` olan son 12 girdi.
- `phase==='result'`: HERKESE aynı `result` nesnesi (yukarıdaki biçim, beyaz listeyle kopyalanır) + ortak alanlar. Bu fazda çalışana `catalog/myParts/others/feed`
  gönderilmez; yöneticiye `telemetry/build/catalog/log` üst düzey alanları gönderilmez (hepsi `result` içinde). `missionLabel` gönderilmez.
- **Kesin kural (güncel):** çalışan görünümünde görev bilgisi ve sayılar YALNIZCA `phase==='result'` iken ve YALNIZCA `result` anahtarı altında bulunur.
  `building`/`poll` fazlarında Aşama 2 kuralı aynen geçerli (ayrıca `result` anahtarı yok, `poll` içinde sayı yok).

## Socket olayı ekleri
| Olay | Payload | Ack (başarı) |
|---|---|---|
| `poll:start` | `{}` | `{ ok:true }` |
| `poll:cancel` | `{}` | `{ ok:true }` |
| `poll:vote` | `{ vote: 'go' \| 'nogo' }` | `{ ok:true }` |
| `game:restart` | `{}` | `{ ok:true }` |

## Modüller (Aşama 3)

### Modül H: Fırlatma çözümü + puanlama
- [x] Durum: tamam
- **Sahip dosya(lar):** `server/launch.js`, `server/scoring.js`, `data/missions.json`, `test/launch.test.js`
- **Arayüz:** yukarıdaki "Fırlatma çözümü" ve "Puanlama" bölümleri birebir. `parMassKg` değerlerini gerçek physics + parts.json ile hesapla (okuyabilirsin, değiştirme).
- **Bağımlılıklar:** yok (telemetri/mission biçimi Aşama 2'deki gibi)
- **Atanan agent:** gelistirici
- **Notlar:** `node --test test/launch.test.js` 19/19, `npm test` 64/64. Puan (yalnızca başarıda; başarısızlıkta hepsi 0): base 1000; time = round(500·timeLeftSec/durationSec), 0..500, null → 0;
  budget = round(500·(budget−spent)/budget), 0..500; mass = massKg ≤ parMassKg ise 300, üstünde doğrusal azalır, 2×par'da 0 (par yoksa 0); undo = −100·undoUsed;
  total = max(0, toplam). Yıldız: başarı ≥1; total ≥1400 → 2; ≥1700 → 3. parMassKg: lunar-relay 18000, mars-rover 30000, asteroid-sample 19500
  (hafif sabit çözümler 17090 / 28330 / 18250 kg). minTwr: `telemetry.minTwr` varsa o, yoksa parts.json constants. Eksik alet metni "Ad (id)" biçiminde. Eksik `checks` → false sayılır.

### Modül I: Oda mantığı + filtre (anket, sonuç, yeniden başlatma)
- [x] Durum: tamam
- **Sahip dosya(lar):** `server/constants.js`, `server/rooms.js`, `server/filter.js`, `test/stage1.test.js`, `test/stage2.test.js`, `test/stage3.test.js`
- **Arayüz:** yukarıdaki "Akış", "Sunucu durumu ekleri", "Oda mantığı ekleri", "Görünüm ekleri" birebir. Testlerde sahte `resolveLaunch`/`computeScore`/physics kullan.
- **Bağımlılıklar:** Modül H arayüzü (enjekte)
- **Atanan agent:** gelistirici
- **Notlar:** stage1+2+3 39/39 (sahte physics/launch/score). `resolveLaunch`/`computeScore` verilmezse TypeError. Bağlantısı kopuk çalışanın oyu `NOT_ALLOWED`. Aynı oyun tekrarı log'a yazılmaz. Sonuçta `room.poll=null`; "Fırlatma: …" logu `role:null`. `result` görünümünde yalnızca ortak alanlar + `result` (yöneticiye de `mission/undoLeft` üst düzeyde gitmez). Rolsüz çalışan poll'da `votes` alır, `myVote` almaz.

### Modül J: Sunucu bağlama (anket olayları)
- [x] Durum: tamam
- **Sahip dosya(lar):** `server/index.js`
- **Arayüz:** "Socket olayı ekleri"; `createRoomManager({ missions, physics, resolveLaunch, computeScore })`.
- **Bağımlılıklar:** Modül H, I
- **Atanan agent:** gelistirici
- **Notlar:** poll:start/cancel/vote, game:restart eklendi (requireRoom + mevcut on() sarmalayıcısı; vote string değilse BAD_REQUEST). 4 istemcili socket duman testi 28/28 geçti.

### Modül K: İstemci (anket + fırlatma + sonuç ekranı, hâlâ tasarımsız)
- [x] Durum: tamam
- **Sahip dosya(lar):** `public/index.html`, `public/client.js`
- **Davranış / seçiciler:**
  - Yönetici, `building`: `#poll-start-btn` ("GO/NO-GO anketini başlat"; `telemetry.ready` false ise butonun yanında/üstünde "UYARI: göstergeler yeşil değil" yazısı `#poll-warning`, buton yine basılabilir).
  - `poll` fazı, herkes: `#poll-box` görünür; içinde 3 çalışan rolü için `[data-vote-role="rocket|spacecraft|payload"]` öğeleri, `data-vote="go|nogo|pending"` ve metin (GO / NO-GO / bekleniyor).
    Çalışanlarda `#vote-go-btn` ve `#vote-nogo-btn`; yöneticide `#poll-cancel-btn`. `poll` fazında çalışanın ekle/çıkar butonları devre dışı.
  - `result` fazı, herkes: `#screen-result` görünür (`#screen-game` gizli), `data-outcome="<outcome>"` ve `data-success="true|false"`.
    Önce `#launch-sequence` içinde kısa metin tabanlı fırlatma dizisi (geri sayım 3-2-1, sonra outcome'a göre satırlar; toplam ~4 sn; `#skip-launch-btn` ile atlanır;
    sayfa `result` fazındayken yüklenirse/yeniden bağlanırsa dizi atlanır), bitince `#result-panel` görünür: `#result-title`, `#result-reason`,
    `#result-score` (toplam + yıldız), `#result-breakdown` (5 kalem), `#result-mission` (görev kartı — artık herkes görür), `#result-telemetry` (son sayılar + 5 kontrol),
    `#result-build` (üç rolün parçaları), `#result-nasa` ("Gerçekte NASA bunu şöyle yapıyor": `mission.nasaReal`), yalnızca yöneticide `#restart-btn` ("Yeni tur").
  - Aşama 1–2 seçicileri ve davranışları korunur. innerHTML yok. İstemci kural hesaplamaz.
- **Bağımlılıklar:** "Görünüm ekleri" ve "Socket olayı ekleri"
- **Atanan agent:** gelistirici
- **Notlar:** Anket kontrolleri (`#poll-start-btn`, `#poll-warning`, `#poll-box`, oy butonları, `#poll-cancel-btn`) `#screen-game` DIŞINDA, hemen altındaki `#poll-controls` bölümünde
  (Aşama 2 e2e "yöneticide `#screen-game button` sayısı 0" bozulmasın diye). Dizi yalnızca önceki state `poll` iken oynar; yükleme/yeniden bağlanma (disconnect sonrası ilk state) atlar; aynı sonuç (endedAt+outcome) tekrar gelirse yeniden başlamaz.
  Sonuçta alet id'leri tire→boşluk ile gösterilir (katalog adı bu fazda gelmez). Sahte io + sahte state ile Playwright'ta 41/41 doğrulandı (375px taşma yok); gerçek sunucuyla denenmedi.
  Tur 1 düzeltmesi: `#poll-controls` DOM'da `#room-info`'nun hemen altına taşındı ve poll fazında `data-phase="poll"` ile sticky üstte; anket/oy/iptal/yeni tur butonları istek sürerken disabled, faz değişince eski hata temizlenir; 0 puanlı 'time' kalemi "—" gösterilir (e2e stage2 130/130, stage3 221/2 FAIL yalnız bilinen c2 kurgusu).

## Paralel dağıtım (Aşama 3)
- **Grup 1 (paralel):** Modül H, I, J, K

## Test-düzelt turları — Aşama 3 (en fazla 3)
- [x] Tur 1 — kritik/orta hata ve sızıntı yok; 3 düşük önemli istemci düzeltmesi yapıldı (Modül K), stage2 e2e 130/130, stage3 e2e 219/221
- [ ] Tur 2
- [ ] Tur 3

## Son durum — Aşama 3 (şef doldurur)
- **Çalışanlar:** GO/NO-GO anketi (başlat/iptal/oy, NO-GO geri dönüş, ankette parça kilidi), fırlatma çözümü (başarı + 5 başarısızlık türü,
  öncelik sırası), puan + yıldız + 5 kalemlik döküm, metin fırlatma dizisi, sonuç ekranı (görev herkese açılır, NASA kutusu), yeni tur
  (farklı görev), yeniden bağlanma, building/poll fazlarında sızıntı yok. `npm test` 78/78.
- **Kalanlar:** `test/e2e/stage3.e2e.js`'te 2 doğrulama (c2) test kurgusu yüzünden FAIL — lunar-relay'de o senaryo kurulamıyor, oyun hatası değil.
  Sticky anket kutusu gerçek telefonda gözle doğrulanmadı. Sonuç ekranında alet adları id olarak görünüyor. Süre puanı Aşama 4'e kadar "—".
  Süre bonusu olmadan 3 yıldız zor. Mobilde sonuç sayfası uzun. `test/e2e/stage1.e2e.js` eskimiş durumda. Aşama 4–5 yapılmadı.

---

# AŞAMA 4 — Zaman baskısı + rastgele olaylar + geri alma  ← ŞU AN

Aşama 1–3'teki her şey geçerli kalır; aşağıdakiler EKLENİR. Çelişki olursa bu bölüm geçerlidir. Kapsam dışı: pixel-art/animasyon (Aşama 5).

## Zaman: `now` ve `tick`
- `createRoomManager({ missions, physics, resolveLaunch, computeScore, windowMissedResult, rng, now = Date.now, config = {} })`.
  Tüm zamanlar `now()` ile okunur (testte sahte saat). rooms.js zamanlayıcı KURMAZ.
- `manager.tick(code)` → `boolean` (durum değiştiyse true). `manager.roomCodes()` → `string[]`. index.js her 250 ms'de tüm odaları tick'ler, true dönenlere state yollar.
- `config` (hepsi isteğe bağlı): `windowSec` (yoksa `mission.durationSec`, o da yoksa 300), `secondWindowSec` (180), `telemetryDelayMs` (2000),
  `holdSec` (30), `lockSec` (45), `events`: tanımsız → rastgele; `[]` → olay yok; `[{ type, atSec }]` → sabit plan (test için).

## Fırlatma penceresi
- Oyun `building`'e geçince (ilk başlangıç ve restart): `room.timer = { window: 1, endsAt: now + windowSec*1000 }`.
- Sayaç `building` ve `poll` fazlarında işler (ankette de, bekleme sırasında da durmaz). `result`'ta durur.
- tick: `now >= endsAt` ve window 1 → `window = 2`, `endsAt = now + secondWindowSec*1000`, log (kind `'event'`): "Fırlatma penceresi kaçırıldı! İkinci pencere açıldı".
  window 2 de biterse → fırlatma yapılmadan başarısızlık: `windowMissedResult()` ile `room.result`, `phase='result'`, puan 0 (açık anket varsa kapanır).
- Puan için `timeLeftSec`: window 1'de kalan saniye; window 2'de kalan saniyenin yarısı (aşağı yuvarla). `computeScore`'a böyle verilir.

## Telemetri gecikmesi (yalnızca yönetici görünümü)
- `room.telemetry` her zaman GERÇEK değerdir (fırlatma bununla çözülür).
- Her yeniden hesaplamada `room.telemetryQueue.push({ at: now + telemetryDelayMs, telemetry: kopya })`. tick, zamanı gelenleri sırayla `room.telemetryShown`'a taşır (→ true).
  Oyun/tur başlangıcında `telemetryShown` = ilk telemetri (gecikmesiz). `telemetryDelayMs` 0 ise kuyruk kullanılmaz, anında gösterilir.
- Yönetici görünümünde `telemetry` = `room.telemetryShown`; ek alan `telemetryDelayMs`. Yöneticinin `build` listesi ve `log` gecikmesizdir.

## Rastgele olaylar
- Tur başında plan: `config.events` yoksa rastgele 1 ya da 2 olay, türleri birbirinden farklı, window 1 içinde `atSec` ∈ [40, windowSec−60] (windowSec küçükse orantıla),
  iki olay arası ≥ 45 sn. `room.pendingEvents = [{ type, at }]`. tick zamanı geleni ateşler (yalnızca `building`/`poll`).
- Ateşlenen olay `room.events`'e eklenir: `{ id, type, text, t, until: ms|null }` ve log (kind `'event'`). Türler:
  - `'weather'` — text: "Hava kötü: 30 sn fırlatma beklemesi". `room.holdUntil = now + holdSec*1000`; `until` = holdUntil. Bekleme sırasında `startPoll` → `HOLD` hatası;
    açık anket varsa iptal edilir (log: "Hava nedeniyle anket iptal edildi", kind `'poll'`), faz `building`.
  - `'computer-fault'` — text: "Uçuş bilgisayarı arızalandı: yedek bilgisayar takılmalı". `room.needBackupComputer = true` (tur sonuna kadar), `until: null`.
    Bu bayrak açıkken telemetriye `checks.computer` eklenir: spacecraft build'inde `category === 'computer'` olan bir parça varsa true. `ready` buna göre yeniden hesaplanır.
    (rooms.js, `physics.computeTelemetry` sonucunu saran tek bir yardımcıda yapar; physics.js DEĞİŞMEZ.) Bayrak kapalıyken `checks.computer` anahtarı YOKTUR.
  - `'supplier-delay'` — o an takılı OLMAYAN rastgele bir katalog parçası `lockSec` süreyle kilitlenir: `room.locks[partId] = now + lockSec*1000`; `until` = o an.
    text: "Tedarikçi gecikti: <parça adı> kilitli". Kilitliyken `addPart` → `PART_LOCKED`. Süre dolunca tick kilidi siler (→ true). (Geri alma kilidi deler, aşağıya bak.)
- Bekleme bitince / kilit açılınca log'a kısa satır (kind `'event'`): "Hava açtı: fırlatma beklemesi kalktı", "<parça adı> yeniden kullanılabilir".

## Geri alma (yöneticinin tek gücü)
- `room.lastMove = { rocket: null | { type: 'add'|'remove', uid, partId }, spacecraft: ..., payload: ... }` — her başarılı add/remove ilgili rolünkini günceller.
- `manager.undo(code, playerId, role)` → room. Yalnızca yönetici, yalnızca `building`. `role` çalışan rolü değilse `BAD_REQUEST`.
  `undoLeft === 0` → `NO_UNDO_LEFT`; `lastMove[role]` yok → `NOTHING_TO_UNDO`.
  `add` geri alınır = o uid çıkarılır; `remove` geri alınır = aynı partId YENİ uid ile geri takılır (limit/kilit kontrolü yapılmaz).
  Sonra `lastMove[role] = null`, `undoLeft--`, `undoUsed++`, telemetri yenilenir, log (kind `'undo'`):
  "Yönetici, <Rol adı> son hamlesini geri aldı: <parça adı> çıkarıldı" / "... geri takıldı".

## Fırlatma çözümü ekleri (`server/launch.js`)
- `resolveLaunch` öncelik sırası: `twr` → `deltaV` → `power` → `computer` → `heat` → `payload`. `checks.computer === false` → outcome `'computer-failure'`
  (title: "Uçuş bilgisayarı arızalandı"). `checks.computer` anahtarı yoksa yok sayılır.
- Yeni export: `windowMissedResult()` → `{ success:false, outcome:'window-missed', title:'Fırlatma penceresi kaçırıldı', reasonText, failedChecks: [] }`.

## Durum ve görünüm ekleri
Sunucu: `room.timer`, `room.telemetryShown`, `room.telemetryQueue`, `room.pendingEvents`, `room.events`, `room.holdUntil` (null|ms), `room.locks`,
`room.needBackupComputer`, `room.lastMove`. `room.result`'a ek: `timeLeftSec`, `window`, `undoUsed`, `events: [{ type, text }]`.
Log `kind` değerleri: `'system' | 'part' | 'poll' | 'event' | 'undo'`. Çalışan `feed`'i: `part`, `poll`, `event`, `undo` türlerinin son 12'si.

`viewFor` — `building` ve `poll` fazlarında HERKESE:
```js
timer: { window: 1|2, endsAt: ms, now: ms },     // now = sunucu saati (istemci saat farkını düzeltir)
events: [{ id, type, text, t, until }],          // ateşlenenler, en yeni önce, en çok 5
holdUntil: ms | null
```
Çalışana ek: `catalog` öğelerine `locked: bool`. Yöneticiye ek: `telemetryDelayMs`, `locks: { [partId]: untilMs }`,
`undo: { left, available: { rocket: bool, spacecraft: bool, payload: bool } }` (`undoLeft` de kalır).
Güvenlik kuralı aynen: çalışan görünümünde `pendingEvents` (gelecek olaylar) ve hiçbir sayı/görev bilgisi yok. `pendingEvents` yöneticiye de GÖNDERİLMEZ.

## Socket olayı ve hata ekleri
| Olay | Payload | Ack |
|---|---|---|
| `undo:use` | `{ role }` | `{ ok:true }` |
Yeni hata kodları: `HOLD`, `PART_LOCKED`, `NO_UNDO_LEFT`, `NOTHING_TO_UNDO`.
index.js ortam değişkenleri (test/sunum ayarı): `PP_WINDOW_SEC`, `PP_SECOND_WINDOW_SEC`, `PP_TELEMETRY_DELAY_MS`, `PP_HOLD_SEC`, `PP_LOCK_SEC`,
`PP_EVENTS` (`none` → `[]`; `weather@5,computer-fault@12` → sabit plan; tanımsız → rastgele).

## Modüller (Aşama 4)

### Modül L: Fırlatma çözümü ekleri
- [x] Durum: tamamlandı
- **Sahip dosya(lar):** `server/launch.js`, `server/scoring.js`, `test/launch.test.js`
- **Arayüz:** "Fırlatma çözümü ekleri". scoring.js'te değişiklik gerekmiyorsa dokunma (süre kalemi zaten var).
- **Atanan agent:** gelistirici
- **Notlar:** `node --test test/launch.test.js` 24/24. `computer` isteğe bağlı kontrol: yalnızca `=== false` başarısız sayılır (yok/true → etkisiz). `windowMissedResult()` her çağrıda yeni nesne döner. scoring.js değişmedi (süre kırpma zaten vardı).

### Modül M: Oda mantığı + filtre (sayaç, gecikme, olaylar, geri alma)
- [x] Durum: tamam
- **Sahip dosya(lar):** `server/constants.js`, `server/rooms.js`, `server/filter.js`, `test/stage1.test.js`, `test/stage2.test.js`, `test/stage3.test.js`, `test/stage4.test.js`
- **Arayüz:** bu bölümün tamamı (launch.js ve index.js kısımları hariç). Testlerde sahte saat (`now`), sahte physics/launch/score ve sabit `config.events` kullan.
  Mevcut testlerde `config: { events: [], telemetryDelayMs: 0 }` vererek eski beklentileri koru.
- **Bağımlılıklar:** Modül L arayüzü (enjekte)
- **Atanan agent:** gelistirici
- **Notlar:** stage1–4 59/59 (`npm test` 103/103). Kararlar: filter.js saati odaya `Object.defineProperty` ile eklenen SAYILAMAZ `room.clock`'tan okur
  (viewFor imzası değişmedi; JSON/structuredClone'a girmez); `room.telemetryDelayMs` (yönetici görünümü için) ve `room.eventSeq` (olay id'si `ev<n>`, turlar arası artar) ek alanlar.
  `constants.EVENT_TYPES` eklendi. timeLeftSec = floor(kalan sn) (w2'de floor(kalan/2)); 250 ms içinde süre bitip tick gelmeden oylama biterse kalan 0 sayılır.
  Kısa pencerede olay aralıkları f=min(1, windowSec/300) ile orantılanır (lo=40f, hi=windowSec−60f, aralık 45f). supplier-delay adayı: tüm katalogda takılı ve kilitli olmayan parçalar; aday yoksa olay sessizce atlanır (events/log'a girmez).
  Olay `until`: weather → holdUntil, supplier-delay → kilit bitişi. Weather metni `holdSec`'i kullanır. Window-missed log'u kind `'event'` "Fırlatma: <title>"; computeScore'a success:false, timeLeftSec:0.
  windowMissedResult verilmez/hata atarsa yerleşik window-missed sonucu. Undo `add` için uid artık yoksa NOTHING_TO_UNDO. Çalışan katalog öğesine `locked`, rolsüz çalışana timer/events/holdUntil da gider.

### Modül N: Sunucu bağlama (tick, ortam değişkenleri, geri alma olayı)
- [x] Durum: tamam
- **Sahip dosya(lar):** `server/index.js`
- **Arayüz:** 250 ms tick döngüsü (`unref`), `PP_*` değişkenlerinden `config`, `windowMissedResult` enjeksiyonu, `undo:use` olayı.
- **Bağımlılıklar:** Modül L, M
- **Atanan agent:** gelistirici
- **Notlar:** config modül yüklenirken process.env'den okunur (geçersiz sayı → uyarı + yok sayılır; sayılar ≥0 olmalı; PP_EVENTS bilinmeyen tür/biçim → uyarı + rastgele). 4 istemcili socket duman testi (kısa PP_* değerleri) 30/30 + PP_EVENTS=none 22/22, eski smoke3 ve `npm test` 103/103 geçti.

### Modül O: İstemci (sayaç, olaylar, kilitler, geri alma)
- [x] Durum: tamam
- **Sahip dosya(lar):** `public/index.html`, `public/client.js`
- **Davranış / seçiciler:**
  - Herkes (`building`/`poll`): `#timer` — `dd:ss` geri sayım, `data-window="1|2"`, pencere etiketi ("1. pencere"/"2. pencere"); istemci `timer.now` ile saat farkını düzeltip
    yerelde saniyede ≥2 kez günceller; son 30 sn'de `data-urgent="true"`. `#events-box` — `[data-event-type="weather|computer-fault|supplier-delay"]` öğeleri (text + varsa kalan süre).
    `#hold-banner` — `holdUntil` gelecekteyse görünür ("FIRLATMA BEKLEMEDE: nn sn").
  - Çalışan: kilitli katalog öğesi `[data-locked="true"]`, `button[data-add]` disabled ve "KİLİTLİ" yazısı.
  - Yönetici: `#undo-box` içinde `#undo-left` ("Geri alma: n/3") ve `button[data-undo="rocket|spacecraft|payload"]` (available false ya da hak 0 ise disabled; `building` dışında disabled);
    bunlar `#screen-game` DIŞINDA (#poll-controls gibi). `#telemetry-delay-note` ("Telemetri 2 sn gecikmeli"). Bekleme sırasında `#poll-start-btn` disabled.
    `checks.computer` varsa 6. gösterge `[data-check="computer"]` ("Yedek bilgisayar"). Yönetici kataloğunda kilitli parça satırı `[data-locked="true"]`.
  - Sonuç: `computer-failure` ve `window-missed` için metinler; `window-missed`'de geri sayım dizisi oynatılmaz, panel doğrudan açılır. Dökümde süre kalemi artık gerçek değer.
    `#result-events` (turda yaşanan olaylar), kullanılan geri alma sayısı.
  - Aşama 1–3 seçicileri/davranışları korunur. innerHTML yok. İstemci kural hesaplamaz (yalnızca sayaç gösterimi için saat çıkarması yapar).
- **Atanan agent:** gelistirici
- **Notlar:** `#timer` (içinde `#timer-label`, `#timer-value`) ve `#hold-banner`, en üstte sticky `#timer-bar` içinde; `#undo-box` ve `#events-box` `#poll-controls`'ün hemen altında (#screen-game dışında). Poll'daki sticky anket kutusu `--bar-h` ile sayacın altına yapışır.
  250 ms yerel döngü sayaç/bekleme/olay kalan sürelerini ve `#poll-start-btn` (bekleme bitince state beklemeden açılır) günceller; result/lobby/girişte durur. Yeni olay `data-new="true"` (sunucu saatine göre `t`'den 5 sn). Kalan süre `#result-time`, geri alma `#result-undo`.
  Alanlar yoksa (eski sunucu) gizlenir/`undoLeft`'e düşer. Sahte io + sahte state ile Playwright'ta 44/44 (375px taşma yok, konsol hatası yok); gerçek sunucuyla denenmedi.

## Paralel dağıtım (Aşama 4)
- **Grup 1 (paralel):** Modül L, M, N, O

## Test-düzelt turları — Aşama 4 (en fazla 3)
- [x] Tur 1 — kritik/orta hata ve sızıntı yok; 3 düşük önemli mobil/kozmetik bulgu Aşama 5'e (arayüz yeniden tasarımı) bırakıldı, düzeltme turu yapılmadı
- [ ] Tur 2
- [ ] Tur 3

## Son durum — Aşama 4 (şef doldurur)
- **Çalışanlar:** 5 dk fırlatma penceresi + 3 dk ikinci pencere + ikisi de kaçarsa otomatik başarısızlık; yöneticide 2 sn telemetri gecikmesi
  (fırlatma gerçek değerle çözülür); tur başına 1–2 rastgele olay (hava beklemesi, bilgisayar arızası → 6. gösterge, tedarikçi kilidi);
  3 hakla geri alma; süre puanı; `PP_*` ortam değişkenleriyle süre/olay ayarı. `npm test` 103/103, stage4 e2e 16 senaryo geçti.
- **Kalanlar (Aşama 5'te ele alınacak):** mobilde anket sırasında sabit alanlar ekranın ~yarısını kaplıyor; yöneticide göstergeler geri alma ve
  olay kutularının altında kalıyor; "Geri alma hakkı: 3" satırı iki kez görünüyor.
  **Diğer:** stage3 e2e'de 4 doğrulama eskidi (süre bonusu beklentisi, rastgele göreve bağlı bir senaryo) — betik güncellenmedi. Süre bitiminden
  ≤250 ms sonra gelen 3. GO kabul ediliyor. Tedarikçi kilidi gövdeyi (structure-frame) kilitleyebilir. Bilgisayar arızası mars-rover'da çözüm
  alanını daraltıyor. Varsayılan sürelerle (300/180 sn) tam tur ve gerçek telefon denenmedi. Aşama 5 yapılmadı.

---

# EK — Demo kontrol modu (`/demo.html`)  ← ŞU AN

Amaç: tek kişi, tek ekranda dört oyuncunun ekranını yan yana görsün ve hepsini kendisi oynatabilsin (jüri sunumu / tek başına deneme).
Sunucu tarafı DEĞİŞMEZ: her panel gerçek bir oyuncudur (kendi socket'i, kendi filtrelenmiş görünümü) — güvenlik modeli aynen korunur.

## Modül P: Demo kontrol modu
- [x] Durum: tamamlandı
- **Sahip dosya(lar):** `public/demo.html`, `public/demo.js` (yeni), `public/client.js`, `public/index.html` (yalnızca aşağıdaki küçük ekler), `baslat.bat`, `README.md`
- **`client.js` ekleri (URL parametreleri; hiçbiri yoksa davranış bugünküyle AYNI):**
  - `slot=<ad>` → sessionStorage anahtarına sonek (`pixelPayloadSession:<ad>`); aynı sekmedeki iframe'ler oturum paylaşmasın.
  - `auto=create|join`, `name=<isim>`, `role=<rol>`, `code=<kod>` (join için) → bağlanınca: kayıtlı oturum varsa önce `room:rejoin`; yoksa/başarısızsa
    otomatik `room:create` ya da `room:join`, ardından lobide `role:select`. Hata olursa normal giriş ekranı + `#error-msg`.
  - `embed=1` → `<html data-embed="1">`; gömülü görünümde geliştirme `<details>` (ham state) gizlenir, kenar boşlukları küçülür.
  - İframe içindeyse (`window.parent !== window`) her `state` sonrası üst pencereye
    `postMessage({ type: 'pp-state', slot, code, phase, role, name }, location.origin)` gönderir — görev/sayı YOK.
- **`demo.html` / `demo.js`:**
  - Üst çubuk `#demo-bar`: `#demo-start-btn` ("Demo odası kur"), `#demo-code` (oda kodu), `#demo-reset-btn` ("Sıfırla": dört paneli kapatır, slot oturumlarını siler),
    yerleşim düğmeleri `button[data-layout="grid|director|row"]` (2×2 ızgara / yönetici büyük + 3 çalışan / dört sütun), panel başına `button[data-focus="<rol>"]` (tek paneli büyüt, tekrar basınca geri).
  - Dört panel `.demo-panel[data-role="director|rocket|spacecraft|payload"]`: başlık (rol adı) + `iframe`. Başlat: önce yönetici iframe'i
    `/?embed=1&slot=demo-director&auto=create&name=Yönetici&role=director`; ondan `pp-state` ile oda kodu gelince diğer üçü
    `auto=join&code=<kod>` ile yüklenir (isimler: Roketçi, Uzaycı, Yükçü). Dört rol dolunca oyun kendiliğinden başlar.
  - `#demo-join-code` + `#demo-join-btn`: var olan bir odaya yalnızca BOŞ rolleri demo panelleriyle doldurmak için (ör. 2 gerçek telefon + 2 panel);
    hangi rollerin panel olacağı `input[type=checkbox][data-demo-role]` ile seçilir (varsayılan dördü de işaretli; işaretsiz rol için panel açılmaz ve
    "Bu rol için telefonla katıl: <kod>" yazar). Kur modunda yönetici işaretsizse oda bir çalışan paneliyle açılır.
  - Sayfa yenilenirse paneller slot oturumlarıyla `rejoin` yapar (demo.js son kodu ve seçili rolleri `sessionStorage`'da tutar).
  - Tasarım: sade, koyu; paneller ekrana sığar (iframe'ler kendi içinde kayar). Pixel-art Aşama 5'te.
- **`baslat.bat`:** `PP_DEMO=1` ise tarayıcıyı `/demo.html` ile açar. Ayrıca yeni `demo.bat`: `PP_DEMO=1` ayarlayıp `baslat.bat`'ı çağırır. (demo.bat da bu modülün dosyası.)
- **Bağımlılıklar:** mevcut istemci ve socket olayları. Sunucu dosyalarına dokunulmaz.
- **Atanan agent:** gelistirici
- **Notlar:** Arayüz birebir. Ekler: index.html'de ham state `<details>`'a `id="debug-details"` (embed'de gizlenir; embed'de h1 de gizli),
  demo.html'de `#demo-error` (hata satırı). postMessage ayrıca room:closed/çıkış/rejoin hatasında `code/phase/role=null` ile gider.
  "Demo odası kur" önce eski demo oturumlarını siler. Ev sahibi panelin kodu değişirse (ör. lobide yenileme → oda kapanıp yeniden açılır)
  diğer paneller yeni koda bağlanır. Yerleşim/odak yalnız CSS sınıfı. Playwright deneme 60/60, stage2 e2e 130/130.
  Tur 1 düzeltmesi: otomatik akış hatasında iframe üst pencereye `postMessage({ type: 'pp-error', slot, error, message }, location.origin)` gönderir (yalnız hata kodu + Türkçe mesaj); demo.js bunu `#demo-error`'da "<Rol>: <mesaj>" gösterir, başlık "Bağlanamadı" olur, ROOM_NOT_FOUND'da paneller kapanır.
  Embed'de client.js `<html>`'e `data-pp-phase`/`data-pp-role` yazar (yalnız CSS sıkıştırması; oyun/anket/sonuçta #room-info gizli). demo.e2e 48/0, stage2 130/130.

---

# AŞAMA 5 — 3B ortak roket alanı + gövde seçimi + yuva/uyumsuzluk kuralları + görev kontrol arayüzü  ← ŞU AN

Kullanıcı isteği (özet): (1) her parçanın fiyatı olsun, bütçeyi yönetici bilsin; (2) "tıkla-ekle" listesi yerine ortada 3 boyutlu bir oyun alanı: boş bir roket,
parçalar ona takılır; roketin birden çok gövde tipi var, yönetici (CEO) seçer; bir yuvaya biri parça koyunca başkası koyamaz; bazı parçalar bilimsel nedenlerle
yan yana/aynı yüzeyde olamaz; (3) tüm ekranlar NASA görev kontrol panosu tarzında (koyu lacivert, ince çerçeveli paneller, monospace, camgöbeği/amber/yeşil göstergeler).
Pixel-art fikri bu tarzla değiştirildi. Aşama 1–4 kuralları (gizlilik, anket, sayaç, olaylar, geri alma, puan) geçerli kalır; aşağıdakiler EKLENİR/DEĞİŞİR.

## Yeni akış
`lobby` → (4 rol dolunca) `setup` → (yönetici gövde seçer) `building` → `poll` → `result` → (restart) `setup`
- `setup`: görev atanmıştır; yönetici görev kartını ve gövde seçeneklerini (sayılarıyla) görür; çalışanlar "Yönetici roket gövdesini seçiyor" + gövde adları/açıklamaları (sayısız).
  Sayaç ve olay planı `setup`'ta BAŞLAMAZ; `selectFrame` anında başlar (Aşama 4'teki "building'e geçince" kuralı artık bu an).
- Gövde tur boyunca değişmez.

## Veri: gövdeler ve kurallar (`data/frames.json`)
```json
{ "frames": [ {
    "id": "frame-slim", "name": "…", "desc": "sayısız açıklama (herkes görür)",
    "massKg": 0, "cost": 0,
    "shape": { "segments": [ { "id": "stage1", "name": "Birinci kademe", "y0": 0, "y1": 4, "radius": 1.2 } ],
               "nose": { "y0": 9, "y1": 11.5, "radius": 1.0 }, "fins": 4, "boosters": 0 },
    "slots": [ { "id": "eng-c", "name": "Merkez motor yuvası", "zone": "engine-mount", "segment": "stage1",
                 "face": "C", "kind": "mount", "accepts": ["engine"], "pos": [0, 0, 0], "normal": [0, -1, 0],
                 "neighbors": ["eng-n", "tank-1"] } ] } ],
  "rules": [ { "id": "shield-vs-solar", "a": { "tag": "ablative" }, "b": { "tag": "needs-sun" },
               "scope": "same-face", "reason": "Isı kalkanı yüzeyi kaplar; altındaki panel güneş ışığı alamaz." } ] }
```
- `massKg` ve `cost` YALNIZ yöneticiye gider.
- En az 3 gövde, şekil ve karakter olarak belirgin farklı (ör. ince/hafif: az yuva; ağır yük taşıyıcı: yan iticili, çok yuva ama ağır ve pahalı; geniş burunlu: çok faydalı yük hacmi).
- `kind`: `'mount'` (motor altı), `'internal'` (gövde içi bölme), `'surface'` (dış yüzey/kaplama). `face`: `'N'|'E'|'S'|'W'|'C'` (C = eksen/iç).
  `pos`/`normal`: roket yerel koordinatı (y yukarı, metre benzeri birim) — yalnız çizim için.
- `accepts`: parça KATEGORİLERİ. **Paylaşılan yuvalar şart:** bazı iç bölmeler hem uzay aracı hem faydalı yük parçası kabul eder; bazı dış yüzey yuvaları güneş paneli / ısı kalkanı /
  anten / kamera / radar kabul eder; en az bir yuva hem roket (ek tank) hem uzay aracı (batarya) parçası kabul eder. Böylece roller aynı yer için yarışır (kaos).
- `rules` (uyumsuzluklar): `a`/`b` seçicisi `{ tag }` | `{ category }` | `{ partId }`; `scope`: `'same-face'` (aynı segment + yüz), `'neighbors'` (komşu yuvalar), `'same-segment'`.
  Her kuralın gerçek mühendislik gerekçesi `reason` alanında, SAYISIZ Türkçe cümle. En az 5 kural; fikirler: ablatif kalkan ↔ güneş paneli (ışık alamaz),
  radar ↔ yüksek kazançlı anten (elektromanyetik girişim), kriyojenik (hidrojenli) yakıt/tank ↔ ısı üreten parça (yakıt kaynar), optik alet (kamera/spektrometre) ↔ motor yakını
  (egzoz ve toz optiği kirletir), büyük anten ↔ aynı yüzde güneş paneli (gölge), sondaj ↔ hassas optik (titreşim/toz).
- `data/parts.json`: her parçaya `tags: []` ve `model` (3B çizim ipucu: `engine|tank|fuel|panel|battery|shield|dish|box|frame|camera|spectrometer|radar|rover|drill|capsule`) eklenir.
  `fuel` (yakıt tipi) de bir yuvaya takılır (`zone: 'fuel-line'`), yine tekil. Mevcut `max`/`requires`/ışık kuralları kalır.

## Yerleşim modülü (`server/layout.js`) — saf
`module.exports = { createLayout }`; `createLayout({ framesData, physics })` →
- `listFrames()` → tam gövde nesneleri (yalnız yöneticiye gider)
- `getFrame(frameId)` → tam nesne | undefined
- `publicFrame(frameId)` → `{ id, name, desc, shape, slots: [{ id, name, zone, segment, face, kind, accepts, pos, normal }] }` — `massKg`/`cost` YOK
- `publicFrameOptions()` → `[{ id, name, desc, shape }]`
- `canPlace(build, frameId, role, partId, slotId)` → `{ ok: true }` | `{ ok: false, error, reason }`;
  `error`: `INVALID_SLOT` | `SLOT_TAKEN` | `SLOT_MISMATCH` (yuva bu kategoriyi kabul etmez) | `PART_CONFLICT` (bir `rules` kuralı; `reason` = kuralın gerekçesi) |
  `INVALID_PART` | `NOT_ALLOWED` | `PART_LIMIT` (physics.canAdd'den). `reason` her zaman sayısız Türkçe.
- `slotOptions(build, frameId, role, partId)` → `[{ slotId, ok, error?, reason? }]` (yalnız o kategoriyi kabul eden yuvalar)
- `slotName(frameId, slotId)` → string
- `build` girdisi artık `{ uid, partId, slotId }` (üç rolün build'i de aynı gövdenin yuvalarını paylaşır).

## Fizik değişikliği (`server/physics.js`)
- `computeTelemetry(build, mission, frame)` — `frame` (tam gövde nesnesi | null/undefined): `massKg` kuru kütleye, `cost` harcamaya eklenir. Telemetriye `frameMassKg`, `frameCost` eklenir.
- `publicCatalog(role)` öğelerine `model` eklenir (sayı değil). Diğer arayüzler aynı.
- Dengeleme: her görev en az 2 farklı çözümle (tercihen farklı gövdelerle) kazanılabilir; her gövde en az bir görevi çözebilir; görev başına en az bir gövde o görevi belirgin
  zorlaştırır. `parMassKg` ve bütçeler gövde kütle/maliyetiyle yeniden ayarlanır. Sabit çözümler yuva ve uyumsuzluk kurallarına UYAR (yerleşimleriyle birlikte testte sabitlenir).

## Oda mantığı (`server/rooms.js`) değişiklikleri
- `createRoomManager({ …, layout })` — `layout` zorunlu (createLayout çıktısı / testte sahte).
- `PHASES.SETUP = 'setup'`. 4 rol dolunca: görev atanır, `phase='setup'`, `room.frameId = null`. Sayaç/olay planı yok.
- `manager.selectFrame(code, playerId, frameId)` → room: yalnız yönetici, yalnız `setup`; geçersiz gövde → `INVALID_FRAME`. Sonra `phase='building'`, sayaç + olay planı başlar,
  telemetri gövdeyle hesaplanır, log (system): "Yönetici gövdeyi seçti: <ad>".
- `manager.addPart(code, playerId, partId, slotId)` — `layout.canPlace` kullanılır; hata kodları yukarıdaki gibi + `PART_LOCKED`; `GameError.message` = `reason`.
  Log: "<Rol adı>: <parça adı> → <yuva adı>" (sayısız). `removePart(code, playerId, uid)` aynı.
- Geri alma: `add` geri alınır = çıkarılır; `remove` geri alınır = aynı yuvaya geri takılır; yuva artık doluysa `SLOT_TAKEN` (hak düşmez).
- `restart` → `phase='setup'`, `frameId=null`, yeni görev; Aşama 4 durumu sıfır.
- Aşama 4'teki supplier-delay, computer-fault, weather aynen (computer parçası da bir yuvaya takılır).

## Görünümler (`server/filter.js`) — `viewFor(room, playerId, physics, layout)`
`setup` fazı: herkese `frameOptions: publicFrameOptions()`; yöneticiye ek `mission` (tam), `frames: listFrames()` (sayılı), `undoLeft`. Çalışana `missionLabel`.
`building` / `poll` fazları — Aşama 2–4 alanlarına EK olarak herkese:
```js
frame: publicFrame(frameId),
slots: [ { id, occupant: null | { role, name, icon, model, mine: bool } } ]      // tüm yuvalar, gövdedeki sırayla
```
Çalışana ek: `catalog` öğelerinde `model` ve `slots: [{ slotId, ok, reason? }]` (o parça için `slotOptions`; `error` kodu gönderilmez, yalnız `ok` + `reason`);
`myParts` öğelerinde `slotId`, `slotName`. Yöneticiye ek: `frameInfo: { id, name, massKg, cost }`, `build` öğelerinde `slotId`, `slotName`, `cost`;
`budget: { total, spent, left }` (`spent` gecikmeli telemetriyle aynı: `telemetryShown.spent`); `log` girdilerinde parça hareketleri için `cost` (±, yalnız yöneticide);
`catalog` (tam, sayılı) aynen.
`result`: `result.frame = { name }` + mevcut alanlar; `result.build` öğelerinde `slotName`.
**Gizlilik kuralı aynen:** çalışan görünümünde (setup/building/poll) gövde `massKg`/`cost`, `frames`, `frameInfo`, `budget`, parça fiyatları ve tüm sayısal parça alanları YOK.
`pos`/`normal`/`shape` geometri sayılarıdır, izinli. Fiyatları ve bütçeyi yalnız yönetici görür (kullanıcı isteği 1).

## Socket olayları
| Olay | Payload | Ack |
|---|---|---|
| `frame:select` | `{ frameId }` | `{ ok:true }` |
| `part:add` | `{ partId, slotId }` | `{ ok:true }` (hata: `{ ok:false, error, message }` — message = gerekçe) |
Diğer olaylar aynı. index.js: `/vendor/three` → `node_modules/three` ve `/vendor/fonts` → seçilen yerel font paketi statik sunulur (internet GEREKMEZ; CDN YOK).

## 3B sahne (`public/scene3d.js`) — ES modülü, Three.js
`import * as THREE from 'three'` (sayfadaki importmap: `three` → `/vendor/three/build/three.module.js`, `three/addons/` → `/vendor/three/examples/jsm/`).
```js
export const supported            // WebGL var mı
export function createRocketScene(container) → {
  setFrame(publicFrame | null),                     // gövde + boş yuva işaretçileri (prosedürel geometri; dış model dosyası yok)
  setSlots(slots),                                  // occupant'lara göre parça mesh'leri (model + rol rengi)
  setHighlights(map | null),                        // { [slotId]: 'ok' | 'blocked' } — parça seçiliyken
  setMyRole(role),
  onSlotClick(fn(slotId)), onPartClick(fn(slotId)), // boş yuva / dolu yuva tıklaması (fare + dokunma; raycast)
  focusSlot(slotId), resize(), dispose(),
  playLaunch(outcome) → Promise                     // sonuç animasyonu (aşağıda)
}
```
- `playLaunch`: success kalkış + yükseliş; no-liftoff sarsılıp rampada kalır; out-of-fuel yükselip düşer; power-loss ışıklar söner; overheat kızarır;
  computer-failure savrulur; mission-failed normal kalkış; window-missed animasyon yok (hemen resolve).
- Sürükle = döndür, tekerlek/iki parmak = yakınlaştır (OrbitControls); yavaş otomatik dönüş (etkileşimde durur). Yuva üstüne gelince/dokununca ad etiketi (`.slot-label` DOM öğesi).
- Rol renkleri: rocket amber `#ffb347`, spacecraft camgöbeği `#4fd1ff`, payload yeşil `#4dff9a`; boş yuva soluk tel kafes; `ok` vurgusu yeşil nabız, `blocked` kırmızı.
- Görünüm: koyu uzay arka planı (`#05080f`/şeffaf), "holografik pano" hissi (kenar çizgileri, hafif ışıma), yıldızlar; düşük poligon. Telefon için hafif (pixelRatio ≤ 2).
- Test kancası: hazır olunca `container.dataset.sceneReady = '1'`; `window.__ppScene = { slotScreenPos(slotId) → {x,y} | null, clickSlot(slotId) }`.

## İstemci (`public/index.html`, `public/styles.css`, `public/client.js`, `public/ui/*`, `public/demo.html`, `public/demo.js`)
**Sanat yönü — görev kontrol panosu (kullanıcının gönderdiği ekran görüntüsü):** zemin `#05080f`, panel `#0a1120`, çerçeve `#1b2a44` (1px, köşe çentikleri / başlık şeridi),
metin `#c9d6ea`, soluk `#5f7391`, camgöbeği `#4fd1ff`, amber `#ffb347`, yeşil `#4dff9a`, kırmızı `#ff5a6a`. Tümü monospace (yerel font: `/vendor/fonts/...`; büyük sayılar terminal hissi),
BÜYÜK HARF aralıklı panel başlıkları ("● GÖREV DURUMU"), küçük durum rozetleri, ince ilerleme çubukları. Emoji ikonlar kalabilir. Tarama çizgisi/ışıma çok hafif.
- **Yönetici panosu:** üst şerit büyük göstergeler: sayaç (pencere), görev fazı, BÜTÇE (harcanan / toplam + çubuk, aşımda kırmızı), Δv (mevcut / gereken), İtki/Ağırlık, Güç, Isı;
  ortada 3B roket (salt izleme: tıklayınca yuva/parça bilgisi); solda görev kartı + gövde bilgisi; sağda kontrol göstergeleri (5–6 check) + olaylar;
  altta "zaman çizelgesi" olarak log (parça hareketlerinde ± fiyat) ve takılı parça listesi (yuva + fiyat); en altta ekip şeridi (4 oyuncu, rol, bağlantı, oy).
  Geri alma ve anket düğmeleri belirgin. Sayılı tam katalog açılır panel.
- **Çalışan panosu:** ortada 3B roket; yanında/altında kendi kataloğu. Akış: katalogdan parça SEÇ (`button[data-pick="<partId>"]`, seçili olan `aria-pressed="true"`) → uygun yuvalar
  3B'de yeşil, engelliler kırmızı → 3B'de yuvaya tıkla YA DA `#slot-list` içindeki `button[data-slot="<slotId>"]` (engelliler disabled + gerekçe metni) → `part:add`.
  Kendi takılı parçasına 3B'de tıklayınca (onay sorarak) ya da `#my-parts button[data-remove="<uid>"]` ile çıkar. Kırmızı/sarı/yeşil ışıklar aynen. Diğerlerinin parçaları 3B'de rol rengiyle.
  WebGL yoksa `#slot-list` tek başına yeterli olmalı (3B alanında "3B desteklenmiyor" notu). Hiçbir sayı/fiyat yok.
- **Setup:** yönetici `#frame-select` içinde gövde kartları (`button[data-frame="<id>"]`; ad, açıklama, kütle, maliyet, yuva sayıları, küçük siluet); çalışanlar bekleme ekranı.
- **Sonuç:** 3B'de `playLaunch(outcome)` (`#skip-launch-btn` kalır), sonra panel.
- Korunacak seçiciler: `#name-input #create-btn #code-input #join-btn #error-msg #room-code #player-list [data-role] #leave-btn #screen-entry #screen-lobby #screen-game
  #screen-result #catalog #my-parts [data-status] button[data-remove] #feed #gauges [data-check][data-ok] #ready-line #log-box #mission-box #build-box #director-catalog
  #poll-start-btn #poll-warning #poll-box [data-vote-role][data-vote] #vote-go-btn #vote-nogo-btn #poll-cancel-btn #timer[data-window][data-urgent] #events-box [data-event-type]
  #hold-banner #undo-box #undo-left button[data-undo] #result-panel #result-title #result-reason #result-score #result-breakdown #result-mission #result-nasa #restart-btn
  #skip-launch-btn #debug-state`. Yeni: `#screen-setup #frame-select button[data-frame] #scene3d #slot-list button[data-slot] button[data-pick] #budget-box[data-over="true|false"] #frame-box`.
  `button[data-add]` KALKAR (yerine pick + slot). "Yöneticide `#screen-game button` sayısı 0" kuralı KALKAR.
- Telefon (≥360px) ve dizüstü: telefonda 3B üstte (~40–45vh), altında sekmeli/çekmeceli paneller; sticky alanlar ekranın en çok ~%30'u. Demo modu (iframe paneller ~470–800px) düzgün görünmeli;
  demo.html/demo.js aynı tarza çekilir, URL parametreleri/postMessage sözleşmesi korunur.
- innerHTML yok; istemci kural hesaplamaz (uygunluk sunucudan `catalog[].slots` ile gelir).

## Modüller (Aşama 5)

### Modül Q: Gövde/yuva verisi + yerleşim kuralları + fizik + dengeleme
- [x] Durum: tamam
- **Sahip dosya(lar):** `data/frames.json`, `data/parts.json`, `data/missions.json`, `server/layout.js`, `server/physics.js`, `test/physics.test.js`, `test/layout.test.js`, `test/launch.test.js`
- **Atanan agent:** gelistirici
- **Notlar:** `node --test test/physics.test.js test/layout.test.js test/launch.test.js` 66/66. Arayüz birebir; EKLER (geriye uyumlu):
  (1) yuvada isteğe bağlı `acceptsTags: { <kategori>: [etiket...] }` — o kategoriden parça en az bir etiketi taşımalı (yoksa SLOT_MISMATCH; slotOptions bu yuvayı hiç listelemez).
  Dış yüzeyde `instrument` yalnız `outward` (kamera, spektrometre, radar, röle anteni); dar iç bölmelerde `stowable` (matkap); geniş bölmelerde `stowable`+`bulky` (rover, örnek kapsülü).
  (2) Burun yuvalarının `segment`'i `"nose"` (= `shape.nose`, segments dizisinde yok). (3) Dev'de `shape.booster: { radius, y0, y1, offset, axis:'x' }` — yan iticiler ±x'te; yan itici yuvaları face E/W, pos x=±offset.
  (4) Gövde yokken canPlace → `INVALID_SLOT` ("Henüz roket gövdesi seçilmedi."). (5) `layout.rules()` (kuralların kopyası) ek export. (6) `tank-large.max` 3 → 4. (7) Telemetride `frameMassKg`, `frameCost` her zaman var (gövdesizde 0).
  İç bölme `normal` = [0,1,0]; motor yuvası pos y=0, normal [0,-1,0]; yüzey pos = segment yarıçapı × yüz yönü.
  **Gövdeler:** `frame-swift` Kırlangıç (700 kg / 60; 14 yuva: 2 motor, 2 tank [biri tank+batarya], dar burun — geniş bölme YOK, rover/kapsül sığmaz);
  `frame-heavy` Dev (2000 kg / 220; 21 yuva: 3 merkez + 2 yan itici motoru, 5 tank, 2 servis bölmesi, 1 geniş yük bölmesi); `frame-cargo` Kargo (1300 kg / 110; 20 yuva: 3 motor,
  3 tank [biri tank+batarya], geniş yük bölümünde 6 dış yüzey + 3 yük bölmesi [2'si geniş]).
  **Kurallar:** `shield-vs-solar` (ablatif kalkan ↔ panel, aynı yüz: kurum/gölge), `radar-vs-radio` (radar ↔ HGA/röle anteni, komşu: EM girişim), `cryo-vs-heat` (sıvı hidrojen ↔ batarya/rover RTG, komşu: kaynama),
  `optics-vs-engine` (kamera/spektrometre ↔ motor, komşu: egzoz/toz/titreşim), `dish-vs-solar` (büyük çanak ↔ panel, aynı yüz: gölge), `drill-vs-optics` (matkap ↔ optik, aynı segment: titreşim/toz).
  **missions.json:** lunar-relay Δv 4200 / bütçe 800 / par 18500; mars-rover 5400 / 2300 / 54000; asteroid-sample 4950 / 1550 / 31000.
  **Sabit çözümler (test/physics.test.js `SOLUTIONS`, yuvalarıyla):** Ay rölesi — Kırlangıç (Kerkenez + büyük tank + metan; 650, 17790 kg) ve Kargo (Kerkenez + büyük tank + hidrojen; 790);
  Mars — Kargo (Balıkçıl + 2 Kerkenez + 3 büyük tank + hidrojen; 1740) ve Dev (Balıkçıl + 3 Kerkenez + 4 büyük tank + hidrojen; 2130);
  Asteroit — Kargo (Balıkçıl + Kerkenez + büyük + 2 küçük tank + hidrojen; 1275) ve Dev (2 Kerkenez + 2 büyük + küçük tank + hidrojen; 1415). Arızada (yedek bilgisayar): Ay → Kırlangıç, Mars/Asteroit → Kargo (`FAULT_SOLUTIONS`).
  **Gövde seçimi (arama sonucu):** Ay: Kırlangıç kolay (10 bileşim), Kargo zor (2), Dev imkânsız (bütçe). Mars: Dev rahat (17), Kargo çok zor (3, yalnız tam tank dolu), Kırlangıç imkânsız (rover sığmaz).
  Asteroit: Kargo kolay (55, 9 roket varyantı), Dev zor (1), Kırlangıç imkânsız (kapsül sığmaz). Açgözlü build her görev × her gövdede bütçeyi aşar.
  **Tur 1 düzeltmesi:** `layout.unfitParts(frameId, partIds)` eklendi. A6: yalnız yuva `pos` değerleri değişti (id/accepts/komşuluk aynı); aynı gövdede yuva merkezleri ≥ 0.6, aynı segmentte yüzey ile iç bölme y farkı ≥ 0.3 (testli); Kargo yük bölmeleri eksen yakınında üst üste. Testler 68/68.

### Modül R: Oda mantığı + filtre (setup fazı, yuvalı yerleşim)
- [x] Durum: tamam
- **Sahip dosya(lar):** `server/constants.js`, `server/rooms.js`, `server/filter.js`, `test/stage1.test.js`, `test/stage2.test.js`, `test/stage3.test.js`, `test/stage4.test.js`, `test/stage5.test.js`
- **Atanan agent:** gelistirici
- **Notlar:** stage1–5 74/74 (sahte saat/physics/layout). `layout` verilmezse TypeError. Kararlar: setup'ta `room.telemetry`/`telemetryShown` sıfır nesne, computeTelemetry ilk kez selectFrame'de çağrılır; selectFrame logu kind `'system'`, role `'director'` (çalışan feed'ine girmez).
  Çıkarma log metni "<Rol>: <parça> çıkardı (<yuva adı>)"; log `cost`: takma +, çıkarma −, undo'da geri takma +, geri alınan takma −. addPart sırası: faz/rol → partId tipi (INVALID_PART) → slotId tipi (INVALID_SLOT) → PART_LOCKED → layout.canPlace (mesaj = `reason`, yoksa yedek Türkçe metin).
  Undo `remove`: yuva doluysa SLOT_TAKEN, hak ve `lastMove` korunur; geri takmada limit/kilit/uyumsuzluk kontrolü yok. `lastMove` öğelerine `slotId` eklendi. `constants.LOCK_REASON` eklendi.
  Filtre: `frame`/`frameOptions` üst düzey beyaz liste; `shape` derin kopyalanır ve her derinlikte `massKg/dryMassKg/cost/price/budget` anahtarları atılır (geometri alanları serbest). `frameInfo` gövde yoksa null. Rolsüz çalışan building/poll'da `frame`+`slots`+timer alır, katalog almaz. `others` öğeleri hâlâ `{name, icon}` (model yok; 3B için `slots[].occupant.model` kullanılır). Testlerdeki sahte yuva adları rakamsız; gerçek yuva adlarında rakam olursa log metnine geçer.
  Tur 1 düzeltmesi (yalnız filter.js): yönetici setup'ına `catalog` (fullCatalog kopyası) ve `frames[i].unfit` (layout.unfitParts yoksa/hata atarsa `[]`), result'a `mission.requiredInstrumentNames` (bilinmeyen id → id) eklendi; çalışana hiçbiri gitmez, stage1–5 76/76.

### Modül S: Sunucu bağlama + bağımlılıklar
- [x] Durum: tamam
- **Sahip dosya(lar):** `server/index.js`, `package.json`, `package-lock.json`, `README.md`, `baslat.bat`
- **İş:** `three` + yerel monospace font paketi (npm, ör. `@fontsource/jetbrains-mono`); `/vendor/three`, `/vendor/fonts` statik yolları; `createLayout` kurulumu ve manager/viewFor'a verilmesi;
  `frame:select` olayı; `part:add`'e `slotId`. baslat.bat: `node_modules\three` yoksa da `npm install` çalışsın.
- **Atanan agent:** gelistirici
- **Notlar:** Kurulu: `three@0.187.0`, `@fontsource/jetbrains-mono@5.3.0`. KESİN URL'ler (sunucuda açık, başka node_modules yolu YOK):
  - importmap: `"three": "/vendor/three/build/three.module.js"`, `"three/addons/": "/vendor/three/examples/jsm/"`
    (three.module.js `./three.core.js`'i import eder — aynı klasörden sunulur; OrbitControls: `/vendor/three/examples/jsm/controls/OrbitControls.js`, `'three'` import eder → importmap şart).
    Açık olanlar yalnızca `/vendor/three/build/*` ve `/vendor/three/examples/jsm/*` (`/vendor/three/package.json` vb. 404).
  - Font (family `'JetBrains Mono'`): Türkçe için İKİSİ birden gerekli (latin = temel A–Z, latin-ext = ğ ş ı İ ç ö ü):
    `<link rel="stylesheet" href="/vendor/fonts/jetbrains-mono/latin-400.css">` + `/vendor/fonts/jetbrains-mono/latin-ext-400.css`;
    kalın için `latin-700.css` + `latin-ext-700.css` (100–800 ve `-italic` sürümleri de var). CSS'ler `./files/*.woff2`'yi göreli çağırır (`/vendor/fonts/jetbrains-mono/files/...`).
  - index.js: `createLayout` → manager + `viewFor(room, pid, physics, layout)`; `frame:select` (frameId string değilse BAD_REQUEST); `part:add` partId+slotId string şart; hata ack'i `message` = GameError.message (gerekçe).
    baslat.bat: `node_modules`, `node_modules\three` ya da `node_modules\@fontsource\jetbrains-mono` yoksa `npm install`. Gerçek Q+R dosyalarıyla 4 istemcili duman testi 54/54 (setup/frame:select/SLOT_TAKEN/SLOT_MISMATCH/INVALID_SLOT/çıkarma/gizlilik + vendor 200/404 kaçış denemeleri).

### Modül T: 3B sahne
- [x] Durum: tamam
- **Sahip dosya(lar):** `public/scene3d.js`, `public/scene3d-dev.html` (bağımsız deneme sayfası)
- **Atanan agent:** gelistirici
- **Notlar:** Arayüz birebir. Kullanım: sayfada importmap (three + three/addons/) olmalı; `import { supported, createRocketScene } from './scene3d.js'`.
  Container'a CSS ile yükseklik verin (canvas %100 doldurur; position static ise relative yapılır). `.slot-label` öğesini modül container içine kendisi ekler
  (`:where(.slot-label)` ile sıfır özgüllüklü varsayılan stil enjekte eder; styles.css ezebilir; içte `.slot-label-part` span'ı). Tüm setX çağrıları ucuz (JSON imza farkı).
  `playLaunch` her zaman resolve eder (reject yok); dispose/yeni setFrame kesince de resolve. Sonuç animasyonu sonrası sahne o halde kalır; aynı gövdeyle `setFrame` tekrar çağrılırsa rampaya sıfırlanır.
  `shape.booster` ({radius,y0,y1,offset,axis}) varsa yan iticiler oraya çizilir (frame-heavy yuvalarıyla uyumlu). `window.__ppScene` son oluşturulan sahneye aittir;
  `slotScreenPos` viewport (client) koordinatı verir — `page.mouse.click(x,y)` ile doğrudan kullanılabilir. Dev sayfası: `/scene3d-dev.html` (data/frames.json gövdeleri gömülü kopya).

### Modül U: İstemci arayüzü (görev kontrol tarzı)
- [x] Durum: tamam
- **Sahip dosya(lar):** `public/index.html`, `public/styles.css`, `public/client.js`, `public/ui/*`, `public/demo.html`, `public/demo.js`
- **Atanan agent:** gelistirici
- **Notlar:** Dosyalar: `index.html` (importmap + yerel font linkleri), `styles.css` (yeni, tüm stil), `client.js` (tek IIFE, `import('/scene3d.js')` dinamik); `public/ui/` kullanılmadı. demo.html yalnız stil + etiketler, demo.js yalnız `PHASE_LABELS.setup`.
  Düzen JS ile `<html>`'e yazılır: `data-layout="wide|split|stack"` (≥1100×600 pano; 700–1099 ya da embed ≥440 iki sütun, 3B sol yapışık; dar → tek sütun + sekmeler), `data-phase`, `data-rolekind`, `data-scene="none"` (3B yoksa), `data-debug="1"` (`?debug=1`). Embed'de `data-pp-phase/role` aynen.
  Yeni seçiciler (PLAN'dakilere ek): `#app-head #head-code #head-role #conn-status #error-wrap #error-close #gauge-strip #phase-value #timer-value #timer-label #role-name #mission-label #g-frame-name #budget-spent #budget-total #budget-left #budget-bar #g-deltav #g-twr #g-power #g-heat [data-ok] #setup-director #setup-worker #setup-mission #frame-options #scene-panel #scene-host #scene-info[data-kind] #picked-bar #unpick-btn #slot-panel #slot-hint #slot-msg #tabs [data-tab-btn] [data-tab] #poll-ready-note #poll-votes .vt-role/.vt-state #result-stage #result-scene-host #result-badge #result-frame #debug-details`; `#screen-result[data-stage="launch|panel"][data-scene="live|none"]`; katalog `li[data-locked] > button[data-pick][aria-pressed]`; yuva `#slot-list li > button[data-slot]` (+ `p.sl-reason`); `#my-parts .status-dot[data-status]`; ekip `#player-list li[data-connected]` (+ ankette `.crew-vote[data-vote]`); `#log-box ul.timeline li[data-kind]` (`.c[data-sign]` ± fiyat); `#build-box [data-build-role] li[data-slot-id]`.
  Davranış: #room-info lobide üst panel, oyunda alttaki ekip şeridi; `#timer-bar` KALKTI (`#timer` şeritte). Yöneticide #poll-controls/#undo-box/#events-box artık #screen-game İÇİNDE. 3B'de kendi parçasına tıklama → `#scene-info` içinde satır içi onay; liste `button[data-remove]` doğrudan çıkarır. Parça eklenince seçim sıfırlanır; faz değişince dar düzende sayfa başa kayar. Gerçek sunucuyla 4 sayfa uçtan uca (olaysız + olaylı tur, başarı/başarısızlık, yeni tur, rejoin, demo 2×2, 3B yok senaryosu) — konsol hatası yok, yatay taşma yok.
  Bilinen eksikler: setup'ta katalog gelmediği için ilk turda yönetici görev kartındaki aletler id ile ("sample capsule") görünür; 3B vurgu/etiket görünümü T'nin; e2e betikleri eski seçicileri bekliyor (test ajanı).

## Paralel dağıtım (Aşama 5)
- **Grup 1 (paralel):** Modül Q, R, S, T, U

## Tur 1 sonrası arayüz ekleri (Aşama 5)
- `layout.unfitParts(frameId, partIds)` → o gövdede HİÇBİR yuvanın kabul etmediği parça id'leri (boş build varsayımıyla; kategori + acceptsTags). (Modül Q)
- Yönetici `setup` görünümü: `catalog` (tam, sayılı) da gönderilir; `frames[i].unfit: [{ partId, name }]` = görevin zorunlu aletlerinden o gövdeye sığmayanlar
  (yönetici yanlış gövdeyi bilerek seçsin diye uyarı; seçim yine serbest). `result.mission.requiredInstrumentNames: [ad…]` eklenir. Çalışana bunların hiçbiri gitmez. (Modül R)
- İstemci: gövde kartında `unfit` doluysa kırmızı uyarı satırı (`[data-unfit="true"]`): "Bu gövdede yer yok: <adlar>"; görev kartı ve sonuçta alet ADLARI. (Modül U)

## Test-düzelt turları — Aşama 5 (en fazla 3)
- [x] Tur 1 — kritik yok; 2 orta + 8 düşük bulgu → düzeltmeler Q/R/T/U'ya dağıtıldı
- [ ] Tur 2
- [ ] Tur 3

## Son durum — Aşama 5 (şef doldurur)
- **Çalışanlar:** Tur 1'de doğrulananlar (gövde seçimi, yuvalı yerleşim, altı kural, bütçe, gizlilik). Sunucu düzeltmeleri (Q, R) tamam, 144/144.
- **Kalanlar:** 3B sahne ve istemci düzeltmeleri yarıda bırakıldı; kullanıcı kararıyla 3B ve sıkışık pano terk edildi → Aşama 6 ikisini de baştan yapar. Tur 2 çalıştırılmadı.

---

# AŞAMA 6 — Sakin arayüz + 2B roket  ← ŞU AN

Kullanıcı kararı: (1) 3B çok zor/karmaşık → roket ve parçalar **2B**; (2) mevcut pano "sıkışık, kaotik" → kullanıcının gönderdiği iki ana menü görseline benzeyen,
**sakin, büyük, kolay kullanılan** bir arayüz: numaralı büyük kartlar (01 camgöbeği, 02 amber, 03 gri), köşe çentikli çerçeveler, ince üst çubuk, ince alt durum satırı,
büyük tek düğmeler, sağda geniş "kahraman" alanı. (3) Girişte "Solo" yok; üçüncü kart **Demo modu**. Tasarım kararları şefe/geliştiriciye bırakıldı.
**Sunucuya, veriye, socket olaylarına, `viewFor` çıktısına DOKUNULMAZ** (oda sistemi değişikliği ayrıca konuşulacak, bu aşamada YOK). Gizlilik kuralları aynen.
Kullanıcı ileride kendi 2B çizimlerini (PNG) verecek; şimdilik her şey kodla (SVG/CSS) çizilir. Dış dosya indirme, CDN, fotoğraf YOK.

## Ortak tasarım dili (Modül V, W, X aynen kullanır)
- Renkler: zemin `#05080f`, panel `#0a1120`, çerçeve `#1b2a44`, metin `#e3ecf8`, soluk `#7f93b0`, camgöbeği `#4fd1ff`, amber `#ffb347`, yeşil `#4dff9a`, kırmızı `#ff5a6a`, gri kart `#3a4252`.
  Rol renkleri: rocket amber, spacecraft camgöbeği, payload yeşil, director beyaz/metin.
- Kart: 2px renkli çerçeve, içi aynı rengin ~%12 saydam dolgusu, köşe çentiği/köşe işaretleri, sol üstte büyük soluk numara ("01"), büyük başlık + altında köşeli parantezli küçük açıklama ("[ODAYA BAĞLAN]").
- Yazı: gövde ve başlıklar sistem sans (`"Segoe UI", system-ui, sans-serif`), yalnız sayılar/kodlar `'JetBrains Mono'` (yerel). Taban ≥ 16px; en küçük yazı 13px. Başlıklar BÜYÜK HARF.
- Sakinlik kuralları: ekran başına TEK ana iş; en çok 3 vurgu rengi; bol boşluk (16–24px); düğme yüksekliği ≥ 48px; tarama çizgisi, yanıp sönen süs, anlamsız "telemetri" yazıları YOK
  (yalnız acil durumlar nabız atar: son 30 sn, bekleme, kilit). İkincil bilgiler (kayıt, tam katalog, takılı parça listesi, ham state) bir düğmenin arkasında açılır panel/çekmece.
- Üst çubuk: solda "PIXEL PAYLOAD" + küçük alt başlık; sağda bağlantı durumu noktası + `NASIL OYNANIR` düğmesi. Alt durum satırı: oda kodu · rol · faz (tek satır, soluk).

## 2B roket sahnesi (`public/scene2d.js`) — ES modülü, bağımlılıksız (SVG), Three.js YOK
Arayüz, eski 3B sahneyle AYNI (istemci kodu az değişsin):
```js
export const supported = true
export function createRocketScene(container) → {
  setFrame(publicFrame | null), setSlots(slots), setHighlights(map | null),   // { [slotId]: 'ok' | 'blocked' }
  setMyRole(role), onSlotClick(fn(slotId)), onPartClick(fn(slotId)),
  focusSlot(slotId), resize(), dispose(), playLaunch(outcome) → Promise      // her zaman resolve
}
```
- Görünüm: roket dik, yandan, düz 2B çizim (kalın dış hat, düz dolgu; piksel-art'a yakın sade stil). Gövde `publicFrame.shape`'ten çizilir (segment yarıçap/yükseklik, burun, kanatlar,
  `shape.booster` varsa yan iticiler) → üç gövde bir bakışta farklı görünür. Roket kabın yüksekliğinin ≥ %85'ini doldurur, ortalanır; döndürme/yakınlaştırma YOK.
- Yuva yerleşimi (3B `pos` → 2B): dikey konum `pos[1]`; yatay konum yüze göre: `W` gövdenin solu (dışa taşan), `E` sağı, `C` eksen, `N` eksenin biraz solu, `S` biraz sağı
  (yan itici yuvalarında `pos[0]` kullanılır). Yuva işaretçileri ÜST ÜSTE BİNMEZ (gerekirse otomatik kaydır; üç gövdede de doğrula) ve telefonda dokunma alanı ≥ 40px.
- Boş yuva: soluk kesik çerçeve + kategori ipucu simgesi. Dolu yuva: parçanın 2B simgesi (occupant.model'e göre ayrı çizim: engine, tank, fuel, panel, battery, shield, dish, box, frame,
  camera, spectrometer, radar, rover, drill, capsule) rol rengiyle; `mine` olanlar belirgin (dolu çerçeve). Vurgu: `ok` yeşil nabız, `blocked` kırmızı çarpı/soluk. Parça seçili değilken vurgu yok.
- Üstüne gelince/dokununca yuva adı etiketi (`.slot-label`, içinde parça adı için `.slot-label-part`). Tıklama: boş yuva → onSlotClick, dolu yuva → onPartClick.
- `playLaunch`: success kalkış + yükseliş (alev, duman); no-liftoff sarsılır, kalır; out-of-fuel yükselir, düşer; power-loss ışıklar söner; overheat kızarır; computer-failure savrulur;
  mission-failed normal kalkış; window-missed hemen resolve. 2–4 sn. Dispose/yeni setFrame kesince de resolve.
- Test kancası (aynı): hazır olunca `container.dataset.sceneReady = '1'`; `window.__ppScene = { slotScreenPos(slotId) → {x,y} (viewport) | null, clickSlot(slotId) }`.
- Varsayılan stiller `:where()` ile sıfır özgüllükte enjekte edilir; arka plan saydam. Kap, CSS ile yükseklik alır.

## İstemci (`public/index.html`, `public/styles.css`, `public/client.js`)
`import('/scene2d.js')`; Three.js importmap'i ve `/scene3d.js` kullanımı kalkar. Kap id'si `#scene3d` KALIR (seçici uyumu için; içerik artık 2B).
- **Giriş (`#screen-entry`):** solda üç büyük kart: `#card-create` "01 ODA KUR [YENİ GÖREV BAŞLAT]" (camgöbeği), `#card-join` "02 ODAYA KATIL [KODLA BAĞLAN]" (amber),
  `#demo-link` "03 DEMO MODU [TEK KİŞİ, DÖRT EKRAN]" (gri; `/demo.html`'e gider). Sağda kahraman alanı: kodla çizilmiş Dünya yayı, yörünge elipsleri, ince ızgara, küçük roket silueti,
  ortada "PIXEL PAYLOAD / UZAY GÖREV SİMÜLASYONU". Karta basınca kahraman alanında (telefonda kartın altında) o kartın formu açılır: Oda kur → `#name-input` + `#create-btn`;
  Odaya katıl → `#code-input` + ad + `#join-btn`. `#name-input` TEK öğedir (iki formda ortak; DOM'da taşınabilir). `#error-msg` formun altında.
- **Lobi:** büyük oda kodu ("Bu kodu ekibe söyle"), dört büyük rol kartı (`[data-role]`; boş/dolu/benim), altında "4 rol dolunca görev başlar" satırı (oyun sunucuda kendiliğinden başlar; düğme YOK), `#leave-btn`.
- **Setup:** yönetici: üstte kısa görev özeti, altında üç büyük gövde kartı (`#frame-select button[data-frame]`: siluet, ad, açıklama, kütle, maliyet, yuva sayısı, `[data-unfit]` uyarısı). Çalışan: sakin bekleme ekranı.
- **Çalışan oyun ekranı:** üstte ince şerit: sayaç + rol + "GÖREV: GİZLİ". Ortada büyük 2B roket. Altında/yanında "PARÇALARIM": büyük parça kartları (`button[data-pick]`, simge + ad + durum ışığı).
  Parça seçilince: roket üstünde uygun yuvalar yeşil; aynı anda `#slot-list` (kısa, büyük satırlar; engelli olanlarda gerekçe) görünür — telefonda roket ve yuva listesi AYNI ANDA ekranda olmalı
  (Tur 1 bulgusu A1). Takılı parçalarım (`#my-parts`, çıkar düğmeli) küçük bir bölüm. Diğerlerinin hareketleri (`#feed`) varsayılan KAPALI çekmecede ("KAYIT" düğmesi). Hiçbir sayı/fiyat yok.
- **Yönetici oyun ekranı:** sol: görev kartı (`#mission-box`) + bütçe (`#budget-box`, büyük çubuk); orta: 2B roket (salt izleme) + altında büyük sayaç; sağ: beş-altı büyük gösterge kartı
  (`#gauges [data-check][data-ok]`: İtki/Ağırlık, Δv, Güç, Isı, Yük, [Bilgisayar]) — her biri tek satır değer + geçti/kaldı rengi. Altta büyük iki düğme: geri alma (`#undo-box`) ve `#poll-start-btn`.
  Olaylar (`#events-box`) yalnız olay varken görünen tek bir uyarı şeridi. `#log-box`, `#build-box`, `#director-catalog` düğmeyle açılan çekmecelerde; kapalıyken son kayıt tek satır olarak görünür.
- **Anket:** ekranı kaplayan sakin tek kart: dört rolün oyu, büyük GO / NO-GO düğmeleri.
- **Sonuç:** önce 2B fırlatma animasyonu (`#skip-launch-btn`), sonra tek sütun sonuç kartı: başlık, neden, puan + yıldız, puan dökümü, "Gerçekte NASA bunu şöyle yapıyor", `#restart-btn`.
- **Nasıl oynanır:** `#help-btn` → `#help-panel` (kapatılabilir katman): 5–6 kısa madde, sayısız.
- Düzen: dizüstü (≥1100px) üç sütun; tablet/demo paneli (440–1099px) iki sütun; telefon (≥360px) tek sütun, roket üstte ~45vh. Yatay taşma yok. Embed (`data-embed="1"`, ~470px panel) düzgün ve sıkı.
- Korunacaklar: Aşama 5'teki "Korunacak seçiciler" + "Yeni" listesindeki tüm seçiciler ve Modül U notlarındaki seçiciler (öğe yeri değişebilir, id/attribute aynı kalır); URL parametreleri
  (`slot, auto, name, role, code, embed, debug`), `pp-state`/`pp-error` postMessage sözleşmesi, sessionStorage oturumu, rejoin. innerHTML yok; istemci kural hesaplamaz.
- TEST_RAPORU.md "Aşama 5 — Tur 1" bulguları (A1–A10) yeni tasarımda tekrar etmemeli.

## Demo (`public/demo.html`, `public/demo.js`)
Aynı tasarım diline çekilir (üst çubuk, kart çerçeveleri, büyük düğmeler, sans yazı); sol üstte `#demo-home` "← ANA MENÜ" (`/`). İşlev, seçiciler, URL/postMessage sözleşmesi AYNEN.
Paneller iframe'e en çok yeri bırakır (panel başlığı tek ince satır).

## Modüller (Aşama 6)

### Modül V: 2B roket sahnesi
- [x] Durum: tamam
- **Sahip dosya(lar):** `public/scene2d.js`, `public/scene2d-dev.html` (bağımsız deneme sayfası; üç gövde, dolu/boş/vurgulu durumlar, tüm playLaunch sonuçları).
  Eski `public/scene3d.js` ve `public/scene3d-dev.html` dosyalarını `arsiv/3b/` klasörüne TAŞIR (silmez).
- **Atanan agent:** gelistirici
- **Notlar:** Arayüz birebir (ek export yok). 3B dosyalar `arsiv/3b/`'ye taşındı. Kullanım: `import { supported, createRocketScene } from '/scene2d.js'`; kaba CSS ile yükseklik verin
  (position static ise relative yapılır); modül içine `div.pp2d` (svg + `.slot-label`) ekler, arka plan saydam, stiller `:where()` ile. Tüm setX ucuz (JSON imza farkı), boyut ResizeObserver ile izlenir.
  Yerleşim: roket tabandan dik, yüksekliğin ~%87–93'ü (ölçüldü); siluet okunsun diye yatayda en çok 1.5× genişletilir (gövdeler arası oran korunur). Yuva işaretçileri g×g ızgara hücrelerine
  (g = 42–60px; hücre = dokunma alanı) Macar algoritmasıyla atanır → çakışma imkânsız; işaretçi gerçek yerinden kaydıysa ince çizgi + nokta yuvayı gösterir. E/W yüzeyleri gövde dışında, N/S eksenin solu/sağı.
  Durumlar `g.pp2d-slot[data-slot][data-state=empty|occupied|mine|ok|blocked|dim]`; vurgu varken listede olmayanlar soluk (`dim`); yalnız `ok` nabız atar (reduced-motion'da sabit).
  Tıklama `click` (fare+dokunma) + klavye (Enter/Boşluk); fırlatma sırasında tıklama yok. focusSlot = kısa beyaz çerçeve + etiket (yakınlaştırma yok). playLaunch 3.0–3.8 sn, hep resolve
  (dispose/setFrame keser); bitince son poz kalır, aynı gövdeyle setFrame rampaya sıfırlar. `slotScreenPos` viewport koordinatı (mouse.click'e doğrudan). Çizimler tek yerde: `PART_ART` (model→SVG),
  PNG için `PART_IMAGES[model]` / `FRAME_IMAGES[frameId]` tablolarına URL yazmak yeter. Dev: `/scene2d-dev.html` (gerçek frames.json'dan gövde kopyası gömülü).
  Doğrulama: Playwright, 3 gövde × (1256×576, 366×608, 360×380 kap): çakışma 0, tüm hücreler ≥ 42px ve kap içinde, clickSlot + gerçek fare/dokunma tıklaması tüm yuvalarda doğru geri çağrı, 8 sonuç resolve, konsol hatası 0.
  Bilinen: kap çok küçükse (≈ <300px yükseklik, 21 yuva) hücre 40px'in altına iner; `.slot-tag` (3B'deki kalıcı ad etiketleri) yok — adlar hover/dokunma etiketinde ve #slot-list'te.

### Modül W: İstemci arayüzü (sakin tasarım)
- [x] Durum: tamam
- **Sahip dosya(lar):** `public/index.html`, `public/styles.css`, `public/client.js`
- **Bağımlılık:** Modül V'nin yukarıdaki arayüzü (paralel yazılır; dosyası hazır değilse sahte ile dene).
- **Atanan agent:** gelistirici
- **Notlar:** Three importmap kalktı; `import('/scene2d.js')` (kap `#scene3d`). Tüm korunacak seçiciler, URL parametreleri, pp-state/pp-error, oturum/rejoin aynen. innerHTML yok; süsler inline SVG/CSS.
  **Düzen:** JS `<html>`'e yazar: `data-layout="wide|split|stack"` (≥1100×560 üç sütun; ≥440 iki sütun, roket solda yapışkan; dar → tek sütun), `data-phase`, `data-rolekind`, `data-myrole` (rol rengi `--me`),
  `data-picked="1"`, `data-scene="none"`, `data-drawer`; embed'de `data-pp-phase/role` aynen ve odadayken iç üst çubuk gizli. Telefonda parça seçiliyken roket (30svh) + seçili parça çubuğu yapışkan, `#slot-list` hemen altında (A1).
  **Yeni seçiciler:** giriş `#card-create #card-join #demo-link[href=/demo.html]` (kart `aria-expanded`), formlar `#entry-form #form-create #form-join` (gizli; karta basınca açılır, `#name-input` açık forma taşınır),
  `#screen-entry[data-form]`; `#help-btn #help-panel #help-close`; çekmece `button[data-drawer="log|parts|catalog"]` (şeritte `#drawer-bar`) → `#drawer #drawer-title #drawer-close #drawer-scrim [data-drawer-sec]`;
  yönetici `#last-log`, `#dir-actions #center-timer-host` (yönetici geniş/iki sütunda `#timer` buraya taşınır), `#g-payload`, `#g-computer` (yalnız arıza olayında); alt satır `#app-foot #foot-phase #foot-crew .crew-dot[data-r][data-connected]`;
  `#conn-text`; `#restart-wait`; `#result-more` (ayrıntılar `<details>`); katalog `button.pick[data-avail="ok|noslot|full|limit|placed|locked"]`; `#slot-list li[data-ok]`; `#lobby-note`; `#picked-icon #picked-sub`.
  **Değişen/yer değiştiren:** `#head-code`/`#head-role` artık alt durum satırında (boşken "—"); `#room-info` lobide; `#gauges` öğeleri sabit `li#g-twr/#g-deltav/#g-power/#g-heat/#g-payload[data-check][data-ok]` (yerinde güncellenir);
  `#budget-box` sol sütunda; `#poll-box` `#poll-controls` dışında, ankette oyun gövdesi gizlenir ve tek kart görünür; `#feed #others #log-box #build-box #telemetry-box #director-catalog` çekmecede (DOM'da hep var);
  `#mine-panel` geniş düzende sağ sütunda. **Kalkanlar:** `#phase-track`, `#tabs`/`[data-tab-btn]`/`[data-tab]`, `#scene-title`, `#catalog-details`, `#launch-sequence` yalnız tek satır gösterir, `.crew-vote`, oyunda `#player-list` (yalnız lobide).
  Kart numaraları CSS `attr(data-num)` ile çizilir (innerText'te rakam yok); çalışan ekranında sayaç dışında rakam yok (ölçüldü). A5: limit dolu + bende takılı → "TAKILDI"; yer yok / limit / boş yuva yok ayrı.
  **Doğrulama:** gerçek sunucu (3200, PP_EVENTS=none), 4 sayfa tam tur ×3 (Ay/Mars/Asteroit rastgele geldi; yerleşimlerin yarısı sahneye gerçek fare tıklamasıyla), başarı → yeni tur → setup, yenilemede rejoin; scene2d.js engelliyken liste ile tam tur;
  1366×768, 390×844, 768×1024, 360×740'ta her ekran — yatay taşma 0, konsol hatası/uyarısı 0; demo 2×2 (iframe 667×284) ve "Yönetici büyük" düzgün, iframe içi sahne tıklaması doğru; `npm test` 144/144.
  **Bilinen eksikler:** demo 2×2'de paneller çok kısa (≈284px) — roket küçük, içerik kaydırılır (sunumda Büyüt önerilir); yönetici geniş düzende roket alanı ~300px (sayaç/eylemler altında); e2e betikleri (`test/e2e/stage5*`) eski seçicileri bekliyor (`#tabs`, giriş formunun açık olması vb.) — test ajanı güncellemeli.

### Modül X: Demo sayfası görünümü
- [x] Durum: tamam
- **Sahip dosya(lar):** `public/demo.html`, `public/demo.js`
- **Atanan agent:** gelistirici
- **Notlar:** Stil demo.html içinde (styles.css'e bağlı değil). Üst çubuk 2 ince satır (~108px): `#demo-home`, başlık, oda kodu, Sıfırla, ana "Demo odası kur"; alt satır rol çipleri (checkbox), var olan oda (`#demo-join-btn` metni artık "Katıl"), yerleşim segmenti. Panel başlığı 30px, çerçeve rol renginde, köşe çentikli.
  Ek: oda yokken `body.is-idle` → paneller gizli, ortada `#demo-empty` açıklama kartı + `#demo-empty-start` (aynı `start('create')`). Tüm eski seçiciler/URL/postMessage aynen. Playwright 1366×768 + 1920×1080: kurulum→4 panel setup, yerleşim/odak/sıfırla/yanlış kod hatası OK, konsol hatası 0.

## Paralel dağıtım (Aşama 6)
- **Grup 1 (paralel):** Modül V, W, X

## Test-düzelt turları — Aşama 6 (en fazla 3)
- [ ] Tur 1
- [ ] Tur 2
- [ ] Tur 3

## Son durum — Aşama 6 (şef doldurur)
- **Çalışanlar:** V, W, X geliştirici testleriyle tamam (tam tur, telefon, demo, sahnesiz yol). Tur 1 testci kullanım sınırında yarıda kaldı.
- **Kalanlar:** Kullanıcı yeni ana kapsam verdi (Aşama 7: iki görev, Stitch tasarımı, sohbet). Aşama 6 arayüzü Stitch tasarımıyla değişeceği için ayrı test turu yapılmadı.

---

# AŞAMA 7 — İki görevli mühendislik oyunu (ANA KAPSAM)  ← ŞU AN

Kaynak: kullanıcının "PIXEL PAYLOAD — MASTER DEVELOPMENT PROMPT" metni + ekleri. Özet ve bağlayıcı kararlar:
- **Yalnız iki görev:** `lunar` (insanlı Ay: kalkış → Ay → iniş → yüzey → dönüş → kurtarma; Artemis esinli) ve `mars` (Perseverance esinli gezgin: kalkış → seyir → EDL → iniş → gezgin → bilim → veri iletimi). Asteroit ve diğerleri SİLİNİR.
- **Roller (id'ler aynı kalır):** `director` = Operatör, `rocket` = İtki Mühendisi, `spacecraft` = Uzay Aracı Mühendisi, `payload` = Bilim & Faydalı Yük Mühendisi.
- **Asimetrik bilgi (yeni hali):** Operatör küresel hedefleri, tüm telemetriyi, birleşik hazırlık raporunu görür. Her mühendis YALNIZ kendi sistemlerinin sayılarını ve gereksinimlerini görür.
  Mühendisler arası bağımlılık değerleri ("ihtiyaçlar": ör. itki mühendisinin bilmesi gereken toplam faydalı yük kütlesi) mühendise ETİKET olarak gider, DEĞERİ yalnız operatöre gider → operatör aktarır.
- **Bağlılık ("birinin sorunu diğerine vursun"):** hazırlık kalemleri zincirlidir (güç açığı → iletişim + bilim + yaşam desteği; ısı → batarya; kütle fazlası → itki Δv; iletişim hızı < bilim verisi → bilim puanı). Zincirle başka rolü etkileyen kalem o rolde `cascadeFrom` ile görünür (sayısız metin).
- **Metin sohbeti (zorunlu, sunucuda yetkili):** mühendis ↔ operatör özel; operatör → tüm mühendisler yayını; mühendis ↔ mühendis ve mühendis → herkes YASAK.
- **Rastgele olay yok;** simülasyon olayları yapılandırmadan ve tohumlu güvenilirlikten doğar. Eski geri alma/tedarikçi/hava olayları KALKAR.
- **Oda/host:** odayı kuran HOST'tur (kendi bilgisayarında `baslat.bat` çalışır, diğerleri aynı Wi-Fi'den katılır; merkezi sunucu kurulmaz). Host yönetimi: hazır durumu, başlatma, oyuncu çıkarma, host devri; lobide LAN katılım adresi gösterilir.
- **Her sayfada GERİ düğmesi; sonuçta TEKRAR OYNA.**
- **Arayüz:** kullanıcı Google Stitch tasarımını AYRICA verecek (20 ekran). Arayüz modülleri tasarım gelince dağıtılır. Mevcut 2B sahne korunur (3B yok).
- **İş akışı (kullanıcı şartı, jeton tasarrufu):** önce TÜM geliştirme + entegrasyon; geliştirme sırasında tekrar tekrar `npm test`/Playwright koşturulmaz, testci çağrılmaz.
  Geliştirici yalnız kendi yeni modülünün birim testlerini bir kez (bitince) çalıştırır. En sonda TEK kapsamlı testci turu, sonra en çok 3 düzelt-doğrula turu.
- Eski Aşama 1–6 sunucu mantığı (`layout.js`, `launch.js`, `scoring.js`, `physics.js`, `data/*.json`, eski testler) `arsiv/asama6/` altına taşınır; yeni modüller yerini alır.

## Yeni akış (sunucu fazları)
`lobby` → `mission-select` → `briefing` → `design` → `review` → `simulation` → `debrief` → (TEKRAR OYNA) `mission-select` | (AYNI GÖREV) `design`
- `lobby`: 4 rol seçilir, herkes "Hazır" der; host "Başlat"a basar (4 rol dolu + 4 hazır şart).
- `mission-select`: operatör iki görevden birini seçer (herkes iki görev kartını görür; ayrıntılı hedefler yalnız operatörde).
- `briefing`: her rol kendi brifingini okur ve "Anladım" der; 4'ü de anlayınca `design` (operatör bekleyenleri atlatabilir).
- `design`: mühendisler kendi ekipmanlarını takar/çıkarır ve ayarlarını yapar; operatör izler, `review`'u açar. Süre sayılır (puan için; zorla bitirmez).
- `review`: hazırlık raporu (PASS/WARN/FAIL). Her mühendis kendi sistemini "ONAY" ya da "DÜZELT" işaretler. Kritik FAIL varken fırlatma YOK.
  3 onay + kritik FAIL yok → operatör "FIRLAT". Operatör veya "DÜZELT" diyen mühendis → `design`'a geri.
- `simulation`: sunucu görevin aşamalarını sırayla oynatır (aşama başı `PP_PHASE_MS`, varsayılan 3500 ms); her aşama ok/warn/fail + olaylar. Fail → durur.
- `debrief`: sonuç (success | partial | failure), puan ve döküm. "TEKRAR OYNA" (host veya operatör).
- GERİ (sunucu fazında): `briefing → mission-select` (operatör), `review → design` (operatör), `debrief → mission-select`. Sunucu fazı olmayan sayfalarda (oda kur/katıl, nasıl oynanır, ayarlar) geri istemci içidir.

## Veri (`data/`) — tek kanonik kaynak, istemcide kopyası YOK
### `data/science/sources.json`
`[{ "id": "nasa-orion", "title": "...", "publisher": "NASA", "url": "https://...", "accessed": "2026-11-15" }]`
### `data/physics/constants.json`
`{ "g0": {...}, "earth": { "muM3s2", "radiusM", "surfaceGravity" }, "moon": {...}, "mars": { ..., "atmosphere": { "surfaceDensityKgM3", "scaleHeightM" } },
   "lightSpeedMs", "distances": { "earthMoonM", "earthMarsMinM", "earthMarsMaxM" } }` — her değer `{ "v": 9.80665, "unit": "m/s2", "src": "<sources id>", "class": "measured|derived|estimated|game" }` biçiminde.
### `data/equipment/<lunar|mars|shared>.json` → `{ "items": [Item] }`
```json
{ "id": "rs25-core", "name": "RS-25 esinli ana motor kümesi", "category": "main-engine", "role": "rocket", "module": "launch-vehicle",
  "missions": ["lunar"], "icon": "engine", "desc": "sayısız kısa açıklama",
  "massKg": 0, "cost": 0, "powerW": 0, "powerGenW": 0, "batteryWh": 0, "thrustN": 0, "ispS": 0, "propellantKg": 0,
  "dataRateBps": 0, "dataGenMbPerSol": 0, "scienceValue": 0, "reliability": 0.99, "tempRangeC": [-40, 50],
  "provides": ["main-propulsion"], "requires": ["propellant-lox-lh2"], "incompatibleWith": [{ "tag": "x", "reason": "bilimsel gerekçe" }], "tags": [],
  "lifeSupport": { "o2Kg": 0, "waterKg": 0, "co2ScrubPersonDays": 0 }, "edl": { "maxHeatFluxWcm2": 0, "dragArea": 0, "maxMach": 0 },
  "refs": { "massKg": { "src": "nasa-...", "class": "measured", "note": "" } } }
```
- Alanlar isteğe bağlı (gerekeni yaz). Sayılar SI (kg, N, s, W, Wh, bps). `cost` = oyun birimi (milyon $ esinli, `class: game`). Her önemli sayının `refs` kaydı olur; NASA'da yoksa `class: "estimated"` ya da `"game"` ve not.
- `module`: görevin araç modülü (aşağıda). `role`: kimin kataloğunda. Her parça yalnız tek rolün.
### `data/missions/<lunar|mars>.json`
```json
{ "id": "lunar", "name": "İnsanlı Ay Görevi", "summary": "herkese açık kısa metin", "educationalNote": "basitleştirilmiş eğitsel senaryo; gerçek uçuş modeli değildir",
  "budget": 0, "crew": 4, "durationDays": 0,
  "modules": [{ "id": "launch-vehicle", "name": "Fırlatma aracı", "role": "rocket",
                "categories": [{ "category": "main-engine", "min": 1, "max": 2 }] }],
  "phases": [{ "id": "launch", "name": "Kalkış", "dvMs": 0, "dvFrom": "launch-vehicle", "checks": ["twr", "dv-launch"] }],
  "objectives": [{ "id": "crew-return", "name": "Mürettebatı güvenle döndür", "type": "primary|secondary|science", "critical": true }],
  "briefing": { "director": ["..."], "rocket": ["kendi gereksinimleri, sayılarıyla"], "spacecraft": ["..."], "payload": ["..."] },
  "settings": [{ "key": "propellantLoad", "role": "rocket", "label": "...", "type": "number", "min": 0.6, "max": 1, "step": 0.05, "default": 1, "unit": "" }],
  "limits": { "maxLaunchMassKg": 0, "minTWR": 1.2, "landingMaxVms": 0, "...": 0 },
  "nasaReality": "Gerçekte NASA bunu şöyle yapıyor: ...", "refs": { "...": { "src": "...", "class": "..." } } }
```
- Ayar anahtarları SABİT: `propellantLoad` (rocket, 0.6–1), `consumableMarginDays` (spacecraft, lunar; 0–10), `powerMode` (spacecraft, `eco|normal|max`), `instrumentMode` (payload, `survey|balanced|intensive`).
- Görev başına modül önerisi: lunar → `launch-vehicle` (rocket), `crew-vehicle` (spacecraft: kapsül + servis modülü + ECLSS), `lander` (inişi/çıkışı rocket; sensörler/güç/erişim spacecraft), `surface-kit` (payload: bilim + EVA).
  mars → `launch-vehicle` (rocket), `cruise-stage` (rocket itki + spacecraft güç/iletişim), `edl` (spacecraft: aeroshell, ısı kalkanı, paraşüt, radar; iniş itkisi rocket), `rover` (spacecraft: şasi, tekerlek, güç, iletişim, bilgisayar; payload: aletler).
- Kapsam: Ana prompt §7.3–7.6 ve §8.3–8.8'deki TÜM bileşen listeleri (her listeden en az bir, tercihen 2–3 seçenekli). MOXIE isteğe bağlı. Her görev ≥ 2 farklı geçerli çözüm; açgözlü "hepsini al" bütçe/kütle nedeniyle başarısız.

## Simülasyon (`server/sim/`) — saf, durumsuz, sunucu yetkili
`module.exports = { createSim }` (`server/sim/index.js`); `createSim({ dataDir })` (varsayılan `data/`) veya `createSim({ equipment, missions, constants, sources })` (test için) →
- `listMissions()` → `[{ id, name, summary, educationalNote }]`
- `getMission(id)` → tam görev nesnesi | undefined
- `getItem(id)`; `catalogFor(missionId, role)` → o rolün tam parçaları (sayılı); `publicItem(itemId)` → `{ id, name, category, role, module, icon, desc }` (SAYISIZ)
- `canAdd(build, missionId, role, itemId, moduleId)` → `{ ok: true }` | `{ ok: false, error, reason }`; `error`: `INVALID_ITEM | NOT_ALLOWED (başka rolün) | WRONG_MISSION | WRONG_MODULE | CATEGORY_FULL | DUPLICATE | INCOMPATIBLE (reason = gerekçe) | MISSING_REQUIREMENT`. (`requires` eksikliği takarken engel DEĞİL, hazırlıkta FAIL/WARN.)
- `defaultSettings(missionId)`; `validateSetting(missionId, role, key, value)` → `{ ok, value }` | `{ ok:false, error:'BAD_SETTING' }`
- `evaluate(missionId, build, settings)` → `Evaluation`:
```js
{ telemetry: { massKg: { total, byModule:{}, byRole:{} }, cost, budget,
               twr, stages: [{ id, dvMs }], dv: { [phaseId]: { available, required } },
               power: { genW, useW, batteryWh, marginW }, thermal: { status, note },
               comms: { relayBps, directBps, delayS, dataMbPerSol, downlinkMbPerSol },
               lifeSupport: { crew, days, o2Days, waterDays, co2Days } | null,
               edl: { entryMs, peakHeatWcm2, shieldMaxWcm2, chuteMach, landingVms, hazard } | null,
               science: { value, max, instruments: n } },
  readiness: [{ id, system, role, status: 'PASS'|'WARN'|'FAIL', critical: bool, text, value?, limit?, unit?, cascadeFrom?: [role] }],
  overall: 'PASS'|'WARN'|'FAIL',
  needs: { rocket: [{ id, label, value, unit, fromRole }], spacecraft: [...], payload: [...] },   // mühendise yalnız label+fromRole gider
  unmetRequirements: [{ itemId, requires, text }] }
```
  `text` alanları Türkçe; operatöre/kendi rolüne sayı içerebilir. Zincirli kalemler: kaynak role ait kalem + etkilenen role ait ayrı kalem (`cascadeFrom: [kaynak]`, metni SAYISIZ: "Güç açığı nedeniyle iletişim kısıtlı").
  Kontroller (§12): itki, araç kütlesi, yakıt, aşama aşama Δv, TWR, güç, ısı, iletişim, navigasyon, faydalı yük uyumu, görev özel (lunar: yaşam desteği, iniş/çıkış Δv, EVA; mars: EDL, iniş hızı, gezgin enerji dengesi, iletişim pencereleri), bütçe.
- `simulate(missionId, build, settings, seed)` → `{ phases: [{ id, name, status: 'ok'|'warn'|'fail', events: [{ id, severity: 'info'|'warn'|'critical', text, roles: [] }], note }],
   outcome: 'success'|'partial'|'failure', reason, objectives: [{ id, name, done }], landing?: { ok }, science?: { score } }` — deterministik (aynı seed → aynı sonuç);
  olasılıklar yalnız güvenilirlik ve marjlardan; Mars'ta iniş başarısı ile bilim başarısı ayrı; Ay'da mürettebat güvenliği kritik.
- `debrief(missionId, evaluation, simResult, team)` (`team = { designSec, reviewRounds, chat: { [role]: n }, signoffs }`) →
  `{ score, stars (0–3), outcome, sections: [{ id: 'objectives'|'engineering'|'fuel'|'power'|'comms'|'science'|'budget'|'events'|'failed'|'team', title, score, max, lines: [] }], lessons: [] , nasaReality, sources: [{ title, url }] }`
- Fizik yardımcıları (`server/sim/physics.js`): Tsiolkovsky (kademeli), TWR, yerçekimi, yörünge/kaçış hızı, ışık gecikmesi, basit atmosfer (üstel), EDL ısı akısı (Sutton-Graves tipi basit), güç/enerji dengesi. Hepsi "basitleştirilmiş eğitsel model" olarak etiketli.

## Sohbet (`server/chat.js`) — saf
`createChat({ now, maxLen = 300, rate = { count: 5, perMs: 5000 }, historyLimit = 200 })` →
- `send(room, senderPlayerId, { to, text })` → `{ ok: true, message, recipients: [playerId] }` | `{ ok: false, error }`.
  `to`: mühendis için YALNIZ `'director'`; operatör için `'rocket'|'spacecraft'|'payload'|'engineers'`. Hatalar: `NOT_IN_ROOM | NO_ROLE | FORBIDDEN | BAD_TARGET | EMPTY | TOO_LONG | RATE_LIMIT | TARGET_EMPTY` (hedef rol boşsa).
  Gönderici rolü ve odası SUNUCU durumundan alınır, istemciden gelmez. Metin trim, kontrol karakterleri temizlenir.
  `message = { id, ts, thread: 'rocket'|'spacecraft'|'payload'|'broadcast', from: role, fromName, text }`; `room.chat = { threads: { rocket: [], spacecraft: [], payload: [], broadcast: [] }, rate: {} }` (rate kaydı playerId başına; görünümde gitmez).
- `viewFor(room, playerId)` → operatör: `{ threads: { rocket, spacecraft, payload, broadcast } }`; mühendis: `{ threads: { mine: room.chat.threads[role], broadcast } }`; rolsüz: `null`.
- `reset(room)` (yeni oyunda sohbet KORUNUR; yalnız oda kapanınca silinir — ayrı reset gerekmez ama fonksiyon olsun).

## Oda mantığı + görünüm (`server/rooms.js`, `server/filter.js`, `server/constants.js`)
`createRoomManager({ sim, chat, now, rng, config })` — `tick(code)` ile simülasyon aşamalarını ilerletir (zamanlayıcı yok). `config = { phaseMs, reconnectGraceMs, emptyRoomMs }`.
- Oda: `{ code, hostId, players: Map<playerId,{ id, name, role, ready, connected, socketId, lastSeen }>, phase, missionId, build: [{ uid, itemId, moduleId, role }], settings, briefingAck: Set<role>,
  signoff: { rocket: null|'ok'|'fix', ... }, reviewRounds, designStartedAt, sim: { result, shownPhases, nextAt, seed } | null, debrief, chat, log: [{ ts, kind, role, text }] }`.
- Yöntemler: `createRoom, joinRoom, rejoin(code, playerId, socketId), selectRole, setReady, kick(code, hostId, seat), transferHost(code, hostId, seat), startGame (host), selectMission (director),
  ackBriefing, skipBriefing (director), addItem(code, pid, itemId, moduleId), removeItem(code, pid, uid), setSetting(code, pid, key, value), openReview (director), signoff(code, pid, 'ok'|'fix'),
  backToDesign (director), launch (director), goBack(code, pid) (fazına göre), playAgain(code, pid, 'new'|'same'), leave, setConnected, tick`.
- Kurallar: host ayrılırsa host bağlı ilk oyuncuya geçer; oyun ortasında kopan oyuncunun rolü `reconnectGraceMs` (varsayılan 120 sn) korunur; boş oda `emptyRoomMs` sonra silinir.
  Lobi dışında yeni katılan oyuncu boş rol varsa alır, yoksa `ROOM_FULL`. Tüm durum değişiklikleri faz + rol + üyelik doğrulamalı. Her hata `GameError(code, Türkçe mesaj)`.
- `viewFor(room, playerId, sim, chat)` (filter.js, beyaz liste): herkese `phase, code, me: { seat, name, role, isHost }, players: [{ seat, name, role, ready, connected, isHost }], missionOptions` (lobi/seçim),
  `mission: { id, name, summary }`, `vehicle: [{ uid, moduleId, item: publicItem, role, mine }]` (ortak 2B araç), `overall` (hazırlık ışığı), `signoff`, `simulation: { phases: gösterilenler }`, `chat: chat.viewFor`.
  Operatöre ek: tam görev (hedefler, limitler, bütçe, brifing.director), tam telemetri, tüm hazırlık kalemleri, `needs` (değerli), ekip ilerlemesi (rol başına parça sayısı, eksik kategori), tam katalog (salt okunur), sonuç.
  Mühendise ek: kendi brifingi (sayılı), kendi kataloğu (sayılı, her parça için `canAdd` sonucu + gerekçe), kendi ayarları, kendi rolünün hazırlık kalemleri + `cascadeFrom`'lu kalemler, `needs[role]` yalnız `{ id, label, fromRole }`,
  kendi alt sistem telemetrisi (rocket: kütle/TWR/Δv/yakıt; spacecraft: güç/ısı/iletişim/yaşam desteği/EDL; payload: bilim değeri, alet kütle+güç toplamı, veri üretimi).
  Mühendise ASLA: başka rolün sayıları, bütçe/maliyet, operatörün hedef listesi, `needs` değerleri, başka mühendislerin sohbeti. `debrief` fazında herkes tam sonucu görür.

## Socket olayları (`server/index.js`)
`room:create {name}`, `room:join {code,name}`, `room:rejoin {code,playerId}`, `room:leave`, `role:select {role}`, `player:ready {ready}`, `host:start`, `host:kick {seat}`, `host:transfer {seat}`,
`mission:select {missionId}`, `briefing:ack`, `briefing:skip`, `equip:add {itemId,moduleId}`, `equip:remove {uid}`, `setting:set {key,value}`, `review:open`, `review:signoff {decision}`,
`review:back`, `mission:launch`, `phase:back`, `game:again {mode:'new'|'same'}`, `chat:send {to,text}`. Hepsi ack `{ ok:true }` | `{ ok:false, error, message }`.
Sunucu → istemci: `state` (kişiye özel `viewFor`), `chat:message` (yalnız alıcılara + gönderene; mesaj nesnesi), `room:closed`, `kicked`.
`GET /api/info` → `{ lanUrls: ["http://192.168.x.x:3000"] }` (lobide katılım adresi). Ortam: `PORT, PP_PHASE_MS, PP_GRACE_MS`.

## Modüller (Aşama 7) — Grup 1 (paralel, arayüz bekleme)

### Modül Y: Bilimsel veri + ekipman veritabanı
- [x] Durum: tamam
- **Sahip dosya(lar):** `data/equipment/*.json`, `data/missions/*.json`, `data/science/sources.json`, `data/physics/constants.json`, `docs/VERI_KAYNAKLARI.md`
- **Bağımlılık:** yok (Grup 2'de Z'nin `evaluate`'iyle dengeleme yapar).
- **Atanan agent:** gelistirici
- **Notlar:** lunar 65 parça, mars 57 parça (122 tekil id), 24 kaynak, 6 iki yönlü uyumsuzluk kuralı. Ayrıntı + kaba hesaplar: `docs/VERI_KAYNAKLARI.md`.
  **Z için alan kuralları:** `massKg` = yakıt HARİÇ kütle (O2/su gibi sarflar dahil); `thrustN` vakum, `thrustSlN`/`ispSlS` deniz seviyesi; `launch-vehicle` parçalarında `stage` 1/2/3 → seri kademeli Tsiolkovsky önerilir. Aşamalarda `carries` (itilen modüller) + `excludeTags` (`jettison-after-launch` = LAS, `jettison-before-powered-descent` = kabuk/kalkan/paraşüt) — bunlar YOK SAYILIRSA Ay'da iniş aracı fırlatma yüküne, Mars'ta kabuk motorlu inişe eklenir ve dengeler bozulur. Ay iniş aracı ayrı fırlatılır (launch `carries` yalnız launch-vehicle + crew-vehicle).
  Eklenen isteğe bağlı alanlar: parça `stage, thrustSlN, ispSlS, dutyCycle (ort. güç = powerW×dutyCycle), heatRejectW, heatW, crewCapacity, maxMissionDays, maxLandingVms, evaHours, evaHoursBonus, maxEntryMassKg, maxPayloadKg, instrumentCapacityKg, linkSecPerSol`; görev `surfaceCrew, surfaceSols`, karışık rollü modülde `roles` + kategori `role`, aşama `carries/excludeTags`, ayar `type:'enum'` + `options` + `optionInfo` (önerilen çarpanlar) + `help`.
  **Aday çözümler (kaba el hesabı):** Ay A = SRB5+4×RS-25+ICPS, Orion+ESM+amin ECLSS, LOX/LH2 iniş aracı, AxEMU (4.147/4.300); Ay B = 3×RS-25, hafif kapsül+LiOH+pasif ısı, metan/LOX iniş aracı, hafif giysi+yedekler (3.410). Mars A = 4 SRB+RD-180 sınıfı+Centaur, MMRTG, 6 alet (1.009/1.100); Mars B = 2 SRB, hafif şasi+güneş paneli+büyük batarya, 4 alet (776). Açgözlü: Ay 4.820 (bütçe aşımı), Mars 1.157 + alet yuvası 91,8/45 kg.
  **Doğrulanamayan (estimated):** ESM yakıt/itki, Orion/LAS kütleleri, güneş dizisi gücü, ICPS/EUS kütleleri, tüm HLS esinli iniş aracı değerleri, AxEMU, CO2 1,04 ve su 2,5 kg/kişi-gün, Atlas V değerleri, Mars 2020 kademe kütleleri, ısı kalkanı akı sınırları, Δv bütçeleri. Maliyet/bilim/güvenilirlik `game`.

### Modül Z: Simülasyon + fizik + hazırlık + debrief
- [x] Durum: tamam
- **Sahip dosya(lar):** `server/sim/*.js`, `test/sim/*.test.js`, `test/fixtures/*`
- **Bağımlılık:** yukarıdaki veri şeması (gerçek veri gelmeden fixture ile yazılır).
- **Atanan agent:** gelistirici
- **Notlar:**
  - Dosyalar: `server/sim/{index,loader,evaluate,simulate,debrief,physics,util}.js`; testler `test/sim/{physics,catalog,evaluate,simulate,debrief,realdata}.test.js` (37 test: 36 geçti + 1 todo); fixture `test/fixtures/mini.js` (küçük iki görev), `test/fixtures/solutions.js` (Y'nin Ay A/B, Mars A/B adayları). İmzalar PLAN'la birebir; hiçbir yöntem istisna atmaz (iç hata → `{ok:false,error}`).
  - **İsteğe bağlı ekler:** telemetri `massKg.launch`, `power.buses[]` (bara başına; üst düzey power = bilim aletlerinin barası), `landing{vms,maxVms,hazard,sensor}`, `propellant{loadedKg,remainingKg,load}`, `eva{hours,min}`, `model`; simulate `seed`, `model`, `science.done`; debrief `reason`, `model`; hata dönüşlerinde `ok:false,error`. `canAdd` `MISSING_REQUIREMENT` döndürmez (gereksinim hazırlıkta `req-<itemId>` FAIL + parça devre dışı).
  - **overall:** FAIL yalnız kritik FAIL varsa; kritik olmayan FAIL/WARN → WARN (rooms `overall==='FAIL'` ile fırlatmayı keser).
  - **Desteklenen veri alanları (Y):** `stage` (seri kademe; kalkış TWR = kademe ≤2 `thrustSlN` toplamı / (kalkış yığını × g0)), `carries`/`stack`, `excludeTags` (kalıcı atma), aşama `stage` (yalnız o kademeyi yak), `kind` (aşama türü; yoksa id'den), `dutyCycle`, `heatRejectW`/`heatW`, `linkSecPerSol`, `crewCapacity`, `maxMissionDays`, `maxLandingVms`, `evaHours(+Bonus)`, `maxEntryMassKg`, `maxPayloadKg`, `instrumentCapacityKg`, ayar `optionInfo` (useFactor/dutyFactor/scienceFactor/dataFactor). Sınır takma adları: `minLanderTWR|minDescentTWR`, `o2PerCrewDayKg`, `waterPerCrewDayKg`, `entryVelocityMs`, `entryFlightPathDeg`, `chuteDeployMach`, `maxChuteMach`, `solarDustFactor`, `minScience`, `minEvaHours`, `maxLanderMassKg`, `minDvMarginPct`; isteğe bağlı `massAllotmentKg{spacecraft,payload}`, `powerBuses`, `terrainHazard`, `touchdownVms`, `commsDistanceM`, `crewModule`.
  - **Model varsayımları (eğitsel):** `propellantLoad` yalnız rocket rolündeki yakıta uygulanır; sarf kütlesi parça kütlesinde (ek kütle yok), mürettebat kütlesi 0; yaşam desteği kapasitesi yalnız mürettebat modülünden (gün < süre → kritik FAIL, < süre+yedek → WARN). Güç baraları: üretim kategorisi olan her modül bir bara, diğerleri önceki baraya bağlanır (Ay: kabin / iniş aracı+kit; Mars: seyir / gezgin). Isı: kontrol varken iç ortam 0…30 °C, ısı sorunu bataryayı ×0,7. İletişim yalnız birincil barada (yüzey/gezgin). EDL: Allen-Eggers + Sutton-Graves, paraşüt Mach veriden, motorlu iniş Δv = max(veri, paraşüt hızı + g·15 s); temas hızı = gereken Δv açığı + yarım sınır. İniş/çıkış TWR yanma başındaki kütleyle. Arazi tehlikesi 0,15 × radar 0,3 × TRN 0,5. Sim: risk = (1−Πgüvenilirlik)·0,5 + WARN 0,04/kalem; Mars'ta iniş sonrası kritik hata → partial; Ay'da kritik hata → failure.
  - **Gerçek veriyle sonuç:** Ay B (3.405, TWR 1,47, kritik FAIL yok, sim success), Mars A (1.017, TWR 2,04, PASS), Mars B (776, TWR 1,69, WARN: güç marjı dar) geçer; açgözlü Ay (EUS+XL servis) bütçeyle, açgözlü Mars (MOXIE+önbellek) alet yuvasıyla kalır; Ay B doluluk 0,85'te Δv FAIL. **Ay A KALIYOR:** `ld-eng-hydrolox` 44,5 kN, iniş başında ~32,5 t × 1,62 → TWR 0,85 < `minLanderTWR` 1,5 (Y'nin el hesabında iniş TWR'si yok). Y için öneri: hidrolox motor itkisini ≥ ~80 kN yapmak (ya da 2 motor) veya sınırı düşürmek. Test `todo` olarak işaretli.

### Modül AB: Sohbet yetkileri
- [x] Durum: tamam
- **Sahip dosya(lar):** `server/chat.js`, `test/chat.test.js`
- **Atanan agent:** gelistirici
- **Notlar:** 14 test geçti. `room.chat` yoksa `send/viewFor` kendisi başlatır. Bilinen ama izinsiz hedef (`director/rocket/.../engineers/all/everyone/broadcast`) → FORBIDDEN, bilinmeyen/string olmayan → BAD_TARGET. Hata sırası: NOT_IN_ROOM → NO_ROLE → BAD_TARGET/FORBIDDEN → EMPTY/TOO_LONG → TARGET_EMPTY → RATE_LIMIT (yalnız kabul edilen mesajlar sayılır). `\t\n\r` boşluğa çevrilir. `message.id` sayaç (number). Uzunluk kod noktası ile. Yayında hiç mühendis yoksa TARGET_EMPTY.

### Modül AA: Oda/host/akış + görünüm filtresi + socket bağlama
- [x] Durum: tamam
- **Sahip dosya(lar):** `server/rooms.js`, `server/filter.js`, `server/constants.js`, `server/index.js`, `test/rooms.test.js`, `test/filter.test.js`; eski sunucu dosyalarını ve testleri `arsiv/asama6/`ya taşır (`server/layout.js, launch.js, scoring.js, physics.js`, `data/frames.json, parts.json, missions.json`, `test/*.test.js` eskiler, `test/e2e/*`).
- **Bağımlılık:** Z ve AB arayüzleri (sahte sim/chat ile yazılır).
- **Atanan agent:** gelistirici
- **Notlar:**
  - **`state` görünümü (herkes):** `phase, code, me:{seat,name,role,isHost}, players:[{seat,name,role,ready,connected,isHost}]` (koltuk sırası),
    `missionOptions:[{id,name,summary,educationalNote}]` (yalnız lobby/mission-select; diğer fazlarda []), `mission:{id,name,summary,educationalNote}|null`,
    `vehicle:[{uid,moduleId,item:{id,name,category,role,module,icon,desc},role,mine}]`, `overall:'PASS'|'WARN'|'FAIL'|null`, `signoff:{rocket,spacecraft,payload}` (null|'ok'),
    `briefing:{acked:[role]}`, `review:{rounds}`, `design:{startedAt|null, elapsedMs}` (elapsedMs = önceki tasarım turlarının toplamı),
    `simulation:{phases:[{id,name,status,note,events:[{id,severity,text,roles}]}], phaseMs}|null` (yalnız açılan aşamalar; debrief'te hepsi),
    `chat:{threads:{...}}|null` (operatör: rocket/spacecraft/payload/broadcast; mühendis: mine/broadcast; rolsüz null; mesaj `{id,ts,thread,from,fromName,text}`),
    `result:{debrief,simulation(tam sim sonucu),telemetry,readiness,overall,needs(değerli)}|null` (yalnız debrief fazında, herkese), `director:null|{...}`, `engineer:null|{...}`.
  - **`director`:** `missionDetails:[tam görev]` (yalnız mission-select), `mission` (tam görev; `briefing` = yalnız operatör satırları), `settings` (tüm ayarlar), `telemetry` (tam),
    `readiness` (tüm kalemler), `needs:{rocket|spacecraft|payload:[{id,label,value,unit,fromRole}]}`, `unmetRequirements`, `progress:{[rol]:{items, missingCategories:[{moduleId,category,min,have}]}}`,
    `catalog:{[rol]:[parça, sayılı, maliyetsiz]}`, `costs:{[uid]:cost}`.
  - **`engineer`:** `briefing:[string]`, `modules:[{id,name,role,categories:[{category,min,max}] (yalnız kendi kataloğundaki kategoriler)}]`,
    `catalog:[parça (sayılı, cost YOK) + canAdd:{ok,error?,reason?}|null (yalnız design fazında dolu)]`, `settingDefs:[kendi ayar tanımları]`, `settings:{key:value}` (yalnız kendi),
    `readiness` (yalnız `role===kendi`; `cascadeFrom`lu kalemde value/limit/unit atılır), `needs:[{id,label,fromRole}]`,
    `telemetry`: rocket `{massKg:{mine},twr,stages,dv,propellant:{capacityKg,load,loadedKg}}`; spacecraft `{massKg:{mine},power,thermal,comms:{relayBps,directBps,delayS,downlinkMbPerSol},lifeSupport,edl}`;
    payload `{science:{value,max,instruments},instruments:{count,massKg,powerW},dataMbPerSol}`.
  - **Ack:** `{ok:true}` (+ `room:create/join/rejoin`: `code,playerId`; `equip:add`: `uid`; `chat:send`: `message`) | `{ok:false,error,message}`. `kicked {reason}`, `room:closed {reason}`.
    `host:kick/transfer {seat}` koltuk numarası (1–4). `chat:send` sonrası `chat:message` alıcılara+gönderene, `state` yalnız onlara.
  - **Hata kodları (constants.ERRORS):** BAD_REQUEST, NAME_REQUIRED, ROOM_NOT_FOUND, NOT_IN_ROOM, ROOM_FULL, INVALID_ROLE, ROLE_TAKEN, NO_ROLE, GAME_STARTED, WRONG_PHASE,
    NOT_ALLOWED, NOT_HOST, NOT_READY, INVALID_TARGET, INVALID_MISSION, ITEM_NOT_FOUND, BAD_SETTING, LAUNCH_BLOCKED, RATE_LIMITED (socket başına 40 olay/5 sn);
    `canAdd` hataları (INVALID_ITEM, WRONG_MODULE, INCOMPATIBLE …) ve sohbet hataları (FORBIDDEN, TARGET_EMPTY …, Türkçe mesaj `CHAT_ERROR_MESSAGES`) aynen geçer.
  - **Kararlar:** başlatma = host + 4 rol + 4 hazır + 4 bağlı. Bağlantı kopunca (lobi dahil) rol `reconnectGraceMs` korunur, sonra oyuncu düşer. Host kopar/ayrılırsa bağlı ilk koltuğa geçer.
    `playAgain 'same'` → aynı görev, tasarım (build+ayarlar) KORUNUR, sayaçlar sıfır; `'new'` → her şey sıfır. `playAgain` ve debrief GERİ: host veya operatör.
    `reviewRounds` review→design dönüşlerinde artar. Son aşama açıldıktan bir `phaseMs` sonra debrief. `team.signoffs` = oyun boyunca verilen ONAY+DÜZELT sayısı.
  - **Taşınanlar (`arsiv/asama6/`):** `server/{layout,launch,scoring,physics}.js`, `data/{frames,parts,missions}.json`, `test/{launch,layout,physics,stage1..5}.test.js`, `test/e2e/`.
  - **Grup 2 eki:** `engineer.settingDefs[]` += `help` (string) ve `optionInfo:{[opt]:{label,desc?,note?,text?,help?}}` (yalnız string alanlar; useFactor/dutyFactor/scienceFactor/dataFactor gibi sayılar atılır); herkese `simulation.phaseList:[{id,name}]` (yalnız simulation/debrief fazında). filter.test.js 7/7.
  - Duman denemesi yapılmadı: `server/sim/index.js` henüz yok (sunucu bu durumda "Simülasyon modülü bulunamadı" deyip çıkış 1 veriyor). package.json'a dokunulmadı.

## Grup 2 (Grup 1 bitince)
- **Dengeleme (Y):** gerçek veriyle `evaluate/simulate` çalıştırılır; her görev ≥ 2 çözüm, açgözlü başarısız; çözümler `test/sim/solutions.test.js`'e (Z'nin dosyası; Y yalnız bu dosyayı ekler, şef sahipliği devreder).
- Dengeleme: [x] — `ld-eng-hydrolox.thrustN` 44,5 → 110,1 kN (RL10 sınıfı, `nasa-sls` ICPS RL10 24.750 lbf, measured); `limits.minLanderTWR` ref `game`. Ay A iniş TWR 2,09, dört çözüm kritik FAIL yok + sim(42) success; açgözlü Ay `budget`, Mars `instrument-capacity` ile kalır. `node --test "test/sim/*.test.js"` 48/48.
- **Arayüz:** aşağıdaki "Aşama 7 — Arayüz" bölümü (Modül AC, AD, AE; Y/Z ile paralel başlar, sunucu `state` biçimi Modül AA notlarında).
- **Belgeler:** README.md (çalıştırma, oda, roller, sohbet kuralları, görevler, ekipman, kaynaklar, varsayımlar, sınırlar).
- README: [x]

## Aşama 7 — Arayüz (Stitch görselleri: `tasarim/stitch/ekran-01..07.jpg`)
Görseller: 01 açılış (BAŞLA / GÖZLEMCİ / ÇIKIŞ, sağda Dünya + mekik), 02 gözlemci şifre katmanı, 03 bilim istasyonu (araç görünümü + alet kataloğu + seçili alet + hedefler),
04 güvenlik kontrol merkezi (durum, risk, protokol listesi, GO/NO-GO, ekip oylaması), 05 iletişim merkezi (kanal durumları, mesaj akışı, ekip kartları, koordinasyon),
06 kalkış simülasyonu (aşama listesi, telemetri, yörünge grafiği, aşama ilerlemesi, büyük durum şeridi), 07 sonuç (başlık, puan dökümü, TEKRAR OYNA / ÇIK).
Kullanıcı: "birebir aynısı şart değil ama kullansan iyi olur" → dil, düzen ve bileşenler bu görsellerden alınır; içerik BİZİM oyunumuz (görsellerdeki "Güvenlik/İletişim Uzmanı",
takım sıralaması, ödül/kredi, 4827 sayacı, "Gözlemci şifresi" gibi karşılığı olmayan öğeler KONMAZ; karşılığı olan ekranlara eşlenir: 04 → hazırlık incelemesi + onay,
05 → operatör iletişim merkezi, 03 → mühendis çalışma alanı). İşlevsiz düğme YOK. Fotoğraf yok: Dünya/mekik/roket kodla (SVG/CSS) çizilir, logo piksel-art roket (SVG `rect`'lerle).

### Görsel dil (tüm arayüz modülleri aynen)
- Zemin: çok koyu lacivert uzay (`#040a16` → `#071a33` radyal), ince ızgara + seyrek yıldız; sağ alttan Dünya yayı (açılış/kalkış/sonuç ekranlarında).
- Panel: yarı saydam lacivert (`rgba(8,24,48,.72)`), 1.5px camgöbeği (`#38c8ff`) çerçeve, KESİK köşeler (`clip-path` 12px), başlık şeridi: ikon + BÜYÜK HARF başlık, altında ince çizgi.
  Parıltı ÖLÇÜLÜ: yalnız odaktaki/aktif panel ve ana düğmede `box-shadow: 0 0 18px rgba(56,200,255,.35)`; her yere glow YOK (CLAUDE.md).
- Renkler: camgöbeği `#38c8ff` (ana/aktif), yeşil `#3dff8a` (PASS/GO/hazır), amber `#ffc247` (WARN), kırmızı `#ff4d5e` (FAIL/NO-GO), mor `#b57bff` (yalnız demo), metin `#e6f1ff`, soluk `#8aa4c8`.
  Rol renkleri: Operatör beyaz-camgöbeği, İtki amber/turuncu, Uzay Aracı camgöbeği, Bilim yeşil.
- Yazı: başlıklar ve sayılar **Rajdhani** (600/700, BÜYÜK HARF, hafif aralık), gövde Rajdhani 500 ≥ 16px; yerel (`@fontsource/rajdhani` npm, `/vendor/fonts/rajdhani/` — Modül AE kurar ve sunar). CDN YOK.
- Üst çubuk (her ekranda): sol piksel-art roket logosu + "PIXEL PAYLOAD / ORTAKLAŞA YÖRÜNGE GÖREVLERİ"; orta sekmeler (bağlama göre: girişte BAŞLA · NASIL OYNANIR · UÇUŞ VERİLERİ · AYARLAR;
  oyunda GÖREV · İLETİŞİM · HAZIRLIK · (operatörde) EKİP); sağ: oda kodu kutusu, "n / 4" oyuncu, bağlantı ve sistem noktası. Alt durum satırı: oda · rol · faz · süre · bağlantı.
- **GERİ düğmesi her ekranda** (sol üst, ana içeriğin üstünde, "← GERİ"): sunucu fazlı ekranlarda `phase:back`/`review:back` (yetkisi yoksa gizli değil, devre dışı + neden ipucu),
  diğerlerinde istemci içi geçmiş. Sonuç ekranında **TEKRAR OYNA** (`game:again new` + "AYNI GÖREV" ikincil) ve **ÇIK** (`room:leave`).
- Erişilebilirlik: düğme ≥ 44px, odak halkası, `prefers-reduced-motion`. Telefon ≥ 360px tek sütun; tablet 2; ≥ 1200px 3 sütun. Yatay taşma yok. innerHTML yok (DOM API).

### İstemci mimarisi (ES modülleri, çerçevesiz)
- `public/index.html` — kabuk: üst çubuk, `#back-btn`, `<main id="screen">`, alt satır, `#toast`, `#modal-root`; `<script type="module" src="/js/app.js">`.
- `public/js/core.js` (AC) dışa açar:
  `connect()`, `emit(event, payload) → Promise<ack>`, `getState()`, `subscribe(fn(state, prevState))`, `onEvent(name, fn)` (`chat:message`, `kicked`, `room:closed`),
  `session` (sessionStorage `pixelPayloadSession[:slot]`, rejoin, URL paramları `slot, auto, name, role, code, embed, debug` + `pp-state`/`pp-error` postMessage sözleşmesi — Aşama 5 Modül P aynen),
  `nav: { go(localScreenId), back(), current() }` (fazsız ekranlar: `home, create, join, how, data, settings`), `prefs` (localStorage: `reduceMotion, textScale, name`).
- `public/js/ui.js` (AC): `h(tag, attrs, ...children)`, `panel({ title, icon, accent, actions }, ...children)`, `button({ label, sub, variant: 'primary'|'go'|'nogo'|'ghost'|'demo', onClick, disabled, reason })`,
  `statusDot(status)`, `statusPill('PASS'|'WARN'|'FAIL'|...)`, `icon(name)` (SVG ikon seti: rocket, crew, shield, antenna, flask, power, thermo, fuel, engine, chart, gear, chat, back, check, cross, warn, clock, star, satellite, rover, moon, mars, play, exit, eye),
  `pixelRocket(size)`, `earthArc()`, `meter({ value, max, status })`, `stepList(steps)`, `toast(msg, kind)`, `modal({ title, body, actions })`, `roleBadge(role)`, `fmt.num/fmt.unit/fmt.time`.
- `public/js/app.js` (AC): ekran yönlendirici. Sunucu fazı varsa ekran fazdan seçilir, yoksa `nav`. Ekran modülü sözleşmesi:
  `export default { id, render(root, state, api) , update?(state, prev, api), destroy?() }` — `api = { emit, nav, ui, prefs, scene }`. Yönlendirme tablosu:
  `home|create|join|how|data|settings` → AC; `lobby, mission-select, briefing` → AC; `design` → AD (rol: `director` → `screens/operator.js`, diğerleri → `screens/engineer.js`);
  `review` → AD (`screens/review.js`); `simulation` → AE (`screens/simulation.js`); `debrief` → AE (`screens/debrief.js`). İletişim paneli (`screens/comms.js`, AD) design/review/simulation'da
  sağ çekmece + operatörde ayrıca "İLETİŞİM" sekmesiyle tam ekran (05'teki düzen). Ekran dosyası yoksa app.js "bu ekran hazırlanıyor" yer tutucusu gösterir (çökme yok).
- CSS: `public/css/base.css` (AC: token'lar, kabuk, panel/düğme/form bileşenleri), `public/css/work.css` (AD), `public/css/sim.css` (AE). Eski `public/styles.css` ve `public/client.js` `arsiv/asama6/public/`'e taşınır (AC).
- 2B araç sahnesi `public/scene2d.js` (AE yeniden yazar; eski `createRocketScene` kalkar):
  `createVehicleScene(container) → { setVehicle({ missionId, modules: [{ id, name, role }], items: state.vehicle, highlightModule? }), onModuleClick(fn(moduleId)), playPhase(phaseId, status) → Promise, reset(), dispose() }`.
  Görevin modüllerini dikey yığın olarak (Ay: fırlatma aracı → mürettebat aracı → iniş aracı + yüzey kiti; Mars: fırlatma aracı → seyir kademesi → EDL/aeroshell → gezgin) kodla çizer;
  takılı parçaları modül üstünde rol renkli simgelerle gösterir; boş modül soluk kesik. `playPhase`: kalkış, ayrılma, giriş ısınması, paraşüt, iniş, yüzey, dönüş için kısa (≤ 2.5 sn) animasyon; her zaman resolve.

### Ekranlar
- **AC:** açılış (01: BAŞLA → oda kur / odaya katıl seçimi; DEMO MODU (mor, 02'deki "Gözlemci" kartının yeri) → `/demo.html`; NASIL OYNANIR), oda kur (ad), odaya katıl (kod + ad),
  lobi (oda kodu büyük + LAN adresleri `GET /api/info`; 4 rol kartı (05'teki astronot kartları gibi, rol renginde); hazır düğmesi; host: BAŞLAT, oyuncu çıkar, host devret), görev seçimi
  (iki büyük görev kartı Ay / Mars, kodla çizilmiş gezegen; ayrıntılar yalnız operatörde; mühendis "Operatör görevi seçiyor"), brifing (rolüne göre metin, ANLADIM; operatörde kimlerin okuduğu + ATLAT),
  nasıl oynanır, UÇUŞ VERİLERİ (= bilimsel kaynaklar sayfası: `GET /api/sources` listesi + "gerçek / tahmin / oyun varsayımı" açıklaması), ayarlar (ad, hareketi azalt, yazı boyutu; localStorage).
- **AD:** mühendis çalışma alanı (03): sol rol kartı + kendi brifing özeti + ihtiyaçlar ("Operatörden öğren: …" etiketleri); orta 2B araç (kendi modülleri vurgulu) + kendi telemetrisi;
  alt ekipman kataloğu (kategori sekmeli kartlar: ad, simge, kendi sayıları, `canAdd` engeli varsa gerekçe; TAK), seçili ekipman ayrıntısı + kaynak sınıfı; takılı ekipmanım (ÇIKAR); kendi ayarları;
  sağ kendi hazırlık kalemleri (PASS/WARN/FAIL, `cascadeFrom` olanlar "başka ekipten etki" rozetiyle). Operatör çalışma alanı: görev hedefleri, bütçe, birleşik telemetri, ekip ilerlemesi
  (rol başına eksik kategoriler), `needs` değerleri (aktarması için "kime söyle" ipucu), 2B araç, HAZIRLIK İNCELEMESİNİ AÇ. Hazırlık incelemesi (04): durum özeti, kalem listesi rol bazlı,
  mühendiste ONAY / DÜZELT, operatörde ekip onay şeridi + FIRLAT (GO) / TASARIMA DÖN (NO-GO); kritik FAIL'de FIRLAT devre dışı + neden. İletişim merkezi (05): operatörde 4 kanal sekmesi
  (İtki, Uzay Aracı, Bilim, TÜM EKİP) + okunmamış sayısı; mühendiste tek kanal "OPERATÖR" + yayınlar; mesaj saati ve gönderen; `chat:send`; hata (hız sınırı vb.) toast.
- **AE:** simülasyon (06): sol aşama listesi (açılan aşamalar ✓/⚠/✗), orta 2B araç `playPhase`, sağ telemetri (operatör tam; mühendis kendi), olay akışı (rol etiketli), alt büyük durum şeridi;
  debrief (07): büyük sonuç başlığı (BAŞARILI / KISMİ / BAŞARISIZ), yıldız + puan, bölümler (hedefler, mühendislik, yakıt, güç, iletişim, bilim, bütçe, olaylar, karşılanmayan, ekip), dersler,
  "Gerçekte NASA bunu şöyle yapıyor", kaynaklar, TEKRAR OYNA / AYNI GÖREV / ÇIK. Demo sayfası (`public/demo.html`, `public/demo.js`) yeni görsel dile ve iki göreve uyarlanır (işlev aynı).

## Modüller (Aşama 7 — Arayüz)
### Modül AC: Kabuk, çekirdek, giriş/lobi/görev seçimi/brifing/yardım/veri/ayarlar
- [x] Durum: tamam
- **Sahip dosya(lar):** `public/index.html`, `public/js/core.js`, `public/js/ui.js`, `public/js/app.js`, `public/js/screens/{home,create,join,lobby,mission-select,briefing,how,data,settings}.js`, `public/css/base.css`; `public/styles.css` + `public/client.js` → `arsiv/asama6/public/`.
- **Atanan agent:** gelistirici · **Skill'ler:** game-ui-ux → frontend-design → design-system → ux-reviewer → visual-design-critic (+ motion-design)
- **Notlar:**
  - **CSS değişkenleri (base.css `:root`):** zemin `--bg --bg2 --panel --panel-solid --panel-hi`; çizgi `--line --line-dim --line-faint`; renk `--cyan --green --amber --red --purple --text --muted --ink`;
    rol `--c-director --c-rocket --c-spacecraft --c-payload`, `--me` (html[data-myrole]); `[data-role=x]` öğede `--rc` = rol rengi; yazı `--font --text-scale --fs-xs/sm/md/lg/xl/2xl/3xl/4xl` (rem; 13…49px) `--track`;
    aralık `--s-1..--s-8` (4,8,12,16,24,32,48,64) `--pad`; biçim `--cut (12px) --cut-sm (8px) --bw (1.5px) --glow --glow-in --shadow --tap (48px) --head-h --maxw`; katman `--z-bar/drawer/modal/toast`; süre `--t-fast --t-mid`. Kırılma: 480/768/1200 (+900 açılış).
    Not: `clip-path` dış glow'u keser → panel/düğmede `--glow-in` (iç) kullanılır.
  - **Bileşen sınıfları:** `.panel[data-accent=green|amber|rocket|red|purple|director|dim|payload][data-active=1]` + `__head __title __actions __body`; `.btn.btn--primary|go|nogo|ghost|demo` + `.btn--lg .btn--block`, `__label __sub __reason`;
    `.field __label __input(--code) __hint __error`, `.toggle`, `.seg/.seg__opt[aria-pressed]`; `.dot[data-status=ok|warn|fail|info|idle]`, `.pill[data-status]`, `.role-badge[data-role]`; `.meter(__fill)`, `.steps`, `.list/.list__item/.list__main`;
    `.subtabs/.subtab[aria-selected]`, `.modal…`, `.toast[data-status]`, `.loading(__bar)`, `.placeholder`, `.empty`, `.bracket`, `.eyebrow`, `.screen-head/.screen-title`, `.stack .row .grid-2 .grid-3`, `.muted .num .sr-only`.
  - **core.js:** `connect()`, `emit(ev,payload)→Promise<ack>` (bağlı değilse `{ok:false,error:'OFFLINE'}`, 8 sn'de `TIMEOUT`; create/join/rejoin ack'inde oturum kaydı, `room:leave`'de yerel durum temizlenir), `getState()`, `subscribe(fn(state,prev))→unsub`,
    `onEvent(name,fn)→unsub` — `chat:message, kicked, room:closed` + ek: `connection` ('connecting'|'online'|'offline'), `nav`, `error`. `connection()` ek. `session {key,slot,embed,debug,inFrame,params,load,save,clear}`;
    `nav {go(id), back(), current()}` + ek `canBack()`, `reset(id)`; `prefs {get,set}` + ek `all()` (anahtarlar `reduceMotion,textScale,name`; html `data-reduce-motion`, `--text-scale` yazar). Kicked/room:closed'da oturum silinir, state=null.
    URL paramları + `pp-state` (`me`'den code/phase/role/name) / `pp-error` aynen.
  - **ui.js kesin imzalar:** `h(tag, attrs, ...children)` (attrs: class|text|style{}|dataset{}|on<Olay>|özellikler), `panel({title,icon,accent,actions,active,className}, ...children)`,
    `button({label,sub,variant,onClick,disabled,reason,icon,type,className,size:'lg',ariaLabel})` (onClick Promise dönerse bitene kadar meşgul; reason düğme içinde 2. satır), `statusDot(status)`, `statusPill(status,label?)`,
    `icon(name,size?)` (PLAN listesi + ek: copy, crown, info, lock, book, wifi, users, link, globe), `pixelRocket(size)`, `earthArc()`, `meter({value,max,status,label})`, `stepList([{label,status:'done'|'active'|'pending'|'ok'|'warn'|'fail',note}])`,
    `toast(msg, kind='info'|'ok'|'warn'|'error', ms?)`, `modal({title,body,actions:[{label,variant,icon,onClick,close}],onClose})→{close,el}`, `roleBadge(role,{short})`, `fmt.num(n,d) fmt.unit(n,unit,d) fmt.time(v)` (ts>1e11→SS:DD, yoksa süre) + `fmt.clock fmt.duration`.
    Ekler: `clear(node)`, `confirmModal({title,body,okLabel,okVariant,cancelLabel})→Promise<bool>`, `planet('moon'|'mars'|'earth', size)`, `statusKind(s)`, sabitler `ROLES ROLE_NAMES ROLE_SHORT ROLE_ICONS PHASE_NAMES`.
  - **app.js:** sözleşme aynen (`render(root,state,api)`, `update?(state,prev,api)` — yoksa her state'te destroy+render; `update` yalnız state değişince çağrılır). `api = {emit,nav,ui,prefs,scene}` + ek `getState, onEvent, session`.
    `api.scene()` → `import('/scene2d.js')` modülü ya da null. Yönlendirme PLAN'daki tablo; dosya yoksa/`render` yoksa "BU EKRAN HAZIRLANIYOR" yer tutucusu.
    Odadayken üst sekmeler: GÖREV · İLETİŞİM · NASIL OYNANIR · AYARLAR (how/data/settings faz ekranının üstünde katman olarak açılır; GERİ katmanı kapatır). HAZIRLIK/EKİP sekmeleri KONMADI (AD ekran içi; işlevsiz düğme olmasın).
    **İletişim:** AD'nin engineer/operator ekranları design'da iletişimi kendileri gösteriyor → kabuk çekmecesi (`#drawer`, `screens/comms.js` default modülü, `#comms-root[data-mode=drawer|full]`) yalnız review/simulation'da; operatörde İLETİŞİM sekmesi design/review/simulation'da comms'u tam ekran açar.
    **GERİ:** lobby → odadan çık (onaylı); mission-select/design/simulation → devre dışı + neden; briefing → `phase:back` (operatör); review → `review:back` (operatör); debrief → `phase:back` (host/operatör); fazsız ekranlar → `nav.back()`.
    Sağ üstte oda kodu, n/4, bağlantı, çıkış (onaylı `room:leave`). Alt satır süresi = istemcide fazda geçen süre. `?debug=1` ham state gösterir.
  - **Doğrulama:** `server/sim/index.js` yok → statik sayfa Playwright `page.route` + sahte socket ile 1366×768 ve 390×844: açılış, uçuş verileri (gerçek sources.json), lobi (sahte state), oda kur, embed 470px. Konsol hatası yok, yatay taşma yok.
  - **Bilinen eksikler:** görev seçimi ve brifing ekranları gerçek sunucuyla görülmedi (yalnız kod; alan adları AA notlarına göre). Yeniden bağlanma şeridi yalnız kodla kontrol edildi. `index.html` `work.css`/`sim.css`'i de yükler.
### Modül AD: Çalışma alanları, hazırlık incelemesi, iletişim merkezi
- [x] Durum: tamam
- **Sahip dosya(lar):** `public/js/screens/{engineer,operator,review,comms}.js`, `public/js/widgets/*.js` (yalnız AD), `public/css/work.css`
- **Bağımlılık:** AC'nin `core/ui/app` arayüzü (yukarıda; paralel yazılır), AE'nin `createVehicleScene`.
- **Atanan agent:** gelistirici · **Skill'ler:** game-ui-ux → frontend-design → design-system → ux-reviewer → visual-design-critic
- **Notlar:**
  - **İletişim:** `comms.js` default ekranı app.js'nin `#comms-root`'una çizilir (`data-mode="full"|"drawer"`, CSS ile kipe uyar; görünürlük IntersectionObserver ile → okundu). Operatör: 4 kanal (İTKİ/UZAY ARACI/BİLİM/TÜM EKİP → `to: rol|'engineers'`) + kanal başına okunmamış; mühendis: tek OPERATÖR kanalı + YAYIN etiketli yayınlar. `chat:message` canlı eklenir (id ile tekil), hata ack.message toast. Okundu bilgisi sessionStorage `ppCommsSeen`.
  - **`mountCommsDrawer(root, getState, api)` → `{ el, open(channel?, draft?), close(), toggle(), update(state), destroy() }`** (comms.js named export; sağ alt İLETİŞİM düğmesi + okunmamış rozeti + sağ çekmece, Esc kapatır, core.subscribe ile kendini günceller). Kullanım: design fazında `engineer.js` bunu açar (kabuk çekmecesi yalnız review/simulation'da). review/simulation'da kabuk çekmecesi var → AE'nin çağırması GEREKMEZ (çift panel olur). Operatör iletişimi kabuğun İLETİŞİM sekmesindeki tam ekran. Ayrıca `createCommsPanel(api, {mode, onUnread})` ve `totalUnread(state)` dışa açık.
  - **Widget'lar (`public/js/widgets/`):** `util.js` (h/refill, sözlükler, biçimleyiciler, `makeKit(api)` → ui.js panel/button/statusPill/roleBadge/toast varsa onları kullanır, yoksa yerel yedek; `act(event,payload,okMsg)` = emit + hata toast), `frame.js` (titleBar, section ezberleme, iki adımlı `confirmButton`, `designTimer`), `vehicle.js` (`mountVehicle` → createVehicleScene, yoksa modül yığını yedeği), `telemetry.js`, `readiness.js`, `catalog.js`, `settings.js`.
  - Operatör "AKTAR" ve mühendis "OPERATÖRE SOR" doğrudan `chat:send` ile özel mesaj yollar (kabukta İLETİŞİM'e geçiş API'si olmadığından). DÜZELT, NO-GO ve FIRLAT iki adımlı onaylı. FIRLAT engel nedeni state'ten okunur (onay bekleyenler + kritik FAIL); asıl karar sunucuda (LAUNCH_BLOCKED toast).
  - Doğrulama: sunucu sim'i (`server/sim/index.js`) yokken sahte state + gerçek `data/` ile scratchpad test sayfasında 10 ekran görüntüsü (1440/820/375): konsol hatası yok, yatay taşma yok; TAK/NO-GO/chat:send olayları doğru.
  - **Bilinen eksikler / test edilemeyenler:** gerçek sunucuyla 4 oyunculu uçtan uca akış denenmedi. Kategori/ikon Türkçe adları istemcide sözlükle (veride yok). Telemetride birkaç renk tonu iki sunucu sayısının karşılaştırması (yalnız görsel; kural readiness'te). Ayarlar: `settingDefs.help` etiketin altında soluk satır; seçenek adı önce `optionInfo[opt].label`, yoksa yerel sözlük; seçili seçeneğin açıklaması (`desc || note || text || help`) altta kısa satır + düğme `title`. AE sahnesi dar sütunda modül etiketlerini kırpıyor (scene2d.js, AE).
### Modül AE: 2B araç sahnesi, simülasyon, debrief, demo, font ve kaynak uç noktası
- [x] Durum: tamam
- **Sahip dosya(lar):** `public/scene2d.js`, `public/scene2d-dev.html`, `public/js/screens/{simulation,debrief}.js`, `public/css/sim.css`, `public/demo.html`, `public/demo.js`;
  `server/index.js` YALNIZ şu iki ek: `/vendor/fonts/rajdhani` statik yolu ve `GET /api/sources` (`data/science/sources.json`'ı döndürür); `package.json`/`package-lock.json` (yalnız `@fontsource/rajdhani` eklemek), `baslat.bat` (font paketi yoksa `npm install`).
- **Atanan agent:** gelistirici · **Skill'ler:** game-ui-ux → frontend-design → motion-design → visual-design-critic
- **Notlar:**
  - **Sahne:** `import { createVehicleScene } from '/scene2d.js'` (ayrıca default export) → `{ setVehicle({ missionId, modules, items, highlightModule? }), onModuleClick(fn), playPhase(phaseId, status, opts?) → Promise, reset(), dispose() }`.
    Tek ek: `playPhase(..., { instant: true })` = animasyonsuz son poz (yeniden bağlanma/debrief için; isteğe bağlı, geriye uyumlu). Her zaman resolve (≤ ~2.5 sn, en geç 3.7 sn güvence); `prefers-reduced-motion` veya `<html data-reduce-motion="1">` → anında.
    Yığın (aşağıdan yukarı): lunar `launch-vehicle → lander → surface-kit → crew-vehicle`; mars `launch-vehicle → edl → rover → cruise-stage`. Bilinmeyen modül kimliği üste basit kutu olarak eklenir. `modules` boş olabilir (ad/rol varsayılanı sahnede).
    Aşama kimliği anahtar kelimeyle animasyona eşlenir (launch / tli·loi·tcm·cruise·depart·approach·*orbit*·*transfer* = ayrılma / entry / parachute / landing·descent / surface·rover·science / downlink / ascent(Ay)·return / recovery; diğerleri kısa nabız). Ayrılan kademeler soluk kalır, görünüm etkin yığına yakınlaşır.
    `item.icon` eşlemesi: engine, fuel(tank), power(battery, rtg), solar(panel), antenna(dish), shield, heatshield, thermo, flask(spectrometer, instrument), camera, crew(capsule, suit), computer, satellite(station), rover, wheel, parachute(chute), radar(sensor), drill, leg(legs), chart, gear, rocket; bilinmeyen (generic) → kutu. Renk = `item.role` (rol renkleri base.css ile aynı). Dar kapta (< 440 px) etiketler kelime kelime alt alta, parça sayısı gizli; viewBox ResizeObserver ile kaba uyar (etiket kırpılmaz).
  - **Ekranlar:** `screens/simulation.js` (update yazıldı: sahne her state'te yeniden kurulmaz, yalnız yeni açılan aşama oynatılır; aynı veriyle `setVehicle` yeniden çizmez). İletişim çekmecesi KURULMAZ (kabuk kuruyor). Telemetri: operatör `director.telemetry`, mühendis `engineer.telemetry`; yoksa panel gizli. `screens/debrief.js`: TEKRAR OYNA `game:again {mode:'new'}`, AYNI GÖREV `{mode:'same'}`, ÇIK onay modalı + `room:leave` (+ `nav.reset('home')`); host/operatör değilse iki düğme devre dışı + tek not "Yeni turu host veya operatör başlatır". Host devri/rol değişince yeniden çizer.
  - **Font:** `@fontsource/rajdhani` kuruldu; `/vendor/fonts/rajdhani/<latin|latin-ext>-<500|600|700>.css` (server/index.js). `baslat.bat` paket yoksa `npm install`.
  - **`GET /api/sources`** → `data/science/sources.json` dizisi aynen (`[{id,title,publisher,url,accessed}]`); dosya yok/bozuk → `[]`.
  - **Demo:** seçiciler/URL/postMessage aynen; yeni görsel dil (Rajdhani, kesik köşe, mor DEMO etiketi), metinler Operatör/İtki/Uzay Aracı/Bilim + iki görev. Panel oyuncu adları `Operatör, İtki, Uzay Aracı, Bilim` (eski Yönetici/Roketçi… yerine). Faz etiketleri yeni fazlar.
  - Eski sahne `arsiv/asama6/public/scene2d-roket.js` (+ `scene2d-dev-roket.html`).
  - Doğrulama (bir kez): node --check; scene2d-dev + sahte state'le sim/debrief (1440/820/390 px) + demo ekran görüntüleri, yatay taşma 0, konsol hatası yok; gerçek sunucuda /api/sources ve font 200. Gerçek oyun akışıyla (4 oyuncu → simülasyon) uçtan uca denenmedi.
  - **Bilinen eksikler:** sahne animasyonları şematik; aşama eşlemesi anahtar kelimeyle (veri kimlikleri değişirse "nabız"a düşer).
  - Ek: `simulation.phaseList` ([{id,name}]) kullanılıyor — simülasyonda herkes tüm aşamaları görür (açılanlar durumlu, gelecektekiler soluk ad); debrief'te ulaşılmayan aşamalar soluk kesik çip. phaseList yoksa eski davranış (operatör görev verisi / "Sıradaki aşama…").

## Grup 3 — tek final testi (testci), sonra en çok 3 düzelt-doğrula turu

## Son durum — Aşama 7 (şef doldurur)
- **Çalışanlar:**
- **Kalanlar:**


---

# AŞAMA 8 — Yayın öncesi cila: alan/kapasite, bütçe defteri, fırlatma özgürlüğü, karar sadeleştirme, komuta merkezi  ← ŞU AN

Kaynak: kullanıcının "PIXEL PAYLOAD — FINAL PRODUCT POLISH & RELEASE PROMPT" metni (metin §7'nin ortasında kesik geldi; §7 "Operatör komuta merkezi" listesi makul biçimde tamamlandı).
**Bağlayıcı kurallar:** mevcut mimari, Socket.io, sunucu otoritesi, faz akışı, sohbet kuralları, asimetrik bilgi KORUNUR. Baştan yazma yok, yeni bağımlılık yok.
Geriye uyumluluk: `volumeU` yoksa 0, `capacityU` yoksa sınırsız, `kind` yoksa istemci status'tan türetir. Var olan testler (gerektiği kadar güncellenerek) geçmeye devam eder.
İş akışı: geliştirici yalnız kendi birim testlerini BİR kez (bitince) koşar. Arayüz geliştiricisi en sonda en çok bir ekran görüntüsü turuyla `visual-design-critic` yapar. Sonra tek final testci turu + en çok 3 düzeltme turu.

## 8.1 Yeni kavramlar ve veri (sahip: Modül AF)
- **Parça hacmi:** her parçaya `volumeU` (tam sayı, "kapasite birimi" U, ≥0). **Modül kapasitesi:** her modüle `capacityU`. Karışık rollü modüllerde (Ay `lander`, Mars `cruise-stage`/`edl`/`rover`) kapasite ORTAKTIR → roller pazarlık eder.
  Kapasite sert fiziksel sınırdır: sığmayan parça takılamaz (`canAdd` → `NO_SPACE`). Çıkarınca alan geri gelir. Opsiyonel bilim ekipmanı da alan tüketir.
- **Standart donanım:** tek seçenekli zorunlu kategoriler veride `auto: true` ile işaretlenir; tasarıma girerken sunucu bunları otomatik takar (çıkarılamaz; maliyeti/kütlesi/alanı sayılır). Amaç: tıklama azaltmak.
- **Karar alanı hedefi:** her mühendis için ≈10 anlamlı karar (≥2 seçenekli kategori + ayarlar). Tek seçenekli/önemsiz kategoriler `auto` olur ya da birleştirilir; az seçenekli önemli kategorilere gerçek ödünleşimli 2.–3. seçenek eklenir (kütle/maliyet/güç/hacim/güvenilirlik farkıyla; her koşulda en iyi seçenek olmasın).
- **Yeni ayarlar:** her mühendise gerçek ödünleşimli 1–2 yeni ayar (ör. rocket `landingReservePct` iniş yakıt rezervi veya `ascentProfile`; spacecraft `commsPlan` bağlantı süresi↔güç; payload `samplePriority`). Anahtarlar AF notlarına yazılır. Arayüz ayarları `settingDefs`'ten genel çizer (number → kaydırıcı, enum → bölümlü düğme, `optionInfo.label/desc`).
- **Bilim hedefleri:** görevde `scienceGoals: [{ id, name, desc, requiresTags: [provides etiketleri], value }]` — her görevde 3 opsiyonel hedef; makul bir tasarımda kapasite/bütçe yalnız ~2'sine yeter.
- **Bütçe:** bütçe aşımı artık KRİTİK DEĞİL (kritik olmayan FAIL, `kind:'budget'`). Fırlatmayı engellemez; debrief'te raporlanır ve puanı düşürür.

## 8.2 Simülasyon arayüzü değişiklikleri (`server/sim/*`, sahip: AF)
- `autoItems(missionId)` → `[{ itemId, moduleId, role }]` (auto kategoriler; bilinmeyen görev → []).
- `canAdd(build, missionId, role, itemId, moduleId)` → mevcut hatalar + `NO_SPACE` (`reason`: "Modülde yer yok: kullanılan 34/40 U, parça 8 U"). Build'deki auto parçalar da alan sayar.
- `evaluate(...)` ekleri:
  - `telemetry.capacity: { [moduleId]: { name, usedU, capacityU, freeU, byRole: { rocket, spacecraft, payload } } }` (capacityU yoksa `null`, freeU `null`).
  - `telemetry.scienceGoals: [{ id, name, desc, value, status: 'ready'|'partial'|'missing', missingTags: [] }]`.
  - `telemetry.budget: { budget, spent, remaining, byRole: { rocket, spacecraft, payload } }` (mevcut `cost/budget` alanları da kalır).
  - Her readiness kalemine `kind`: `'ok'` (PASS) | `'missing'` (zorunlu kategori/gereksinim eksik) | `'physical'` (Δv, TWR, kütle, temas hızı gibi fiziksel yetersizlik) | `'risky'` (diğer WARN/FAIL: marj dar, koruma eksik, ısı…) | `'budget'`.
  - `evaluation.launchStatus`: `'INSUFFICIENT'` (kritik physical var) > `'MISSING'` (kritik missing var) > `'RISKY'` (herhangi WARN/FAIL) > `'READY'`. `overall` aynen kalır (geri uyum).
- **Gerçek etkileşimler (denetle, eksikse ekle):** faydalı yük kütlesi → toplam kütle → Δv/TWR; aletlerin gücü → uzay aracı barası; güç kapasitesi → iletişim/bilim/yaşam desteği; iletişim kapasitesi → bilim verisi ve bilim hedefi; ısı/çevre (Ay gecesi, Mars toz/soğuk) → ısı/batarya; ortak modül kapasitesi → roller arası pazarlık. Hepsi sunucu hesaplarında, metin değil.
- `simulate(...)` (deterministik kalır): sonuçlar türe göre kademeli —
  `physical` kritik → ilgili aşamada kesin başarısızlık (yakıt/itki yetmezse araç gerçekten ulaşamaz); `missing` koruma/destek → olasılıklı hasar olayı, hedefleri düşürebilir (yaşamsal olanlar Ay'da yine ölümcül olabilir); eksik bilim ekipmanı → ilgili bilim hedefi yapılamaz; `budget` → simülasyonu etkilemez.
  Dönüşe ek: `scienceGoals: [{ id, name, done, reason }]`.
- `debrief(...)` ekleri: `budget: { budget, spent, overrun, overrunPct }` (aşımda bütçe bölümü 0 + ayrı ceza satırı ve ders), `scienceGoals` (yapılan/yapılamayan + neden). Toplam 1000 korunur (bölüm ağırlıkları AF'nin kararı).
- Dengeleme: Ay A/B, Mars A/B çözümleri kapasiteye sığar ve geçer; açgözlü tasarım bütçe veya kapasiteyle kalır; 3 bilim hedefinin üçü birden makul tasarımda sığmaz.

## 8.3 Oda ve görünüm (`server/rooms.js`, `server/filter.js`, `server/constants.js`, `server/index.js`, sahip: AG)
- **Build girişi:** `{ uid, itemId, moduleId, role, auto?: true, cost }` — `cost` takma anındaki maliyet (iade aynı tutar; çift ücret yok).
- **Standart donanım:** tasarıma ilk girişte (yeni görev / 'new') `sim.autoItems` eksik olanları ekler (`auto:true`). `removeItem` auto parçada → `GameError('LOCKED', 'Standart donanım çıkarılamaz.')`. 'same' tekrarında build korunur. `sim.autoItems` yoksa (eski sahte sim) atlanır.
- **Harcama defteri:** `room.ledger: [{ id, ts, role, playerName, action: 'add'|'remove'|'auto', itemId, itemName, moduleId, cost }]` (ekle +cost, çıkar −cost iade). En çok 300 kayıt. Yeni görevde ('new') sıfırlanır, 'same'de korunur. Harcanan = build maliyetleri toplamı (defter yalnız geçmiş).
- **Fırlatma:** kritik FAIL / bütçe artık ENGEL DEĞİL. Tek engel: 3 mühendis onayı (`LAUNCH_BLOCKED`). `launch(code, pid, { confirm })`: `evaluation.launchStatus` (yoksa overall'dan türet) `!== 'READY'` ve `confirm !== true` → `GameError('LAUNCH_CONFIRM', 'Tasarım hazır değil (<durum>): <en çok 4 kalem>. Yine de fırlatmak için onayla.')`. Socket: `mission:launch { confirm: boolean }`.
- **Yeni hata kodları:** `NO_SPACE` (canAdd'den aynen), `LOCKED`, `LAUNCH_CONFIRM` (+Türkçe mesaj).
- **Görünüm ekleri (filter, beyaz liste):**
  - Herkese: `launchStatus`, `capacity: { [moduleId]: { name, usedU, capacityU, freeU, mineU } }` (alan herkesçe görülür, pazarlık için; `mineU` = izleyenin rolünün kullandığı, operatörde 0), `vehicle[i].auto`, `vehicle[i].volumeU`.
  - Mühendise: `engineer.budgetBand: 'ok'|'tight'|'over'` (SAYI YOK; tight = %90 üstü), katalog parçasında `volumeU` + `canAdd` (`NO_SPACE` dahil), readiness kalemlerinde `kind`, payload'a ayrıca `engineer.scienceGoals: [{ id, name, desc, status, missingTags }]` (value YOK).
  - Operatöre: `director.budget: { budget, spent, remaining, byRole }`, `director.ledger` (tam, yeni→eski), `director.telemetry.capacity`, `director.telemetry.scienceGoals` (value dahil), readiness `kind`, `director.launchStatus`.
  - Mühendise ASLA: maliyet, bütçe sayısı, defter, başka rolün sayıları (kapasite U hariç).
  - debrief fazında `result.debrief.budget` ve `result.debrief.scienceGoals` herkese.
- README: kapasite, standart donanım, defter, fırlatma özgürlüğü, bütçe aşımı, yeni ayarlar bölümleri güncellenir (AG; ayar anahtarları için AF notlarına/veriye bak).

## 8.4 Arayüz — mühendis tarafı (sahip: AH)
Dosyalar: `public/js/screens/engineer.js`, `public/js/widgets/{catalog,vehicle,readiness,settings,util}.js`, `public/css/work.css`.
- **Alan görünümü:** her modül için kapasite çubuğu (kendi rolün / diğer roller / boş), parça kartında `volumeU`; takınca/çıkarınca anında güncellenen görsel yerleşim (modül içi blok/ızgara). `vehicle.js` ortak araç görünümüne modül kapasite doluluğu eklenir (operatör ve inceleme de kullanır → `mountVehicle` API'si geriye uyumlu kalsın, durumdan `capacity` okusun).
- **Karar odaklı katalog:** kategori = karar kartı; seçenekler yan yana kıyas (kütle, güç, hacim, güvenilirlik, etkinlik) + kısa artı/eksi; `NO_SPACE`/`INCOMPATIBLE` gerekçesi açık. Standart donanım ayrı, kilitli, sade bir "standart" satırında.
- **Hazırlık türleri:** `readiness.js` `kind`'a göre rozet: Hazır / Eksik / Riskli / Fiziksel yetersiz / Bütçe (kind yoksa status'tan türet). Ekle: `export const KIND_TR` ve `export function kindOf(item)` (AI de kullanır). Fırlatmayı engellemediği dille anlatılır.
- **Bütçe bandı** çipi (rahat / sınırda / aşıldı; sayı yok). Payload'da bilim hedefleri kartı (ready/partial/missing + eksik etiket adı).
- Skill sırası: `game-ui-ux` → `frontend-design` → `design-system` → `ux-reviewer` → `visual-design-critic` (+ `motion-design` takma/çıkarma geri bildirimi için). `base.css`'e dokunma; tasarım sistemini koru.

## 8.5 Arayüz — operatör komuta merkezi, inceleme, sonuç (sahip: AI)
Dosyalar: `public/js/screens/{operator,review,debrief}.js`, `public/js/widgets/telemetry.js`, YENİ `public/js/widgets/ledger.js`, YENİ `public/css/command.css`, `public/css/sim.css` (yalnız debrief kısmı), `public/index.html` (yalnız command.css `<link>` ekle).
- **Komuta merkezi (operator.js):** üstte tek bakışta görev durumu (`launchStatus` 4 durum, büyük ve net), bütçe (harcanan/kalan, rol başına), toplam kütle, kapasite (modül başına kullanılan/boş), enerji durumu, itki yeterliliği (TWR ve Δv marjları), rol başına sistem durumu (kind sayıları), bilim hedefleri. Altında harcama defteri (kim, ne, +/−maliyet, saat; kaydırılır). Tablo yığını/admin paneli görünümünden kaçın; hiyerarşi net, az ama büyük sayı.
- **İnceleme (review.js):** dört durum açıklaması, kalemler türüne göre gruplu; FIRLAT düğmesi yalnız onay eksikse kapalı. Durum READY değilse FIRLAT önce açık bir risk onayı modalı gösterir ("Eksik/riskli tasarımla fırlatıyorsun: …") → `mission:launch {confirm:true}`. `LAUNCH_CONFIRM` hatası gelirse de aynı modal.
- **Sonuç (debrief.js):** bütçe raporu (aşım tutarı/% ve puan etkisi), bilim hedefleri (yapıldı/yapılamadı + neden).
- `util.js`/`vehicle.js`/`readiness.js`/`catalog.js`/`work.css`'i DEĞİŞTİRME (AH'nin); `readiness.js`'ten `kindOf`/`KIND_TR` import edilebilir (AH ekler; yoksa yerel yedek yaz). Skill sırası AH ile aynı (+ `motion-design` durum geçişleri).

## Modüller (Aşama 8) — dördü paralel
### Modül AF: Veri + simülasyon (alan, standart donanım, kararlar, bilim hedefleri, fırlatma türleri, bütçe)
- [x] Durum: tamam
- **Sahip:** `data/**`, `server/sim/*.js`, `test/sim/*.test.js`, `test/fixtures/*`, `docs/VERI_KAYNAKLARI.md`
- **Arayüz:** 8.1 + 8.2. **Bağımlılık:** yok.
- **Notlar:**
  - **Yeni ayarlar** (iki görevde de; `optionInfo.label/desc` Türkçe, sayısal çarpanlar filtrede atılır): rocket `landingReservePct` number 0–15 adım 1 varsayılan 2 (%; iniş Δv ×(1+r) ↔ arazi tehlikesi ×max(0,4;1−3r)); rocket `ascentProfile` enum `lofted|standard|depressed` (kalkış Δv ×1,04/1/0,96 ↔ sim kalkış arıza riski ×0,6/1/1,6); spacecraft `commsPlan` enum `minimal|standard|continuous` (birincil bara verici bağlantı penceresi ×0,5/1/1,6 ↔ verici gücü ×0,6/1/1,8); payload `samplePriority` enum `goals|balanced|explore` (genel bilim ×0,85/1/1,15; goals: hedef aleti arızalansa da hedef tamamlanır; explore: tüm hedefler `partial`/limitedBy `priority` → yapılamaz). Ayar görevde tanımlı değilse nötr. powerMode/instrumentMode seçeneklerine `desc` eklendi.
  - **Standart donanım (`auto:true`, min=max=1):** Ay — launch-vehicle: core-tank, separation, attitude-control, rcs; crew-vehicle: abort, water, radiation, antenna, navigation, flight-computer, battery, emergency-power; lander: landing-sensors, lander-avionics. Mars — launch-vehicle: attitude-control, separation; cruise-stage: cruise-power, cruise-comms; edl: aeroshell, landing-radar; rover: wheels, rover-computer, robotic-arm, mast. Bunun için veriden çıkarılan ikinci seçenekler: `cv-fc-cots, cv-ant-optical, cv-rad-shelter, cv-water-recycler, cs-solar-xl, rv-wheels-ti, rv-computer-single`. `autoItems(missionId)` → `[{itemId,moduleId,role}]`.
  - **Karar listeleri:** İtki Ay 9 (yan itici, ana motor, üst kademe, iniş motoru, iniş tankı, iniş takımı + doluluk, rezerv, kalkış profili); İtki Mars 11 (yan itici, ana motor, çekirdek tank, üst kademe, seyir itkisi, ek seyir tankı, iniş motoru, iniş tankı + 3 ayar); Uzay aracı Ay 13 (kapsül, servis modülü, ECLSS, O2, ısı, güneş dizisi, iniş kabini, iniş radarı, yüzey iletişimi, yüzey gücü + sarf yedeği, güç modu, iletişim planı); Uzay aracı Mars 13 (seyir ısısı, ısı kalkanı, paraşüt, TRN, indirme, şasi, gezgin gücü, batarya, gezgin ısısı, UHF, X bandı + güç modu, iletişim planı); Bilim Ay 9 (giysi, EVA desteği, görüntüleme, örnekleme, istasyon, radyasyon dedektörü, yüzey navigasyonu + alet modu, bilim önceliği); Bilim Mars 10 (8 alet seçimi + 2 ayar). Yeni parça seçeneği EKLENMEDİ (mevcut seçenekler zaten ödünleşimli).
  - **Kapasite (U, class game):** Ay launch-vehicle 40, crew-vehicle 44, lander 44 (ortak), surface-kit 14; Mars launch-vehicle 32, cruise-stage 8 (ortak), edl 20 (ortak), rover 30 (ortak). Her parçada `volumeU` (0–14). `canAdd` → `NO_SPACE` "Modülde yer yok: kullanılan X/Y U, parça Z U." (auto parçalar dahil). Tutarsız build'de `capacity-<modül>` kritik FAIL (physical).
  - **Bilim hedefleri** (`mission.scienceGoals` + ad tablosu `mission.scienceTags`): Ay `lg-geology` [regolith-sample, core-sample] 40, `lg-seismic` [seismic-data, heat-flow-data] 35, `lg-environment` [radiation-data, dust-plasma-data] 30 (matkap–sismometre uyumsuz + 14 U → üçü birden olmaz). Mars `mg-biosignature` [organics-data, elemental-map] 40, `mg-cache` [sample-cache, context-imaging] 45, `mg-climate` [weather-data, subsurface-data] 30 (45 kg yuva + 30 U). telemetry.scienceGoals ek alanları: `missingNames, limitedBy ('power'|'thermal'|'comms'|'priority'), providers, note`; limitedBy varsa status `partial`.
  - **evaluate:** `telemetry.capacity`, `telemetry.scienceGoals`, `telemetry.budget` = **nesne** `{budget,spent,remaining,byRole}` (eski sayı `telemetry.budget` yerine; `telemetry.cost` duruyor). Her kalemde `kind`; `evaluation.launchStatus` (bütçe kalemi RISKY yapmaz: yalnız bütçe aşımı varsa READY). Bütçe FAIL kritik değil → `overall` WARN. Yeni etkileşim: Mars'ta yalnız güneşli gezginde `power-night` (batarya ≥ 12 sa gece tüketimi; ısı sorunu bataryayı düşürür). Diğer zincirler (kütle→Δv/TWR, alet gücü→bara, güç→iletişim/bilim/yaşam, iletişim→bilim, ısı/çevre→batarya) zaten sunucu hesabındaydı; güç/ısı/iletişim artık bilim hedefini de kısar.
  - **simulate:** physical kritik → kesin başarısızlık; missing kritik → ayrı zar akışı (ana akış değişmedi): yaşamsal (insanlı; eclss/o2/su/kapsül/kaçış/kabin/ısı…) %60, diğer %30 aşama kaybı, yoksa hasar (bilim −%15); `comms-link` eksikse yalnız veri kaybı; budget etkisiz; kalkışta `ascentProfile` risk çarpanı. Dönüşe `scienceGoals:[{id,name,done,reason}]`.
  - **debrief:** ağırlıklar objectives 225, engineering 100, fuel 75, power 75, comms 50, science 100 (%70 hedef + %30 hedef ötesi keşif), scienceGoals 100 (tamamlanan değer / en değerli 2 hedefin toplamı), budget 75, events 50, failed 50, team 100 = 1000. `budget:{budget,spent,overrun,overrunPct,penalty}` — aşımda bütçe bölümü 0 + ceza 30 + %başına 6 (en çok 150) toplamdan düşülür, ceza satırı + ders. `scienceGoals:[{id,name,value,status,done,reason}]`.
  - **Dengeleme (seed 42):** Ay A (+matkap) 4.165/4.300 READY success, 2 hedef; Ay B (fc-rad, rad-monitor, hd kamera, +çevre ist.+dedektör) 3.460 RISKY (kapsül dayanımı WARN) success, 2 hedef; Mars A (al tekerlek) 1.009 READY success, 2 hedef; Mars B (çift bilgisayar, **powerMode eco**) 789 READY success, 1 hedef (+1 kısmi). Açgözlü Ay: fırlatma aracı 41/40 U + bütçe aşımı; açgözlü Mars: gezgin 36/30 U + alet yuvası.
  - **Test:** `node --test "test/sim/*.test.js"` → 58/58 geçti (yeni `test/sim/stage8.test.js` 10 test; `mini.stage8Data()` eki).
  - **Bilinen sorunlar / şefe:** (1) `telemetry.budget` artık nesne — `public/js/screens/simulation.js:70` hâlâ sayı bekliyor (`t.cost > t.budget`), sahibi düzeltmeli (filter.js iki biçimi de okuyor). (2) `fmt` yardımcı fonksiyonu evaluate/debrief'te tanımsızdı (metin satırlarında ReferenceError riski); `util.fmt` (tr-TR biçim) eklendi. (3) Uzay aracı karar sayısı 13 (≈10'un üstü). (4) Ay arazi tehlikesi zaten küçük (~%2), rezervin Ay simülasyonundaki etkisi sınırlı; Mars'ta belirgin.
  - **Tur 1 düzeltmeleri:** O-1 debrief'e `sectionTotal` + `adjustments:[{id:'budget-overrun'|'mission-failure', title, points(<0), text}]`; skor = bölüm toplamı + düzeltmeler (başarısızlıkta kalan puanın %30'u ayrı satır; ceza puanı 0'ın altına indirmez), testle sabit. D-1 ölçüldü (500 tohum): Ay A failure %2,4, Mars A %2,4, Mars B %2,4 (READY ≲%10 sağlanıyor; katsayı değişmedi); Ay B (RISKY) %13. `evaluation.launchNote` (durum başına Türkçe açıklama; READY: "kalan risk parça güvenilirliğinden gelir") eklendi — arayüz göstermeli. D-3 gereksinim metinleri Türkçe ad kullanıyor (görevde `tagNames` sözlüğü → yoksa sağlayan parçanın adı); `unmetRequirements[].requiresNames` eklendi; `telemetry.thermal.label` 'Uygun'|'Uyarı' eklendi ("Durum PASS" yazan arayüz bunu kullanmalı). D-4 "yakış" → "Ay'a geçiş ateşlemesi (TLI)", "ateşlemesini tamamla", "İniş yakıtına ayrılan", sim metni "motor ateşlemelerini". Test 61/61.
### Modül AG: Oda/görünüm/socket + README
- [x] Durum: tamam
- **Sahip:** `server/rooms.js`, `server/filter.js`, `server/constants.js`, `server/index.js`, `server/chat.js` (gerekmezse dokunma), `test/rooms.test.js`, `test/filter.test.js`, `test/chat.test.js`, `README.md`
- **Arayüz:** 8.3. **Bağımlılık:** AF arayüzü (8.2; testlerde sahte sim ile).
- **Notlar:**
  - **Görünüm (herkes):** `launchStatus: 'READY'|'RISKY'|'MISSING'|'INSUFFICIENT'|null` (değerlendirme yoksa null), `capacity: { [moduleId]: { name, usedU, capacityU|null, freeU|null, mineU } }` (telemetri yoksa `{}`; operatörde mineU 0), `vehicle[i].auto` (bool), `vehicle[i].volumeU` (yoksa 0).
  - **Mühendis:** `engineer.budgetBand: 'ok'|'tight'|'over'|null` (bütçe bilinmiyorsa null), `engineer.catalog[i].volumeU` (+ `auto` varsa), `canAdd` NO_SPACE dahil, `engineer.modules[].categories[].auto` (varsa), readiness `kind`; yalnız payload'da `engineer.scienceGoals: [{ id, name, desc, status, missingTags }]`. Bütçe kalemleri (`kind:'budget'` ya da `id:'budget'`) mühendise hiç gitmez.
  - **Operatör:** `director.launchStatus`, `director.budget: { budget, spent, remaining, byRole:{rocket,spacecraft,payload} }` (yoksa: sayı telemetry.budget/cost → build cost'ları → görev bütçesi), `director.ledger: [{ id, ts, role, playerName, action:'add'|'remove'|'auto', itemId, itemName, moduleId, cost }]` (yeni→eski; remove'da cost NEGATİF, auto'da playerName 'Standart donanım'), `director.telemetry.capacity` (tam, byRole dahil), `director.telemetry.scienceGoals` (beyaz liste: id,name,desc,status,missingTags,value), `director.costs[uid]` artık build girişindeki cost.
  - **Oda:** build girişi `{ uid, itemId, moduleId, role, cost, auto? }`; standart donanım `selectMission`'da ve her `enterDesign`'da eksikse eklenir (itemId+moduleId ile tekilleşir; `sim.autoItems` yoksa atlanır). `room.ledger` (max 300, `room.ledgerSeq` sayaç), mission-select'e dönüşte ve `selectMission`'da sıfırlanır, 'same'de korunur. `launch(code, pid, { confirm })`: tek engel 3 onay; durum `evaluation.launchStatus` yoksa `constants.launchStatusOf(ev)` ile türetilir (kritik physical→INSUFFICIENT, kritik missing→MISSING, overall FAIL→INSUFFICIENT, WARN/FAIL→RISKY). Socket `mission:launch { confirm?: boolean }` (boolean değilse BAD_REQUEST).
  - **Hata kodları:** `NO_SPACE` (canAdd gerekçesi aynen; yoksa "Modülde yer yok."), `LOCKED` ("Standart donanım çıkarılamaz."), `LAUNCH_CONFIRM` ("Tasarım hazır değil (Riskli|Eksik|Fiziksel yetersiz): <en çok 4 sistem adı>. Yine de fırlatmak için onayla."). `constants`: `ERROR_MESSAGES, LEDGER_MAX, LAUNCH_STATUSES, LAUNCH_STATUS_TR, launchStatusOf`.
  - **Test:** `node --test test/rooms.test.js test/filter.test.js test/chat.test.js` → 42/42 geçti (ilk koşuda kendi yeni testimdeki eski-sim varsayımı hatalıydı, düzeltip bir kez daha koşuldu). chat.js/chat.test.js değişmedi.
  - **Bilinen:** gerçek AF sim'iyle duman denemesi yapılmadı (AF paralel); `autoItems` dönen parça canAdd'den geçirilmez (sim'e güvenilir). README ayar bölümü yeni ayar anahtarlarını adlandırmadan genel yazıldı (AF notlarına göre isim eklenebilir).
  - **Tur 1 düzeltmeleri:** O-2 `director.catalog[rol][i].cost` eklendi (yalnız operatör; mühendis kataloğunda yokluğu testli). D-2 `ledgerSeq` mission-select'e dönüşte ('new', geri) ve `selectMission`'da 0'a sıfırlanır (testli). rooms+filter 28/28 geçti. Ek: üst düzey `launchNote` (string|null, herkese), `thermal.label` (operatör tam telemetri + spacecraft), `director.unmetRequirements[].requiresNames`; debrief `sectionTotal`/`adjustments` olduğu gibi geçer (testli). filter 14/14.
### Modül AH: Mühendis arayüzü
- [x] Durum: tamam
- **Sahip:** 8.4'teki dosyalar. **Bağımlılık:** 8.3 görünüm biçimi.
- **Notlar:**
  - **Ekran (engineer.js):** başlıkta SÜRE + `TASARIM <launchStatus>` çipi (yoksa overall'dan türetilir) + `BÜTÇE RAHAT/SINIRDA/AŞILDI` çipi (`budgetBand` null → gizli; sayı yok). Paneller: Rolüm (brifing katlı), İhtiyaçlarım, Araç·Alan·Telemetrim, Hazırlığım, (payload) Bilim hedefleri, **Kararlarım** (odak paneli), Seçili seçenek, Ayarlarım. "Takılı ekipmanım" paneli kalktı (takılı olan karar kartında + alan yuvasında görünür).
  - **Kararlar (catalog.js):** kategori = karar kartı; üstte "ZORUNLU KARARLAR n/m" + karar şeridi (✓ seçildi / ⚠ zorunlu eksik / ○ isteğe bağlı; dar ekranda yatay kaydırma). Kartta seçenekler yan yana: hacim rozeti (U), aynı satırlarda değişen ölçüler (en çok 4), kısa artı/eksi ("+ En hafif", "− En çok yer kaplar"; kendi gördüğü sayıların kıyası, kural değil), `canAdd` gerekçesi (NO_SPACE kırmızı). Tek seçimlik kararda dolu kategoride **BUNU SEÇ** = çıkar + tak (tak başarısızsa eskisi geri takılır). Standart donanım (`modules[].categories[].auto`, katalog `auto`, ya da tek seçenekli + auto takılı) karar listesinden çıkar; katlı "STANDART DONANIM · kilitli" satırında. Yeni export'lar: `decisionList(catalog, modules, vehicle)`, `standardRow(kit, decisions, vehicle)`; `catalogView(kit, o)` artık `onRemove`, `onSwap` de alır. `itemDetail`, `installedList`, `categoryTabs`, `FIELDS` korunur.
  - **Alan (vehicle.js):** `mountVehicle` imzası aynı; `set()` ek alanları (hepsi isteğe bağlı) `mineRole`, `capacity`, `preview:{moduleId,volumeU,name}`. `capacity` verilmezse `core.getState().capacity` okunur → operatör/inceleme değişmeden modül alanı görür. Her modül: blok şeridi (blok genişliği = volumeU; kendi rolüm dolu rol rengi, diğerleri gri, standart taralı, boş kesik), "used / cap U · n boş", ORTAK etiketi; seçili seçenek hayalet blokla önizlenir (sığmazsa kırmızı + not). Yeni takılan blok 220 ms giriş animasyonu (reduced-motion'da yok). `capacity` boşsa bölüm gizli.
  - **readiness.js:** `export const KIND_TR = { ok:'HAZIR', missing:'EKSİK', risky:'RİSKLİ', physical:'FİZİKSEL YETERSİZ', budget:'BÜTÇE' }`, `export function kindOf(item) → 'ok'|'missing'|'risky'|'physical'|'budget'` (item.kind geçerliyse o; PASS→ok; yoksa id/system/text'ten: bütçe→budget, eksik/gereksinim→missing, Δv/TWR/kütle/temas→physical, diğer→risky). Ayrıca `KIND_TONE`, `kindBadge(kit, kind)`. Liste türe göre sıralı + tür rozetli; `readinessCounts` eski alanlara ek `kinds:{...}`; `countsStrip` tür sayıları (HAZIR + sıfır olmayanlar). Mühendise "fırlatmayı engellemez ama simülasyonda sorun çıkarır" metni.
  - **settings.js:** tamamen `settingDefs`'ten: `options`/`optionInfo` → seçenek düğmeleri (açıklama varsa kart: label + desc/note), number → kaydırıcı (birimsiz 0..1 → %). Anahtar sabit kodlaması (KNOWN_OPTIONS, propellantLoad) kaldırıldı.
  - **util.js:** `LAUNCH_TR`, `BUDGET_BAND`, `tagName(tag)` eklendi. **work.css:** karar kartı/şerit, alan yuvaları, tür rozetleri, durum çipleri, bilim hedefleri; eski `.ad-tab/.ad-item` stilleri silindi; ızgara `ad-grid--goals` varyantı.
  - **Görsel kontrol:** yapıldı — gerçek sunucu (port 3123) + 3 bot socket + tarayıcıda payload mühendisi; 1440×900 ve 375×812 ekran görüntüsü, konsol hatası yok, yatay taşma yok; TAK → kart TAKILI + "BUNU SEÇ" değiştirme düğmesi doğrulandı. Düzeltilen: boş hazırlıkta "0 HAZIR" gizlendi, durum etiketi büyük harf, mobilde karar şeridi tek satır.
  - **Bilinen/denenemeyen:** AF bitmediğinden sunucu `capacity:{}` ve boş `scienceGoals` döndü → alan yuvaları ve bilim hedefleri kartı gerçek veriyle GÖRÜLMEDİ (kod incelemesiyle). Bilim etiketi Türkçe adları istemci sözlüğünde (`tagName`, bilinmeyen etiket okunur hale getirilir). Sahne (scene2d.js, AE) kapasiteyi çizmez; alan yuvaları sahnenin altında ayrı bölüm. Mobilde İLETİŞİM düğmesi (comms.js) kart içeriğinin bir kısmını örtebiliyor.
  - **Tur 1 düzeltmeleri:**
    - D-3: `util.tagName` sözlüğü verideki tüm requires/provides etiketlerini kapsıyor. Yeni `trTags(text)`, sunucu metnindeki ham etiketleri Türkçeye çeviriyor; hazırlık metni, parça açıklaması, uyumsuzluk ve canAdd gerekçesinde kullanılıyor. Parçanın "Sağlar/Gerektirir" çipleri Türkçe.
    - D-6: `.ad-vehicle__scene` ve `.ad-vehbox` için `overflow:hidden` + `contain:paint`; sahne ile MODÜL ALANI arasına çizgi eklendi.
    - D-7: `mountCommsDrawer(root, getState, api, opts)`'a geriye uyumlu `opts.fabHost` eklendi. Mühendiste İLETİŞİM düğmesi başlık şeridinde duruyor; telefonda sağ altta 56px ikon düğme ve sayfa altında 96px boşluk var.
    - Kontrol: 1366×768 ve 375×812'de ekran görüntüsü alındı; sahne taşmıyor, sayfada yatay taşma yok.
    - Açık (AI'nin `telemetry.js`'i): ısı satırında "Durum PASS" ham gösteriliyor; Δv satırlarında "lunar-transfer" gibi ham aşama kimliği görünüyor.
### Modül AI: Operatör komuta merkezi + inceleme + sonuç
- [x] Durum: tamam
- **Sahip:** 8.5'teki dosyalar. **Bağımlılık:** 8.3 görünüm biçimi.
- **Notlar:**
  - `operator.js` → "KOMUTA MERKEZİ": üst bant = fırlatma durumu (büyük kelime + 4 basamaklı ölçek YETERSİZ/EKSİK/RİSKLİ/HAZIR) + 4 gösterge (kalan bütçe + rol renkli harcama çubuğu, toplam kütle/sınır, enerji marjı, TWR + en dar Δv marjı). Izgara: ekip sistemleri (rol başına tür sayıları, parça/kütle/harcama, eksik kategoriler), araç + modül kapasitesi, aktarılacak değerler (AKTAR korunur), hedefler + bilim hedefleri (value dahil), harcama defteri (kaydırılır), katlanır ayrıntılar (türe göre hazırlık raporu + birleşik telemetri).
  - `telemetry.js` ekleri (engineerTelemetry/directorTelemetry imzaları aynen): `capacityView, scienceGoalsView, tightestDv, kindOfItem, kindCounts, KIND_LABEL, KIND_ORDER, LAUNCH, LAUNCH_ORDER, launchStatusOf`. `readiness.js` ad alanı içe aktarımıyla (`import * as R`) AH'nin `kindOf/KIND_TR`'si varsa kullanılır, yoksa yerel yedek. YENİ `widgets/ledger.js` → `ledgerView(kit, entries, { moduleName, limit })`.
  - `review.js`: dört durum açıklaması, kalemler türe göre gruplu (Hazır katlanır); FIRLAT yalnız eksik onayda kapalı; READY → kısa onay modalı `{confirm:false}`, değilse risk modalı (en çok 5 kalem + etkisi) → `{confirm:true}`; `LAUNCH_CONFIRM` ack'inde aynı modal.
  - `debrief.js`: BİLİM HEDEFLERİ (yapıldı/yapılamadı + neden) ve BÜTÇE RAPORU (harcanan/bütçe, aşım M$ ve %, `sections` içindeki `budget` bölüm puanı) panelleri; alan yoksa gizli. `command.css` yeni, `index.html`'e link eklendi; `sim.css`'e yalnız `.deb-goal*/.deb-budget*`.
  - Geri uyum: `launchStatus` yoksa kalem/overall'dan türetilir; `director.budget` yoksa `telemetry.cost/budget`; `capacity`/`ledger`/`scienceGoals` yoksa ilgili bölüm gizli.
  - Doğrulama: sahte state'li yerel düzenekle (sunucusuz) 1440 ve 390 px ekran görüntüsü — operatör, inceleme + risk modalı (emit `{confirm:true}` görüldü), debrief; yatay taşma yok, konsol hatası yok. Gerçek sunucuyla uçtan uca denenmedi.
  - Düzeltme turu 1: debrief puan dökümünde `sectionTotal` + `adjustments` satırları + TOPLAM (bütçe raporunda budget-overrun cezası); `launchNote` komuta merkezi ve inceleme durum satırında (yoksa sabit metin, `launchLine` telemetry.js); ısı durumu `thermal.label` ya da Türkçe (Uygun/Uyarı/Yetersiz), engineerTelemetry dahil. Komuta merkezinde katalog gösterimi olmadığı için `catalog.cost` kullanılmadı. Yalnız kod incelemesi + node --check. Ek: PHASE_NAME tüm Ay/Mars aşama kimlikleriyle tamamlandı, bilinmeyen kimlik okunur hâle getirilir; `engineerTelemetry(kit, role, tel, names?)` isteğe bağlı 4. parametre (nesne ya da `[{id,name}]`, ör. `state.simulation.phaseList`); risk modalı ve bilim hedefi eksik etiketleri `trTags` (varsa) ile Türkçe.

## Test-düzelt turları — Aşama 8 (en fazla 3)
## Son durum — Aşama 8 (şef doldurur)


---

# AŞAMA 9 — İngilizce sürüm (varsayılan dil İngilizce)  ← ŞU AN

Kaynak: kullanıcı "oyunu tamamen bu haline bir de İngilizce sürüm ekle, default İngilizce başlasın".
**Kararlar:**
- Dil **oyuncu başına**: `'en' | 'tr'`, varsayılan `'en'`. Aynı odada biri Türkçe biri İngilizce oynayabilir. Oyun mantığı, sayılar, sonuç dilden BAĞIMSIZ (aynı tohum → aynı sonuç).
- İstemci dili `localStorage['pp.lang']`'te (yoksa `'en'`); açılış ekranında ve AYARLAR'da EN/TR anahtarı; değişince ekran anında yeniden çizilir ve sunucuya bildirilir.
- Sunucu metinleri (hata mesajları, hazırlık/simülasyon/debrief metinleri, görev/ekipman adları ve açıklamaları, brifingler) oyuncunun dilinde gelir. Sohbet mesajları çevrilmez (oyuncu yazısı).
- Mevcut Aşama 8 davranışı, mimari, olaylar, asimetrik bilgi aynen korunur; yeni bağımlılık yok. Sim fonksiyonları `lang` verilmezse `'tr'` (geri uyum, mevcut testler).
- İş akışı: geliştirici yalnız kendi birim testlerini bir kez koşar; sonda tek testci turu + en çok 3 düzeltme turu.

## 9.1 Veri çevirisi (sahip: AK) — `data/i18n/en/*.json` (yalnız İngilizce bindirme; TR dosyaları değişmez)
- `data/i18n/en/equipment-lunar.json`, `equipment-mars.json`: `{ "items": { "<itemId>": { "name", "desc", "incompatible": { "<tag>": "reason" }, "refs": { "<field>": "note" } } } }`
- `data/i18n/en/missions-lunar.json`, `missions-mars.json`: `{ "name", "summary", "educationalNote", "nasaReality", "modules": { "<id>": "name" }, "phases": { "<id>": "name" }, "objectives": { "<id>": "name" }, "briefing": { "director": [..], "rocket": [..], "spacecraft": [..], "payload": [..] }, "settings": { "<key>": { "label", "help", "unit?", "optionInfo": { "<opt>": { "label", "desc", "note?", "text?", "help?" } } } }, "scienceGoals": { "<id>": { "name", "desc" } }, "tagNames": { "<tag>": "name" }, "scienceTags": { "<tag>": "name" }, "categories": { "<category>": "name" } }`
  (TR görev JSON'unda başka çevrilecek metin alanı varsa aynı adla ekle.)
- `data/i18n/en/sources.json`: `{ "<sourceId>": { "title" } }` (yalnız Türkçe başlıklar için).
- Dizi sırası TR ile birebir (brifing satırları). Sayılar metinde aynen kalır; İngilizce biçim (nokta ondalık, virgül binlik).

## 9.2 Simülasyon dili (sahip: AJ) — `server/sim/*`
- Loader, `data/i18n/en/*` bindirmesini (varsa) yükler. Eksik alan → TR'ye düşer.
- Dil parametresi (son, isteğe bağlı `opts = { lang }`; varsayılan `'tr'`):
  `listMissions(lang)`, `getMission(id, lang)` (metin alanları seçilen dilde, sayılar aynı), `catalogFor(missionId, role, lang)`, `publicItem(itemId, lang)`, `getItem(id, lang)`,
  `canAdd(build, missionId, role, itemId, moduleId, lang)` (reason dilde), `evaluate(missionId, build, settings, { lang })`, `simulate(missionId, build, settings, seed, { lang })`, `debrief(missionId, evaluation, simResult, team, { lang })`.
  Var olan çağrı imzaları bozulmaz (yalnız sona ek).
- Tüm üretilen metinler (readiness text/system, launchNote, needs label, unmetRequirements text, thermal.label, capacity name, scienceGoals adları/notları, simulate olay/aşama metinleri ve reason, debrief başlık/satır/ders/adjustments, NO_SPACE vb. gerekçeler) yeni `server/sim/i18n.js` mesaj kataloğundan `msg(lang, key, params)` ile gelir. Sayı biçimi dile göre (`fmt(v, d, lang)`: tr-TR / en-US).
- Determinizm: aynı tohum, farklı dil → aynı status/outcome/score; testle sabitle.

## 9.3 Oda/görünüm (sahip: AL) — `server/rooms.js, filter.js, constants.js, index.js, chat.js`, testleri, README.md
- Oyuncu kaydına `lang` (`'en'` varsayılan). Olaylar: `room:create {name, lang?}`, `room:join {code, name, lang?}`, `room:rejoin {code, playerId, lang?}`, YENİ `player:lang {lang}` (her fazda; geçersiz → BAD_REQUEST). Değişince o oyuncuya yeni `state`.
- Hata mesajları iki dilli: `ERROR_MESSAGES = { en: {...}, tr: {...} }` (+ sohbet hataları, `GameError` Türkçe mesajları → anahtar + parametre). Ack `message` oyuncunun dilinde. `kicked {reason}`, `room:closed {reason}` alıcının dilinde.
- Değerlendirme dil başına önbellek: `room.evaluation` yerine dil başına (`room.evalByLang = { tr, en }`, build/ayar değişince sıfırlanır, gerektiğinde hesaplanır). Simülasyon: tek tohum; sonuç her dilde aynı tohumla üretilir (ya da `simulate` iki kez). Debrief dil başına.
- Defter (`ledger`) `itemName` görünümde oyuncunun diline göre `sim.getItem(itemId, lang).name`; `playerName` 'Standart donanım' → dil anahtarı. `pushLog` metinleri dilde.
- `viewFor(room, playerId, sim, chat)` oyuncunun `lang`'ını kullanır; görünüme `me.lang` eklenir.
- `GET /api/sources?lang=en` başlıkları dilde.
- README'ye kısa "Language / Dil" bölümü ve İngilizce kısa özet (Quick start).

## 9.4 İstemci i18n çekirdeği (sahip: AM) — `public/js/i18n.js` (YENİ) — diğer istemci geliştiricileri bu API'ye göre paralel yazar
```js
export function getLang()            // 'en'|'tr'; localStorage 'pp.lang' (try/catch), yoksa 'en'
export function setLang(lang)        // kaydeder, <html lang> günceller, abonelere bildirir
export function onLang(fn)           // abone ol; dönen fonksiyon aboneliği kaldırır
export function register(dict)       // dict = { en: { 'ns.key': 'text {param}' }, tr: {...} }; birleştirir
export function t(key, params)       // geçerli dil → yoksa en → yoksa key; {param} yerleştirme; params.n ile basit çoğul: 'key' + (n===1?'':'_plural') varsa
export function locale()             // 'en-US' | 'tr-TR'
export function fmtNum(v, digits=0)  // Intl.NumberFormat(locale())
export function upperL(s)            // toLocaleUpperCase(locale())
```
- Sözlükler ad alanına göre ayrı dosyalarda, her dosya `register(...)` çağırır ve ilgili ekranlar onu import eder: `public/js/lang/shell.js` (AM, anahtar öneki `shell.`), `public/js/lang/work.js` (AN, `work.`), `public/js/lang/command.js` (AO, `cmd.`). Ortak rol/faz adları `shell.role.*`, `shell.phase.*` (AM tanımlar: `shell.role.director` = "Operator", rocket = "Propulsion Engineer", spacecraft = "Spacecraft Engineer", payload = "Science & Payload Engineer"; kısa: `shell.roleShort.*` = OPERATOR/PROPULSION/SPACECRAFT/SCIENCE).
- AM: dil değişince `core` bulunduğu ekranı yeniden çizer ve `player:lang` gönderir; `room:create/join/rejoin` yüküne `lang` ekler.
- Tüm sabit arayüz metinleri `t()` ile; sayı/büyük harf biçimleri `fmtNum/upperL` ile (tr-TR sabit kullanımları kalkar).

## 9.5 İstemci ekran sahipliği
- **AM:** `public/js/i18n.js`, `public/js/lang/shell.js`, `public/js/core.js`, `public/js/app.js`, `public/js/ui.js`, `public/js/screens/{home,create,join,lobby,mission-select,briefing,how,data,settings}.js`, `public/index.html`, `public/css/base.css` (yalnız dil anahtarı stili gerekirse). Açılış ekranında ve ayarlarda EN | TR anahtarı.
- **AN:** `public/js/lang/work.js`, `public/js/screens/{engineer,comms}.js`, `public/js/widgets/{catalog,vehicle,readiness,settings,util,frame}.js`, `public/css/work.css`.
- **AO:** `public/js/lang/command.js`, `public/js/screens/{operator,review,debrief,simulation}.js`, `public/js/widgets/{telemetry,ledger}.js`, `public/scene2d.js` (sahne etiketleri), `public/demo.html`, `public/demo.js`, `public/css/{command,sim}.css` (gerekirse).
- Paylaşılan yardımcılar: `ui.js` (AM) içindeki `ROLE_NAMES/ROLE_SHORT/PHASE_NAMES/fmt/confirmModal` varsayılan etiketleri dil duyarlı olur (getter/fonksiyon; dışa açık adlar korunur). `util.js` (AN) içindeki `ROLE_NAME/ROLE_SHORT/STATUS_TR/upper/num` vb. dil duyarlı olur (adlar korunur; nesneler için getter ya da her çizimde güncel değer).

## Modüller (Aşama 9) — altısı paralel
### Modül AJ: Sim dili + mesaj kataloğu
- [x] Durum — **Sahip:** `server/sim/*.js` (yeni `server/sim/i18n.js`), `test/sim/*.test.js`, `test/fixtures/*`. **Arayüz:** 9.2 (bindirme biçimi 9.1). **Bağımlılık:** yok.
- **Notlar:** İmzalar 9.2 ile birebir: `listMissions(lang)`, `getMission(id, lang)`, `getItem(id, lang)`, `catalogFor(m, role, lang)`, `publicItem(id, lang)`, `canAdd(build, m, role, itemId, moduleId, lang)`, `evaluate(m, b, s, {lang})`, `simulate(m, b, s, seed, {lang})`, `debrief(m, ev, sim, team, {lang})`. Son parametre `'en'` metni ya da `{lang:'en'}` olabilir; başka/eksik → `'tr'`. `i18n.js`: `msg(lang, key, params)`, `normLang`, `langOf`, `CATALOG`; `util.fmt(v, d, lang)`. Loader `data/i18n/en/*` bindirmesini (9.1 + AK ekleri `refs` nokta yolu, `categories`) yükler; eksik alan TR'ye düşer; sabit veriyle `createSim({ ..., i18n: { en: { items, missions:{id:ov}, sources } } })`. Birimler de dilde (`gün`→`days`, `Mb/gün`→`Mb/day`…). Debrief'teki "parça arızası" dersi iki dilin olay metnini de tanır. Test: `test/sim/i18n.test.js` (determinizm + EN çıktıda Türkçe yok). TR metinleri değişmedi (eski 61 test geçiyor).
### Modül AK: İngilizce veri bindirmesi
- [x] Durum — **Sahip:** `data/i18n/en/*.json`, `docs/VERI_KAYNAKLARI.md` (yalnız kısa dil notu). **Arayüz:** 9.1. **Bağımlılık:** yok.
- **Notlar:** 5 dosya yazıldı; 115 parça, 2 görev, tüm ayar/hedef/etiket/kategori kapsandı (betikle doğrulandı, TR karakter yok). Ek alan: görevlerde `refs: { "<nokta.yolu>": "note" }` (ör. `"phases.launch.dvMs"`, `"limits.minLanderTWR"`). `sources.json` yalnız `pp-model` (tek Türkçe başlık). `categories` TR görev JSON'unda ad taşımadığı için yeni İngilizce adlar.
### Modül AL: Oda/görünüm dil desteği + README
- [x] Durum — **Sahip:** 9.3 dosyaları. **Bağımlılık:** 9.2 imzaları (testte sahte sim).
- **Notlar:** `constants`: `MESSAGES/ERROR_MESSAGES = {en,tr}`, `msg(lang,key,params)` (`role/roles/status` parametreleri dile çevrilir), `CHAT_ERROR_MESSAGES = {en,tr}`, `LANGS, DEFAULT_LANG, isLang, normLang, roleName, ROLE_NAMES_I18N, LAUNCH_STATUS_I18N`; `GameError(code, key|metin, params)` + `localize(lang)`. Oda: oyuncuda `lang` (varsayılan en), `createRoom(name,sid,lang)`, `joinRoom(code,name,sid,lang)`, `rejoin(...,lang)`, YENİ `setLang(code,pid,lang)`, `langOf`; hata mesajı işlemi yapanın dilinde. `room.evaluation`/`room.sim.result`/`room.debrief` temel dil (en); diğer dil `evalFor/simResultFor/debriefFor` (rooms.js'ten export) ile aynı build/ayar/tohum/ekip istatistiğiyle tembel hesaplanıp önbelleğe alınır. Sim çağrılarına lang geçirilir (sim yok sayarsa da çalışır). Görünüm: `me.lang`, metinler oyuncunun dilinde; defter itemName + 'Standart donanım' dilde; kicked/room:closed alıcının dilinde; `player:lang` (geçersiz → BAD_REQUEST, yalnız o oyuncuya state); `/api/sources?lang=` (`data/i18n/en/sources.json` bindirmesi). Log key/params + en text (istemciye gitmiyor). Test: rooms+filter+chat 47/47. Gerçek AJ sim'iyle denenmedi.
### Modül AM: İstemci i18n çekirdeği + kabuk ekranları
- [x] Durum — **Sahip:** 9.5 AM. **Bağımlılık:** yok.
- **Notlar:** i18n.js 9.4 imzalarına birebir (getLang/setLang/onLang/register/t/locale/fmtNum/upperL); `t` çoğulu önce geçerli dilde, sonra en'de arar; eksik parametre `{p}` olarak kalır. Ek: `?lang=en|tr` URL parametresi dili seçer; `storage` olayıyla başka sekme/iframe dili senkron (demo iframe'leri ana sayfayı izler). core: room:create/join/rejoin yüküne `lang` otomatik eklenir (emit içinde); dil değişince odadaysa `player:lang {lang}` gönderir ve `onEvent('lang')` yayar. app: dil değişince etkin ekran + iletişim modülü destroy→render ile baştan çizilir (ekranlar render'da `t()` okumalı), kabuk + index.html `data-i18n`/`data-i18n-aria` metinleri güncellenir. ui.js: `ROLE_NAMES/ROLE_SHORT/PHASE_NAMES` getter'lı dondurulmuş nesneler (adlar aynı; her okuma geçerli dil), `statusPill` varsayılanları, `modal` TAMAM/Kapat, `confirmModal` EVET/VAZGEÇ varsayılanları dilde, `fmt.num` `locale()` ile; YENİ `langSwitch({className})` ve `LANGS` dışa açık. Stil: base.css sonunda `.lang-switch*`, `.home__lang*`. Ekran görüntüsü turu şef isteğiyle atlandı; yalnız `node --check` + node'da i18n duman testi.
### Modül AN: Mühendis tarafı çevirisi
- [x] Durum — **Sahip:** 9.5 AN. **Bağımlılık:** 9.4 API (AM yazarken dosya yoksa API'ye göre yaz).
- **Notlar:** `lang/work.js` (work.*, en+tr; kategori + etiket adları iki dilde, `TAG_IDS` export). util.js'te `ROLE_NAME/ROLE_SHORT/ROLE_DUTY/STATUS_TR/LAUNCH_TR/BUDGET_BAND/REF_CLASS` aynı adla getter nesneleri (rol adları `shell.role.*`, yoksa `work.role.*` yedeği); `num/upper` locale(); yeni `pct(v,d)` (TR %12 / EN 12%). `tagName/trTags` geçerli dilde. readiness `KIND_TR` getter. Engineer/comms ekranları dil değişince kabuk yeniden çizmediyse kendini yeniden çizer (onLang). work.css değişmedi. Doğrulama: `node --check` + Node'da getter EN/TR kontrolü; ekran görüntüsü alınmadı (şef isteğiyle atlandı).
### Modül AO: Operatör/inceleme/simülasyon/sonuç/demo çevirisi
- [x] Durum — **Sahip:** 9.5 AO. **Bağımlılık:** 9.4 API.
- **Notlar:** YENİ `public/js/lang/command.js` (`cmd.` 308 anahtar, en+tr eşit; ayrıca `tk(key)` = yoksa null, `roleShort/roleName` → `shell.roleShort/role.*`, yüklenmemişse İngilizce yedek). operator/review/debrief/simulation, telemetry (PHASE_NAME → `cmd.phase.*`; `KIND_LABEL`/`LAUNCH` artık dil getter'lı, kopya yok), ledger, scene2d (modül yedek adları, "n parça", aria; `./js/i18n.js` import eder) görünen metinleri t()'de. Bölüm imzalarına `getLang()` eklendi; debrief dil/sonuç değişince yeniden çizer; sim şerit anahtarı dili içerir. demo.html/demo.js: varsayılan EN, üst çubukta EN|TR anahtarı (`localStorage pp.lang`), değişince yüklü panel iframe'leri yeniden yüklenir (slot oturumuyla geri bağlanır). Doğrulama yalnız `node --check` + anahtar kapsama betiği (ekran görüntüsü turu şef isteğiyle atlandı). Sayılar util/ui biçimleyicilerinden (AN/AM yerelleştirir).

## Test-düzelt turları — Aşama 9 (en fazla 3)
## Son durum — Aşama 9 (şef doldurur)
