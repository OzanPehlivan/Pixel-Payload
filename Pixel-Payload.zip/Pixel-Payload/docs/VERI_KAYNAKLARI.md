# Veri kaynakları ve varsayımlar (Modül Y)

Erişim tarihi: 2026-11-15. Kanonik veri `data/` altındadır: `science/sources.json`, `physics/constants.json`, `equipment/{lunar,mars}.json`, `missions/{lunar,mars}.json`.
Oyun sırasında hiçbir API'ye bağlanılmaz; tüm değerler bu dosyalardaki yerel kopyadır.

## Kaynaklar

| id | Kaynak | Yayıncı | Kullanıldığı yer |
|---|---|---|---|
| nasa-sls | https://www.nasa.gov/reference/space-launch-system/ | NASA | SLS itkisi (8,8 Mlbf), yan itici 3,6 Mlbf ve 1,6 Mlb, çekirdek 733.000 galon, ICPS RL10 24.750 lbf (ayrıca `ld-eng-hydrolox` iniş motoru itkisi, RL10 sınıfı ~110,1 kN), Ay'a >27 t |
| l3harris-rs25 | https://www.l3harris.com/all-capabilities/rs-25-engine | L3Harris | RS-25: 512.000 lbf vakum, Isp 452 s vakum / 366 s deniz seviyesi |
| nasa-orion | https://www.nasa.gov/reference/orion-spacecraft/ | NASA | Orion işlevleri, fırlatma kaçış sistemi (sayısal değer yok) |
| nasa-esm | https://www.nasa.gov/reference/european-service-module/ | NASA | ESM: 1 ana + 8 yardımcı + 24 RCS motoru; 4 kanat × 3 panel, 15.000 GaAs hücre; su/O2/N2 dörder tank |
| nasa-artemis | https://www.nasa.gov/humans-in-space/artemis/ | NASA | Dört kişilik mürettebat, mimari |
| nasa-gateway | https://www.nasa.gov/mission/gateway/ | NASA | Ay yörüngesi mimarisi (bağlam) |
| nasa-hls | https://www.nasa.gov/reference/human-landing-systems/ | NASA | Orion yüzeye inmez; HLS ayrı sistemdir |
| nasa-spacesuit | https://www.nasa.gov/humans-in-space/what-is-a-spacesuit/ | NASA | Giysi sırt çantası işlevleri (sayısal değer yok) |
| ntrs-ls-2010 | NTRS 20100036823 | NASA NTRS | O2 tüketimi 0,84 kg/kişi-gün (BVAD tabanlı) |
| ntrs-ices-2022 | NTRS 20220002294 (ICES-2022-388) | NASA NTRS | BVAD'a atıfla içme suyu 2,79 kg/gün |
| nasa-eclss-ochmo | OCHMO ECLSS teknik notu | NASA | ECLSS işlevleri |
| nasa-m2020 | https://science.nasa.gov/mission/mars-2020-perseverance/ | NASA | Görev genel bilgisi |
| nasa-m2020-instruments | .../science-instruments/ | NASA | Alet kütle, güç, veri değerleri |
| nasa-m2020-rover | .../rover-components/ | NASA | Gezgin 1.025 kg, MMRTG ~110 W / 45 kg / 4,8 kg PuO2, teker 52,5 cm, kol 2,1 m, UHF 2 Mbps, X bandı 160/800 bps, sürüş <200 W |
| jpl-m2020-getting | JPL fırlatma basın kiti — Getting to Mars | NASA JPL | Seyir 8 itici, PICA kalkan (~1.300 °C), iniş kademesi 8 motor, gök vinci |
| jpl-m2020-quickfacts | JPL fırlatma basın kiti — Quick Facts | NASA JPL | Atlas V 541, iniş tarihi, gezgin kütlesi |
| jpl-m2020-landing | JPL iniş basın kiti | NASA JPL | 21,5 m paraşüt, ~11 km'de ~940 mil/sa açılma, >12.000 mil/sa giriş |
| ula-atlasv | Atlas V kullanıcı kılavuzu | ULA | Atlas V kademe değerleri (yalnız `estimated` olarak, yuvarlanmış) |
| nssdc-earth / nssdc-moon / nssdc-mars | NSSDCA gezegen bilgi sayfaları | NASA | μ, yarıçap, yerçekimi, kaçış hızı, Mars atmosferi (0,016 kg/m³, 11 km), mesafeler |
| nist-c / nist-g0 | NIST CODATA | NIST | Işık hızı, g0 |
| pp-model | `docs/VERI_KAYNAKLARI.md` | Pixel Payload | Tahmin ve oyun değerleri |

## Sınıflar
- **measured**: kaynakta doğrudan yazan değer (birim dönüşümü dışında değiştirilmedi).
- **derived**: kaynak değerlerinden basit hesapla türetildi (ör. 733.000 galon → ~987 t yakıt; 4 × 2.279 kN; C3'ten ayrılış Δv'si).
- **estimated**: fetch edilen NASA sayfalarında sayı bulunamadı; yaygın yayınlanan değerlere yakın, yuvarlanmış eğitsel tahmin (ör. ESM yakıtı ~8,6 t, AJ10 itkisi, Atlas V kademe kütleleri, ısı kalkanı akı sınırları, tüm kuru kütle payları).
- **game**: oyun dengesi için seçildi; gerçek karşılığı iddia edilmez (tüm `cost`, `scienceValue`, `reliability`, `budget`, alet yuvası kapasitesi, su geri kazanım eşdeğeri).

## Doğrulanamayan önemli değerler (estimated)
ESM yakıt kütlesi ve OMS motor itkisi, Orion kapsül kütlesi, LAS kütlesi, güneş dizisi gücü (~11 kW), ICPS/EUS yakıt ve kuru kütleleri, yan itici yakıt payı, tüm iniş aracı (HLS esinli) değerleri, AxEMU giysi kütlesi ve EVA süresi,
CO2 üretimi 1,04 kg/kişi-gün, su 2,5 kg/kişi-gün (BVAD aralığından seçildi), Atlas V/Centaur/RD-180/RS-68A değerleri, Mars 2020 seyir/kabuk/iniş kademesi kütleleri, PICA/SLA akı sınırları, paraşüt Cd (~0,6),
gezgin batarya kapasitesi, UHF geçiş süresi, tüm Δv bütçeleri (yerçekimi/sürüklenme kayıpları dahil tipik değerler).

## Alan kuralları (Modül Z için)
- `massKg` = parçanın **yakıt hariç** kütlesi; içindeki O2/su gibi sarflar DAHİL. Toplam = `massKg + propellantKg`.
- `thrustN` vakum itkisi; `thrustSlN` / `ispSlS` (isteğe bağlı) deniz seviyesi. Kalkış TWR'si için `stage` 1 ve 2 parçaların `thrustSlN` toplamı önerilir.
- `stage` (yalnız `launch-vehicle`): 1 = yan itici, 2 = çekirdek, 3 = üst kademe. Önerilen hesap: **seri kademe** — önce 1 yakar ve atılır, sonra 2, sonra 3; her kademede Isp = itki ağırlıklı ortalama.
- Aşamada `carries`: o yakışta itilen modüller; `excludeTags`: o aşamada artık taşınmayan parça etiketleri (`jettison-after-launch` = LAS, `jettison-before-powered-descent` = kabuk/kalkan/paraşüt). Aynı `dvFrom` modülünün aşamaları sırayla yakıt tüketir.
- `powerW` aktif güç, `dutyCycle` (varsayılan 1) çalışma oranı → ortalama = `powerW × dutyCycle`. `powerGenW` ortalama üretim (güneş için toz öncesi sol ortalaması).
- `dataGenMbPerSol` Mars'ta sol, Ay'da gün başına megabit. İletim kapasitesi ≈ `dataRateBps × linkSecPerSol / 1e6` Mb/sol.
- Isıl: `heatRejectW` (ısı atma kapasitesi, tüketilen güçle karşılaştırılır), `heatW` (MMRTG atık ısısı).
- Görev modüllerinde karışık rollü modüllerde kategori başına `role` ve modülde `roles` listesi vardır; parçanın `role` alanı belirleyicidir.

### Şemaya eklenen isteğe bağlı alanlar
Parça: `stage`, `thrustSlN`, `ispSlS`, `dutyCycle`, `heatRejectW`, `heatW`, `crewCapacity`, `maxMissionDays`, `maxLandingVms`, `evaHours`, `evaHoursBonus`, `maxEntryMassKg`, `maxPayloadKg`, `instrumentCapacityKg`, `linkSecPerSol`.
Görev: `surfaceCrew`, `surfaceSols`, modülde `roles` + kategoride `role`, aşamada `carries` / `excludeTags`, ayarda `help`, `options`, `optionInfo` (önerilen çarpanlar).

## Basitleştirmeler
- Fırlatma: paralel yanma yerine seri kademe; yerçekimi/sürüklenme kayıpları Δv gereksiniminin içinde. SLS Block 1 + Orion (~27 t) bu modelde ~12,7 km/s verir; gereksinim 12,55 km/s → gerçek "Ay'a >27 t" ile tutarlı.
- Ay: Artemis'e benzer şekilde iniş aracı **ayrı fırlatılır** (fırlatma aracı yalnız mürettebat aracını taşır) ve Ay yörüngesinde buluşur; iniş + çıkış tek modül olarak hesaplanır.
- Mars EDL: üstel atmosfer (ρ0 = 0,016 kg/m³, H = 11 km), giriş hızı ~5,4 km/s, paraşüt Mach ~1,75'te; CFD yok.
- Güç ortalama sol/gün dengesiyle; batarya yalnız tepe ve gece için.
- Yaşam desteği: O2 0,84, su 2,5 kg/kişi-gün; CO2 kapasitesi kişi-gün olarak.

## Kaba el hesapları (Grup 2'de `evaluate` ile ince dengelenecek)
Betik: seri kademeli Tsiolkovsky (g0 = 9,80665), TWR = kalkışta (kademe 1+2 `thrustSlN`) / (toplam kütle × g0), Ay iniş aracı inişte kit dahil, çıkışta kit hariç.

### Ay (bütçe 4.300)
| Yapılandırma | Maliyet | Fırlatma Δv (gerek 12.550) | TWR | Ekip aracı Δv (gerek 950) | İniş aracı (≤ 42 t) / kalan yakıt | Güç (üretim/kullanım) | Isı | Yaşam desteği (gün, gerek 20+marj) | EVA (≥6 h) | Bilim (≥50) |
|---|---|---|---|---|---|---|---|---|---|---|
| **A**: SRB5 + 4×RS-25 + ICPS; Orion + ESM + amin ECLSS + büyük O2 + su tankı + sıvı döngü + 2 kanat; LOX/LH2 iniş aracı (airlock, Ka radar, S bandı, güneş + batarya); AxEMU + HD kamera + kepçe + çevre istasyonu + radyasyon dedektörü; marj 3 | 4.147 | 12.708 | 1,54 | 1.173 | 32,5 t / +353 kg | 6.000 / 3.395 W | 7.000 W | O2 26,8 · su 25 · CO2 100 | 8 | 64 |
| **B**: SRB5 + 3×RS-25 + ICPS; hafif kapsül + ESM + LiOH + büyük O2 + su tankı + pasif ısı + COTS bilgisayar; metan/LOX iniş aracı (basit kabin, S bandı radar, röle iletişim, güneş); hafif giysi + O2 ve batarya yedeği + panorama + kepçe + bilim istasyonu; marj 2 | 3.410 | 12.958 | 1,47 | 1.300 | 38,3 t / +1.259 kg | 6.000 / 2.075 W | 3.500 W | O2 26,8 · su 25 · CO2 25 | 7 | 66 |
| **Açgözlü**: EUS, genişletilmiş servis modülü, 4 kanat, tüm yedekler, tüm bilim, marj 10 | 4.820 ✗ | 13.636 | 1,48 | 1.375 | 33,1 t / +41 kg | — | — | 41,7 / 41 / 100 | 11 | 147 |

Açgözlü yapılandırma bütçeyi (4.820 > 4.300) aşar; ayrıca iniş aracı yakıt marjı ~0'dır (`sk-drill` ↔ `sk-sci-station` uyumsuzluğu da hepsini almayı engeller). Diğer tuzaklar: hipergolik iniş aracı 44,4 t > 42 t; 4 segmentli yan itici + 3 RS-25 TWR 1,34 ile geçer ama Δv marjı dar; yakıt doluluğu 0,85'te B fırlatma Δv'si 11.847 m/s ile başarısız.

### Mars (bütçe 1.100)
| Yapılandırma | Maliyet | Fırlatma Δv (gerek 13.000) | TWR | Seyir Δv (gerek 35) | Giriş kütlesi | Motorlu iniş Δv (gerek 450) / TWR | Gezgin gücü (üretim/ort. kullanım) | Alet kütlesi / yuva | Veri üretim / iletim (Mb/sol) | Bilim (≥60) |
|---|---|---|---|---|---|---|---|---|---|---|
| **A**: Atlas V 541 esinli (4 SRB + RD-180 sınıfı + Centaur); hidrazin seyir + güneş + HRS; PICA + 21,5 m paraşüt + TDS + IMU + TRN + gök vinci + 8 motor; tam şasi + MMRTG + RTG ısı döngüsü + çift bilgisayar + UHF + X bandı; Mastcam-Z, SuperCam, PIXL, SHERLOC, MEDA, RIMFAX | 1.009 | 13.660 | 2,04 | 49 | 2.972 kg | 517 / 3,5 | 110 / 100,7 W | 34,7 / 45 kg | 400 / 614 | 114 |
| **B**: 2 SRB; pasif seyir ısısı; TRN yok; hafif şasi + güneş paneli + büyük batarya + elektrikli ısıtıcı + tek bilgisayar + UHF; Mastcam-Z, PIXL, SHERLOC, MEDA | 776 | 13.361 | 1,69 | 53 | 2.777 kg | 586 / 3,9 | 150 / 101,9 W (toz çarpanı 0,7 ile 105 W) | 21,1 / 22 kg | 332 / 600 | 78 |
| Varyant: A + LOX/LH2 çekirdek (RS-68A esinli) | 1.054 | 13.723 | 2,23 | | | | | | | |
| **Açgözlü**: çift motorlu Centaur, biprop + ek tank, MMRTG + güneş, tüm aletler + MOXIE + önbellekleme | 1.157 ✗ | 13.211 | 2,04 | 84 | 3.389 kg | 555 / 2,9 | 260 / 116,7 W | 91,8 / 45 kg ✗ | 401 / 614 | 146 |

Açgözlü yapılandırma bütçeyi ve alet yuvası kapasitesini aşar; yüksek güçlü UHF ↔ RIMFAX ve iniş platformu ↔ SuperCam uyumsuzlukları da "hepsini al"ı engeller. Yan iticisiz fırlatma: TWR 1,14 ve Δv 12.771 ile başarısız.
A'da MMRTG marjı ~9 W: `instrumentMode: intensive` veya `powerMode: max` güç açığı üretir (bilerek dar).

### Grup 2 dengelemesi (gerçek `evaluate`/`simulate` ile)
- **Sorun:** Ay A'da iniş TWR'si 0,85 idi (`ld-eng-hydrolox` 44,5 kN — BE-7 sınıfı ~10.000 lbf, `estimated` — iniş başında ~32,5 t × 1,62 m/s²) < `minLanderTWR` 1,5. El hesabında iniş TWR'si yoktu.
- **Değişiklik (tek sayısal alan):** `ld-eng-hydrolox.thrustN` 44.500 → **110.100 N**, adı "RL10 sınıfı". Kaynak `nasa-sls` (NASA SLS referansı: ICPS'teki RL10 24.750 lbf vakum = 110,1 kN), sınıf `measured`; iniş için tek RL10 sınıfı motor varsayımı oyun kararıdır (Altair iniş aracı tasarımı da RL10 türevi iniş motoru öngörüyordu). `ispS` 450 ve `massKg` 600 değişmedi (`estimated`; RL10B-2 Isp'si ~465 s olduğundan 450 ihtiyatlıdır).
- **`minLanderTWR` 1,5:** kaynaklı bir gereksinim değil; `limits.minLanderTWR` ref'i `pp-model` / `game` olarak eklendi.
- **Sonuç (tohum 42):** Ay A iniş TWR 2,09, kritik FAIL yok, success; Ay B iniş TWR 1,77, success (WARN: ekip aracı); Mars A success; Mars B success (WARN: güç). Açgözlü Ay `budget`, açgözlü Mars `instrument-capacity` kritik FAIL ile kalır. Kanıt: `test/sim/solutions.test.js`, `test/sim/realdata.test.js`.

## Mühendislik gerekçeli uyumsuzluklar (`incompatibleWith`)
1. Radyoizotop jeneratör (`rtg`) ↔ iniş aracı kriyojenik tankları (`lander-cryo-tank`): sürekli kilovat düzeyinde ısı → buharlaşma kaybı. (Fırlatma aracının `cryogenic` parçaları kapsam dışı; farklı araç.)
2. Radyoizotop jeneratör ↔ yüzey radyasyon dedektörü (`radiation-sensor`): gama/nötron arka planı ölçümü bozar.
3. S bandı iniş radarı (`radar-sband`) ↔ S bandı yüzey vericisi (`surface-sband`): aynı araçta, aynı bantta girişim. (Mürettebat aracının S bandı anteni `antenna-sband-crew` etiketlidir, kapsam dışı.)
4. Karot matkabı (`vibration`) ↔ sismometreli bilim istasyonu (`seismic`): titreşim ölçümü bozar.
5. Yüksek güçlü UHF verici (`antenna-uhf-highpower`) ↔ RIMFAX yeraltı radarı (`gpr-radar`): 150–1200 MHz alıcısı 400 MHz verici tarafından doyurulur.
6. Bacaklı iniş platformu (`plume-near-surface`) ↔ SuperCam (`open-optics`): motor tozu açık optiği ve lazer çıkışını kirletir.

Uyumsuzluk kayıtları iki yönlü yazıldı (her iki parçada da).

## Aşama 8 — Alan (U), standart donanım, bilim hedefleri (Modül AF)
- **Hacim/kapasite sınıfı: `game`** (parça `refs.volumeU`, görev `refs["modules.capacityU"]`). U ("kapasite birimi") modül içi yerleşim payıdır; gerçek litre/m³ değildir. Göreli büyüklükler kabaca gerçekçi tutuldu (ör. LH2 tankı metan/LOX tankından hacimli, kapsül en büyük parça, alet 1–4 U), mutlak değerler oyun dengesi için seçildi (`estimated` değil).
- **Kapasiteler:** Ay — fırlatma aracı 40, mürettebat aracı 44, iniş aracı 44 (itki + uzay aracı ORTAK), yüzey kiti 14. Mars — fırlatma aracı 32, seyir kademesi 8 (ortak), EDL 20 (ortak), gezgin 30 (uzay aracı + bilim ORTAK). Alan sert sınırdır (`canAdd` → `NO_SPACE`); `volumeU`/`capacityU` yoksa 0 / sınırsız.
- **Standart donanım:** tek seçenekli zorunlu kategoriler `auto: true` (Ay: çekirdek tank, kademe ayırma, tutum kontrolü, RCS, kaçış sistemi, su, radyasyon izleme, S bandı anten, navigasyon, uçuş bilgisayarı, ana batarya, acil güç, tehlike lidarı, iniş aviyoniği; Mars: tutum kontrolü, kaplama/ayırma, seyir paneli, seyir anteni, sırt kabuğu, iniş radarı, tekerlekler, gezgin bilgisayarı, robot kol, direk).
  Bunun için önemsiz ikinci seçenekler veriden çıkarıldı: `cv-fc-cots`, `cv-ant-optical`, `cv-rad-shelter`, `cv-water-recycler`, `cs-solar-xl`, `rv-wheels-ti`, `rv-computer-single`.
- **Bilim hedefleri (`game`):** görev başına 3 (`scienceGoals`, `requiresTags` = alet `provides` etiketleri; adlar `scienceTags`). Ay: regolit katmanları (kepçe + matkap, 40), Ay depremleri ve ısı akısı (bilim istasyonu, 35), radyasyon ve toz (dedektör + çevre istasyonu, 30) — matkap/sismometre uyumsuzluğu ve 14 U yüzey kiti üçünü birden engeller. Mars: biyo-imza (SHERLOC + PIXL, 40), numune önbelleği (önbellek + Mastcam-Z, 45), iklim ve yeraltı (MEDA + RIMFAX, 30) — 45 kg alet yuvası ve 30 U gezgin üçünü birden engeller.
- **Yeni ayarların çarpanları (`game`):** kalkış profili Δv ×1,04/1/0,96 ↔ kalkış arıza riski ×0,6/1/1,6; iniş yakıt rezervi %r → iniş Δv ×(1+r), arazi tehlikesi ×max(0,4; 1−3r); iletişim planı bağlantı penceresi ×0,5/1/1,6 ↔ verici gücü ×0,6/1/1,8; bilim önceliği genel bilim ×0,85/1/1,15 (hedef odaklıda hedefler alet arızasına dayanıklı, geniş keşifte hedefler tamamlanamaz).

## Dil / Language (Aşama 9)
- Kanonik veri Türkçedir (`data/equipment`, `data/missions`, `data/science/sources.json`); sayılar yalnız orada tutulur.
- İngilizce metinler `data/i18n/en/` altında **yalnız metin bindirmesi** olarak durur (`equipment-*.json`: ad, açıklama, uyumsuzluk gerekçesi, kaynak notu; `missions-*.json`: görev metinleri, brifing, ayarlar, bilim hedefleri, etiket/kategori adları, `refs` notları (`"phases.launch.dvMs"` gibi nokta yolu); `sources.json`: Türkçe kaynak başlıkları). Eksik alan Türkçeye düşer. TR veri değişirse bindirme de güncellenmelidir.
