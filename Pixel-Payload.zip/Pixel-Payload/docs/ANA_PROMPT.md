# Kullanıcının ana kapsam metni (özet kopya — bağlayıcı kısımlar)

Kaynak: kullanıcının 2026-11-15 tarihli "PIXEL PAYLOAD — MASTER DEVELOPMENT PROMPT" mesajı. Ekler: her sayfada geri düğmesi, sonuçta tekrar oyna;
oda kodu + host yönetimi, dört ayrı istemci, dört rol, Socket.io gerçek zamanlı, ortak oyun durumu, bağlantı kurtarma, sunucu yönetimli simülasyon;
oyuncular arası bağ artsın: birinin sorunu diğerini daha çok etkilesin.

## Görevler (yalnız iki)
1. **İnsanlı Ay görevi** — Dünya'dan Ay'a mürettebat, güvenli iniş, yüzey keşfi, Dünya'ya güvenli dönüş. Artemis dönemi mimarisi eğitsel referans; birebir uçuş yapılandırması değil.
   Aşamalar: hazırlık, kalkış, Dünya park yörüngesi, Ay'a geçiş (TLI), Ay transferi, Ay yörüngesine giriş, mürettebatın iniş aracına geçişi, Ay inişi, yüzey keşfi, Ay'dan kalkış, dönüş transferi, atmosfere giriş, kurtarma.
   Mürettebat aracı ile iniş aracı ayrı (Orion yüzeye inen araç DEĞİLDİR).
   - İtki: ağır fırlatma aracı (SLS esinli seçenek), ana motor sistemi, üst kademe, yakıt tankları, RCS iticileri, kademe ayırma, tutum kontrolü. Her biri: kuru kütle, yakıt kapasitesi, itki, Isp, maliyet, uyumluluk, güvenilirlik (SI).
   - Uzay aracı: Orion esinli kapsül, servis modülü, kabin, ECLSS, oksijen, su, CO2 giderme, kabin basıncı, ısı kontrolü, radyasyon izleme, anten, navigasyon, uçuş bilgisayarı, acil güç, batarya, güneş paneli.
     Yaşam desteği gerçek kısıt: mürettebat sayısı, süre, O2, su, sarf yedekleri, kabin basıncı, güç, ısı limitleri, radyasyon (basit risk göstergesi). Hazırlığı ve sonucu ETKİLER.
   - İniş aracı (HLS esinli, ayrı yapılandırma): iniş itkisi, çıkış itkisi, iniş bacakları, iniş sensörleri, navigasyon, iniş radarı, yüzey iletişimi, mürettebat erişimi, yüzey güç desteği.
   - Yüzey ekipmanı: yüzey kamerası, panoramik görüntüleme, regolit örnekleme, jeolojik örnekleme, çevre izleme istasyonu, radyasyon dedektörü, yüzey navigasyonu, taşınabilir bilim istasyonu, EVA ekipmanı
     (giysi yaşam desteği, O2 yedeği, batarya, ısı yönetimi, iletişim, EVA süresi).
   - Başarı: fırlatma limitleri, yeterli Δv, güvenli mürettebat taşıma, yeterli yaşam desteği, Ay yörüngesine giriş, iniş, güvenli yüzey operasyonu, çıkış için kaynak, Dünya'ya dönüş. Kısmi başarı olabilir; mürettebat güvenliği KRİTİK.
2. **Mars gezgin görevi** — Perseverance (Mars 2020) ana bilimsel/mühendislik referansı; birebir kopya olduğu iddia edilmez.
   Aşamalar: hazırlık, kalkış, Dünya'dan ayrılış, gezegenler arası seyir, yörünge düzeltme, Mars yaklaşımı, atmosfere giriş, paraşüt, motorlu iniş, iniş, gezgin konuşlandırma, yüzey operasyonu, bilimsel veri toplama, veri iletimi.
   - İtki: fırlatma aracı, ana kademe, seyir itkisi, yörünge düzeltme iticileri, tanklar, tutum kontrolü.
   - EDL: aeroshell, ısı kalkanı, süpersonik paraşüt, iniş kademesi, iniş itkisi, iniş radarı, navigasyon sensörleri, gezgin indirme mekanizması.
     Model: atmosfer yoğunluğu, giriş hızı, kalkan performansı, paraşüt koşulları, iniş kademesi performansı, kalan yakıt, iniş hızı, arazi tehlikesi. Basit eğitsel model (CFD değil).
   - Gezgin: şasi, altı teker, süspansiyon, robot kol, direk, navigasyon kameraları, iletişim, güç, ısı kontrolü, bilgisayar, bilim güvertesi.
   - Aletler (hepsi zorunlu DEĞİL; her biri kütle, güç, veri üretimi, bilim değeri, çalışma koşulları, uyumluluk): Mastcam-Z, SuperCam, PIXL, SHERLOC, MEDA, RIMFAX esinli; MOXIE esinli isteğe bağlı teknoloji gösterimi.
   - Güç: üretim, batarya, tüketim, çalışma modları, alet ve hareket gücü, uyku/bekleme. Perseverance'ın gerçek güç mimarisi (MMRTG) ile genel güneş panelli gezgin karıştırılmaz; oyuncu uygun mimariyi seçer.
   - İletişim: (1) Mars yörünge aracı üzerinden UHF röle, (2) Dünya'ya doğrudan X bandı. Erişilebilirlik, veri hızı, sinyal, mesafe, görünürlük, iletim pencereleri, veri birikmesi.
   - Başarı: kalkış, doğru transfer, araç sağ kalımı, yaklaşım, giriş ve iniş, güvenli iniş, gezgin konuşlandırma, güç, iletişim, bilimsel operasyon. Bilim başarısı iniş başarısından AYRI değerlendirilir.

## Veri kuralları
- Gerçek NASA ve yetkili kaynaklar; değer UYDURULMAZ. Her önemli değer: ad, değer, birim, kaynak, URL, erişim tarihi, sınıf (measured/derived/estimated/game).
- Gerçek değer / basitleştirilmiş simülasyon değeri / oyuncu seçimi ayrı tutulur. Eğitsel model "NASA uçuş modeli" diye sunulmaz. Oyun sırasında API'ye bağımlı olunmaz (yerel kopya). API anahtarı istemciye gitmez.
- Kaynaklar: nasa.gov/humans-in-space/artemis, nasa.gov/mission/gateway, nasa.gov/reference/human-landing-systems, nasa.gov/humans-in-space/what-is-a-spacesuit,
  science.nasa.gov/mission/mars-2020-perseverance (+ /science-instruments, /rover-components), jpl.nasa.gov, data.nasa.gov, pds.nasa.gov.

## Fizik
Tsiolkovsky, Δv, TWR, kütle, yakıt, güç dengesi, ısı dengesi, bütçe; yerçekimi, yörünge/kaçış hızı, kütle oranları, iletişim gecikmesi, ısı kısıtları;
Ay: transfer, LOI, iniş, çıkış, yaşam desteği kaynakları, dönüş. Mars: gezegenler arası transfer, atmosfere giriş, paraşüt + motorlu iniş, iniş koşulları, gezgin enerji dengesi, iletişim pencereleri. SI, girdi doğrulama, sunucu yetkili, "basitleştirilmiş" etiketli.

## Oynanış
İşbirlikli mühendislik; dört oyuncu birbirine muhtaç. Hazırlık tüm sistemlere bağlı. Başarı / kısmi başarı / başarısızlık + net nedenler. Gereksiz rastgele olay yok; olaylar koşullara ve kararlara bağlı.
Hazırlık incelemesi: PASS / WARNING / FAIL; kritik FAIL fırlatmayı engeller; uyarılar etkisini açıklar; operatör birleşik raporu, mühendisler kendi ayrıntısını görür.
Debrief: sonuç, tamamlanan hedefler, mühendislik performansı, yakıt verimi, güç verimi, iletişim, bilim çıktısı, bütçe, kritik olaylar, karşılanmayan gereksinimler, ekip koordinasyonu, çıkarılan dersler.

## Sohbet (zorunlu, sunucuda yetkili)
Mühendis → Operatör izinli; Operatör → herhangi bir mühendis izinli; Operatör → tüm mühendisler izinli; mühendis → mühendis YASAK; mühendis → tüm mühendisler YASAK.
Doğrula: gönderen kimliği, rolü, oda üyeliği, alıcı, mesaj tipi, uzunluk, hız sınırı. Değiştirilmiş istemci aşamaz. Özel mesaj yalnız taraflara; yayın yalnız üç mühendise. Yeniden bağlanmada çalışır.
Sohbet, görev olay bildirimleriyle karışmaz.

## Demo
Korunur; iki göreve güncellenir; görev seçimi, role özel bilgi, ekipman, hazırlık, simülasyon, debrief gösterilir; demo eylemleri belirtilir; normal oyun durumunu kirletmez.

## Arayüz
Google Stitch tasarımı (20 ekran: açılış, oda kur, odaya katıl, lobi, görev seçimi, brifing, rol ataması, operatör / itki / uzay aracı / bilim çalışma alanları, ekipman envanteri, araç montajı,
hazırlık incelemesi, fırlatma ve simülasyon, görev olayları, iletişim merkezi, debrief, profil ve ayarlar, nasıl oynanır) görsel şartnamedir; işlevsiz düğme olmaz; yapılamayan açıkça raporlanır.
