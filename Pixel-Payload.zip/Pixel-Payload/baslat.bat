@echo off
rem Pixel Payload - oyunu baslatir. Cift tiklayarak calistir.
rem Test icin: PP_NO_BROWSER=1 tarayici acmaz, PP_NO_PAUSE=1 sonda beklemez.
rem Demo kontrol modu: PP_DEMO=1 ise tarayici /demo.html ile acilir (demo.bat bunu ayarlar).
chcp 65001 >nul
title Pixel Payload
cd /d "%~dp0"
set "PP_PORT=3000"
if defined PORT set "PP_PORT=%PORT%"
set "PP_PATH="
if "%PP_DEMO%"=="1" set "PP_PATH=/demo.html"

rem 1) Node kurulu mu?
where node >nul 2>nul
if errorlevel 1 (
  echo.
  echo  [HATA] Node.js bulunamadi.
  echo  Lutfen https://nodejs.org adresinden Node.js'i kurup tekrar dene.
  echo.
  goto :bitis
)

rem 2) Port zaten dinleniyor mu? (oyun zaten acik)
netstat -ano | findstr /R /C:":%PP_PORT% .*LISTENING" >nul
if not errorlevel 1 (
  echo.
  echo  Oyun zaten acik: http://localhost:%PP_PORT%%PP_PATH%
  echo  Sadece tarayici aciliyor. Kapatmak icin durdur.bat'a cift tikla.
  echo.
  if not defined PP_NO_BROWSER start "" http://localhost:%PP_PORT%%PP_PATH%
  ping -n 3 127.0.0.1 >nul
  exit /b 0
)

rem 3) Bagimliliklar yuklu mu? (Font paketleri sonradan eklendi)
set "PP_NEED_INSTALL="
if not exist "node_modules\" set "PP_NEED_INSTALL=1"
if not exist "node_modules\@fontsource\jetbrains-mono\" set "PP_NEED_INSTALL=1"
if not exist "node_modules\@fontsource\rajdhani\" set "PP_NEED_INSTALL=1"
if defined PP_NEED_INSTALL (
  echo  Bagimliliklar yukleniyor ^(npm install, internet gerekir^)...
  call npm install
  if errorlevel 1 (
    echo.
    echo  [HATA] npm install basarisiz oldu. Internet baglantini kontrol et.
    goto :bitis
  )
)

echo ============================================================
echo   PIXEL PAYLOAD
echo   Oyun adresi: http://localhost:%PP_PORT%
if "%PP_DEMO%"=="1" echo   Demo kontrol modu: http://localhost:%PP_PORT%/demo.html
echo   Kapatmak icin bu pencereyi kapat ya da durdur.bat'a cift tikla.
echo ============================================================
echo.

rem 4) Tarayiciyi ~2 sn sonra ayri bir surecte ac (sunucu bu pencerede on planda kalir)
if not defined PP_NO_BROWSER start "" /min cmd /c "ping -n 3 127.0.0.1 >nul & start http://localhost:%PP_PORT%%PP_PATH%"

rem 5) Sunucu (cikti bu pencerede gorunur: telefonlar icin LAN adresi)
node server\index.js
echo.
echo  Sunucu kapandi (cikis kodu %errorlevel%).

:bitis
if not defined PP_NO_PAUSE pause
