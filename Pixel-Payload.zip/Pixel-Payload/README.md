# Pixel Payload

NASA Space Apps için yapılmış, **4 kişilik işbirlikli bir uzay mühendisliği oyunu**. Bir Operatör ve üç mühendis aynı aracı birlikte tasarlar,
hazırlık incelemesinden geçirir ve fırlatır. Her oyuncu yalnızca kendi sistemlerinin sayılarını görür, bu yüzden takım konuşmadan kazanamaz.

İki görev var:
- **İnsanlı Ay görevi** (Artemis esinli): kalkış → Ay'a geçiş → iniş → yüzey keşfi → dönüş → kurtarma. Dört kişilik mürettebat, bütçe 4.300.
- **Mars gezgin görevi** (Perseverance esinli): kalkış → seyir → giriş, alçalma ve iniş (EDL) → gezgin → bilim → veri iletimi. Bütçe 1.100.

> Oyundaki hesaplar **basitleştirilmiş eğitsel bir modeldir**, gerçek bir uçuş modeli değildir. Değerler NASA kaynaklarına dayanır ama yaklaşıktır.

## Quick start (English)

Pixel Payload is a 4-player co-op space engineering game: one Operator and three engineers (Propulsion, Spacecraft, Science & Payload) design, review and launch a vehicle together. Each player sees only their own numbers, so the team has to talk.

```bash
npm install
npm start          # http://localhost:3000 (share the LAN URL with players on the same Wi-Fi)
```

Create a room, share the 4-letter code, pick roles, mark ready, and the host starts the game.

## Language / Dil

- The game starts in **English** by default; switch EN | TR on the home screen or in Settings. Oyun varsayılan olarak **İngilizce** açılır; açılış ekranında ya da AYARLAR'da EN | TR seçilir.
- Language is **per player**: two players in the same room can play in different languages. Dil oyuncu başınadır; sonuçlar (sayılar, tohum, puan) dilden bağımsızdır.
- Server texts (errors, readiness, simulation, debrief, mission/equipment names) arrive in the player's language. Chat messages are not translated. Sohbet mesajları çevrilmez.
- Socket: `room:create/join/rejoin` take an optional `lang` (`'en' | 'tr'`), and `player:lang { lang }` changes it at any phase. `GET /api/sources?lang=en|tr`.

---

## Çalıştırma

**Gereksinim:** [Node.js](https://nodejs.org). `package.json` bir sürüm (`engines`) belirtmiyor. `npm test` komutundaki glob deseni
(`node --test "test/**/*.test.js"`) Node 21 veya üstünü gerektirdiği için güncel bir LTS sürümü (22 veya üstü) önerilir. Geliştirme Node 24 ile yapıldı.

**Windows'ta en kolay yol:** `baslat.bat` dosyasına çift tıkla.
- Node kurulu mu diye bakar. Eksik paket varsa (`express`, `socket.io`, `@fontsource/rajdhani`, `@fontsource/jetbrains-mono`) `npm install` çalıştırır.
- Sunucuyu başlatır ve birkaç saniye sonra tarayıcıda `http://localhost:3000` adresini açar.
- Oyun zaten açıksa ikinci bir sunucu başlatmaz, yalnızca tarayıcıyı açar.
- **Kapatmak için** pencereyi kapat ya da `durdur.bat`'a çift tıkla. `durdur.bat` yalnızca oyunun portunu dinleyen süreci kapatır.

**Terminalden:**
```
npm install
npm start        # node server/index.js, Ctrl+C ile kapanır
```

**Ortam değişkenleri** (`server/index.js`):

| Değişken | Varsayılan | Ne yapar |
|---|---|---|
| `PORT` | `3000` | Sunucu portu (`baslat.bat` ve `durdur.bat` da bunu okur) |
| `PP_PHASE_MS` | `3500` | Simülasyonda bir aşamanın ekranda kalma süresi (ms) |
| `PP_GRACE_MS` | `120000` | Bağlantısı kopan oyuncunun rolünün ne kadar süre korunacağı (ms) |

Geçersiz (sayı olmayan ya da negatif) değerler uyarıyla yok sayılır. `baslat.bat` ayrıca şunları tanır: `PP_NO_BROWSER=1` (tarayıcı açmaz),
`PP_NO_PAUSE=1` (sonda beklemez), `PP_DEMO=1` (`/demo.html` ile açar).

**Aynı Wi-Fi'den katılma:** Sunucu `0.0.0.0` üzerinde dinler. Açılışta konsola makinenin LAN adreslerini yazar
(ör. `http://192.168.1.20:3000`). Aynı adresler lobide de gösterilir (`GET /api/info`). Diğer oyuncular telefondan ya da
bilgisayardan bu adrese girer. Merkezi bir sunucu yoktur: odayı kuran kişinin bilgisayarı sunucudur. Windows güvenlik duvarı
ilk açılışta Node için izin isteyebilir; izin verilmezse diğer cihazlar bağlanamaz.

**İnternet:** Yalnızca ilk `npm install` için gerekir. Oyun sırasında hiçbir dış servise bağlanılmaz. Yazı tipleri
`node_modules` içinden `/vendor/fonts/...` yolundan sunulur (CDN yok). Bilimsel veriler `data/` altındaki yerel JSON dosyalarındadır.

---

## Oda kurma ve katılma

- **Oda kur:** Açılış ekranında BAŞLA → oda kur, adını yaz (1–16 karakter). Sana 4 harflik bir oda kodu verilir ve odanın **host**'u olursun.
- **Odaya katıl:** Kodu ve adını yaz. Odada en fazla 4 kişi olabilir. Oyun başladıktan sonra yalnızca boş bir rol varsa katılınabilir, yoksa "oda dolu" hatası alınır.
- **Host yönetimi (lobi):** Herkes bir rol seçer ve "Hazır" der. Host **BAŞLAT**'a basar. Başlatmak için 4 rolün dolu, 4 oyuncunun hazır ve bağlı olması gerekir.
  Host bir oyuncuyu çıkarabilir ve host yetkisini bağlı başka bir oyuncuya devredebilir.
- **Host ayrılırsa** yetki bağlı ilk oyuncuya geçer.
- **Yeniden bağlanma:** Oturum tarayıcının `sessionStorage`'ında tutulur. Sayfa yenilenirse ya da bağlantı koparsa istemci aynı odaya ve role
  otomatik döner. Kopan oyuncunun rolü `PP_GRACE_MS` süresince (varsayılan 2 dakika) korunur, sonra oyuncu odadan düşer.
  Aynı oyuncu ikinci bir sekmeden girerse eski bağlantı kapatılır. Bağlı kimsesi kalmayan oda 5 dakika sonra silinir.

---

## Roller ve asimetrik bilgi

| Rol | Kod adı | Sorumluluk |
|---|---|---|
| **Operatör** | `director` | Görevi seçer, tüm telemetriyi ve birleşik hazırlık raporunu görür, bütçeyi bilir, incelemeyi açar, FIRLAT der. Ekipman takmaz. |
| **İtki Mühendisi** | `rocket` | Fırlatma aracı, kademeler, motorlar, yakıt, iniş itkisi. Kütle, TWR, Δv. |
| **Uzay Aracı Mühendisi** | `spacecraft` | Kapsül/gezgin, güç, ısı, iletişim, navigasyon, yaşam desteği, EDL. |
| **Bilim & Faydalı Yük Mühendisi** | `payload` | Bilim aletleri, EVA ekipmanı, bilim değeri, veri üretimi. |

Bilgi bilerek bölünmüştür (sunucu her oyuncuya ayrı, süzülmüş bir görünüm yollar):
- Operatör her şeyi görür: hedefler, limitler, bütçe ve maliyetler, harcama defteri, tüm telemetri, tüm hazırlık kalemleri, bilim hedeflerinin
  değerleri, mühendislerin birbirinden ihtiyaç duyduğu değerler.
- Her mühendis **yalnız kendi** kataloğunu, sayılarını, ayarlarını, brifingini ve hazırlık kalemlerini görür. Bütçeyi, maliyetleri, defteri, başka rolün
  sayılarını görmez. Bütçe için yalnızca sayısız bir **bant** görür: rahat / sınırda (%90 üstü) / aşıldı.
- **Modül alanı herkese açıktır** (pazarlık için): her modülün kullanılan/toplam/boş alanı ve kendi rolünün kullandığı kısım.
- Mühendisin başka bir rolden bilmesi gereken değerler ("ihtiyaçlar", ör. itki mühendisi için toplam faydalı yük kütlesi) ona yalnızca **etiket** olarak gelir.
  Değeri yalnız Operatör görür ve sohbetten aktarır.
- Ortak 2B araç görünümü herkeste vardır: takılı parçaların adı ve simgesi görünür, sayıları görünmez.
- Debrief fazında herkes tam sonucu görür.

---

## Oyun akışı

`lobby` → `mission-select` → `briefing` → `design` → `review` → `simulation` → `debrief` → tekrar

1. **Lobi:** roller seçilir, herkes hazır olur, host başlatır.
2. **Görev seçimi:** Operatör Ay ya da Mars görevini seçer. Herkes iki kartı görür, ayrıntılı hedefler yalnız Operatörde.
3. **Brifing:** herkes kendi rolünün brifingini okur ve ANLADIM der. Dört kişi onaylayınca tasarıma geçilir. Operatör bekleyenleri atlatabilir.
4. **Tasarım:** mühendisler kendi parçalarını takar/çıkarır ve ayarlarını yapar. Operatör izler ve incelemeyi açar. Süre puan için sayılır, zorla bitirmez.
5. **Hazırlık incelemesi:** PASS/WARN/FAIL raporu ve tek bir **fırlatma durumu** (aşağıya bak). Her mühendis kendi sistemi için ONAY ya da DÜZELT der.
   DÜZELT veya Operatörün kararı tasarıma döndürür. Üç mühendis onay verince Operatör **FIRLAT** diyebilir. Tasarım "Hazır" değilse önce
   bir risk onayı istenir (aşağıda "Fırlatma özgürlüğü").
6. **Simülasyon:** sunucu görevin aşamalarını sırayla açar (aşama başı `PP_PHASE_MS`). Her aşama ok/warn/fail ve olaylarla gelir. Kritik hata görevi durdurur.
7. **Debrief:** sonuç (başarılı / kısmi / başarısız), 0–1000 puan, 0–3 yıldız, bölüm bölüm döküm, dersler, "Gerçekte NASA bunu şöyle yapıyor" ve kaynaklar.
   **TEKRAR OYNA** (yeni görev seçimi, her şey sıfırlanır) ya da **AYNI GÖREV** (tasarım korunur). Bunları host ya da Operatör başlatır.

**GERİ:** brifing → görev seçimi (Operatör), inceleme → tasarım (Operatör), debrief → görev seçimi (host ya da Operatör). Fazsız ekranlarda (oda kur/katıl,
nasıl oynanır, ayarlar) geri istemci içinde çalışır. Diğer fazlarda düğme devre dışıdır ve nedenini söyler.

---

## Sohbet kuralları

Sohbet zorunludur ve kurallar **sunucuda** uygulanır (`server/chat.js`). İstemcinin ne yolladığına güvenilmez.

| Gönderen | İzinli hedefler |
|---|---|
| Mühendis | Yalnızca `director` (Operatörle özel kanal) |
| Operatör | `rocket`, `spacecraft`, `payload` (özel) ya da `engineers` (tüm mühendislere yayın) |

- **Yasak:** mühendisten mühendise ve mühendisten herkese mesaj. Bilinen ama izinsiz hedefler `FORBIDDEN`, bilinmeyen hedefler `BAD_TARGET` hatası verir.
- Mühendisler birbirinin özel konuşmasını göremez. Her mühendis yalnız kendi Operatör kanalını ve yayınları görür.
- Göndericinin rolü ve odası sunucudaki oyuncu kaydından alınır.
- Metin kırpılır, sekme ve satır sonu boşluğa çevrilir, kontrol karakterleri ve yön değiştiren Unicode karakterleri silinir. Boş mesaj `EMPTY` hatası verir.
- En fazla **300 karakter** (kod noktası olarak sayılır), aşılırsa `TOO_LONG`. Metin kesilmez, mesaj reddedilir.
- Hız sınırı: oyuncu başına **5 saniyede 5 mesaj** (`RATE_LIMIT`). Hedef rolde kimse yoksa `TARGET_EMPTY`.
- Her kanalda son 200 mesaj tutulur. Sohbet yeni turda silinmez, oda kapanınca silinir.
- Mesaj yalnız alıcılara ve gönderene iletilir.
- Ayrıca tüm socket olayları için bağlantı başına 5 saniyede 40 olay sınırı vardır (`RATE_LIMITED`).

---

## Görevler, ekipman ve hazırlık

**Ekipman** (`data/equipment/*.json`):

| Görev | Toplam | İtki | Uzay Aracı | Bilim & Faydalı Yük |
|---|---|---|---|---|
| Ay | 65 | 18 | 35 | 12 |
| Mars | 57 | 17 | 32 | 8 |

Araç modülleri. Ay: fırlatma aracı, mürettebat aracı, iniş aracı, yüzey kiti. Mars: fırlatma aracı, seyir kademesi, EDL, gezgin.
Her modülde kategori başına en az/en çok parça sayısı vardır. Takarken sunucu şunları denetler: parça başka rolün mü, göreve ve modüle uygun mu,
kategori dolu mu, zaten takılı mı, takılı bir parçayla **uyumsuz** mu (bilimsel gerekçesiyle). Eksik bir gereksinim (`requires`) takmayı engellemez,
ama hazırlıkta FAIL olur ve parça çalışmaz.

**Modül alanı (kapasite):** her parçanın bir hacmi (`volumeU`, "kapasite birimi" U), her modülün bir kapasitesi (`capacityU`) vardır.
Kapasite sert bir sınırdır: sığmayan parça takılamaz (`NO_SPACE`, gerekçesinde kullanılan/toplam U yazar). Parça çıkarınca alan geri gelir.
Opsiyonel bilim ekipmanı da alan tüketir. Birden çok rolün paylaştığı modüllerde (Ay'da iniş aracı; Mars'ta seyir kademesi, EDL, gezgin)
alan **ortaktır**, roller Operatör üzerinden pazarlık eder. Veride hacim ya da kapasite yoksa parça 0 U sayılır, modül sınırsızdır.

**Standart donanım:** tek seçenekli zorunlu kategoriler veride `auto: true` ile işaretlidir. Tasarıma girerken sunucu bunları kendisi takar
(araçta "standart" olarak görünür). Maliyetleri, kütleleri ve alanları sayılır ama **çıkarılamazlar** (`LOCKED`). AYNI GÖREV tekrarında tasarım korunur, kopya eklenmez.

**Harcama defteri:** her takma (`+maliyet`), çıkarma (`−maliyet`, takma anındaki tutar iade edilir, çift ücret yok) ve standart donanım (`auto`)
kaydı kim, ne, hangi modül, maliyet ve saatle tutulur. Yalnız Operatör görür (yeniden eskiye). En çok 300 kayıt tutulur. Yeni görevde sıfırlanır,
AYNI GÖREV tekrarında korunur. Harcanan tutar defterden değil, takılı parçaların maliyetlerinin toplamından hesaplanır.

**Bütçe aşımı:** bütçeyi aşmak artık fırlatmayı **engellemez**. Hazırlık raporunda kritik olmayan bir FAIL olarak (`kind: 'budget'`) görünür,
debrief'te aşım tutarı ve yüzdesiyle raporlanır ve puanı düşürür.

**Bilim hedefleri:** her görevde 3 opsiyonel bilim hedefi vardır. Her biri belirli yetenekler (alet etiketleri) ister. Makul bir tasarımda alan ve bütçe
genelde ancak ikisine yeter. Bilim mühendisi hedeflerin durumunu (hazır / kısmi / eksik ve eksik yetenekler) görür, değerlerini yalnız Operatör görür.
Debrief'te hangi hedefin yapıldığı ya da neden yapılamadığı yazar.

**Ayarlar:** her mühendisin gerçek ödünleşimli ayarları vardır (görev verisindeki `settings`, ör. `propellantLoad` yakıt doluluğu, `powerMode` güç modu,
`instrumentMode` alet modu, Ay'da `consumableMarginDays` yedek sarf günü). Aşama 8'de her mühendise 1–2 yeni ayar eklendi (iniş yakıt rezervi ya da
çıkış profili, iletişim planı, örnek önceliği gibi). Arayüz ayarları tanımlardan genel olarak çizer: sayı → kaydırıcı, seçenek → bölümlü düğme. Güncel anahtarlar
ve aralıklar için `data/missions/{lunar,mars}.json` dosyasındaki `settings` listesine bak.

**Hazırlık raporu:** her kalem `PASS`, `WARN` ya da `FAIL` alır, bazıları **kritiktir**. Genel durum yalnızca kritik bir FAIL varsa `FAIL` olur.
Kritik olmayan FAIL'ler ve WARN'lar genel durumu `WARN` yapar. Her kalemin bir türü vardır: hazır (`ok`), eksik (`missing`, zorunlu kategori ya da gereksinim yok),
fiziksel yetersiz (`physical`, Δv, TWR, kütle, temas hızı), riskli (`risky`, dar marj, eksik koruma, ısı) ve bütçe (`budget`). Kontrol edilenler: bütçe, fırlatma ve iniş aracı kütlesi,
rol kütle payları, aşama aşama Δv, TWR, yakıt, güç baraları, ısı, iletişim, navigasyon, iniş sensörü ve temas hızı, zorunlu kategoriler, parça gereksinimleri.
Görevlere özel: Ay'da yaşam desteği (O₂, su, CO₂), mürettebat aracı, EVA ve dönüş ısı kalkanı; Mars'ta aeroshell, ısı kalkanı, giriş kütlesi, paraşüt, indirme mekanizması ve alet yuvası.

**Fırlatma özgürlüğü:** tasarımın tek bir fırlatma durumu vardır: `READY` (Hazır) / `RISKY` (Riskli: herhangi bir WARN ya da FAIL) /
`MISSING` (Eksik: kritik bir eksik var) / `INSUFFICIENT` (Fiziksel yetersiz: kritik bir fiziksel yetersizlik var). Fırlatmanın **tek engeli üç mühendisin
onayıdır** (`LAUNCH_BLOCKED`). Kritik FAIL ya da bütçe aşımı fırlatmayı engellemez. Durum `READY` değilse sunucu önce bir onay ister (`LAUNCH_CONFIRM`,
mesajda durum ve öne çıkan en çok 4 sistem yazar). Operatör riski kabul ederse istemci `mission:launch { confirm: true }` gönderir. Sonuç simülasyonda
görülür: fiziksel yetersizlik ilgili aşamada kesin başarısızlıktır, eksik koruma ya da destek olasılıklı hasar verir, eksik bilim ekipmanı ilgili bilim hedefini düşürür,
bütçe simülasyonu etkilemez.

**Zincir etkileri:** bir rolün sorunu başka role de yansır. Etkilenen rolde ayrı bir kalem çıkar (`cascadeFrom`, sayısız metin). Örnekler:
- güç açığı → iletişim, bilim, EVA ve yaşam desteği uyarısı,
- ısı sorunu → batarya kapasitesi (×0,7) ve bilim,
- fazla kütle → itkinin Δv'si,
- iletim kapasitesi bilim verisinin altında → bilim,
- iniş sensörü eksik → iniş itkisi.

---

## Fizik modeli (basitleştirilmiş, eğitsel)

`server/sim/` saf ve durumsuzdur, tek yetkili sunucudur. Tüm modeller **"Basitleştirilmiş eğitsel model; gerçek uçuş modeli değildir"** etiketini taşır.

- **Δv:** Tsiolkovsky `Δv = Isp·g0·ln(m0/mf)`. Fırlatma aracı seri kademelidir (yan itici → çekirdek → üst kademe, boşalan kademe atılır).
  Birden çok motorun Isp'si itki ağırlıklı alınır. Yerçekimi ve sürüklenme kayıpları görevin Δv gereksiniminin içindedir.
- **TWR:** `itki / (kütle·g)`. Kalkışta deniz seviyesi itkisi, iniş ve çıkışta yerel yerçekimi (Ay 1,62, Mars 3,73 m/s²) ve yanma başındaki kütle kullanılır.
- **Güç:** ortalama üretim ve ortalama tüketim (`powerW × dutyCycle`) bara bara karşılaştırılır. Açık varsa batarya bunu en az 12 saat karşılamalıdır (görev verisi başka bir sınır vermezse).
- **Isı:** tüketilen güç ve atık ısı, ısı atma kapasitesiyle karşılaştırılır. Isı kontrolü varsa iç ortam 0…30 °C kabul edilir.
- **EDL (Mars):** üstel atmosfer (ρ0 = 0,016 kg/m³, H = 11 km), Allen-Eggers balistik giriş ve Sutton-Graves tipi tepe ısı akısı. Paraşüt açılma Mach'ı ve
  motorlu inişin Δv'si basit kurallarla hesaplanır. CFD yoktur.
- **İletişim:** günlük iletim kapasitesi yaklaşık `veri hızı × bağlantı süresi`. Işık gecikmesi `mesafe / c`.
- **Yaşam desteği:** kişi × gün × günlük tüketim (O₂ 0,84 kg/kişi-gün, su 2,5 kg/kişi-gün).
- **Simülasyon:** rastgele olay yoktur. Riskler yalnızca parça güvenilirliğinden, WARN/FAIL marjlarından ve arazi tehlikesinden gelir.
  Tohumlu bir PRNG kullanılır: aynı tasarım ve aynı tohum aynı sonucu verir. Mars'ta iniş başarısı ile bilim başarısı ayrı değerlendirilir
  (iniş sonrası arıza "kısmi" sonuç verir). Ay'da mürettebat güvenliği kritiktir.
- **Puan:** hedefler, mühendislik, yakıt, güç, iletişim, bilim, bütçe, olaylar, karşılanmayan gereksinimler ve ekip koordinasyonu bölümlerinden oluşur (toplam 1000).
  Bütçe aşımında bütçe bölümü 0 olur, ayrıca bir ceza satırı ve ders eklenir. Debrief bütçe raporunu (bütçe, harcanan, aşım, aşım %) ve bilim hedeflerini gösterir.
  Bu bir oyun modelidir.

---

## Veri kaynakları

Tüm sayılar `data/` altındadır: `science/sources.json` (24 kaynak), `physics/constants.json`, `equipment/{lunar,mars}.json`, `missions/{lunar,mars}.json`.
Ayrıntılar, kaynak tablosu ve kaba hesaplar için: **[docs/VERI_KAYNAKLARI.md](docs/VERI_KAYNAKLARI.md)**.

Her önemli değerin bir kaynak sınıfı vardır:
- **measured:** kaynakta doğrudan yazan değer,
- **derived:** kaynak değerlerinden basit hesapla türetilmiş,
- **estimated:** NASA sayfalarında bulunamayan, yuvarlanmış eğitsel tahmin,
- **game:** oyun dengesi için seçilmiş (tüm maliyetler, bilim değerleri, güvenilirlikler, bütçeler).

Oyundaki UÇUŞ VERİLERİ sayfası kaynak listesini `GET /api/sources` üzerinden gösterir.

---

## Demo sayfası

`/demo.html` (ya da `demo.bat`): dört oyuncunun ekranını tek sayfada yan yana gösterir. Sunum ya da tek kişilik deneme içindir.
Her panel ayrı bağlantısı ve kendi süzülmüş görünümü olan gerçek bir oyuncudur, sunucuda ayrı bir demo modu yoktur. Demo odası kurulabilir
ya da var olan bir odaya bazı rollerle katılınabilir (ör. 2 gerçek telefon + 2 panel).

---

## Testler

```
npm test
```

Node'un yerleşik test koşucusuyla (`node --test`) `test/` altındaki birim testlerini çalıştırır: sohbet yetkileri, oda mantığı, görünüm filtresi
ve simülasyon (fizik, katalog, hazırlık, simülasyon, debrief, gerçek veriyle çözümler).

---

## Varsayımlar ve sınırlamalar

- Fizik ve puanlama **eğitsel yaklaşımlardır**. Gerçek görev tasarımı ya da uçuş tahmini için kullanılamaz.
- Birçok değer `estimated` ya da `game` sınıfındadır (ör. iniş aracı değerleri, ESM yakıtı, ısı kalkanı sınırları, Δv bütçeleri, tüm maliyetler). Liste `docs/VERI_KAYNAKLARI.md`'de.
- Ay'da iniş aracı ayrı fırlatılmış sayılır, iniş ve çıkış tek modül olarak hesaplanır. Mürettebat kütlesi kapsül kütlesine dahildir.
- Oda durumu yalnızca bellekte tutulur. Sunucu kapanınca odalar ve sohbet silinir. Hesap ya da kalıcı kayıt yoktur.
- Kimlik doğrulama yoktur. Oyun güvenilir bir yerel ağ için tasarlanmıştır, internete açık sunucu olarak düşünülmemiştir.
- Bir oda tam 4 oyuncuyla başlar. Daha az kişiyle oynamak için demo sayfası kullanılabilir.
- `baslat.bat`, `demo.bat` ve `durdur.bat` yalnızca Windows içindir. Diğer sistemlerde `npm start` kullanılır.
- Simülasyon animasyonları şematiktir (kodla çizilmiş 2B sahne).

---

## Klasör yapısı

```
server/
  index.js        Express + Socket.io, ortam değişkenleri, /api/info, /api/sources
  rooms.js        oda, host, faz akışı
  filter.js       oyuncuya özel görünüm (asimetrik bilgi)
  chat.js         sohbet yetkileri
  constants.js    roller, fazlar, hata kodları
  sim/            evaluate, simulate, debrief, physics, loader
public/
  index.html, js/ (core, ui, app, screens/, widgets/), css/
  scene2d.js      2B araç sahnesi
  demo.html, demo.js
data/             equipment/, missions/, physics/, science/
docs/             ANA_PROMPT.md, VERI_KAYNAKLARI.md
test/             birim testleri
arsiv/            eski aşamaların dosyaları
baslat.bat, demo.bat, durdur.bat
```
