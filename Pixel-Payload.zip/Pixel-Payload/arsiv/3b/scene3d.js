// Pixel Payload — 3B roket sahnesi (Modül T)
// Arayüz: PLAN.md > AŞAMA 5 > "3B sahne". Tüm geometri prosedürel; dış model/doku dosyası yok.
import * as THREE from 'three';
import { OrbitControls } from 'three/addons/controls/OrbitControls.js';

const C = {
  bg: 0x05080f, cyan: 0x4fd1ff, amber: 0xffb347, green: 0x4dff9a, red: 0xff5a6a,
  dim: 0x5f7391, frame: 0x1b2a44, hullFill: 0x0b2238
};
const ROLE_COLORS = { rocket: 0xffb347, spacecraft: 0x4fd1ff, payload: 0x4dff9a };
const LAUNCH_DUR = {
  success: 4.6, 'mission-failed': 4.6, 'no-liftoff': 3.8, 'out-of-fuel': 5.2,
  'power-loss': 4.0, overheat: 4.4, 'computer-failure': 4.8
};

// ---------------------------------------------------------------- WebGL tespiti
export const supported = (() => {
  try {
    if (typeof document === 'undefined' || typeof window === 'undefined') return false;
    const c = document.createElement('canvas');
    const gl = window.WebGLRenderingContext && (c.getContext('webgl2') || c.getContext('webgl'));
    if (!gl) return false;
    const ext = gl.getExtension('WEBGL_lose_context');
    if (ext) ext.loseContext(); // tespit bağlamını serbest bırak
    return true;
  } catch (e) { return false; }
})();

function createNoopScene() {
  const noop = () => {};
  return {
    setFrame: noop, setSlots: noop, setHighlights: noop, setMyRole: noop,
    onSlotClick: noop, onPartClick: noop, focusSlot: noop, resize: noop, dispose: noop,
    playLaunch: () => Promise.resolve()
  };
}

export function createRocketScene(container) {
  if (!supported || !container) return createNoopScene();
  try {
    return buildScene(container);
  } catch (err) {
    console.warn('[scene3d] başlatılamadı:', err);
    return createNoopScene();
  }
}

// ---------------------------------------------------------------- yardımcılar
const num = (v, d) => (Number.isFinite(+v) && v !== null && v !== '' ? +v : d);
const clamp = (v, a, b) => Math.max(a, Math.min(b, v));
const smooth = (a, b, x) => { const t = clamp((x - a) / (b - a), 0, 1); return t * t * (3 - 2 * t); };
const now = () => performance.now() / 1000;
const easeOutBack = (k) => { const c1 = 1.70158, c3 = c1 + 1; return 1 + c3 * Math.pow(k - 1, 3) + c1 * Math.pow(k - 1, 2); };
function vec3(a, d) {
  return Array.isArray(a) && a.length >= 3 ? new THREE.Vector3(num(a[0], 0), num(a[1], 0), num(a[2], 0)) : d.clone();
}

let styleInjected = false;
function injectStyle() {
  if (styleInjected) return;
  styleInjected = true;
  const st = document.createElement('style');
  // :where() → sıfır özgüllük; styles.css istediği gibi ezebilir
  st.textContent = `:where(.slot-label){position:absolute;left:0;top:0;transform:translate(-50%,calc(-100% - 14px));
pointer-events:none;z-index:5;white-space:nowrap;font:11px/1.35 ui-monospace,"JetBrains Mono",Consolas,monospace;
letter-spacing:.06em;text-transform:uppercase;color:#c9d6ea;background:rgba(10,17,32,.92);border:1px solid #1b2a44;
border-left:2px solid #4fd1ff;padding:4px 8px;box-shadow:0 0 12px rgba(79,209,255,.15)}
:where(.slot-label) .slot-label-part{display:block;font-size:10px;opacity:.95}
:where(.slot-label) .slot-label-empty{color:#8fa3bf}
:where(.slot-tag){position:absolute;left:0;top:0;pointer-events:none;z-index:4;white-space:nowrap;overflow:hidden;
text-overflow:ellipsis;max-width:min(170px,44%);font:10px/1.3 ui-monospace,"JetBrains Mono",Consolas,monospace;
letter-spacing:.03em;color:#e3ecf8;background:rgba(5,8,15,.82);border:1px solid rgba(77,255,154,.55);
border-left:3px solid #4dff9a;padding:1px 5px;will-change:transform}
:where(.slot-tag[data-state="blocked"]){border-color:rgba(255,90,106,.5);border-left-color:#ff5a6a;color:#ffc9cf}
:where(.slot-tag.slot-tag-sm){font-size:9px;padding:0 4px}`;
  document.head.appendChild(st);
}

function makeGlowTexture() {
  const c = document.createElement('canvas');
  c.width = c.height = 64;
  const g = c.getContext('2d');
  const grd = g.createRadialGradient(32, 32, 0, 32, 32, 32);
  grd.addColorStop(0, 'rgba(255,255,255,1)');
  grd.addColorStop(0.4, 'rgba(255,255,255,0.55)');
  grd.addColorStop(1, 'rgba(255,255,255,0)');
  g.fillStyle = grd;
  g.fillRect(0, 0, 64, 64);
  const tex = new THREE.CanvasTexture(c);
  return tex;
}

// Holografik gövde dolgusu: koyu düşük opaklık + kenarda (fresnel) camgöbeği ışıma
function makeHoloMaterial() {
  return new THREE.ShaderMaterial({
    uniforms: {
      uColor: { value: new THREE.Color(C.hullFill) },
      uRim: { value: new THREE.Color(C.cyan) },
      uOpacity: { value: 0.26 },
      uPower: { value: 1 }
    },
    vertexShader: `varying vec3 vN; varying vec3 vV;
      void main(){ vec4 mv = modelViewMatrix * vec4(position,1.0);
        vN = normalize(normalMatrix * normal); vV = normalize(-mv.xyz); gl_Position = projectionMatrix * mv; }`,
    fragmentShader: `uniform vec3 uColor; uniform vec3 uRim; uniform float uOpacity; uniform float uPower;
      varying vec3 vN; varying vec3 vV;
      void main(){ float f = 1.0 - abs(dot(normalize(vN), normalize(vV))); f = pow(f, 2.0);
        vec3 c = uColor * (0.35 + 0.65 * uPower) + uRim * f * 0.85 * uPower;
        gl_FragColor = vec4(c, uOpacity + f * 0.4 * uPower);
        #include <colorspace_fragment>
      }`,
    transparent: true, depthWrite: false, side: THREE.DoubleSide
  });
}

// Yuvanın yerel ekseni: +Z = dışa normal, +Y = mümkünse yukarı
function slotQuaternion(slot) {
  const q = new THREE.Quaternion();
  if (slot.kind === 'internal') return q;
  const z = vec3(slot.normal, new THREE.Vector3(0, 0, 1));
  if (z.lengthSq() < 1e-6) return q;
  z.normalize();
  const up = Math.abs(z.y) > 0.9 ? new THREE.Vector3(0, 0, 1) : new THREE.Vector3(0, 1, 0);
  const x = new THREE.Vector3().crossVectors(up, z).normalize();
  const y = new THREE.Vector3().crossVectors(z, x);
  return q.setFromRotationMatrix(new THREE.Matrix4().makeBasis(x, y, z));
}

// ---------------------------------------------------------------- parça modelleri
// Hepsi s (yuva ölçüsü) birimiyle; taban z=0'da, dışa +Z yönünde uzanır.
function buildPartModel(model, s) {
  const geoms = []; // { geom, upright? }
  const G = (geom) => { geoms.push(geom); return geom; };
  const rx = (geom) => geom.rotateX(Math.PI / 2); // +Y → +Z
  let upright = false;
  switch (model) {
    case 'engine': {
      G(rx(new THREE.CylinderGeometry(0.17 * s, 0.2 * s, 0.22 * s, 10)).translate(0, 0, 0.11 * s));
      G(rx(new THREE.CylinderGeometry(0.42 * s, 0.17 * s, 0.55 * s, 14, 1, true)).translate(0, 0, 0.495 * s));
      break;
    }
    case 'tank':
      G(new THREE.CapsuleGeometry(0.27 * s, 0.5 * s, 3, 10).translate(0, 0, 0.3 * s));
      G(new THREE.CylinderGeometry(0.29 * s, 0.29 * s, 0.05 * s, 10).translate(0, 0, 0.3 * s));
      break;
    case 'fuel':
      G(new THREE.IcosahedronGeometry(0.25 * s, 1).translate(0, 0, 0.32 * s));
      G(new THREE.CylinderGeometry(0.05 * s, 0.05 * s, 0.95 * s, 8).translate(0, 0, 0.32 * s));
      G(new THREE.TorusGeometry(0.2 * s, 0.035 * s, 6, 14).translate(0, -0.42 * s, 0.32 * s));
      break;
    case 'panel': {
      G(rx(new THREE.CylinderGeometry(0.03 * s, 0.03 * s, 0.3 * s, 6)).translate(0, 0, 0.15 * s));
      for (let i = 0; i < 3; i++) G(new THREE.BoxGeometry(0.03 * s, 0.6 * s, 0.34 * s).translate(0, 0, 0.5 * s + i * 0.38 * s));
      break;
    }
    case 'battery':
      G(new THREE.BoxGeometry(0.5 * s, 0.38 * s, 0.3 * s).translate(0, 0, 0.15 * s));
      G(new THREE.CylinderGeometry(0.05 * s, 0.05 * s, 0.1 * s, 8).translate(-0.12 * s, 0.24 * s, 0.15 * s));
      G(new THREE.CylinderGeometry(0.05 * s, 0.05 * s, 0.1 * s, 8).translate(0.12 * s, 0.24 * s, 0.15 * s));
      break;
    case 'shield': {
      const R = 1.1 * s, L = 0.95;
      G(new THREE.CylinderGeometry(R, R, 0.8 * s, 12, 1, true, -L / 2, L).translate(0, 0, -R + 0.07 * s));
      G(new THREE.CylinderGeometry(R + 0.04 * s, R + 0.04 * s, 0.8 * s, 12, 1, true, -L / 2, L).translate(0, 0, -R + 0.07 * s));
      break;
    }
    case 'dish': {
      const R = 0.45 * s;
      G(rx(new THREE.CylinderGeometry(0.04 * s, 0.04 * s, 0.22 * s, 6)).translate(0, 0, 0.11 * s));
      G(new THREE.SphereGeometry(R, 14, 5, 0, Math.PI * 2, 0, 0.85).rotateX(-Math.PI / 2).translate(0, 0, R + 0.2 * s));
      G(rx(new THREE.CylinderGeometry(0.02 * s, 0.02 * s, 0.4 * s, 5)).translate(0, 0, 0.4 * s));
      G(new THREE.OctahedronGeometry(0.05 * s).translate(0, 0, 0.62 * s));
      break;
    }
    case 'frame': {
      const h = 0.3 * s, r = 0.02 * s;
      const strut = (ax, x, y, z, len) => {
        const g = new THREE.CylinderGeometry(r, r, len, 4);
        if (ax === 'x') g.rotateZ(Math.PI / 2); else if (ax === 'z') g.rotateX(Math.PI / 2);
        G(g.translate(x, y, z));
      };
      for (const a of [-h, h]) for (const b of [-h, h]) {
        strut('x', 0, a, h + b, 2 * h); strut('y', a, 0, h + b, 2 * h); strut('z', a, b, h, 2 * h);
      }
      const d = new THREE.CylinderGeometry(r, r, 2 * h * Math.SQRT2, 4).rotateZ(Math.PI / 4);
      G(d.clone().translate(0, 0, 0)); G(d.translate(0, 0, 2 * h));
      break;
    }
    case 'camera':
      G(new THREE.BoxGeometry(0.32 * s, 0.26 * s, 0.32 * s).translate(0, 0, 0.16 * s));
      G(rx(new THREE.CylinderGeometry(0.11 * s, 0.09 * s, 0.2 * s, 12)).translate(0, 0, 0.42 * s));
      G(new THREE.TorusGeometry(0.11 * s, 0.025 * s, 6, 12).translate(0, 0, 0.52 * s));
      break;
    case 'spectrometer':
      G(new THREE.BoxGeometry(0.26 * s, 0.55 * s, 0.28 * s).translate(0, 0, 0.14 * s));
      G(rx(new THREE.CylinderGeometry(0.17 * s, 0.05 * s, 0.26 * s, 8, 1, true)).translate(0, 0.12 * s, 0.41 * s));
      G(new THREE.BoxGeometry(0.12 * s, 0.14 * s, 0.12 * s).translate(0.2 * s, -0.15 * s, 0.1 * s));
      break;
    case 'radar':
      G(rx(new THREE.CylinderGeometry(0.035 * s, 0.035 * s, 0.26 * s, 6)).translate(0, 0, 0.13 * s));
      G(new THREE.BoxGeometry(0.75 * s, 0.48 * s, 0.04 * s).rotateX(-0.35).translate(0, 0, 0.3 * s));
      G(new THREE.BoxGeometry(0.75 * s, 0.03 * s, 0.06 * s).rotateX(-0.35).translate(0, 0, 0.3 * s));
      break;
    case 'rover': {
      upright = true;
      G(new THREE.BoxGeometry(0.52 * s, 0.16 * s, 0.36 * s).translate(0, 0.02 * s, 0));
      for (const x of [-0.29, 0.29]) for (const z of [-0.15, 0, 0.15]) {
        G(new THREE.CylinderGeometry(0.08 * s, 0.08 * s, 0.06 * s, 8).rotateZ(Math.PI / 2).translate(x * s, -0.1 * s, z * s));
      }
      G(new THREE.CylinderGeometry(0.02 * s, 0.02 * s, 0.24 * s, 5).translate(0.12 * s, 0.22 * s, 0.1 * s));
      G(new THREE.BoxGeometry(0.12 * s, 0.07 * s, 0.07 * s).translate(0.12 * s, 0.36 * s, 0.1 * s));
      break;
    }
    case 'drill':
      G(rx(new THREE.CylinderGeometry(0.15 * s, 0.15 * s, 0.28 * s, 8)).translate(0, 0, 0.14 * s));
      G(rx(new THREE.ConeGeometry(0.1 * s, 0.42 * s, 8)).translate(0, 0, 0.49 * s));
      G(new THREE.TorusGeometry(0.1 * s, 0.025 * s, 5, 10).translate(0, 0, 0.36 * s));
      break;
    case 'capsule':
      upright = true;
      G(new THREE.CylinderGeometry(0.15 * s, 0.42 * s, 0.46 * s, 12).translate(0, 0.26 * s, 0));
      G(new THREE.CylinderGeometry(0.44 * s, 0.44 * s, 0.06 * s, 14));
      G(new THREE.CylinderGeometry(0.08 * s, 0.12 * s, 0.1 * s, 8).translate(0, 0.54 * s, 0));
      break;
    default: // box + bilinmeyen modeller
      G(new THREE.BoxGeometry(0.48 * s, 0.42 * s, 0.36 * s).translate(0, 0, 0.18 * s));
  }
  return { geoms, upright };
}

// ---------------------------------------------------------------- duman parçacıkları
function createSmoke(texture) {
  const N = 220;
  const pos = new Float32Array(N * 3);
  const col = new Float32Array(N * 4);
  const geo = new THREE.BufferGeometry();
  geo.setAttribute('position', new THREE.BufferAttribute(pos, 3));
  geo.setAttribute('color', new THREE.BufferAttribute(col, 4));
  const mat = new THREE.PointsMaterial({
    size: 2.6, map: texture, vertexColors: true, transparent: true, depthWrite: false, sizeAttenuation: true
  });
  const points = new THREE.Points(geo, mat);
  points.frustumCulled = false;
  const P = Array.from({ length: N }, () => ({ age: 1, life: 1, x: 0, y: -999, z: 0, vx: 0, vy: 0, vz: 0, hot: 0 }));
  let cursor = 0;
  return {
    points,
    emit(x, y, z, n, groundY) {
      for (let i = 0; i < n; i++) {
        const p = P[cursor]; cursor = (cursor + 1) % N;
        const a = Math.random() * Math.PI * 2;
        const nearGround = y - groundY < 2.5;
        const sp = nearGround ? 2.5 + Math.random() * 4 : 0.6 + Math.random();
        p.x = x + (Math.random() - 0.5) * 0.4; p.y = nearGround ? groundY + 0.3 : y; p.z = z + (Math.random() - 0.5) * 0.4;
        p.vx = Math.cos(a) * sp; p.vz = Math.sin(a) * sp;
        p.vy = nearGround ? 0.3 + Math.random() * 1.2 : -1.5 - Math.random() * 1.5;
        p.age = 0; p.life = 1.6 + Math.random() * 1.6; p.hot = 1;
      }
    },
    update(dt) {
      for (let i = 0; i < N; i++) {
        const p = P[i];
        if (p.age < p.life) {
          p.age += dt;
          p.vx *= 1 - 0.9 * dt; p.vz *= 1 - 0.9 * dt; p.vy = p.vy * (1 - 0.8 * dt) + 0.35 * dt;
          p.x += p.vx * dt; p.y += p.vy * dt; p.z += p.vz * dt;
        }
        const k = clamp(p.age / p.life, 0, 1);
        const alive = p.age < p.life;
        pos[i * 3] = p.x; pos[i * 3 + 1] = alive ? p.y : -999; pos[i * 3 + 2] = p.z;
        const hot = Math.max(0, 1 - k * 5); // ilk anlar turuncu
        col[i * 4] = 0.55 + 0.45 * hot; col[i * 4 + 1] = 0.58 + 0.12 * hot; col[i * 4 + 2] = 0.66 - 0.3 * hot;
        col[i * 4 + 3] = alive ? (1 - k) * 0.5 * Math.min(1, k * 8 + 0.2) : 0;
      }
      geo.attributes.position.needsUpdate = true;
      geo.attributes.color.needsUpdate = true;
    },
    clear() { for (const p of P) { p.age = p.life = 1; } this.update(0); }
  };
}

// ================================================================ sahne
function buildScene(container) {
  injectStyle();
  const renderer = new THREE.WebGLRenderer({ antialias: true, alpha: true, powerPreference: 'low-power' });
  renderer.setPixelRatio(Math.min(window.devicePixelRatio || 1, 2));
  renderer.setClearColor(C.bg, 1);
  const canvas = renderer.domElement;
  canvas.className = 'scene3d-canvas';
  Object.assign(canvas.style, { display: 'block', width: '100%', height: '100%', touchAction: 'none', outline: 'none' });
  if (getComputedStyle(container).position === 'static') container.style.position = 'relative';
  container.appendChild(canvas);

  const label = document.createElement('div');
  label.className = 'slot-label';
  label.hidden = true;
  container.appendChild(label);

  const scene = new THREE.Scene();
  scene.fog = new THREE.FogExp2(C.bg, 0.014);
  const camera = new THREE.PerspectiveCamera(38, 1, 0.1, 800);
  camera.position.set(14, 8, 18);

  const controls = new OrbitControls(camera, canvas);
  controls.enableDamping = true; controls.dampingFactor = 0.08;
  controls.enablePan = false;
  controls.rotateSpeed = 0.7;
  controls.autoRotate = true; controls.autoRotateSpeed = 0.6;
  controls.minPolarAngle = 0.12; controls.maxPolarAngle = Math.PI * 0.86;

  // Işıklar
  const hemi = new THREE.HemisphereLight(0xa8d4ff, 0x0a1120, 1.4);
  const sun = new THREE.DirectionalLight(0xffffff, 1.8);
  sun.position.set(8, 14, 10);
  const flameLight = new THREE.PointLight(0xffa040, 0, 18, 1.5);
  scene.add(hemi, sun, flameLight);

  // Paylaşılan malzemeler (dispose'da topluca serbest bırakılır)
  const shared = [];
  const S = (m) => { shared.push(m); return m; };
  const glowTex = makeGlowTexture();
  const hullMat = S(makeHoloMaterial());
  const edgeMat = S(new THREE.LineBasicMaterial({ color: C.cyan, transparent: true, opacity: 0.8 }));
  const seamMat = S(new THREE.LineBasicMaterial({ color: C.cyan, transparent: true, opacity: 0.22 }));
  // Yuva işaretçisi görünümü (durum başına). Malzemeler yuva başına (opaklık/nabız ayrı ayrı); minPx = ekrandaki asgari boyut.
  const MARK = {
    neutral: { color: 0xa6dcff, band: 0.92, fill: 0.16, minPx: 16 },
    ok: { color: C.green, band: 1, fill: 0.3, minPx: 20 },
    blocked: { color: C.red, band: 0.95, fill: 0.3, minPx: 18 },
    occupied: { color: 0x8fb4d8, band: 0.22, fill: 0, minPx: 10 },
    dim: { color: C.dim, band: 0.28, fill: 0.04, minPx: 9 }
  };
  const hitMat = S(new THREE.MeshBasicMaterial({ visible: false }));
  const partMats = new Map(); // role|mine → { mesh, edge }
  function partMaterial(role, mine) {
    const key = `${role}|${mine ? 1 : 0}`;
    if (!partMats.has(key)) {
      const color = ROLE_COLORS[role] ?? 0xc9d6ea;
      const mesh = S(new THREE.MeshPhongMaterial({
        color, emissive: color, emissiveIntensity: mine ? 0.38 : 0.16, flatShading: true, shininess: 40, side: THREE.DoubleSide
      }));
      const edge = S(new THREE.LineBasicMaterial({
        color: mine ? 0xffffff : color, transparent: true, opacity: mine ? 0.9 : 0.45
      }));
      mesh.userData.baseEmissive = mesh.emissiveIntensity;
      mesh.userData.baseColor = mesh.color.clone();
      edge.userData.baseOpacity = edge.opacity;
      partMats.set(key, { mesh, edge });
    }
    return partMats.get(key);
  }

  // ---------------------------------------------------------- ortam: yıldızlar, zemin
  {
    const n = 700, p = new Float32Array(n * 3), c = new Float32Array(n * 3);
    for (let i = 0; i < n; i++) {
      const v = new THREE.Vector3().randomDirection().multiplyScalar(220 + Math.random() * 120);
      if (v.y < -40) v.y = -v.y; // çoğu ufkun üstünde
      p.set([v.x, v.y, v.z], i * 3);
      const b = 0.35 + Math.random() * 0.65, cy = Math.random() < 0.25;
      c.set([b * (cy ? 0.6 : 1), b * (cy ? 0.85 : 1), b], i * 3);
    }
    const g = new THREE.BufferGeometry();
    g.setAttribute('position', new THREE.BufferAttribute(p, 3));
    g.setAttribute('color', new THREE.BufferAttribute(c, 3));
    const stars = new THREE.Points(g, S(new THREE.PointsMaterial({
      size: 1.6, sizeAttenuation: false, vertexColors: true, fog: false, transparent: true, opacity: 0.9
    })));
    scene.add(stars);
    const grid = new THREE.GridHelper(120, 60, 0x1f4a6e, 0x12223a);
    grid.material.transparent = true; grid.material.opacity = 0.7;
    shared.push(grid.material);
    grid.position.y = -0.2;
    scene.add(grid);
  }
  const envGroup = new THREE.Group(); // rampa + kule (gövde boyutuna göre)
  scene.add(envGroup);
  const beacons = [];

  // ---------------------------------------------------------- roket grupları
  const rocketRoot = new THREE.Group();
  const hullGroup = new THREE.Group();
  const slotGroup = new THREE.Group();
  const fxGroup = new THREE.Group();
  rocketRoot.add(hullGroup, slotGroup, fxGroup);
  scene.add(rocketRoot);
  const smoke = createSmoke(glowTex);
  scene.add(smoke.points);

  // ---------------------------------------------------------- durum
  let frameData = null, frameSig = null;
  let dims = { H: 10, W: 1.5, lift: 0.5, r0: 1 };
  const slotObjs = new Map(); // slotId → { slot, root, line, fill, hit, size, occupant, partKey, holder, state }
  let lastSlots = null, slotsSig = null;
  let highlights = null, hlSig = null;
  let myRole = null;
  let slotCb = null, partCb = null;
  const anims = [];
  let launch = null, launchDirty = false, launchTimer = 0;
  let userZoomed = false, autoTimer = 0; // elle yakınlaştırma/odak → resize kadrajı bozmaz
  let labelSlot = null, labelTimer = 0;
  let fade = 1, curPower = 1;             // highlight varken gövde/parçalar soluklaşır
  let tags = [];                          // .slot-tag öğeleri: { el, id, state, w, h }
  let disposed = false, ready = false;

  function disposeTree(obj) {
    obj.traverse((o) => { if (o.geometry) o.geometry.dispose(); });
  }
  function clearGroup(g) {
    for (const ch of [...g.children]) { g.remove(ch); disposeTree(ch); }
  }
  function addSolid(group, geom, mat = hullMat, edges = edgeMat, thr = 25) {
    const m = new THREE.Mesh(geom, mat);
    group.add(m);
    if (edges) group.add(new THREE.LineSegments(new THREE.EdgesGeometry(geom, thr), edges));
    return m;
  }

  // ---------------------------------------------------------- gövde çizimi
  function buildHull(shape, slots) {
    clearGroup(hullGroup);
    shape = shape || {};
    let noseInfo = null, booster = null;
    let segs = (Array.isArray(shape.segments) ? shape.segments : []).map((s) => {
      const y0 = num(s.y0, 0), y1 = num(s.y1, y0 + 1);
      const r = num(s.radius, 1);
      return { y0: Math.min(y0, y1), y1: Math.max(y0, y1), rb: num(s.radiusBottom ?? s.r0, r), rt: num(s.radiusTop ?? s.r1, r), id: s.id };
    }).sort((a, b) => a.y0 - b.y0);
    if (!segs.length) segs = [{ y0: 0, y1: 6, rb: 1, rt: 1 }];

    const frustum = (y0, y1, rb, rt) => {
      const h = Math.max(0.01, y1 - y0);
      addSolid(hullGroup, new THREE.CylinderGeometry(rt, rb, h, 28, 1, true).translate(0, (y0 + y1) / 2, 0));
      // N/E/S/W dikiş çizgileri (yüzleri okutur)
      const pts = [];
      for (let i = 0; i < 4; i++) {
        const a = (i * Math.PI) / 2;
        pts.push(Math.cos(a) * rb, y0, Math.sin(a) * rb, Math.cos(a) * rt, y1, Math.sin(a) * rt);
      }
      const g = new THREE.BufferGeometry();
      g.setAttribute('position', new THREE.Float32BufferAttribute(pts, 3));
      hullGroup.add(new THREE.LineSegments(g, seamMat));
    };
    const ring = (y, r1, r2) => {
      addSolid(hullGroup, new THREE.RingGeometry(Math.min(r1, r2), Math.max(r1, r2), 28).rotateX(-Math.PI / 2).translate(0, y, 0));
    };

    let prev = null, maxR = 0;
    for (const s of segs) {
      if (prev) {
        if (s.y0 > prev.y1 + 1e-3) frustum(prev.y1, s.y0, prev.rt, s.rb);
        else if (Math.abs(prev.rt - s.rb) > 1e-3) ring(s.y0, prev.rt, s.rb);
      }
      frustum(s.y0, s.y1, s.rb, s.rt);
      maxR = Math.max(maxR, s.rb, s.rt);
      prev = s;
    }
    let top = prev.y1;
    // Burun: ogive benzeri profil
    if (shape.nose) {
      const ny0 = num(shape.nose.y0, top), ny1 = Math.max(ny0 + 0.2, num(shape.nose.y1, ny0 + 2));
      const R = num(shape.nose.radius, prev.rt);
      if (ny0 > top + 1e-3) frustum(top, ny0, prev.rt, R);
      else if (Math.abs(prev.rt - R) > 1e-3) ring(ny0, prev.rt, R);
      const pts = [];
      for (let i = 0; i <= 14; i++) {
        const t = i / 14;
        pts.push(new THREE.Vector2(Math.max(0.001, R * Math.pow(Math.cos((t * Math.PI) / 2), 0.75)), ny0 + t * (ny1 - ny0)));
      }
      addSolid(hullGroup, new THREE.LatheGeometry(pts, 28), hullMat, edgeMat, 18);
      maxR = Math.max(maxR, R);
      noseInfo = { y0: ny0, y1: ny1, R };
      top = ny1;
    }

    // Kanatçıklar / yan iticiler: yüzey yuvalarını kapatmayacak açıya yerleştirilir
    const s0 = segs[0];
    const r0 = s0.rb;
    const finCount = clamp(Math.round(num(shape.fins, 0)), 0, 8);
    const boosterCount = clamp(Math.round(num(shape.boosters, 0)), 0, 8);
    const slotAngles = (Array.isArray(slots) ? slots : [])
      .filter((s) => s && s.kind === 'surface')
      .map((s) => { const p = vec3(s.pos, new THREE.Vector3()); return Math.atan2(p.z, p.x); });
    const bestOffset = (n) => {
      if (!slotAngles.length) return Math.PI / 4;
      let best = Math.PI / 4, bestScore = -1;
      const step = (Math.PI * 2) / n;
      for (let o = 0; o < step; o += Math.PI / 36) {
        let score = Infinity;
        for (let i = 0; i < n; i++) for (const a of slotAngles) {
          const d = Math.abs(Math.atan2(Math.sin(o + i * step - a), Math.cos(o + i * step - a)));
          score = Math.min(score, d);
        }
        if (score > bestScore + 1e-6) { bestScore = score; best = o; }
      }
      return best;
    };
    // shape.booster (isteğe bağlı): { radius, y0, y1, offset, axis: 'x'|'z' } — yuvalar bu konuma göre verilmiş olabilir
    const bs = shape.booster && typeof shape.booster === 'object' ? shape.booster : null;
    const finGeom = (rootH, span) => {
      const sh = new THREE.Shape();
      sh.moveTo(0, 0); sh.lineTo(span, -rootH * 0.18); sh.lineTo(span, rootH * 0.22); sh.lineTo(0, rootH);
      sh.closePath();
      return new THREE.ExtrudeGeometry(sh, { depth: 0.06, bevelEnabled: false }).translate(0, 0, -0.03);
    };
    let outer = maxR;
    if (boosterCount > 0) {
      const rb = num(bs?.radius, r0 * 0.38);
      const by0 = num(bs?.y0, 0.1);
      const len = Math.max(1, num(bs?.y1, by0 + Math.max(2, (s0.y1 - s0.y0) * 0.95)) - by0);
      const d = num(bs?.offset, r0 + rb + 0.06);
      const a0 = bs ? (bs.axis === 'z' ? Math.PI / 2 : 0) : bestOffset(boosterCount);
      for (let i = 0; i < boosterCount; i++) {
        const a = a0 + (i * Math.PI * 2) / boosterCount;
        const g = new THREE.Group();
        addSolid(g, new THREE.CylinderGeometry(rb, rb, len, 16, 1, true).translate(0, by0 + len / 2, 0));
        addSolid(g, new THREE.ConeGeometry(rb, len * 0.2, 16, 1, true).translate(0, by0 + len + len * 0.1, 0));
        addSolid(g, new THREE.CylinderGeometry(rb * 0.55, rb * 0.8, 0.35, 12, 1, true).translate(0, by0 - 0.175, 0));
        if (finCount > 0) {
          const f = new THREE.Mesh(finGeom(len * 0.35, rb * 1.4), hullMat);
          f.position.set(rb * 0.95, by0, 0);
          g.add(f, new THREE.LineSegments(new THREE.EdgesGeometry(f.geometry, 25), edgeMat));
          g.children[g.children.length - 1].position.copy(f.position);
        }
        g.position.set(Math.cos(a) * d, 0, Math.sin(a) * d);
        g.rotation.y = -a;
        hullGroup.add(g);
      }
      outer = Math.max(outer, d + rb * (finCount > 0 ? 2.4 : 1));
      booster = { r: rb, d };
    } else if (finCount > 0) {
      const rootH = Math.min((s0.y1 - s0.y0) * 0.45, 2.4), span = r0 * 0.8;
      const fo = bestOffset(finCount);
      for (let i = 0; i < finCount; i++) {
        const a = fo + (i * Math.PI * 2) / finCount;
        const g = new THREE.Group();
        addSolid(g, finGeom(rootH, span));
        g.position.set(Math.cos(a) * r0 * 0.98, s0.y0, Math.sin(a) * r0 * 0.98);
        g.rotation.y = -a;
        hullGroup.add(g);
      }
      outer = Math.max(outer, r0 + span);
    }
    return { H: top, W: outer, R: maxR, r0, segs, nose: noseInfo, booster };
  }

  // Rampa + servis kulesi
  let envMats = null;
  function buildEnv() {
    clearGroup(envGroup);
    beacons.length = 0;
    const R = dims.W + 1.4;
    envMats = envMats || {
      pad: S(new THREE.MeshPhongMaterial({ color: 0x0a1424, emissive: 0x050a14, flatShading: true })),
      edge: S(new THREE.LineBasicMaterial({ color: C.cyan, transparent: true, opacity: 0.35 })),
      tower: S(new THREE.LineBasicMaterial({ color: C.cyan, transparent: true, opacity: 0.2 })),
      beacon: S(new THREE.SpriteMaterial({ map: glowTex, color: C.amber, transparent: true, depthWrite: false, blending: THREE.AdditiveBlending }))
    };
    const padMat = envMats.pad, padEdge = envMats.edge;
    addSolid(envGroup, new THREE.CylinderGeometry(R, R * 1.06, 0.2, 40).translate(0, -0.1, 0), padMat, padEdge, 20);
    for (const rr of [R * 0.55, R * 0.8]) {
      const pts = [];
      for (let i = 0; i <= 48; i++) { const a = (i / 48) * Math.PI * 2; pts.push(new THREE.Vector3(Math.cos(a) * rr, 0.01, Math.sin(a) * rr)); }
      envGroup.add(new THREE.Line(new THREE.BufferGeometry().setFromPoints(pts), seamMat));
    }
    // Kafes kule (yalnız çizgi; ince, kısa ve soluk — roketi kapatmaz, kadraja girmez)
    const towerMat = envMats.tower;
    const th = Math.max(3, (dims.H + dims.lift) * 0.55), tw = 0.55, tx = -(dims.W + 0.9);
    const tp = [];
    const levels = Math.max(3, Math.round(th / 1.2));
    for (let l = 0; l <= levels; l++) {
      const y = (l / levels) * th, y2 = ((l + 1) / levels) * th;
      const c = [[-tw / 2, -tw / 2], [tw / 2, -tw / 2], [tw / 2, tw / 2], [-tw / 2, tw / 2]];
      for (let i = 0; i < 4; i++) {
        const [ax, az] = c[i], [bx, bz] = c[(i + 1) % 4];
        tp.push(ax, y, az, bx, y, bz);
        if (l < levels) { tp.push(ax, y, az, ax, y2, az); tp.push(ax, y, az, bx, y2, bz); }
      }
    }
    const tg = new THREE.BufferGeometry();
    tg.setAttribute('position', new THREE.Float32BufferAttribute(tp, 3));
    const tower = new THREE.LineSegments(tg, towerMat);
    tower.position.x = tx;
    envGroup.add(tower);
    const arm = new THREE.BufferGeometry().setFromPoints([new THREE.Vector3(tx + tw / 2, th * 0.7, 0), new THREE.Vector3(-dims.r0 - 0.1, th * 0.7, 0)]);
    envGroup.add(new THREE.Line(arm, towerMat));
    const bMat = envMats.beacon;
    for (const y of [th, th * 0.5]) {
      const b = new THREE.Sprite(bMat);
      b.scale.setScalar(0.6);
      b.position.set(tx, y + 0.1, 0);
      envGroup.add(b);
      beacons.push(b);
    }
  }

  // ---------------------------------------------------------- yuva işaretçileri
  // İşaretçi geometrileri XY düzleminde, +Z'ye bakar. Kalın kenar = içi boş şekil (WebGL çizgileri 1 px kalır).
  function rectBand(w, h, t) {
    const s = new THREE.Shape();
    s.moveTo(-w / 2, -h / 2); s.lineTo(w / 2, -h / 2); s.lineTo(w / 2, h / 2); s.lineTo(-w / 2, h / 2); s.closePath();
    const iw = w / 2 - t, ih = h / 2 - t, hole = new THREE.Path();
    hole.moveTo(-iw, -ih); hole.lineTo(-iw, ih); hole.lineTo(iw, ih); hole.lineTo(iw, -ih); hole.closePath();
    s.holes.push(hole);
    return new THREE.ShapeGeometry(s);
  }
  function crossMeshes(len, t, mat) {
    const g = new THREE.Group();
    for (const a of [Math.PI / 4, -Math.PI / 4]) {
      const m = new THREE.Mesh(new THREE.PlaneGeometry(len, t).rotateZ(a), mat);
      m.renderOrder = 6;
      g.add(m);
    }
    return g;
  }
  function disposeMarkerMats() {
    for (const so of slotObjs.values()) { so.bandMat.dispose(); so.fillMat.dispose(); }
  }
  function buildMarkers() {
    disposeMarkerMats();
    clearGroup(slotGroup);
    slotObjs.clear();
    if (!frameData || !Array.isArray(frameData.slots)) return;
    const slots = frameData.slots.filter((s) => s && s.id != null);
    const P = slots.map((s) => vec3(s.pos, new THREE.Vector3()));
    const radiusAt = (slot, p) => {
      const n = dims.nose;
      if (n && (slot.segment === 'nose' || (p.y > n.y0 && p.y <= n.y1))) {
        return n.R * Math.max(0.35, Math.cos(((clamp(p.y, n.y0, n.y1) - n.y0) / (n.y1 - n.y0)) * Math.PI / 2));
      }
      const b = dims.booster;
      if (b && Math.hypot(p.x, p.z) > b.d - b.r - 0.05) return b.r;
      const seg = dims.segs.find((s) => s.id === slot.segment) || dims.segs.find((s) => p.y >= s.y0 && p.y <= s.y1) || dims.segs[0];
      return Math.max(seg.rb, seg.rt);
    };
    const matOpts = { transparent: true, depthWrite: false, depthTest: false, side: THREE.DoubleSide };
    slots.forEach((slot, i) => {
      const p = P[i];
      let nearest = Infinity;
      P.forEach((q, j) => { if (j !== i) nearest = Math.min(nearest, p.distanceTo(q)); });
      const r = radiusAt(slot, p);
      const base = slot.kind === 'mount' ? clamp(r * 0.65, 0.35, 0.9) : slot.kind === 'internal' ? clamp(r * 0.85, 0.4, 1.3) : clamp(r * 0.75, 0.4, 1.0);
      const size = Math.max(0.22, Math.min(base, nearest * 0.85));
      const root = new THREE.Group();
      root.position.copy(p);
      root.quaternion.copy(slotQuaternion(slot));
      const bandMat = new THREE.MeshBasicMaterial({ ...matOpts, color: MARK.neutral.color, opacity: MARK.neutral.band });
      const fillMat = new THREE.MeshBasicMaterial({ ...matOpts, color: MARK.neutral.color, opacity: MARK.neutral.fill });
      const t = size * 0.13; // kenar kalınlığı
      let bg, fg, crossLen;
      // İç bölme = baklava, motor = halka (ikisi de kameraya döner: her açıdan okunur); yüzey = yüze yapışık çerçeve
      if (slot.kind === 'mount') {
        const rr = size * 0.5;
        bg = new THREE.RingGeometry(rr - t, rr, 32);
        fg = new THREE.CircleGeometry(rr - t, 24);
        crossLen = rr * 1.5;
      } else if (slot.kind === 'internal') {
        const a = size * 0.72;
        bg = rectBand(a, a, t).rotateZ(Math.PI / 4);
        fg = new THREE.PlaneGeometry(a - 2 * t, a - 2 * t).rotateZ(Math.PI / 4);
        crossLen = a * 0.95;
      } else {
        const w = size * 0.9, h = size * 1.15;
        bg = rectBand(w, h, t);
        fg = new THREE.PlaneGeometry(w - 2 * t, h - 2 * t);
        crossLen = Math.min(w, h) * 1.05;
      }
      const marker = new THREE.Group();
      if (slot.kind === 'surface') marker.position.z = 0.05;
      const fill = new THREE.Mesh(fg, fillMat); fill.renderOrder = 4;
      const band = new THREE.Mesh(bg, bandMat); band.renderOrder = 5;
      const cross = crossMeshes(crossLen, t * 0.9, bandMat);
      cross.visible = false;
      const hitR = Math.max(size * 0.8, 0.4);
      const hit = new THREE.Mesh(new THREE.SphereGeometry(hitR, 8, 6), hitMat);
      hit.userData.slotId = slot.id;
      marker.add(fill, band, cross, hit);
      root.add(marker);
      slotGroup.add(root);
      slotObjs.set(slot.id, {
        slot, root, marker, band, fill, cross, hit, hitR, size, bandMat, fillMat,
        billboard: slot.kind !== 'surface', scale: 1, px: 0,
        occupant: null, partKey: '', holder: null, state: 'neutral'
      });
    });
  }

  function computeState(so) {
    const h = highlights && highlights[so.slot.id];
    if (h === 'ok' || h === 'blocked') return h;
    if (so.occupant) return 'occupied';
    return highlights ? 'dim' : 'neutral';
  }
  function applyState(so) {
    so.state = computeState(so);
    const m = MARK[so.state];
    so.bandMat.color.setHex(m.color);
    so.fillMat.color.setHex(m.color);
    so.cross.visible = so.state === 'blocked';
  }

  // Her kare: kameraya döndürme, asgari ekran boyutu, nabız, arka yüz soluklaştırma
  const _q = new THREE.Quaternion(), _wp = new THREE.Vector3(), _n = new THREE.Vector3(), _c = new THREE.Vector3();
  function updateMarkers(pulse) {
    if (!slotObjs.size) return;
    const tanH = Math.tan(THREE.MathUtils.degToRad(camera.fov) / 2);
    const ch = canvas.clientHeight || 1;
    camera.updateMatrixWorld();
    for (const so of slotObjs.values()) {
      const m = MARK[so.state];
      so.root.getWorldPosition(_wp);
      const ppu = ch / (2 * Math.max(0.01, camera.position.distanceTo(_wp)) * tanH); // px / birim
      const hov = labelSlot === so.slot.id && so.state !== 'dim' && so.state !== 'occupied';
      let sc = clamp(m.minPx / (so.size * ppu), 1, 3.2);
      so.scale = sc;
      if (so.state === 'ok') sc *= 1 + 0.14 * pulse;
      if (hov) sc *= 1.15;
      so.marker.scale.setScalar(sc);
      so.px = so.size * ppu * sc;
      if (so.billboard) {
        so.root.getWorldQuaternion(_q).invert().multiply(camera.quaternion);
        so.marker.quaternion.copy(_q);
      }
      let a = 1;
      if (so.slot.kind === 'surface') {
        // kameraya sırtı dönük yüz yuvası gövdenin arkasında: daha soluk
        _n.set(0, 0, 1).applyQuaternion(so.root.getWorldQuaternion(_q));
        if (_n.dot(_c.subVectors(camera.position, _wp)) < 0) a = 0.45;
      }
      let band = m.band, fill = m.fill;
      if (so.state === 'ok') { band = 0.7 + 0.3 * pulse; fill = 0.18 + 0.24 * pulse; }
      if (hov) { band = 1; fill = Math.max(fill, 0.3); }
      so.bandMat.opacity = band * a;
      so.fillMat.opacity = fill * a;
    }
  }

  // ---------------------------------------------------------- parçalar
  function makePart(so, occ) {
    const mats = partMaterial(occ.role, !!occ.mine);
    // dış parçalar işaretçiden biraz büyük çizilir ki uzaktan okunabilsin
    const scale = so.slot.kind === 'internal' ? 1.05 : 1.3;
    const { geoms, upright } = buildPartModel(String(occ.model || 'box'), so.size * scale);
    const model = new THREE.Group();
    for (const g of geoms) {
      const m = new THREE.Mesh(g, mats.mesh);
      m.userData.slotId = so.slot.id;
      model.add(m, new THREE.LineSegments(new THREE.EdgesGeometry(g, 35), mats.edge));
    }
    const holder = new THREE.Group();
    holder.add(model);
    if (so.slot.kind === 'internal' || upright) {
      const box = new THREE.Box3().setFromObject(model);
      const c = box.getCenter(new THREE.Vector3());
      model.position.sub(c);
      if (so.slot.kind !== 'internal') {
        // dik modeli yuvanın dış normali yönünde yüzeye oturt (holder uzayında)
        const n = new THREE.Vector3(0, 0, 1).applyQuaternion(so.root.quaternion);
        const sz = box.getSize(new THREE.Vector3());
        model.position.addScaledVector(n, Math.max(sz.x, sz.y, sz.z) * 0.5);
      }
    }
    if (upright) holder.quaternion.copy(so.root.quaternion).invert(); // dünyaya göre dik
    holder.userData.slotId = so.slot.id;
    so.root.add(holder);
    return holder;
  }
  function removePart(so, animate) {
    const holder = so.holder;
    so.holder = null;
    if (!holder) return;
    if (!animate) { so.root.remove(holder); disposeTree(holder); return; }
    const s0 = holder.scale.x;
    anims.push({
      t0: now(), dur: 0.25,
      update(k) { holder.scale.setScalar(Math.max(0.001, s0 * (1 - k * k))); },
      done() { if (holder.parent) holder.parent.remove(holder); disposeTree(holder); }
    });
  }
  function addPart(so, occ, animate) {
    const holder = makePart(so, occ);
    so.holder = holder;
    if (!animate) return;
    const outward = so.slot.kind === 'internal' ? 0 : so.size * 0.8;
    holder.scale.setScalar(0.001);
    anims.push({
      t0: now(), dur: 0.45,
      update(k) {
        holder.scale.setScalar(Math.max(0.001, easeOutBack(k)));
        holder.position.z = outward * (1 - k) * (1 - k);
      },
      done() { holder.scale.setScalar(1); holder.position.z = 0; }
    });
    // yerine oturma parlaması
    const flash = new THREE.Mesh(new THREE.RingGeometry(so.size * 0.3, so.size * 0.42, 24),
      new THREE.MeshBasicMaterial({ color: ROLE_COLORS[occ.role] ?? 0xffffff, transparent: true, opacity: 0.9, depthWrite: false, side: THREE.DoubleSide, blending: THREE.AdditiveBlending }));
    flash.position.z = 0.06;
    so.root.add(flash);
    anims.push({
      t0: now(), dur: 0.5,
      update(k) { flash.scale.setScalar(1 + k * 2); flash.material.opacity = 0.9 * (1 - k); },
      done() { so.root.remove(flash); flash.geometry.dispose(); flash.material.dispose(); }
    });
  }
  function syncParts(animate) {
    const byId = new Map();
    if (Array.isArray(lastSlots)) for (const s of lastSlots) if (s && s.id != null) byId.set(s.id, s.occupant || null);
    for (const so of slotObjs.values()) {
      const occ = byId.get(so.slot.id) || null;
      const key = occ ? `${occ.role}|${occ.model}|${occ.mine ? 1 : 0}` : '';
      so.occupant = occ;
      if (key !== so.partKey) {
        removePart(so, animate);
        if (occ) addPart(so, occ, animate);
        so.partKey = key;
      }
      applyState(so);
    }
    if (labelSlot) updateLabelText();
    if (fade < 1) applyLook(); // yeni parça malzemeleri de soluk başlasın
  }

  // ---------------------------------------------------------- kamera
  // Otomatik kadraj: rampa tabanından burun ucuna kadar roket, kapsayıcı yüksekliğinin FILL_H'ini doldurur
  // (genişlik FILL_W ile sınırlı). Örnekler y ekseni etrafında dairesel → otomatik dönüşte kadraj sabit kalır.
  // Kule/rampa hesaba katılmaz. Mesafe yinelemeli izdüşümle bulunur (perspektif + kamera yüksekliği dahil).
  const FILL_H = 0.86, FILL_W = 0.9;
  const fitCam = new THREE.PerspectiveCamera();
  function fitSamples() {
    const top = dims.lift + dims.H, W = Math.max(0.4, dims.W), Rh = Math.max(0.3, num(dims.R, dims.W));
    const yBody = dims.lift + (dims.nose ? dims.nose.y0 : dims.H);
    const pts = [new THREE.Vector3(0, top, 0)];
    for (let i = 0; i < 16; i++) {
      const a = (i / 16) * Math.PI * 2, c = Math.cos(a), s = Math.sin(a);
      pts.push(new THREE.Vector3(c * W, 0, s * W), new THREE.Vector3(c * W, dims.lift + dims.H * 0.3, s * W),
        new THREE.Vector3(c * Rh, yBody, s * Rh));
    }
    return pts;
  }
  function fitCamera(keepDir = true) {
    let dir = new THREE.Vector3().subVectors(camera.position, controls.target);
    if (!keepDir || dir.lengthSq() < 1e-6) dir = new THREE.Vector3(0.55, 0.2, 0.8);
    dir.normalize();
    const pts = fitSamples();
    const top = dims.lift + dims.H;
    const tanH = Math.tan(THREE.MathUtils.degToRad(camera.fov) / 2);
    const cosE = Math.max(0.2, Math.sqrt(1 - dir.y * dir.y));
    fitCam.fov = camera.fov; fitCam.aspect = camera.aspect; fitCam.near = 0.05; fitCam.far = 5000;
    fitCam.updateProjectionMatrix();
    const target = new THREE.Vector3(0, top * 0.5, 0);
    let d = top * 1.8 + 2;
    const v = new THREE.Vector3();
    for (let it = 0; it < 8; it++) {
      fitCam.position.copy(target).addScaledVector(dir, d);
      fitCam.lookAt(target);
      fitCam.updateMatrixWorld();
      let x0 = Infinity, x1 = -Infinity, y0 = Infinity, y1 = -Infinity;
      for (const p of pts) {
        v.copy(p).project(fitCam);
        if (v.z > 1) { y0 = -9; y1 = 9; continue; } // kameranın arkasında: uzaklaş
        x0 = Math.min(x0, v.x); x1 = Math.max(x1, v.x); y0 = Math.min(y0, v.y); y1 = Math.max(y1, v.y);
      }
      // ortala (yalnız dünya y'si; hedef eksende kalır) ve ölçekle
      target.y += ((y0 + y1) / 2) * d * tanH / cosE;
      const k = Math.max((y1 - y0) / 2 / FILL_H, (x1 - x0) / 2 / FILL_W);
      d = Math.max(dims.W * 1.5 + 1, d * clamp(k, 0.3, 3));
    }
    controls.target.copy(target);
    camera.position.copy(target).addScaledVector(dir, d);
    controls.minDistance = Math.max(1.5, d * 0.28);
    controls.maxDistance = d * 2.6;
    camera.updateProjectionMatrix();
    controls.update();
  }
  function pauseAuto(ms = 7000) {
    controls.autoRotate = false;
    clearTimeout(autoTimer);
    autoTimer = setTimeout(() => { if (!launch && !disposed) controls.autoRotate = true; }, ms);
  }
  controls.addEventListener('start', () => { controls.autoRotate = false; clearTimeout(autoTimer); });
  const onWheel = () => { userZoomed = true; };
  canvas.addEventListener('wheel', onWheel, { passive: true });
  controls.addEventListener('end', () => pauseAuto(7000));

  // ---------------------------------------------------------- seçme (raycast + ekran mesafesi)
  const raycaster = new THREE.Raycaster();
  const tmpV = new THREE.Vector3();
  function slotWorldPos(so, out = new THREE.Vector3()) { return so.root.getWorldPosition(out); }
  function projectToCanvas(world) {
    const v = tmpV.copy(world).project(camera);
    if (v.z > 1 || v.z < -1) return null;
    const w = canvas.clientWidth, h = canvas.clientHeight;
    return { x: ((v.x + 1) / 2) * w, y: ((1 - v.y) / 2) * h, z: v.z };
  }
  function pick(clientX, clientY, pointerType) {
    if (!slotObjs.size) return null;
    scene.updateMatrixWorld();
    const rect = canvas.getBoundingClientRect();
    const px = clientX - rect.left, py = clientY - rect.top;
    const ndc = new THREE.Vector2((px / rect.width) * 2 - 1, -(py / rect.height) * 2 + 1);
    raycaster.setFromCamera(ndc, camera);
    const targets = [];
    for (const so of slotObjs.values()) { targets.push(so.hit); if (so.holder) targets.push(so.holder); }
    const hits = raycaster.intersectObjects(targets, true);
    const rayIds = new Set();
    for (const h of hits) {
      let o = h.object;
      while (o && o.userData.slotId == null) o = o.parent;
      if (o) rayIds.add(o.userData.slotId);
    }
    const minR = pointerType === 'mouse' ? 10 : 26;
    const camRight = new THREE.Vector3().setFromMatrixColumn(camera.matrixWorld, 0);
    const cands = [];
    for (const so of slotObjs.values()) {
      // highlight haritası varken yalnız haritadaki yuvalar aday (alakasız yuvalar tıklamayı çalmaz)
      const hl = highlights ? highlights[so.slot.id] : null;
      if (highlights && hl !== 'ok' && hl !== 'blocked') continue;
      const wp = slotWorldPos(so);
      const sp = projectToCanvas(wp);
      if (!sp) continue;
      const edge = projectToCanvas(wp.clone().addScaledVector(camRight, so.hitR * so.scale));
      const rpx = edge ? Math.hypot(edge.x - sp.x, edge.y - sp.y) : 0;
      const d = Math.hypot(sp.x - px, sp.y - py);
      if (!rayIds.has(so.slot.id) && d > Math.max(rpx, minR)) continue;
      // 'ok' vurgulu yuva, kendisinden biraz uzak bir engelli/komşu yuvaya göre öncelikli (OK_BONUS px)
      cands.push({ id: so.slot.id, s: d - (hl === 'ok' ? OK_BONUS : 0), z: sp.z });
    }
    if (!cands.length) return null;
    cands.sort((a, b) => a.s - b.s);
    // ekranda neredeyse aynı yerde olanlar (TIE px): kameraya en yakın olan (önde) seçilir
    let best = cands[0];
    for (const c of cands) if (c.s - cands[0].s <= TIE_PX && c.z < best.z) best = c;
    return best.id;
  }
  const OK_BONUS = 6, TIE_PX = 3;
  function fire(slotId) {
    const so = slotObjs.get(slotId);
    if (!so) return false;
    const cb = so.occupant ? partCb : slotCb;
    try { if (cb) cb(slotId); } catch (e) { console.error('[scene3d] tıklama işleyicisi hatası:', e); }
    return true;
  }

  // ---------------------------------------------------------- etiket
  function updateLabelText() {
    const so = labelSlot && slotObjs.get(labelSlot);
    if (!so) { hideLabel(); return; }
    label.textContent = '';
    label.appendChild(document.createTextNode(String(so.slot.name ?? so.slot.id)));
    if (so.occupant && so.occupant.name) {
      const sp = document.createElement('span');
      sp.className = 'slot-label-part';
      sp.textContent = `${so.occupant.icon ? so.occupant.icon + ' ' : ''}${so.occupant.name}`;
      const c = ROLE_COLORS[so.occupant.role];
      if (c != null) sp.style.color = '#' + c.toString(16).padStart(6, '0');
      label.appendChild(sp);
    } else if (!so.occupant) {
      const sp = document.createElement('span');
      sp.className = 'slot-label-part slot-label-empty';
      sp.textContent = '(boş)';
      label.appendChild(sp);
    }
    label.hidden = false;
  }

  // ---------------------------------------------------------- kalıcı yuva etiketleri (.slot-tag)
  // Highlight varken vurgulu yuvaların yanında küçük ad etiketleri; en çok MAX_TAGS, önce 'ok'. Çakışan/ekran dışı gizlenir.
  const MAX_TAGS = 8;
  function clearTags() { for (const t of tags) t.el.remove(); tags = []; }
  function syncTags() {
    clearTags();
    if (!highlights || launch) return;
    const list = [];
    for (const so of slotObjs.values()) {
      const st = highlights[so.slot.id];
      if (st === 'ok' || st === 'blocked') list.push({ so, st });
    }
    list.sort((a, b) => (a.st === b.st ? 0 : a.st === 'ok' ? -1 : 1));
    const small = (canvas.clientWidth || 0) < 480 || (canvas.clientHeight || 0) < 260;
    for (const { so, st } of list.slice(0, MAX_TAGS)) {
      const el = document.createElement('div');
      el.className = 'slot-tag' + (small ? ' slot-tag-sm' : '');
      el.dataset.state = st;
      el.dataset.slot = so.slot.id;
      el.textContent = String(so.slot.name ?? so.slot.id);
      el.style.visibility = 'hidden';
      container.appendChild(el);
      tags.push({ el, id: so.slot.id, w: 0, h: 0 });
    }
  }
  function positionTags() {
    if (!tags.length) return;
    const cw = canvas.clientWidth, chh = canvas.clientHeight;
    const placed = [];
    // önce tüm işaretçi merkezleri: etiket başka bir vurgulu işaretçinin üstüne binmesin
    const centers = [];
    for (const t of tags) { const so = slotObjs.get(t.id); const sp = so && projectToCanvas(slotWorldPos(so)); if (sp) centers.push({ id: t.id, x: sp.x, y: sp.y, r: so.px * 0.5 }); }
    const axis = projectToCanvas(new THREE.Vector3(0, rocketRoot.position.y + dims.H * 0.5, 0));
    const cx = axis ? axis.x : cw / 2;
    for (const t of tags) {
      const so = slotObjs.get(t.id);
      const sp = so && !launch && labelSlot !== t.id ? projectToCanvas(slotWorldPos(so)) : null;
      if (!sp || sp.x < 0 || sp.y < 0 || sp.x > cw || sp.y > chh) { t.el.style.visibility = 'hidden'; continue; }
      if (!t.w) { t.w = t.el.offsetWidth; t.h = t.el.offsetHeight; }
      if (!t.w) { t.el.style.visibility = 'hidden'; continue; }
      const off = so.px * 0.5 + 5;
      const right = sp.x >= cx;
      let x = right ? sp.x + off : sp.x - off - t.w;
      let y = sp.y - t.h / 2;
      x = clamp(x, 2, Math.max(2, cw - t.w - 2));
      y = clamp(y, 2, Math.max(2, chh - t.h - 2));
      const r = { x0: x - 2, y0: y - 1, x1: x + t.w + 2, y1: y + t.h + 1 };
      const hitsTag = placed.some((p) => r.x0 < p.x1 && r.x1 > p.x0 && r.y0 < p.y1 && r.y1 > p.y0);
      const hitsMarker = centers.some((c) => c.id !== t.id && c.x + c.r > r.x0 && c.x - c.r < r.x1 && c.y + c.r > r.y0 && c.y - c.r < r.y1);
      if (hitsTag || hitsMarker) { t.el.style.visibility = 'hidden'; continue; }
      placed.push(r);
      t.el.style.visibility = '';
      t.el.style.transform = `translate(${Math.round(canvas.offsetLeft + x)}px,${Math.round(canvas.offsetTop + y)}px)`;
    }
  }
  function showLabel(slotId, ms) {
    clearTimeout(labelTimer);
    if (labelSlot !== slotId) { labelSlot = slotId; updateLabelText(); }
    if (ms) labelTimer = setTimeout(hideLabel, ms);
    positionLabel();
  }
  function hideLabel() { labelSlot = null; label.hidden = true; clearTimeout(labelTimer); }
  function positionLabel() {
    const so = labelSlot && slotObjs.get(labelSlot);
    if (!so) return;
    const sp = projectToCanvas(slotWorldPos(so));
    if (!sp) { label.style.visibility = 'hidden'; return; }
    label.style.visibility = '';
    label.style.left = `${canvas.offsetLeft + sp.x}px`;
    label.style.top = `${canvas.offsetTop + sp.y}px`;
  }

  // ---------------------------------------------------------- işaretçi olayları (tıklama ≠ sürükleme)
  let down = null;
  const active = new Set();
  const onDown = (e) => {
    active.add(e.pointerId);
    if (active.size > 1) userZoomed = true; // iki parmak = yakınlaştırma
    if (active.size > 1 || !e.isPrimary) { down = null; return; }
    down = { x: e.clientX, y: e.clientY, t: performance.now(), type: e.pointerType };
  };
  const onUp = (e) => {
    active.delete(e.pointerId);
    if (!down || !e.isPrimary) return;
    const d = Math.hypot(e.clientX - down.x, e.clientY - down.y);
    const thr = down.type === 'mouse' ? 5 : 12;
    const quick = performance.now() - down.t < 800;
    const type = down.type;
    down = null;
    if (d > thr || !quick || launch) return;
    const id = pick(e.clientX, e.clientY, type);
    if (id == null) { hideLabel(); return; }
    showLabel(id, type === 'mouse' ? 0 : 2600);
    fire(id);
  };
  const onCancel = (e) => { active.delete(e.pointerId); down = null; };
  const onMove = (e) => {
    if (down) {
      if (Math.hypot(e.clientX - down.x, e.clientY - down.y) > 12) hideLabel();
      return;
    }
    if (e.pointerType !== 'mouse' || launch) return;
    const id = pick(e.clientX, e.clientY, 'mouse');
    canvas.style.cursor = id != null ? 'pointer' : '';
    if (id != null) showLabel(id, 0); else if (labelSlot) hideLabel();
  };
  const onLeave = (e) => { if (e.pointerType === 'mouse') { hideLabel(); canvas.style.cursor = ''; } };
  canvas.addEventListener('pointerdown', onDown);
  canvas.addEventListener('pointerup', onUp);
  canvas.addEventListener('pointercancel', onCancel);
  canvas.addEventListener('pointermove', onMove);
  canvas.addEventListener('pointerleave', onLeave);

  // ---------------------------------------------------------- fırlatma efektleri
  let flames = [];
  function buildFlames() {
    for (const f of flames) { fxGroup.remove(f.group); disposeTree(f.group); }
    flames = [];
    const mounts = [...slotObjs.values()].filter((so) => so.slot.kind === 'mount');
    const spots = mounts.length ? mounts.map((so) => ({ p: so.root.position.clone(), s: so.size }))
      : [{ p: new THREE.Vector3(0, 0, 0), s: dims.r0 * 0.6 }];
    for (const sp of spots) {
      const g = new THREE.Group();
      const outer = new THREE.Mesh(new THREE.ConeGeometry(sp.s * 0.62, 1, 12, 1, true).rotateX(Math.PI).translate(0, -0.5, 0), flameOuterMat);
      const inner = new THREE.Mesh(new THREE.ConeGeometry(sp.s * 0.3, 0.55, 10, 1, true).rotateX(Math.PI).translate(0, -0.275, 0), flameInnerMat);
      const glow = new THREE.Sprite(flameGlowMat);
      glow.scale.setScalar(sp.s * 2.6);
      glow.position.y = -0.15;
      g.add(outer, inner, glow);
      g.position.copy(sp.p);
      g.position.y -= sp.s * 1.0;
      g.scale.set(1, 0.001, 1);
      g.visible = false;
      fxGroup.add(g);
      flames.push({ group: g, len: Math.max(1.5, dims.H * 0.35), y: g.position.y });
    }
  }
  const flameGlowMat = S(new THREE.SpriteMaterial({ map: glowTex, color: 0xff9a40, transparent: true, opacity: 0.8, depthWrite: false, blending: THREE.AdditiveBlending }));
  const flameOuterMat = S(new THREE.MeshBasicMaterial({ color: 0xff6a1a, transparent: true, opacity: 0.6, depthWrite: false, blending: THREE.AdditiveBlending, side: THREE.DoubleSide }));
  const flameInnerMat = S(new THREE.MeshBasicMaterial({ color: 0xfff2b0, transparent: true, opacity: 0.95, depthWrite: false, blending: THREE.AdditiveBlending, side: THREE.DoubleSide }));
  function setFlame(k) {
    for (const f of flames) {
      f.group.visible = k > 0.01;
      const fl = k * (0.85 + Math.random() * 0.3);
      f.group.scale.set(0.7 + 0.3 * k, Math.max(0.001, fl * f.len), 0.7 + 0.3 * k);
    }
    flameLight.intensity = k * (25 + Math.random() * 10);
  }

  // Gövde/parça görünümü = güç (fırlatma: power-loss) × soluklaşma (highlight varken hedefler öne çıksın)
  function applyLook() {
    const p = curPower, f = fade;
    hullMat.uniforms.uPower.value = p * (0.4 + 0.6 * f);
    hullMat.uniforms.uOpacity.value = 0.26 * (0.55 + 0.45 * f);
    edgeMat.opacity = 0.8 * (0.08 + 0.92 * p) * (0.32 + 0.68 * f);
    seamMat.opacity = 0.22 * p * f;
    for (const { mesh, edge } of partMats.values()) {
      mesh.emissiveIntensity = mesh.userData.baseEmissive * p * (0.4 + 0.6 * f);
      mesh.color.copy(mesh.userData.baseColor).multiplyScalar(0.45 + 0.55 * f);
      edge.opacity = edge.userData.baseOpacity * (0.15 + 0.85 * p) * (0.35 + 0.65 * f);
    }
  }
  function applyPower(p) {
    curPower = p;
    applyLook();
    slotGroup.visible = p > 0.3 || Math.random() > 0.7;
    hemi.intensity = 1.4 * (0.25 + 0.75 * p);
    sun.intensity = 1.8 * (0.3 + 0.7 * p);
    for (const b of beacons) b.visible = p > 0.5;
  }
  const heatCold = { fill: new THREE.Color(C.hullFill), rim: new THREE.Color(C.cyan), edge: new THREE.Color(C.cyan) };
  const heatHot = { fill: new THREE.Color(0x5a0e04), rim: new THREE.Color(0xff5a2a), edge: new THREE.Color(0xff7a3a) };
  function applyHeat(h) {
    hullMat.uniforms.uColor.value.copy(heatCold.fill).lerp(heatHot.fill, h);
    hullMat.uniforms.uRim.value.copy(heatCold.rim).lerp(heatHot.rim, h);
    edgeMat.color.copy(heatCold.edge).lerp(heatHot.edge, h);
  }

  let impact = null;
  function resetLaunch() {
    clearTimeout(launchTimer);
    if (launch) { const r = launch.resolve; launch = null; r(); }
    rocketRoot.position.set(0, dims.lift, 0);
    rocketRoot.rotation.set(0, 0, 0);
    setFlame(0);
    smoke.clear();
    if (impact) { scene.remove(impact); impact.geometry.dispose(); impact.material.dispose(); impact = null; }
    applyPower(1);
    slotGroup.visible = true;
    applyHeat(0);
    controls.enabled = true;
    if (launchDirty) { launchDirty = false; fitCamera(true); }
  }

  function playLaunch(outcome) {
    if (disposed || outcome === 'window-missed' || !frameData) return Promise.resolve();
    resetLaunch();
    hideLabel();
    buildFlames();
    return new Promise((resolve) => {
      const dur = LAUNCH_DUR[outcome] ?? 4.6;
      launch = {
        outcome, dur, resolve, t0: now(), last: 0,
        camOff: new THREE.Vector3().subVectors(camera.position, controls.target),
        look0: controls.target.clone(), vy: 0, crashed: false
      };
      launchDirty = true;
      controls.enabled = false;
      controls.autoRotate = false;
      // sekme gizliyse rAF durur: güvenlik zamanlayıcısı
      launchTimer = setTimeout(() => finishLaunch(), (dur + 1.5) * 1000);
    });
  }
  function finishLaunch() {
    clearTimeout(launchTimer);
    if (!launch) return;
    const r = launch.resolve;
    setFlame(0);
    launch = null;
    controls.target.copy(rocketRoot.position).add(new THREE.Vector3(0, dims.H * 0.5, 0));
    controls.enabled = true;
    controls.update();
    r();
  }

  function updateLaunch(t, dt) {
    const L = launch;
    const e = t - L.t0;
    const lift = dims.lift, H = dims.H;
    const rp = rocketRoot.position;
    let flame = 0, shake = 0, smokeRate = 0, power = 1, heat = 0;
    rp.set(0, lift, 0);
    const ign = smooth(0, 0.9, e);
    switch (L.outcome) {
      case 'no-liftoff': {
        flame = e < 2.0 ? ign * 0.9 : e < 2.8 ? (Math.random() > 0.35 ? 0.8 : 0.15) : 0;
        shake = 0.02 + 0.12 * smooth(0.8, 2.6, e) * (e < 3.0 ? 1 : 0.2);
        rp.y += 0.08 * smooth(0.9, 1.6, e) * (1 - smooth(2.4, 3.0, e));
        smokeRate = e < 2.8 ? 40 : 6;
        break;
      }
      case 'out-of-fuel': {
        const t1 = 2.4;
        if (e < 0.8) { flame = ign; shake = 0.03; smokeRate = 40; }
        else if (e < t1) {
          const tt = e - 0.8;
          rp.y += 2.2 * tt * tt;
          flame = e > 2.15 ? (Math.random() > 0.4 ? 0.9 : 0.1) : 1;
          smokeRate = 30;
        } else {
          const y1 = 2.2 * 1.6 * 1.6, v1 = 4.4 * 1.6, tb = e - t1;
          const y = y1 + v1 * tb - 4.5 * tb * tb;
          if (y <= 0 || L.crashed) {
            if (!L.crashed) {
              L.crashed = true;
              impact = new THREE.Mesh(new THREE.SphereGeometry(1, 16, 10), new THREE.MeshBasicMaterial({ color: 0xff6a3a, transparent: true, opacity: 0.8, depthWrite: false, blending: THREE.AdditiveBlending }));
              impact.position.set(L.crashX ?? 0, 0.5, 0);
              impact.userData.t0 = t;
              scene.add(impact);
            }
            rp.y = lift * 0.6;
            rp.x = L.crashX ?? 0;
            rocketRoot.rotation.z = 1.25;
            smokeRate = 25;
          } else {
            rp.y += y;
            rocketRoot.rotation.z = Math.min(1.25, Math.max(0, tb - 0.5) * 0.9);
            rp.x = -Math.sin(rocketRoot.rotation.z) * H * 0.3;
            L.crashX = rp.x;
          }
        }
        break;
      }
      case 'power-loss': {
        if (e < 0.6) power = 1;
        else if (e < 2.4) power = Math.random() > (e - 0.6) / 1.8 ? 1 : 0.12;
        else power = 0.12 * (1 - smooth(2.4, 3.2, e)) + 0.03;
        break;
      }
      case 'overheat': {
        flame = e < 3.3 ? ign * (0.8 + Math.random() * 0.2) : Math.max(0, 1 - (e - 3.3) * 3) * 0.5;
        const up = smooth(0.9, 2.6, e) * 2.4 * (1 - smooth(3.0, 4.2, e));
        rp.y += up;
        heat = smooth(0.6, 2.0, e) * (0.85 + 0.15 * Math.sin(e * 18));
        shake = 0.02 + 0.08 * smooth(1.5, 3.5, e);
        smokeRate = 40;
        break;
      }
      case 'computer-failure': {
        flame = ign;
        smokeRate = 35;
        if (e > 0.9) {
          const tt = e - 0.9;
          rp.y += 1.3 * tt * tt;
          const w = Math.max(0, tt - 0.9);
          rocketRoot.rotation.z = -(0.9 * Math.pow(w, 1.4)) + 0.25 * Math.sin(w * 7) * Math.min(1, w);
          rocketRoot.rotation.y += dt * w * 3;
          rp.x = 0.9 * Math.pow(w, 2.2);
        } else shake = 0.03;
        break;
      }
      default: { // success, mission-failed: normal kalkış
        flame = ign;
        smokeRate = 45;
        if (e > 0.9) { const tt = e - 0.9; rp.y += 0.9 * tt * tt + 0.45 * tt * tt * tt; } else shake = 0.03;
      }
    }
    if (shake) { rp.x += (Math.random() - 0.5) * shake * 2; rp.z += (Math.random() - 0.5) * shake * 2; }
    setFlame(flame);
    if (L.outcome === 'power-loss') applyPower(power);
    if (heat) applyHeat(heat);
    // Duman
    if (smokeRate > 0 && flame > 0.05) {
      const n = Math.round(smokeRate * dt + Math.random());
      const base = rocketRoot.localToWorld(new THREE.Vector3(0, -0.6, 0));
      smoke.emit(base.x, base.y, base.z, n, 0);
    }
    if (impact) {
      const k = clamp((t - impact.userData.t0) / 0.8, 0, 1);
      impact.scale.setScalar(0.5 + k * 3.5);
      impact.material.opacity = 0.8 * (1 - k);
    }
    // Kamera takibi
    const look = new THREE.Vector3(rp.x * 0.8, Math.max(L.look0.y, rp.y + H * 0.5 - lift * 0.5), 0);
    const zoom = 1 + 0.18 * clamp(e / L.dur, 0, 1);
    camera.position.copy(look).addScaledVector(L.camOff, zoom);
    camera.position.y = Math.max(0.8, camera.position.y - (look.y - L.look0.y) * 0.25);
    if (flame > 0.3 && e < 1.4) camera.position.x += (Math.random() - 0.5) * 0.06;
    camera.lookAt(look);
    if (e >= L.dur) finishLaunch();
  }

  // ---------------------------------------------------------- döngü
  let raf = 0, running = false, lastT = now(), tStart = now();
  function tick() {
    const t = now();
    const dt = Math.min(0.05, t - lastT);
    lastT = t;
    for (let i = anims.length - 1; i >= 0; i--) {
      const a = anims[i];
      const k = clamp((t - a.t0) / a.dur, 0, 1);
      a.update(k);
      if (k >= 1) { anims.splice(i, 1); if (a.done) a.done(); }
    }
    const pulse = 0.5 + 0.5 * Math.sin((t - tStart) * 6);
    for (const b of beacons) b.material.opacity = Math.sin((t - tStart) * 3) > 0 ? 1 : 0.25;
    const fadeTarget = highlights && !launch ? 0.4 : 1;
    if (Math.abs(fade - fadeTarget) > 0.002) {
      fade += (fadeTarget - fade) * Math.min(1, dt * 7);
      if (Math.abs(fade - fadeTarget) <= 0.002) fade = fadeTarget;
      applyLook();
    }
    if (launch) updateLaunch(t, dt);
    else if (controls.enabled) controls.update();
    smoke.update(dt);
    updateMarkers(pulse);
    if (labelSlot) positionLabel();
    positionTags();
    renderer.render(scene, camera);
    if (!ready) { ready = true; container.dataset.sceneReady = '1'; }
  }
  function loop() { if (!running) return; raf = requestAnimationFrame(loop); tick(); }
  function start() { if (running || disposed || document.hidden) return; running = true; lastT = now(); raf = requestAnimationFrame(loop); }
  function stop() { running = false; cancelAnimationFrame(raf); }
  const onVis = () => { if (document.hidden) stop(); else start(); };
  document.addEventListener('visibilitychange', onVis);

  // ---------------------------------------------------------- boyut
  let lastW = 0, lastH = 0;
  function resize() {
    if (disposed) return;
    const w = container.clientWidth, h = container.clientHeight;
    if (!w || !h || (w === lastW && h === lastH)) return;
    lastW = w; lastH = h;
    renderer.setSize(w, h, false);
    camera.aspect = w / h;
    camera.updateProjectionMatrix();
    if (!userZoomed && !launch) fitCamera(true);
    if (highlights) syncTags(); // küçük/büyük etiket stili boyuta bağlı
    if (!running) tick();
  }
  let ro = null;
  if (typeof ResizeObserver !== 'undefined') { ro = new ResizeObserver(() => resize()); ro.observe(container); }
  else window.addEventListener('resize', resize);

  // ---------------------------------------------------------- dış arayüz
  function setFrame(frame) {
    if (disposed) return;
    const sig = frame ? JSON.stringify(frame) : 'null';
    if (sig === frameSig && !launchDirty && !launch) return;
    const changed = sig !== frameSig;
    frameSig = sig;
    resetLaunch();
    if (!changed) return;
    frameData = frame || null;
    hideLabel();
    for (const so of slotObjs.values()) removePart(so, false);
    clearTags();
    userZoomed = false; // gövde değişince kadraj sıfırlanır
    if (!frameData) {
      disposeMarkerMats();
      clearGroup(hullGroup); clearGroup(slotGroup); slotObjs.clear();
      dims = { H: 10, W: 1.5, lift: 0.5, r0: 1, segs: [] };
      buildEnv();
      fitCamera(false);
      return;
    }
    const d = buildHull(frameData.shape, frameData.slots);
    dims = { ...d, lift: 0.5 };
    buildMarkers();
    let maxMount = 0;
    for (const so of slotObjs.values()) if (so.slot.kind === 'mount') maxMount = Math.max(maxMount, so.size);
    dims.lift = Math.max(0.5, maxMount * 1.05 + 0.25, num(frameData.shape?.boosters, 0) > 0 ? 0.55 : 0);
    rocketRoot.position.set(0, dims.lift, 0);
    buildEnv();
    fitCamera(false);
    syncParts(false);
    if (highlights) syncTags();
  }
  function setSlots(slots) {
    if (disposed) return;
    const sig = JSON.stringify(slots ?? null);
    if (sig === slotsSig) return;
    slotsSig = sig;
    lastSlots = Array.isArray(slots) ? slots : null;
    syncParts(ready);
  }
  function setHighlights(map) {
    if (disposed) return;
    const m = map && typeof map === 'object' ? map : null;
    const sig = JSON.stringify(m);
    if (sig === hlSig) return;
    hlSig = sig;
    highlights = m;
    for (const so of slotObjs.values()) applyState(so);
    syncTags();
  }
  function setMyRole(role) { myRole = role ?? null; }
  function focusSlot(slotId) {
    const so = slotObjs.get(slotId);
    if (!so || launch) return;
    pauseAuto(9000);
    userZoomed = true;
    scene.updateMatrixWorld();
    const wp = slotWorldPos(so);
    let dir;
    if (so.slot.kind === 'internal') dir = new THREE.Vector3().subVectors(camera.position, controls.target).normalize();
    else {
      dir = new THREE.Vector3(0, 0, 1).applyQuaternion(so.root.getWorldQuaternion(new THREE.Quaternion()));
      dir.y = Math.max(dir.y, 0) + 0.35;
      dir.normalize();
    }
    const dist = Math.max(so.size * 9, (dims.H + dims.lift) * 0.7, controls.minDistance * 1.05);
    const fromT = controls.target.clone(), fromP = camera.position.clone();
    const toP = wp.clone().addScaledVector(dir, dist);
    anims.push({
      t0: now(), dur: 0.7,
      update(k) {
        const e = smooth(0, 1, k);
        controls.target.lerpVectors(fromT, wp, e);
        camera.position.lerpVectors(fromP, toP, e);
      }
    });
    showLabel(slotId, 2500);
  }
  function dispose() {
    if (disposed) return;
    resetLaunch();
    disposed = true;
    stop();
    clearTimeout(autoTimer); clearTimeout(labelTimer);
    document.removeEventListener('visibilitychange', onVis);
    if (ro) ro.disconnect(); else window.removeEventListener('resize', resize);
    canvas.removeEventListener('pointerdown', onDown);
    canvas.removeEventListener('pointerup', onUp);
    canvas.removeEventListener('pointercancel', onCancel);
    canvas.removeEventListener('pointermove', onMove);
    canvas.removeEventListener('pointerleave', onLeave);
    canvas.removeEventListener('wheel', onWheel);
    clearTags();
    disposeMarkerMats();
    controls.dispose();
    scene.traverse((o) => { if (o.geometry) o.geometry.dispose(); });
    for (const m of shared) m.dispose();
    glowTex.dispose();
    renderer.dispose();
    canvas.remove();
    label.remove();
    delete container.dataset.sceneReady;
    if (window.__ppScene === hooks) delete window.__ppScene;
  }

  // Test kancaları
  const hooks = {
    slotScreenPos(slotId) {
      const so = slotObjs.get(slotId);
      if (!so || disposed) return null;
      scene.updateMatrixWorld();
      camera.updateMatrixWorld();
      const sp = projectToCanvas(slotWorldPos(so));
      if (!sp) return null;
      const rect = canvas.getBoundingClientRect();
      if (sp.x < 0 || sp.y < 0 || sp.x > rect.width || sp.y > rect.height) return null;
      return { x: rect.left + sp.x, y: rect.top + sp.y };
    },
    clickSlot(slotId) { return fire(slotId); }
  };
  window.__ppScene = hooks;

  buildEnv();
  rocketRoot.position.y = dims.lift;
  resize();
  if (!lastW) { renderer.setSize(300, 150, false); camera.aspect = 2; camera.updateProjectionMatrix(); }
  fitCamera(false);
  tick(); // ilk kare → sceneReady
  start();

  return {
    setFrame, setSlots, setHighlights, setMyRole,
    onSlotClick(fn) { slotCb = typeof fn === 'function' ? fn : null; },
    onPartClick(fn) { partCb = typeof fn === 'function' ? fn : null; },
    focusSlot, resize: () => { lastW = lastH = 0; resize(); }, dispose, playLaunch
  };
}
