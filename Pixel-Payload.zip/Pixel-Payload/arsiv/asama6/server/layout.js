'use strict';
// Gövde/yuva yerleşim kuralları — saf, durumsuz.
// createLayout({ framesData, physics }) -> yerleşim nesnesi.
// framesData = data/frames.json içeriği: { frames: [...], rules: [...] }
// build = { rocket: [{ uid, partId, slotId }], spacecraft: [...], payload: [...] } (üç rol aynı gövdenin yuvalarını paylaşır)

const WORKER_ROLES = ['rocket', 'spacecraft', 'payload'];
const PUBLIC_SLOT_FIELDS = ['id', 'name', 'zone', 'segment', 'face', 'kind', 'accepts', 'pos', 'normal'];

// Hata kodlarının sayısız Türkçe gerekçeleri (çalışana gider).
const REASONS = {
  INVALID_PART: 'Böyle bir parça yok.',
  NOT_ALLOWED: 'Bu parça senin rolüne ait değil.',
  PART_LIMIT: 'Bu parçadan daha fazla takılamaz.',
  INVALID_SLOT: 'Bu gövdede böyle bir yuva yok.',
  NO_FRAME: 'Henüz roket gövdesi seçilmedi.',
  SLOT_TAKEN: 'Bu yuva dolu; önce oradaki parça çıkarılmalı.',
  SLOT_MISMATCH: 'Bu yuva bu tür parçayı kabul etmiyor.',
};

const clone = (x) => JSON.parse(JSON.stringify(x));
const fail = (error, reason) => ({ ok: false, error, reason: reason || REASONS[error] });

function createLayout({ framesData, physics } = {}) {
  if (!physics || typeof physics.canAdd !== 'function' || typeof physics.getPart !== 'function') {
    throw new TypeError('createLayout: physics gerekli');
  }
  const frames = framesData && Array.isArray(framesData.frames) ? framesData.frames : [];
  const rules = framesData && Array.isArray(framesData.rules) ? framesData.rules : [];
  const frameById = new Map(frames.map((f) => [f.id, f]));
  const slotIndex = new Map(frames.map((f) => [f.id, new Map((f.slots || []).map((s) => [s.id, s]))]));

  function getSlot(frameId, slotId) {
    const m = slotIndex.get(frameId);
    return m && typeof slotId === 'string' ? m.get(slotId) : undefined;
  }

  // Yuva bu parçayı kabul ediyor mu? Kategori `accepts`'te olmalı; yuvada `acceptsTags[kategori]`
  // tanımlıysa parça o etiketlerden en az birini taşımalı (ör. dış yüzeye yalnız dışarı bakan aletler).
  function slotAccepts(slot, part) {
    if (!slot || !part || !Array.isArray(slot.accepts) || !slot.accepts.includes(part.category)) return false;
    const need = slot.acceptsTags && slot.acceptsTags[part.category];
    if (!Array.isArray(need) || need.length === 0) return true;
    const tags = Array.isArray(part.tags) ? part.tags : [];
    return need.some((t) => tags.includes(t));
  }

  // Kural seçicisi: { tag } | { category } | { partId }
  function matches(sel, part) {
    if (!sel || !part) return false;
    if (sel.partId) return part.id === sel.partId;
    if (sel.category) return part.category === sel.category;
    if (sel.tag) return Array.isArray(part.tags) && part.tags.includes(sel.tag);
    return false;
  }

  function inScope(scope, s1, s2) {
    if (scope === 'same-face') return s1.segment === s2.segment && s1.face === s2.face;
    if (scope === 'same-segment') return s1.segment === s2.segment;
    if (scope === 'neighbors') {
      return (Array.isArray(s1.neighbors) && s1.neighbors.includes(s2.id)) ||
        (Array.isArray(s2.neighbors) && s2.neighbors.includes(s1.id));
    }
    return false;
  }

  // Gövdedeki dolu yuvalar: [{ role, uid, part, slot }] (yuvasız / geçersiz girdiler yok sayılır).
  function placed(build, frameId) {
    const out = [];
    for (const role of WORKER_ROLES) {
      const arr = build && Array.isArray(build[role]) ? build[role] : [];
      for (const e of arr) {
        if (!e) continue;
        const part = physics.getPart(e.partId);
        const slot = getSlot(frameId, e.slotId);
        if (part && slot) out.push({ role, uid: e.uid, part, slot });
      }
    }
    return out;
  }

  // Yeni parça (part @ slot) ile takılı parçalar arasında ilk uyumsuzluk kuralı (yoksa null). İki yönlü.
  function findConflict(build, frameId, part, slot) {
    const others = placed(build, frameId);
    for (const rule of rules) {
      for (const o of others) {
        if (o.slot.id === slot.id) continue;
        const hit = (matches(rule.a, part) && matches(rule.b, o.part)) || (matches(rule.b, part) && matches(rule.a, o.part));
        if (hit && inScope(rule.scope, slot, o.slot)) return { rule, other: o };
      }
    }
    return null;
  }

  function listFrames() {
    return frames.map(clone);
  }

  function getFrame(frameId) {
    const f = frameById.get(frameId);
    return f ? clone(f) : undefined;
  }

  function publicFrame(frameId) {
    const f = frameById.get(frameId);
    if (!f) return undefined;
    return {
      id: f.id, name: f.name, desc: f.desc, shape: clone(f.shape),
      slots: (f.slots || []).map((s) => {
        const o = {};
        for (const k of PUBLIC_SLOT_FIELDS) o[k] = clone(s[k]);
        return o;
      }),
    };
  }

  function publicFrameOptions() {
    return frames.map((f) => ({ id: f.id, name: f.name, desc: f.desc, shape: clone(f.shape) }));
  }

  // Sıra: parça/rol/limit (physics.canAdd) -> yuva var mı -> dolu mu -> kategori uyumu -> kurallar
  function canPlace(build, frameId, role, partId, slotId) {
    const base = physics.canAdd(build, role, partId);
    if (!base || !base.ok) return fail((base && base.error) || 'INVALID_PART');
    if (!frameById.has(frameId)) return fail('INVALID_SLOT', REASONS.NO_FRAME);
    const slot = getSlot(frameId, slotId);
    if (!slot) return fail('INVALID_SLOT');
    if (placed(build, frameId).some((o) => o.slot.id === slot.id)) return fail('SLOT_TAKEN');
    const part = physics.getPart(partId);
    if (!slotAccepts(slot, part)) return fail('SLOT_MISMATCH');
    const c = findConflict(build, frameId, part, slot);
    if (c) return fail('PART_CONFLICT', c.rule.reason);
    return { ok: true };
  }

  // Yalnız bu parçayı kabul eden yuvalar, gövdedeki sırayla.
  function slotOptions(build, frameId, role, partId) {
    const f = frameById.get(frameId);
    const part = physics.getPart(partId);
    if (!f || !part) return [];
    return (f.slots || [])
      .filter((s) => slotAccepts(s, part))
      .map((s) => {
        const r = canPlace(build, frameId, role, partId, s.id);
        return r.ok ? { slotId: s.id, ok: true } : { slotId: s.id, ok: false, error: r.error, reason: r.reason };
      });
  }

  function slotName(frameId, slotId) {
    const s = getSlot(frameId, slotId);
    return s ? s.name : '';
  }

  // Gövdede HİÇBİR yuvanın kabul etmediği parça id'leri (boş build; yalnız kategori + acceptsTags,
  // kurallar/limitler yok). Geçersiz gövde → tüm id'ler; bilinmeyen parça id'si de listeye girer.
  function unfitParts(frameId, partIds) {
    const ids = Array.isArray(partIds) ? partIds : [];
    const f = frameById.get(frameId);
    return ids.filter((id) => {
      const part = typeof id === 'string' ? physics.getPart(id) : undefined;
      return !f || !part || !(f.slots || []).some((s) => slotAccepts(s, part));
    });
  }

  return { listFrames, getFrame, publicFrame, publicFrameOptions, canPlace, slotOptions, slotName, unfitParts, rules: () => clone(rules) };
}

module.exports = { createLayout };
