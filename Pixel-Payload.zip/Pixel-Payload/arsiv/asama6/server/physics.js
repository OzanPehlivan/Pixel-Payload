'use strict';
// Saf, durumsuz fizik hesapları. createPhysics(catalog) -> fizik nesnesi.
// catalog = data/parts.json içeriği: { constants: { g0, minTwr }, parts: [...] }

const WORKER_ROLES = ['rocket', 'spacecraft', 'payload'];

// Çalışana giden katalogda yalnızca bu alanlar bulunur (sayı yok).
const PUBLIC_FIELDS = ['id', 'name', 'icon', 'desc', 'category', 'model'];

// Bu kategorilerden bir rol build'inde en fazla 1 parça olabilir.
const SINGLETON_CATEGORIES = ['fuel'];

// Sonlu olmayan değerleri 0'a çevirir (NaN/Infinity sızmasın).
function fin(x) {
  return Number.isFinite(x) ? x : 0;
}

// Göstergelerde okunaklı olsun diye küçük yuvarlama.
function round(x, digits) {
  const f = Math.pow(10, digits);
  return Math.round(fin(x) * f) / f;
}

function createPhysics(catalog) {
  const constants = Object.assign({ g0: 9.81, minTwr: 1.2 }, (catalog && catalog.constants) || {});
  const parts = (catalog && Array.isArray(catalog.parts)) ? catalog.parts : [];
  const byId = new Map(parts.map((p) => [p.id, p]));

  function getPart(partId) {
    return typeof partId === 'string' ? byId.get(partId) : undefined;
  }

  function fullCatalog() {
    const out = { rocket: [], spacecraft: [], payload: [] };
    for (const p of parts) if (out[p.role]) out[p.role].push(Object.assign({}, p, { requires: (p.requires || []).slice() }));
    return out;
  }

  function publicCatalog(role) {
    return parts
      .filter((p) => p.role === role)
      .map((p) => {
        const o = {};
        for (const k of PUBLIC_FIELDS) o[k] = p[k];
        return o;
      });
  }

  // Bir rolün build listesini güvenli şekilde döndürür.
  function listOf(build, role) {
    const arr = build && Array.isArray(build[role]) ? build[role] : [];
    return arr.filter((e) => e && getPart(e.partId));
  }

  function canAdd(build, role, partId) {
    const part = getPart(partId);
    if (!part) return { ok: false, error: 'INVALID_PART' };
    if (!WORKER_ROLES.includes(role) || part.role !== role) return { ok: false, error: 'NOT_ALLOWED' };
    const mine = listOf(build, role).map((e) => getPart(e.partId));
    const sameCount = mine.filter((p) => p.id === part.id).length;
    if (sameCount >= (part.max || 1)) return { ok: false, error: 'PART_LIMIT' };
    if (SINGLETON_CATEGORIES.includes(part.category) && mine.some((p) => p.category === part.category)) {
      return { ok: false, error: 'PART_LIMIT' };
    }
    return { ok: true };
  }

  // frame: tam gövde nesnesi (data/frames.json) | null/undefined. Kütlesi kuru kütleye, maliyeti harcamaya eklenir.
  function computeTelemetry(build, mission, frame) {
    const frameMassKg = frame && typeof frame === 'object' ? fin(frame.massKg) : 0;
    const frameCost = frame && typeof frame === 'object' ? fin(frame.cost) : 0;
    let dryMassKg = frameMassKg, fuelKg = 0, thrustKN = 0, thrustIsp = 0;
    let powerGenW = 0, powerUseW = 0, heat = 0, heatShield = 0, spent = frameCost;
    let ispMult = 0; // yakıt tipi seçilmezse motorlar ateşlenmez -> Isp 0
    let partCount = 0;
    const installed = new Set();

    for (const role of WORKER_ROLES) {
      for (const e of listOf(build, role)) {
        const p = getPart(e.partId);
        partCount++;
        installed.add(p.id);
        dryMassKg += fin(p.massKg);
        fuelKg += fin(p.fuelKg);
        thrustKN += fin(p.thrustKN);
        thrustIsp += fin(p.thrustKN) * fin(p.isp);
        powerGenW += fin(p.powerGenW);
        powerUseW += fin(p.powerUseW);
        heat += fin(p.heat);
        heatShield += fin(p.heatShield);
        spent += fin(p.cost);
        if (p.category === 'fuel') ispMult = fin(p.ispMult);
      }
    }

    const g0 = constants.g0;
    const massKg = dryMassKg + fuelKg;
    const isp = thrustKN > 0 ? (thrustIsp / thrustKN) * ispMult : 0;
    const twr = massKg > 0 ? (thrustKN * 1000) / (massKg * g0) : 0;
    const deltaV = dryMassKg > 0 && massKg > dryMassKg ? isp * g0 * Math.log(massKg / dryMassKg) : 0;

    const required = mission && Array.isArray(mission.requiredInstruments) ? mission.requiredInstruments : [];
    const missing = required.filter((id) => !installed.has(id));
    const overBudget = mission ? spent > fin(mission.budget) : false;

    const checks = {
      twr: twr >= constants.minTwr,
      deltaV: !!mission && deltaV >= fin(mission.requiredDeltaV) && deltaV > 0,
      power: partCount > 0 && powerGenW >= powerUseW,
      payload: !!mission && missing.length === 0 && !overBudget,
      heat: heatShield >= heat,
    };

    return {
      massKg: round(massKg, 1),
      dryMassKg: round(dryMassKg, 1),
      fuelKg: round(fuelKg, 1),
      thrustKN: round(thrustKN, 1),
      isp: round(isp, 1),
      twr: round(twr, 3),
      deltaV: round(deltaV, 0),
      powerGenW: round(powerGenW, 1),
      powerUseW: round(powerUseW, 1),
      heat: round(heat, 1),
      heatShield: round(heatShield, 1),
      spent: round(spent, 1),
      frameMassKg: round(frameMassKg, 1),
      frameCost: round(frameCost, 1),
      checks,
      missing,
      overBudget,
      ready: Object.values(checks).every(Boolean),
    };
  }

  // Durum ışıkları: yalnızca rolün KENDİ parçalarına bakar.
  function partStatuses(build, role) {
    const mine = listOf(build, role).map((e) => ({ uid: e.uid, part: getPart(e.partId) }));
    const cats = new Set(mine.map((m) => m.part.category));
    const ids = new Set(mine.map((m) => m.part.id));
    let gen = 0, use = 0;
    for (const m of mine) { gen += fin(m.part.powerGenW); use += fin(m.part.powerUseW); }

    const out = {};
    for (const { uid, part } of mine) {
      const reqs = Array.isArray(part.requires) ? part.requires : [];
      if (reqs.some((c) => !cats.has(c))) { out[uid] = 'red'; continue; }
      out[uid] = yellowRule(part, cats, ids, gen, use) ? 'yellow' : 'green';
    }
    return out;
  }

  // Yerel uyarılar (sarı ışık).
  function yellowRule(part, cats, ids, gen, use) {
    switch (part.category) {
      case 'engine': return !cats.has('fuel');          // yakıt tipi seçilmemiş
      case 'tank': return !cats.has('fuel') || !cats.has('engine'); // yakıtsız ya da motorsuz tank
      case 'fuel': return !cats.has('engine');          // yakmayacak motor yok
      case 'solar': return !cats.has('battery');        // bataryasız panel
      case 'battery': return !cats.has('solar');        // şarj edecek panel yok
      case 'antenna':
      case 'computer': return use > gen;                // uzay aracının kendi gücü yetmiyor
      case 'instrument': return part.id === 'drill' && !ids.has('rover'); // matkabı taşıyacak gezgin yok
      default: return false;
    }
  }

  return { getPart, fullCatalog, publicCatalog, canAdd, computeTelemetry, partStatuses, constants };
}

module.exports = { createPhysics };
