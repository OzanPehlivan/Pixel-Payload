'use strict';
// Puanlama (saf). computeScore({ success, mission, telemetry, undoUsed, timeLeftSec }) -> { total, stars, breakdown }
//   base   : başarıda 1000
//   time   : round(500 * timeLeftSec / mission.durationSec), 0..500; timeLeftSec null/undefined ise 0
//   budget : round(500 * (budget - spent) / budget), 0..500
//   mass   : massKg <= parMassKg ise 300; üstünde doğrusal azalır, 2×par'da 0
//   undo   : -100 × undoUsed
//   total  : max(0, toplam). Yıldız: başarı = en az 1; >= 1400 -> 2; >= 1700 -> 3. Başarısızlık: 0 / 0.

const BASE = 1000, TIME_MAX = 500, BUDGET_MAX = 500, MASS_MAX = 300, UNDO_PENALTY = 100;
const STAR2 = 1400, STAR3 = 1700;

const num = (x) => (Number.isFinite(x) ? x : 0);
const clamp01 = (x) => Math.max(0, Math.min(1, num(x)));

function computeScore({ success, mission, telemetry, undoUsed, timeLeftSec } = {}) {
  const m = mission || {};
  const t = telemetry || {};
  let pts = { base: 0, time: 0, budget: 0, mass: 0, undo: 0 };

  if (success) {
    const dur = num(m.durationSec);
    const time = timeLeftSec == null || dur <= 0 ? 0 : Math.round(TIME_MAX * clamp01(timeLeftSec / dur));
    const budget = num(m.budget);
    const budgetPts = budget > 0 ? Math.round(BUDGET_MAX * clamp01((budget - num(t.spent)) / budget)) : 0;
    const par = num(m.parMassKg), mass = num(t.massKg);
    // par yoksa kütle bonusu verilmez (açıklanamaz bir bonus olmasın)
    const massPts = par > 0 ? Math.round(MASS_MAX * clamp01(1 - Math.max(0, mass - par) / par)) : 0;
    const undo = -UNDO_PENALTY * Math.max(0, Math.floor(num(undoUsed))) || 0; // -0 olmasın
    pts = { base: BASE, time, budget: budgetPts, mass: massPts, undo };
  }

  const breakdown = [
    { key: 'base', label: 'Görev başarısı', points: pts.base },
    { key: 'time', label: 'Kalan süre', points: pts.time },
    { key: 'budget', label: 'Artan bütçe', points: pts.budget },
    { key: 'mass', label: 'Hafif tasarım', points: pts.mass },
    { key: 'undo', label: 'Geri alma cezası', points: pts.undo },
  ];
  const total = success ? Math.max(0, breakdown.reduce((s, b) => s + b.points, 0)) : 0;
  const stars = !success ? 0 : total >= STAR3 ? 3 : total >= STAR2 ? 2 : 1;
  return { total, stars, breakdown };
}

module.exports = { computeScore };
