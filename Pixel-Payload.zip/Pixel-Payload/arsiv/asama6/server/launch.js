'use strict';
// Fırlatma çözümü (saf). resolveLaunch(telemetry, mission) -> sonuç nesnesi.
// Öncelik: twr -> deltaV -> power -> computer -> heat -> payload. Hepsi true ise success.
// windowMissedResult() -> iki fırlatma penceresi de kaçırıldığında kullanılan sabit sonuç.

const catalog = require('../data/parts.json');

const CHECK_ORDER = ['twr', 'deltaV', 'power', 'computer', 'heat', 'payload'];
// İsteğe bağlı kontroller: anahtar yoksa yok sayılır, yalnızca === false ise başarısız.
// (computer yalnızca 'computer-fault' olayı açıkken telemetride bulunur.)
const OPTIONAL_CHECKS = new Set(['computer']);
const OUTCOME_BY_CHECK = {
  twr: 'no-liftoff',
  deltaV: 'out-of-fuel',
  power: 'power-loss',
  computer: 'computer-failure',
  heat: 'overheat',
  payload: 'mission-failed',
};

const DEFAULT_MIN_TWR = (catalog && catalog.constants && Number.isFinite(catalog.constants.minTwr))
  ? catalog.constants.minTwr : 1.2;

// Parça id -> okunur ad (eksik aletleri anlatmak için).
const PART_NAMES = new Map(((catalog && catalog.parts) || []).map((p) => [p.id, p.name]));

const num = (x) => (Number.isFinite(x) ? x : 0);
const fmt = (x, d = 0) => num(x).toFixed(d);
const partLabel = (id) => (PART_NAMES.has(id) ? `${PART_NAMES.get(id)} (${id})` : String(id));

function resolveLaunch(telemetry, mission) {
  const t = telemetry && typeof telemetry === 'object' ? telemetry : {};
  const m = mission && typeof mission === 'object' ? mission : {};
  const checks = t.checks && typeof t.checks === 'object' ? t.checks : {};

  const failedChecks = CHECK_ORDER.filter((k) =>
    (OPTIONAL_CHECKS.has(k) ? checks[k] === false : checks[k] !== true));
  if (failedChecks.length === 0) {
    const target = m.target ? ` Hedef: ${m.target}.` : '';
    return {
      success: true,
      outcome: 'success',
      title: 'Görev başarılı!',
      reasonText: `Roket kalktı (itki/ağırlık ${fmt(t.twr, 2)}), Δv ${fmt(t.deltaV)} m/s yetti, güç ve ısı dengedeydi, tüm aletler bütçe içinde taşındı.${target}`,
      failedChecks,
    };
  }

  const first = failedChecks[0];
  let title, reasonText;
  switch (first) {
    case 'twr': {
      const minTwr = Number.isFinite(t.minTwr) ? t.minTwr : DEFAULT_MIN_TWR;
      title = 'Roket rampadan kalkamadı';
      reasonText = `İtki/ağırlık oranı ${fmt(t.twr, 2)}; kalkış için en az ${fmt(minTwr, 1)} gerekir. Roket rampada kaldı.`;
      break;
    }
    case 'deltaV':
      title = 'Yolda yakıt bitti';
      reasonText = num(t.deltaV) === 0 && num(t.fuelKg) > 0
        ? `Δv 0 / gereken ${fmt(m.requiredDeltaV)} m/s. Yakıt tipi seçilmediği için motorlar ateşlenemedi.`
        : `Δv ${fmt(t.deltaV)} / gereken ${fmt(m.requiredDeltaV)} m/s. Yakıt hedefe varmadan tükendi.`;
      break;
    case 'power':
      title = 'Güç kesildi';
      reasonText = `Üretilen güç ${fmt(t.powerGenW)} W, tüketim ${fmt(t.powerUseW)} W. Sistemler enerjisiz kaldı ve araçla bağlantı koptu.`;
      break;
    case 'computer':
      title = 'Uçuş bilgisayarı arızalandı';
      reasonText = 'Arızalanan uçuş bilgisayarının yerine yedek bilgisayar takılmadı. Araç yönlendirilemedi ve uçuşta kontrol kaybedildi.';
      break;
    case 'heat':
      title = 'Araç aşırı ısındı';
      reasonText = `Üretilen ısı ${fmt(t.heat)}, kalkan kapasitesi ${fmt(t.heatShield)}. Isı kalkanı yetmedi, sistemler yandı.`;
      break;
    default: { // payload
      const parts = [];
      const missing = Array.isArray(t.missing) ? t.missing : [];
      if (missing.length) parts.push(`Eksik aletler: ${missing.map(partLabel).join(', ')}.`);
      const over = t.overBudget === true || (Number.isFinite(m.budget) && num(t.spent) > m.budget);
      if (over) parts.push(`Bütçe aşıldı: harcanan ${fmt(t.spent)} / bütçe ${fmt(m.budget)}.`);
      if (!parts.length) parts.push('Görev gereksinimleri karşılanmadı.');
      title = 'Görev başarısız';
      reasonText = `Araç hedefe ulaştı ama görev tamamlanamadı. ${parts.join(' ')}`;
    }
  }
  return { success: false, outcome: OUTCOME_BY_CHECK[first], title, reasonText, failedChecks };
}

// İki fırlatma penceresi de kaçırıldı: fırlatma yapılmadı.
function windowMissedResult() {
  return {
    success: false,
    outcome: 'window-missed',
    title: 'Fırlatma penceresi kaçırıldı',
    reasonText: 'İki fırlatma penceresi de kaçırıldı. Ekip tasarımı zamanında tamamlayamadı ve roket rampada kaldı.',
    failedChecks: [],
  };
}

module.exports = { resolveLaunch, windowMissedResult };
