'use strict';
// Aşama 4 birim testleri: sayaç/pencereler, telemetri gecikmesi, rastgele olaylar, geri alma, görünümler.
// SAHTE saat / physics / resolveLaunch / computeScore kullanır. Çalıştır: node --test test/stage4.test.js

const test = require('node:test');
const assert = require('node:assert');

const { GameError, EVENT_TYPES } = require('../server/constants');
const { createRoomManager } = require('../server/rooms');
const { viewFor } = require('../server/filter');

const T0 = 10_000_000;
const NUM_FIELDS = ['massKg', 'cost', 'thrustKN', 'isp', 'powerGenW', 'powerUseW', 'heat', 'heatShield',
  'fuelKg', 'ispMult', 'max', 'requires'];
const SECRET_NUMS = ['7331', '4447', '8123', '9876', '4321', '9991'];

function mk(id, role, category, name, icon, extra = {}) {
  return {
    id, role, category, name, icon, desc: `${name} açıklaması`,
    massKg: 7331, cost: 4447, powerGenW: 0, powerUseW: 0, thrustKN: 8123, isp: 0, heat: 0, heatShield: 0,
    fuelKg: 0, ispMult: 1, max: 3, requires: [], ...extra,
  };
}
const PARTS = [
  mk('eng', 'rocket', 'engine', 'Sahte Motor', 'E'),
  mk('tank', 'rocket', 'tank', 'Sahte Tank', 'T', { max: 1 }),
  mk('panel', 'spacecraft', 'solar', 'Sahte Panel', 'P'),
  mk('comp', 'spacecraft', 'computer', 'Sahte Bilgisayar', 'B'),
  mk('cam', 'payload', 'instrument', 'Sahte Kamera', 'C'),
];
const MISSION = {
  id: 'gorev-gizli', title: 'GIZLI-BASLIK', target: 'GIZLI-HEDEF', requiredDeltaV: 4321, requiredInstruments: ['cam'],
  budget: 9991, durationSec: 300, nasaFact: 'GIZLI-FACT', nasaReal: 'GIZLI-REAL', parMassKg: 7331,
};
const MISSION_B = { ...MISSION, id: 'gorev-gizli-b', title: 'GIZLI-BASLIK-B' };

function fakePhysics() {
  const byId = new Map(PARTS.map((p) => [p.id, p]));
  return {
    getPart: (id) => byId.get(id),
    fullCatalog: () => {
      const out = { rocket: [], spacecraft: [], payload: [] };
      for (const p of PARTS) out[p.role].push(structuredClone(p));
      return out;
    },
    publicCatalog: (role) => PARTS.filter((p) => p.role === role)
      .map((p) => ({ id: p.id, name: p.name, icon: p.icon, desc: p.desc, category: p.category, massKg: p.massKg })),
    canAdd: (build, role, partId) => {
      const p = byId.get(partId);
      if (!p) return { ok: false, error: 'INVALID_PART' };
      if (p.role !== role) return { ok: false, error: 'NOT_ALLOWED' };
      if (build[role].filter((it) => it.partId === partId).length >= p.max) return { ok: false, error: 'PART_LIMIT' };
      return { ok: true };
    },
    computeTelemetry: (build, mission) => {
      const n = build.rocket.length + build.spacecraft.length + build.payload.length;
      return {
        massKg: 7331 + n, deltaV: mission ? 9876 : 0, spent: 0, parts: n,
        checks: { twr: n > 0, deltaV: true, power: true, payload: true, heat: true },
        missing: [], overBudget: false, ready: n > 0,
      };
    },
    partStatuses: () => ({}),
  };
}

function fakeLaunch() {
  const fn = (telemetry) => {
    const failed = Object.keys(telemetry.checks).filter((k) => !telemetry.checks[k]);
    return {
      success: failed.length === 0, outcome: failed.length ? 'no-liftoff' : 'success',
      title: failed.length ? 'Kalkamadı' : 'Başarılı', reasonText: 'r', failedChecks: failed,
    };
  };
  return fn;
}
function fakeScore() {
  const calls = [];
  const fn = (args) => {
    calls.push(args);
    return { total: args.success ? 1 : 0, stars: 0, breakdown: ['base', 'time', 'budget', 'mass', 'undo'].map((key) => ({ key, label: key, points: 0 })) };
  };
  fn.calls = calls;
  return fn;
}
const fakeMissed = () => ({ success: false, outcome: 'window-missed', title: 'Fırlatma penceresi kaçırıldı', reasonText: 'kaçtı', failedChecks: [] });

// Sahte layout (Aşama 5 arayüzü): her kategoriyi kabul eden 30 yuvalı tek gövde; physics.canAdd'i de uygular
const LETTERS = 'abcdefghijklmnopqrstuvwxyz';
const SLOT_IDS = Array.from({ length: 30 }, (_, i) => `yuva-${LETTERS[Math.floor(i / 26)]}${LETTERS[i % 26]}`);
const FRAME_ID = 'govde-deneme';
const slotTaken = (build, slotId) => ['rocket', 'spacecraft', 'payload'].some((r) => build[r].some((it) => it.slotId === slotId));
function fakeLayout(physics) {
  const frame = {
    id: FRAME_ID, name: 'Deneme Gövdesi', desc: 'Deneme gövdesi açıklaması', massKg: 0, cost: 0,
    shape: { segments: [], fins: 0, boosters: 0 },
    slots: SLOT_IDS.map((id) => ({
      id, name: `Yuva ${id.slice(5).toUpperCase()}`, zone: 'bolme', segment: 'kademe', face: 'C', kind: 'internal',
      accepts: ['engine', 'tank', 'structure', 'solar', 'computer', 'instrument'], pos: [0, 0, 0], normal: [0, 1, 0], neighbors: [],
    })),
  };
  const canPlace = (build, frameId, role, partId, slotId) => {
    const c = physics.canAdd(build, role, partId);
    if (!c || !c.ok) return { ok: false, error: c.error, reason: 'Sahte gerekçe' };
    if (frameId !== FRAME_ID || !SLOT_IDS.includes(slotId)) return { ok: false, error: 'INVALID_SLOT', reason: 'Yuva yok' };
    if (slotTaken(build, slotId)) return { ok: false, error: 'SLOT_TAKEN', reason: 'Yuva dolu' };
    return { ok: true };
  };
  return {
    listFrames: () => [structuredClone(frame)],
    getFrame: (id) => (id === FRAME_ID ? frame : undefined),
    publicFrame: (id) => (id === FRAME_ID ? structuredClone(frame) : undefined),
    publicFrameOptions: () => [{ id: frame.id, name: frame.name, desc: frame.desc, shape: structuredClone(frame.shape) }],
    canPlace,
    slotOptions: (build, frameId, role, partId) => SLOT_IDS.map((slotId) => ({ slotId, ...canPlace(build, frameId, role, partId, slotId) })),
    slotName: (frameId, slotId) => (frame.slots.find((s) => s.id === slotId) || {}).name,
  };
}
// İlk boş yuva (oda yoksa ilk yuva)
function free(m, code) {
  const room = m.getRoom(code);
  return SLOT_IDS.find((id) => !room || !slotTaken(room.build, id));
}
function deps() {
  const physics = fakePhysics();
  return { physics, layout: fakeLayout(physics) };
}

const VL = fakeLayout(fakePhysics()); // görünüm için (sahte layout durumsuz)

function throwsCode(fn, code) {
  assert.throws(fn, (err) => err instanceof GameError && err.code === code && err.message.length > 0, `beklenen hata: ${code}`);
}

// Sahte saatli, başlamış oda. p[0]=director, p[1]=rocket, p[2]=spacecraft, p[3]=payload
function started({ config = { events: [], telemetryDelayMs: 0 }, missions = [MISSION], rng = () => 0, missed = fakeMissed, frame = true } = {}) {
  const clock = { t: T0 };
  const physics = fakePhysics();
  const computeScore = fakeScore();
  const m = createRoomManager({
    missions, physics, layout: fakeLayout(physics), resolveLaunch: fakeLaunch(), computeScore, windowMissedResult: missed,
    rng, now: () => clock.t, config,
  });
  const { room, player: p0 } = m.createRoom('Ayşe');
  const p = [p0, m.joinRoom(room.code, 'Bora').player, m.joinRoom(room.code, 'Cem').player, m.joinRoom(room.code, 'Deniz').player];
  ['director', 'rocket', 'spacecraft', 'payload'].forEach((r, i) => m.selectRole(room.code, p[i].id, r));
  if (frame) m.selectFrame(room.code, p[0].id, FRAME_ID); // Aşama 5: setup → building
  const at = (sec) => { clock.t = T0 + sec * 1000; return m.tick(room.code); };
  return { m, room, p, physics, computeScore, clock, code: room.code, at };
}
const lastLog = (room) => room.log[room.log.length - 1];
function allGo(s) {
  for (const i of [1, 2, 3]) s.m.vote(s.code, s.p[i].id, 'go');
}

// Basit tohumlu rng (LCG)
function seeded(seed) {
  let x = seed >>> 0;
  return () => { x = (Math.imul(x, 1664525) + 1013904223) >>> 0; return x / 2 ** 32; };
}

// ---------------- Sayaç / pencereler ----------------

test('sayaç başlangıcı: window 1, endsAt = başlangıç + süre', () => {
  const s = started();
  assert.deepStrictEqual(s.room.timer, { window: 1, endsAt: T0 + 300_000 });
  assert.ok(s.m.roomCodes().includes(s.code));
  const s2 = started({ config: { events: [], telemetryDelayMs: 0, windowSec: 90 } });
  assert.strictEqual(s2.room.timer.endsAt, T0 + 90_000);
  const noDur = { ...MISSION }; delete noDur.durationSec;
  const s3 = started({ missions: [noDur] });
  assert.strictEqual(s3.room.timer.endsAt, T0 + 300_000);
  // lobide sayaç yok ve tick bir şey yapmaz
  const m = createRoomManager({ missions: [MISSION], ...deps(), resolveLaunch: fakeLaunch(), computeScore: fakeScore(), now: () => T0, config: { events: [] } });
  const { room } = m.createRoom('X');
  assert.strictEqual(room.timer, null);
  assert.strictEqual(m.tick(room.code), false);
  assert.strictEqual(m.tick('YOKK'), false);
  assert.strictEqual(m.tick(undefined), false);
});

test('window 1 → 2 geçişi ve tick idempotent', () => {
  const s = started({ config: { events: [], telemetryDelayMs: 0, secondWindowSec: 120 } });
  assert.strictEqual(s.at(299.999), false);
  assert.strictEqual(s.room.timer.window, 1);
  assert.strictEqual(s.at(301), true);
  assert.deepStrictEqual(s.room.timer, { window: 2, endsAt: T0 + 301_000 + 120_000 });
  assert.strictEqual(lastLog(s.room).kind, 'event');
  assert.strictEqual(lastLog(s.room).text, 'Fırlatma penceresi kaçırıldı! İkinci pencere açıldı');
  assert.strictEqual(s.m.tick(s.code), false); // aynı anda tekrar: değişiklik yok
  assert.strictEqual(s.room.phase, 'building');
});

test('window 2 biterse window-missed sonucu (anket açıkken de), result fazında tick boş', () => {
  const s = started();
  s.at(300); // window 2: endsAt = T0+300s+180s
  s.clock.t = T0 + 400_000;
  s.m.startPoll(s.code, s.p[0].id);
  s.m.vote(s.code, s.p[1].id, 'go');
  assert.strictEqual(s.at(479.999), false);
  assert.strictEqual(s.at(480), true);
  const r = s.room.result;
  assert.strictEqual(s.room.phase, 'result');
  assert.strictEqual(s.room.poll, null);
  assert.strictEqual(r.success, false);
  assert.strictEqual(r.outcome, 'window-missed');
  assert.strictEqual(r.title, 'Fırlatma penceresi kaçırıldı');
  assert.deepStrictEqual(r.failedChecks, []);
  assert.strictEqual(r.timeLeftSec, 0);
  assert.strictEqual(r.window, 2);
  assert.strictEqual(r.score.total, 0);
  const args = s.computeScore.calls[0];
  assert.strictEqual(args.success, false);
  assert.strictEqual(args.timeLeftSec, 0);
  assert.strictEqual(lastLog(s.room).kind, 'event');
  // result fazında tick hiçbir şey yapmaz
  const before = JSON.stringify(s.room);
  assert.strictEqual(s.at(10_000), false);
  assert.strictEqual(JSON.stringify(s.room), before);
});

test('windowMissedResult enjekte edilmezse yerleşik varsayılan; bozuksa da çökmez', () => {
  for (const missed of [undefined, () => { throw new Error('x'); }]) {
    const s = started({ missed });
    s.at(300);
    s.at(480);
    assert.strictEqual(s.room.phase, 'result');
    assert.strictEqual(s.room.result.outcome, 'window-missed');
    assert.strictEqual(s.room.result.success, false);
    assert.ok(s.room.result.title.length > 0);
  }
});

test('timeLeftSec: window 1 kalan sn, window 2 kalanın yarısı (aşağı)', () => {
  const s = started();
  s.m.addPart(s.code, s.p[1].id, 'eng', free(s.m, s.code));
  s.clock.t = T0 + 100_400; // kalan 199.6 sn
  s.m.startPoll(s.code, s.p[0].id);
  allGo(s);
  assert.strictEqual(s.computeScore.calls[0].timeLeftSec, 199);
  assert.strictEqual(s.room.result.timeLeftSec, 199);
  assert.strictEqual(s.room.result.window, 1);
  assert.strictEqual(s.room.result.success, true);

  const s2 = started();
  s2.at(300); // window 2: 180 sn
  s2.clock.t = T0 + 330_500; // kalan 149.5 → yarısı 74.75 → 74
  s2.m.startPoll(s2.code, s2.p[0].id);
  allGo(s2);
  assert.strictEqual(s2.computeScore.calls[0].timeLeftSec, 74);
  assert.strictEqual(s2.room.result.window, 2);
});

// ---------------- Telemetri gecikmesi ----------------

test('telemetri gecikmesi: yönetici eski değeri görür, süre dolunca tick true', () => {
  const s = started({ config: { events: [], telemetryDelayMs: 2000 } });
  const d0 = viewFor(s.room, s.p[0].id, s.physics, VL);
  assert.strictEqual(d0.telemetry.parts, 0); // tur başı gecikmesiz
  assert.strictEqual(d0.telemetryDelayMs, 2000);
  s.m.addPart(s.code, s.p[1].id, 'eng', free(s.m, s.code));
  assert.strictEqual(s.room.telemetry.parts, 1); // gerçek değer anında
  assert.strictEqual(viewFor(s.room, s.p[0].id, s.physics, VL).telemetry.parts, 0);
  // yönetici build/log gecikmesiz
  assert.strictEqual(viewFor(s.room, s.p[0].id, s.physics, VL).build.rocket.length, 1);
  s.clock.t = T0 + 500;
  s.m.addPart(s.code, s.p[1].id, 'eng', free(s.m, s.code));
  assert.strictEqual(s.at(1.999), false);
  assert.strictEqual(s.at(2), true);
  assert.strictEqual(viewFor(s.room, s.p[0].id, s.physics, VL).telemetry.parts, 1);
  assert.strictEqual(s.at(2.4), false);
  assert.strictEqual(s.at(2.5), true);
  assert.strictEqual(viewFor(s.room, s.p[0].id, s.physics, VL).telemetry.parts, 2);
  assert.strictEqual(s.room.telemetryQueue.length, 0);
});

test('telemetri gecikmesi 0: anında gösterilir, kuyruk kullanılmaz', () => {
  const s = started();
  s.m.addPart(s.code, s.p[1].id, 'eng', free(s.m, s.code));
  assert.strictEqual(viewFor(s.room, s.p[0].id, s.physics, VL).telemetry.parts, 1);
  assert.strictEqual(s.room.telemetryQueue.length, 0);
  assert.strictEqual(viewFor(s.room, s.p[0].id, s.physics, VL).telemetryDelayMs, 0);
});

// ---------------- Rastgele olay planı ----------------

test('rastgele olay planı: 1–2 olay, farklı tür, aralık kuralları', () => {
  const counts = new Set();
  for (const windowSec of [300, 100]) {
    const f = Math.min(1, windowSec / 300);
    const lo = 40 * f * 1000, hi = (windowSec - 60 * f) * 1000, gap = 45 * f * 1000;
    for (let seed = 1; seed <= 200; seed++) {
      const s = started({ rng: seeded(seed), config: { telemetryDelayMs: 0, windowSec } });
      const pe = s.room.pendingEvents;
      assert.ok(pe.length === 1 || pe.length === 2, `olay sayısı ${pe.length}`);
      counts.add(pe.length);
      assert.strictEqual(new Set(pe.map((e) => e.type)).size, pe.length, 'türler farklı olmalı');
      for (const e of pe) {
        assert.ok(EVENT_TYPES.includes(e.type));
        const off = e.at - T0;
        assert.ok(off >= lo - 1 && off <= hi + 1, `atSec aralık dışı: ${off}`);
      }
      if (pe.length === 2) assert.ok(pe[1].at - pe[0].at >= gap, 'iki olay arası en az 45 sn');
    }
  }
  assert.deepStrictEqual([...counts].sort(), [1, 2]);
  // sabit plan ve boş plan
  assert.deepStrictEqual(started().room.pendingEvents, []);
  const s = started({ config: { events: [{ type: 'weather', atSec: 20 }, { type: 'bogus', atSec: 5 }, { type: 'computer-fault', atSec: 10 }], telemetryDelayMs: 0 } });
  assert.deepStrictEqual(s.room.pendingEvents, [{ type: 'computer-fault', at: T0 + 10_000 }, { type: 'weather', at: T0 + 20_000 }]);
});

// ---------------- Olay etkileri ----------------

test('weather: HOLD, anket iptali, bekleme bitişi', () => {
  const s = started({ config: { events: [{ type: 'weather', atSec: 10 }], telemetryDelayMs: 0 } });
  assert.strictEqual(s.at(9.999), false);
  s.m.startPoll(s.code, s.p[0].id);
  s.m.vote(s.code, s.p[1].id, 'go');
  assert.strictEqual(s.at(10), true);
  assert.strictEqual(s.room.phase, 'building');
  assert.strictEqual(s.room.poll, null);
  assert.strictEqual(s.room.holdUntil, T0 + 40_000);
  assert.strictEqual(s.room.events.length, 1);
  const ev = s.room.events[0];
  assert.deepStrictEqual(Object.keys(ev).sort(), ['id', 't', 'text', 'type', 'until']);
  assert.strictEqual(ev.type, 'weather');
  assert.strictEqual(ev.text, 'Hava kötü: 30 sn fırlatma beklemesi');
  assert.strictEqual(ev.until, T0 + 40_000);
  assert.strictEqual(ev.t, T0 + 10_000);
  const texts = s.room.log.map((e) => `${e.kind}|${e.text}`);
  assert.ok(texts.includes('event|Hava kötü: 30 sn fırlatma beklemesi'));
  assert.strictEqual(lastLog(s.room).text, 'Hava nedeniyle anket iptal edildi');
  assert.strictEqual(lastLog(s.room).kind, 'poll');
  assert.strictEqual(s.room.pendingEvents.length, 0);

  throwsCode(() => s.m.startPoll(s.code, s.p[0].id), 'HOLD');
  assert.strictEqual(viewFor(s.room, s.p[1].id, s.physics, VL).holdUntil, T0 + 40_000);
  assert.strictEqual(s.at(39.9), false);
  assert.strictEqual(s.at(40), true);
  assert.strictEqual(s.room.holdUntil, null);
  assert.strictEqual(lastLog(s.room).text, 'Hava açtı: fırlatma beklemesi kalktı');
  assert.strictEqual(lastLog(s.room).kind, 'event');
  s.m.startPoll(s.code, s.p[0].id);
  assert.strictEqual(s.room.phase, 'poll');
});

test('computer-fault: checks.computer eklenir, ready yeniden hesaplanır', () => {
  const s = started({ config: { events: [{ type: 'computer-fault', atSec: 5 }], telemetryDelayMs: 0 } });
  s.m.addPart(s.code, s.p[1].id, 'eng', free(s.m, s.code));
  assert.ok(!('computer' in s.room.telemetry.checks)); // bayrak kapalıyken anahtar yok
  assert.strictEqual(s.room.telemetry.ready, true);
  assert.strictEqual(s.at(5), true);
  assert.strictEqual(s.room.needBackupComputer, true);
  assert.strictEqual(s.room.telemetry.checks.computer, false);
  assert.strictEqual(s.room.telemetry.ready, false);
  assert.strictEqual(viewFor(s.room, s.p[0].id, s.physics, VL).telemetry.checks.computer, false);
  const ev = s.room.events[0];
  assert.strictEqual(ev.text, 'Uçuş bilgisayarı arızalandı: yedek bilgisayar takılmalı');
  assert.strictEqual(ev.until, null);

  s.m.addPart(s.code, s.p[2].id, 'comp', free(s.m, s.code));
  assert.strictEqual(s.room.telemetry.checks.computer, true);
  assert.strictEqual(s.room.telemetry.ready, true);
  s.m.removePart(s.code, s.p[2].id, s.room.build.spacecraft[0].uid);
  assert.strictEqual(s.room.telemetry.checks.computer, false);
  // fırlatma gerçek telemetriyle çözülür: computer false → başarısız
  s.m.startPoll(s.code, s.p[0].id);
  allGo(s);
  assert.strictEqual(s.room.result.success, false);
  assert.ok(s.room.result.failedChecks.includes('computer'));
  assert.deepStrictEqual(s.room.result.events, [{ type: 'computer-fault', text: 'Uçuş bilgisayarı arızalandı: yedek bilgisayar takılmalı' }]);
});

test('computer-fault gecikmeli telemetride de kuyruktan gelir', () => {
  const s = started({ config: { events: [{ type: 'computer-fault', atSec: 5 }], telemetryDelayMs: 2000 } });
  s.at(5);
  assert.ok(!('computer' in viewFor(s.room, s.p[0].id, s.physics, VL).telemetry.checks));
  assert.strictEqual(s.at(7), true);
  assert.strictEqual(viewFor(s.room, s.p[0].id, s.physics, VL).telemetry.checks.computer, false);
});

test('supplier-delay: takılı olmayan parça kilitlenir, PART_LOCKED, kilit açılır', () => {
  // rng 0 → ilk aday; takılı olanlar aday değil
  const s = started({ config: { events: [{ type: 'supplier-delay', atSec: 5 }], telemetryDelayMs: 0 } });
  s.m.addPart(s.code, s.p[1].id, 'eng', free(s.m, s.code));
  assert.strictEqual(s.at(5), true);
  assert.deepStrictEqual(s.room.locks, { tank: T0 + 50_000 });
  const ev = s.room.events[0];
  assert.strictEqual(ev.type, 'supplier-delay');
  assert.strictEqual(ev.text, 'Tedarikçi gecikti: Sahte Tank kilitli');
  assert.strictEqual(ev.until, T0 + 50_000);
  throwsCode(() => s.m.addPart(s.code, s.p[1].id, 'tank', free(s.m, s.code)), 'PART_LOCKED');
  s.m.addPart(s.code, s.p[1].id, 'eng', free(s.m, s.code)); // kilitsiz parça serbest
  const w = viewFor(s.room, s.p[1].id, s.physics, VL);
  assert.deepStrictEqual(w.catalog.map((c) => [c.id, c.locked]), [['eng', false], ['tank', true]]);
  assert.deepStrictEqual(viewFor(s.room, s.p[0].id, s.physics, VL).locks, { tank: T0 + 50_000 });
  assert.strictEqual(s.at(49.9), false);
  assert.strictEqual(s.at(50), true);
  assert.deepStrictEqual(s.room.locks, {});
  assert.strictEqual(lastLog(s.room).text, 'Sahte Tank yeniden kullanılabilir');
  assert.strictEqual(lastLog(s.room).kind, 'event');
  s.m.addPart(s.code, s.p[1].id, 'tank', free(s.m, s.code));
  assert.ok(viewFor(s.room, s.p[1].id, s.physics, VL).catalog.every((c) => c.locked === false));
});

test('supplier-delay: uygun parça yoksa olay atlanır', () => {
  const s = started({ config: { events: [{ type: 'supplier-delay', atSec: 5 }], telemetryDelayMs: 0 } });
  for (const [i, id] of [[1, 'eng'], [1, 'tank'], [2, 'panel'], [2, 'comp'], [3, 'cam']]) s.m.addPart(s.code, s.p[i].id, id, free(s.m, s.code));
  const n = s.room.log.length;
  assert.strictEqual(s.at(5), false);
  assert.deepStrictEqual(s.room.events, []);
  assert.deepStrictEqual(s.room.locks, {});
  assert.strictEqual(s.room.pendingEvents.length, 0);
  assert.strictEqual(s.room.log.length, n);
});

test('kendi parçasını çıkarıp kilitli parçayı geri ekleyemez; geri alma kilidi deler', () => {
  const s = started({ config: { events: [{ type: 'supplier-delay', atSec: 5 }], telemetryDelayMs: 0 } });
  for (const [i, id] of [[1, 'eng'], [1, 'tank'], [2, 'panel'], [2, 'comp'], [3, 'cam']]) s.m.addPart(s.code, s.p[i].id, id, free(s.m, s.code));
  const tankUid = s.room.build.rocket[1].uid;
  s.m.removePart(s.code, s.p[1].id, tankUid); // tek aday artık tank
  s.at(5);
  assert.ok(s.room.locks.tank > s.clock.t);
  throwsCode(() => s.m.addPart(s.code, s.p[1].id, 'tank', free(s.m, s.code)), 'PART_LOCKED');
  s.m.undo(s.code, s.p[0].id, 'rocket');
  const tanks = s.room.build.rocket.filter((it) => it.partId === 'tank');
  assert.strictEqual(tanks.length, 1);
  assert.notStrictEqual(tanks[0].uid, tankUid);
  assert.strictEqual(lastLog(s.room).text, 'Yönetici, Roket & Yakıt son hamlesini geri aldı: Sahte Tank geri takıldı');
});

// ---------------- Geri alma ----------------

test('undo: hatalar', () => {
  const s = started();
  const { m, code, p } = s;
  throwsCode(() => m.undo(code, p[1].id, 'rocket'), 'NOT_ALLOWED');
  throwsCode(() => m.undo(code, 'yabanci', 'rocket'), 'NOT_IN_ROOM');
  for (const bad of ['director', 'x', undefined, null, 1]) throwsCode(() => m.undo(code, p[0].id, bad), 'BAD_REQUEST');
  throwsCode(() => m.undo(code, p[0].id, 'rocket'), 'NOTHING_TO_UNDO');
  m.addPart(code, p[1].id, 'eng', free(m, code));
  m.startPoll(code, p[0].id);
  throwsCode(() => m.undo(code, p[0].id, 'rocket'), 'WRONG_PHASE');
  m.cancelPoll(code, p[0].id);
  m.undo(code, p[0].id, 'rocket');
  throwsCode(() => m.undo(code, p[0].id, 'rocket'), 'NOTHING_TO_UNDO'); // aynı rolde tekrar
  // hakkı bitir
  m.addPart(code, p[2].id, 'panel', free(m, code));
  m.undo(code, p[0].id, 'spacecraft');
  m.addPart(code, p[3].id, 'cam', free(m, code));
  m.undo(code, p[0].id, 'payload');
  assert.strictEqual(s.room.undoLeft, 0);
  m.addPart(code, p[1].id, 'eng', free(m, code));
  throwsCode(() => m.undo(code, p[0].id, 'rocket'), 'NO_UNDO_LEFT');
  // lobi
  const m2 = createRoomManager({ missions: [MISSION], ...deps(), resolveLaunch: fakeLaunch(), computeScore: fakeScore(), now: () => T0, config: { events: [] } });
  const { room: r2, player } = m2.createRoom('X');
  m2.selectRole(r2.code, player.id, 'director');
  throwsCode(() => m2.undo(r2.code, player.id, 'rocket'), 'WRONG_PHASE');
});

test('undo: add ve remove geri alma, sayaçlar, telemetri, log, görünüm', () => {
  const s = started();
  const { m, code, p, room } = s;
  m.addPart(code, p[1].id, 'eng', free(m, code));
  const engUid = room.build.rocket[0].uid;
  assert.deepStrictEqual(room.lastMove.rocket, { type: 'add', uid: engUid, partId: 'eng', slotId: 'yuva-aa' });
  let d = viewFor(room, p[0].id, s.physics, VL);
  assert.deepStrictEqual(d.undo, { left: 3, available: { rocket: true, spacecraft: false, payload: false } });

  m.undo(code, p[0].id, 'rocket');
  assert.deepStrictEqual(room.build.rocket, []);
  assert.strictEqual(room.lastMove.rocket, null);
  assert.strictEqual(room.undoLeft, 2);
  assert.strictEqual(room.undoUsed, 1);
  assert.strictEqual(room.telemetry.parts, 0);
  assert.strictEqual(lastLog(room).kind, 'undo');
  assert.strictEqual(lastLog(room).role, 'director');
  assert.strictEqual(lastLog(room).text, 'Yönetici, Roket & Yakıt son hamlesini geri aldı: Sahte Motor çıkarıldı');

  // remove geri alma: limit kontrolü yok (tank max 1)
  m.addPart(code, p[1].id, 'tank', free(m, code));
  const tUid = room.build.rocket[0].uid;
  m.removePart(code, p[1].id, tUid);
  assert.deepStrictEqual(room.lastMove.rocket, { type: 'remove', uid: tUid, partId: 'tank', slotId: 'yuva-aa' });
  m.undo(code, p[0].id, 'rocket');
  assert.strictEqual(room.build.rocket.length, 1);
  assert.strictEqual(room.build.rocket[0].partId, 'tank');
  assert.notStrictEqual(room.build.rocket[0].uid, tUid);
  assert.strictEqual(room.undoLeft, 1);
  assert.strictEqual(room.undoUsed, 2);
  assert.strictEqual(room.telemetry.parts, 1);
  d = viewFor(room, p[0].id, s.physics, VL);
  assert.deepStrictEqual(d.undo, { left: 1, available: { rocket: false, spacecraft: false, payload: false } });
  assert.strictEqual(d.undoLeft, 1);
  // çalışan akışında undo görünür
  assert.ok(viewFor(room, p[2].id, s.physics, VL).feed.some((e) => /geri takıldı/.test(e.text)));
  // undoUsed puana ve sonuca gider
  m.startPoll(code, p[0].id);
  allGo(s);
  assert.strictEqual(s.computeScore.calls[0].undoUsed, 2);
  assert.strictEqual(room.result.undoUsed, 2);
});

// ---------------- Restart ----------------

test('restart tüm Aşama 4 durumunu sıfırlar', () => {
  const s = started({
    missions: [MISSION, MISSION_B],
    config: { events: [{ type: 'weather', atSec: 1 }, { type: 'computer-fault', atSec: 2 }, { type: 'supplier-delay', atSec: 3 }], telemetryDelayMs: 2000 },
  });
  const { m, code, p, room } = s;
  m.addPart(code, p[1].id, 'eng', free(m, code));
  m.undo(code, p[0].id, 'rocket');
  m.addPart(code, p[2].id, 'panel', free(m, code));
  s.at(3);
  assert.ok(room.holdUntil && room.needBackupComputer && Object.keys(room.locks).length === 1);
  s.at(300);
  s.at(480);
  assert.strictEqual(room.phase, 'result');
  assert.strictEqual(room.result.events.length, 3);
  s.clock.t = T0 + 600_000;
  m.restart(code, p[0].id);
  // Aşama 5: setup'ta sayaç/olay yok, tick boş
  assert.strictEqual(room.phase, 'setup');
  assert.strictEqual(room.timer, null);
  assert.deepStrictEqual(room.pendingEvents, []);
  s.clock.t = T0 + 650_000;
  assert.strictEqual(m.tick(code), false);
  m.selectFrame(code, p[0].id, FRAME_ID); // sayaç ve olay planı bu an başlar
  assert.strictEqual(room.phase, 'building');
  assert.deepStrictEqual(room.timer, { window: 1, endsAt: T0 + 650_000 + 300_000 });
  assert.deepStrictEqual(room.pendingEvents.map((e) => e.at - (T0 + 650_000)), [1000, 2000, 3000]);
  assert.deepStrictEqual(room.events, []);
  assert.strictEqual(room.holdUntil, null);
  assert.deepStrictEqual(room.locks, {});
  assert.strictEqual(room.needBackupComputer, false);
  assert.deepStrictEqual(room.lastMove, { rocket: null, spacecraft: null, payload: null });
  assert.strictEqual(room.undoLeft, 3);
  assert.strictEqual(room.undoUsed, 0);
  assert.deepStrictEqual(room.telemetryQueue, []);
  assert.deepStrictEqual(room.telemetryShown, room.telemetry);
  assert.ok(!('computer' in room.telemetry.checks));
  assert.strictEqual(room.result, null);
  // yeni tur olayları yeniden işler
  s.clock.t = T0 + 651_000;
  assert.strictEqual(m.tick(code), true);
  assert.strictEqual(room.events.length, 1);
});

// ---------------- Görünümler / güvenlik ----------------

function workerJson(room, me, players, physics) {
  const v = viewFor(room, me.id, physics, VL);
  let json = JSON.stringify(v).split(me.id).join('<ME>');
  for (const uid of room.build[me.role].map((it) => it.uid)) json = json.split(uid).join('<UID>');
  return { v, json };
}

test('görünümler: building/poll ortak alanlar, çalışan beyaz liste, sızıntı yok', () => {
  const s = started({ config: { events: [{ type: 'weather', atSec: 1 }, { type: 'computer-fault', atSec: 2 }, { type: 'supplier-delay', atSec: 3 }], telemetryDelayMs: 2000 } });
  const { m, code, p, room, physics } = s;
  m.addPart(code, p[1].id, 'eng', free(m, code));
  m.addPart(code, p[2].id, 'panel', free(m, code));
  s.at(3);
  s.at(4);
  assert.strictEqual(room.events.length, 3);

  for (const phase of ['building', 'poll']) {
    if (phase === 'poll') { s.at(40); m.startPoll(code, p[0].id); }
    assert.strictEqual(room.phase, phase);
    for (const me of p.slice(1)) {
      const { v, json } = workerJson(room, me, p, physics);
      const keys = Object.keys(v).sort();
      const expected = ['catalog', 'code', 'events', 'feed', 'frame', 'holdUntil', 'missionLabel', 'myParts', 'others', 'phase', 'players', 'roles', 'slots', 'timer', 'you'];
      if (phase === 'poll') expected.push('poll');
      assert.deepStrictEqual(keys, expected.sort());
      for (const k of ['mission', 'telemetry', 'telemetryDelayMs', 'log', 'undoLeft', 'undo', 'build', 'result', 'locks', 'pendingEvents', 'frames', 'frameInfo', 'budget']) {
        assert.ok(!(k in v), `${k} anahtarı var`);
      }
      assert.deepStrictEqual(v.timer, { window: 1, endsAt: T0 + 300_000, now: s.clock.t });
      assert.strictEqual(v.events.length, 3);
      assert.deepStrictEqual(v.events.map((e) => e.type), ['supplier-delay', 'computer-fault', 'weather']); // en yeni önce
      for (const e of v.events) assert.deepStrictEqual(Object.keys(e).sort(), ['id', 't', 'text', 'type', 'until']);
      for (const c of v.catalog) assert.deepStrictEqual(Object.keys(c).sort(), ['category', 'desc', 'icon', 'id', 'locked', 'model', 'name', 'slots']);
      // kilitli parça (supplier-delay → tank): tüm yuvalar engelli + gerekçe
      if (me.role === 'rocket') {
        const tank = v.catalog.find((c) => c.id === 'tank');
        assert.strictEqual(tank.locked, true);
        assert.ok(tank.slots.length > 0 && tank.slots.every((x) => x.ok === false && x.reason === 'Tedarikçi gecikmesi: parça kilitli'));
      }
      for (const f of NUM_FIELDS) assert.ok(!json.includes(`"${f}"`), `${f} alanı sızdı`);
      for (const n of SECRET_NUMS) assert.ok(!json.includes(n), `sayı sızdı: ${n}`);
      for (const x of ['GIZLI', 'gorev-gizli', 'requiredDeltaV', 'budget', 'checks', 'parMassKg', 'pendingEvents']) assert.ok(!json.includes(x), `sızdı: ${x}`);
      for (const o of p) if (o.id !== me.id) assert.ok(!json.includes(o.id), 'başka oyuncunun playerId sızdı');
    }
    const d = viewFor(room, p[0].id, physics, VL);
    for (const k of ['timer', 'events', 'holdUntil', 'telemetryDelayMs', 'locks', 'undo', 'undoLeft', 'telemetry', 'mission', 'log']) assert.ok(k in d, k);
    assert.ok(!('pendingEvents' in d));
    const dj = JSON.stringify(d);
    assert.ok(!dj.includes('pendingEvents'));
    for (const o of p.slice(1)) assert.ok(!dj.includes(o.id), 'yöneticiye başka playerId sızdı');
  }
});

test('görünüm: bekleyen olaylar kimseye gitmez; olay metinlerinde gizli bilgi yok', () => {
  const s = started({ config: { events: [{ type: 'weather', atSec: 100 }], telemetryDelayMs: 0 } });
  for (const pl of s.p) {
    const v = viewFor(s.room, pl.id, s.physics, VL);
    assert.deepStrictEqual(v.events, []);
    assert.strictEqual(v.holdUntil, null);
    assert.ok(!JSON.stringify(v).includes('weather'), 'gelecek olay sızdı');
  }
  s.at(100);
  for (const e of s.room.events) assert.ok(!/GIZLI|4321|9991|9876/.test(e.text));
});

test('görünüm result: Aşama 4 ekleri ve lobi', () => {
  const s = started({ config: { events: [{ type: 'weather', atSec: 1 }], telemetryDelayMs: 0 } });
  s.at(1);
  s.at(31);
  s.m.startPoll(s.code, s.p[0].id);
  allGo(s);
  for (const pl of s.p) {
    const v = viewFor(s.room, pl.id, s.physics, VL);
    assert.deepStrictEqual(Object.keys(v).sort(), ['code', 'phase', 'players', 'result', 'roles', 'you']);
    assert.strictEqual(v.result.timeLeftSec, 269);
    assert.strictEqual(v.result.window, 1);
    assert.strictEqual(v.result.undoUsed, 0);
    assert.deepStrictEqual(v.result.events, [{ type: 'weather', text: 'Hava kötü: 30 sn fırlatma beklemesi' }]);
  }
  // lobide Aşama 4 alanı yok
  const m = createRoomManager({ missions: [MISSION], ...deps(), resolveLaunch: fakeLaunch(), computeScore: fakeScore(), now: () => T0, config: { events: [] } });
  const { room, player } = m.createRoom('X');
  assert.deepStrictEqual(Object.keys(viewFor(room, player.id, fakePhysics())).sort(), ['code', 'phase', 'players', 'roles', 'you']);
  // oda nesnesi JSON'a dökülse de saat fonksiyonu görünmez
  assert.ok(!Object.keys(room).includes('clock'));
});
