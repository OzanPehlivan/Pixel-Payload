'use strict';
// Modül H birim testleri: node --test test/launch.test.js
const test = require('node:test');
const assert = require('node:assert/strict');
const catalog = require('../data/parts.json');
const missions = require('../data/missions.json');
const { createPhysics } = require('../server/physics.js');
const { resolveLaunch, windowMissedResult } = require('../server/launch.js');
const { computeScore } = require('../server/scoring.js');

const ALL_OK = { twr: true, deltaV: true, power: true, payload: true, heat: true };
const MISSION = { id: 'm', target: 'Hedef', requiredDeltaV: 4000, requiredInstruments: ['camera', 'rover'],
  budget: 1000, durationSec: 300, parMassKg: 20000 };

// Sahte telemetri: istenen kontroller false.
function tel(falseKeys = [], extra = {}) {
  const checks = { ...ALL_OK };
  for (const k of falseKeys) checks[k] = false;
  return { massKg: 18000, dryMassKg: 5000, fuelKg: 13000, thrustKN: 250, isp: 300, twr: 1.41, deltaV: 4200,
    powerGenW: 240, powerUseW: 200, heat: 20, heatShield: 30, spent: 600, checks, missing: [], overBudget: false,
    ready: falseKeys.length === 0, ...extra };
}

// ---------- resolveLaunch ----------

test('başarı', () => {
  const r = resolveLaunch(tel(), MISSION);
  assert.equal(r.success, true);
  assert.equal(r.outcome, 'success');
  assert.deepEqual(r.failedChecks, []);
  assert.equal(typeof r.title, 'string');
  assert.equal(typeof r.reasonText, 'string');
});

test('her outcome tek başına', () => {
  const cases = { twr: 'no-liftoff', deltaV: 'out-of-fuel', power: 'power-loss', heat: 'overheat', payload: 'mission-failed' };
  for (const [k, outcome] of Object.entries(cases)) {
    const r = resolveLaunch(tel([k]), MISSION);
    assert.equal(r.success, false, k);
    assert.equal(r.outcome, outcome, k);
    assert.deepEqual(r.failedChecks, [k]);
    assert.ok(r.title.length > 0 && r.reasonText.length > 0);
  }
});

test('no-liftoff metni sayıları içerir', () => {
  const r = resolveLaunch(tel(['twr'], { twr: 0.94 }), MISSION);
  assert.match(r.reasonText, /0\.94/);
  assert.match(r.reasonText, /1\.2/);
});

test('out-of-fuel metni Δv ve gerekeni içerir', () => {
  const r = resolveLaunch(tel(['deltaV'], { deltaV: 3100 }), MISSION);
  assert.match(r.reasonText, /3100/);
  assert.match(r.reasonText, /4000/);
});

test('power-loss ve overheat metinleri sayıları içerir', () => {
  const p = resolveLaunch(tel(['power'], { powerGenW: 120, powerUseW: 260 }), MISSION);
  assert.match(p.reasonText, /120/);
  assert.match(p.reasonText, /260/);
  const h = resolveLaunch(tel(['heat'], { heat: 45, heatShield: 35 }), MISSION);
  assert.match(h.reasonText, /45/);
  assert.match(h.reasonText, /35/);
});

test('mission-failed: eksik alet ve/veya bütçe aşımı', () => {
  const miss = resolveLaunch(tel(['payload'], { missing: ['rover'] }), MISSION);
  assert.match(miss.reasonText, /rover/);
  assert.doesNotMatch(miss.reasonText, /Bütçe/);
  const over = resolveLaunch(tel(['payload'], { overBudget: true, spent: 1200 }), MISSION);
  assert.match(over.reasonText, /Bütçe/);
  assert.match(over.reasonText, /1200/);
  assert.match(over.reasonText, /1000/);
  const both = resolveLaunch(tel(['payload'], { missing: ['camera'], overBudget: true, spent: 1100 }), MISSION);
  assert.match(both.reasonText, /camera/);
  assert.match(both.reasonText, /Bütçe/);
});

test('öncelik sırası: birden çok kontrol false', () => {
  assert.equal(resolveLaunch(tel(['payload', 'heat', 'power', 'deltaV', 'twr']), MISSION).outcome, 'no-liftoff');
  assert.equal(resolveLaunch(tel(['payload', 'heat', 'power', 'deltaV']), MISSION).outcome, 'out-of-fuel');
  assert.equal(resolveLaunch(tel(['payload', 'heat', 'power']), MISSION).outcome, 'power-loss');
  assert.equal(resolveLaunch(tel(['payload', 'heat']), MISSION).outcome, 'overheat');
  const r = resolveLaunch(tel(['payload', 'heat', 'twr']), MISSION);
  assert.equal(r.outcome, 'no-liftoff');
  assert.deepEqual(r.failedChecks.slice().sort(), ['heat', 'payload', 'twr']);
});

test('eksik/bozuk girdi çökmez', () => {
  for (const [t, m] of [[null, null], [undefined, undefined], [{}, {}], [{ checks: null }, MISSION]]) {
    const r = resolveLaunch(t, m);
    assert.equal(r.success, false);
    assert.equal(r.outcome, 'no-liftoff');
    assert.ok(!/NaN|undefined/.test(r.reasonText), r.reasonText);
  }
  const r = resolveLaunch(tel(['deltaV'], { deltaV: undefined }), null);
  assert.equal(r.outcome, 'out-of-fuel');
  assert.ok(!/NaN|undefined/.test(r.reasonText), r.reasonText);
});

// ---------- Aşama 4: computer kontrolü + pencere kaçırma ----------

const withComputer = (falseKeys, computer, extra) => {
  const t = tel(falseKeys, extra);
  t.checks.computer = computer;
  return t;
};

test('computer false -> computer-failure', () => {
  const r = resolveLaunch(withComputer([], false), MISSION);
  assert.equal(r.success, false);
  assert.equal(r.outcome, 'computer-failure');
  assert.equal(r.title, 'Uçuş bilgisayarı arızalandı');
  assert.match(r.reasonText, /yedek/i);
  assert.deepEqual(r.failedChecks, ['computer']);
});

test('computer önceliği: power sonrası, heat öncesi', () => {
  assert.equal(resolveLaunch(withComputer(['power'], false), MISSION).outcome, 'power-loss');
  assert.equal(resolveLaunch(withComputer(['deltaV'], false), MISSION).outcome, 'out-of-fuel');
  assert.equal(resolveLaunch(withComputer(['twr'], false), MISSION).outcome, 'no-liftoff');
  const r = resolveLaunch(withComputer(['heat', 'payload'], false), MISSION);
  assert.equal(r.outcome, 'computer-failure');
  assert.deepEqual(r.failedChecks, ['computer', 'heat', 'payload']);
});

test('computer true/undefined etkisiz', () => {
  const ok = resolveLaunch(withComputer([], true), MISSION);
  assert.equal(ok.outcome, 'success');
  assert.deepEqual(ok.failedChecks, []);
  const none = resolveLaunch(tel(), MISSION);
  assert.ok(!('computer' in tel().checks));
  assert.equal(none.outcome, 'success');
  const heat = resolveLaunch(tel(['heat']), MISSION);
  assert.equal(heat.outcome, 'overheat');
  assert.deepEqual(heat.failedChecks, ['heat']);
  assert.equal(resolveLaunch(withComputer(['heat'], true), MISSION).outcome, 'overheat');
});

test('windowMissedResult biçimi', () => {
  const r = windowMissedResult();
  assert.deepEqual(Object.keys(r).sort(), ['failedChecks', 'outcome', 'reasonText', 'success', 'title']);
  assert.equal(r.success, false);
  assert.equal(r.outcome, 'window-missed');
  assert.equal(r.title, 'Fırlatma penceresi kaçırıldı');
  assert.ok(typeof r.reasonText === 'string' && r.reasonText.length > 0);
  assert.match(r.reasonText, /rampa/);
  assert.deepEqual(r.failedChecks, []);
  assert.notEqual(windowMissedResult().failedChecks, r.failedChecks); // her çağrı yeni nesne
});

// ---------- computeScore ----------

const KEYS = ['base', 'time', 'budget', 'mass', 'undo'];
const score = (o = {}) => computeScore({ success: true, mission: MISSION, telemetry: tel(), undoUsed: 0, timeLeftSec: null, ...o });
const pts = (s, key) => s.breakdown.find((b) => b.key === key).points;

test('5 kalem bu sırada, etiketli ve tamsayı', () => {
  for (const s of [score(), computeScore({ success: false, mission: MISSION, telemetry: tel(), undoUsed: 2, timeLeftSec: 100 })]) {
    assert.deepEqual(s.breakdown.map((b) => b.key), KEYS);
    for (const b of s.breakdown) {
      assert.equal(typeof b.label, 'string');
      assert.ok(Number.isInteger(b.points));
    }
    assert.ok(Number.isInteger(s.total) && s.total >= 0);
  }
});

test('başarısızlık = 0 puan, 0 yıldız', () => {
  const s = computeScore({ success: false, mission: MISSION, telemetry: tel(), undoUsed: 1, timeLeftSec: 200 });
  assert.equal(s.total, 0);
  assert.equal(s.stars, 0);
  for (const b of s.breakdown) assert.equal(b.points, 0);
});

test('başarıda taban 1000 ve en az 1 yıldız', () => {
  const s = score();
  assert.equal(pts(s, 'base'), 1000);
  assert.ok(s.stars >= 1 && s.stars <= 3);
  assert.equal(s.total, s.breakdown.reduce((a, b) => a + b.points, 0));
});

test('bütçe: daha az harcama daha çok puan', () => {
  const cheap = score({ telemetry: tel([], { spent: 200 }) });
  const pricey = score({ telemetry: tel([], { spent: 900 }) });
  assert.ok(pts(cheap, 'budget') > pts(pricey, 'budget'));
  assert.equal(pts(score({ telemetry: tel([], { spent: 1000 }) }), 'budget'), 0);
});

test('kütle: par altı tam bonus, üstünde azalır', () => {
  const under = score({ telemetry: tel([], { massKg: 15000 }) });
  const at = score({ telemetry: tel([], { massKg: 20000 }) });
  const over = score({ telemetry: tel([], { massKg: 26000 }) });
  const way = score({ telemetry: tel([], { massKg: 50000 }) });
  assert.equal(pts(under, 'mass'), 300);
  assert.equal(pts(at, 'mass'), 300);
  assert.ok(pts(over, 'mass') < 300 && pts(over, 'mass') > 0);
  assert.equal(pts(way, 'mass'), 0);
});

test('geri alma: her biri ceza', () => {
  assert.equal(pts(score({ undoUsed: 0 }), 'undo'), 0);
  assert.ok(Object.is(pts(score({ undoUsed: 0 }), 'undo'), 0));
  assert.equal(pts(score({ undoUsed: 2 }), 'undo'), -200);
  assert.ok(score({ undoUsed: 2 }).total < score({ undoUsed: 0 }).total);
});

test('süre: null/undefined 0, kalan süre arttıkça artar', () => {
  assert.equal(pts(score({ timeLeftSec: null }), 'time'), 0);
  assert.equal(pts(score({ timeLeftSec: undefined }), 'time'), 0);
  const a = score({ timeLeftSec: 60 }), b = score({ timeLeftSec: 240 });
  assert.ok(pts(b, 'time') > pts(a, 'time'));
  assert.equal(pts(score({ timeLeftSec: 300 }), 'time'), 500);
  assert.equal(pts(score({ timeLeftSec: 9999 }), 'time'), 500);
});

test('süre puanı timeLeftSec ile monoton artar, toplama yansır', () => {
  let prev = -1;
  for (const s of [0, 30, 90, 150, 210, 300]) {
    const p = pts(score({ timeLeftSec: s }), 'time');
    assert.ok(p > prev, `${s}: ${p}`);
    prev = p;
  }
  assert.equal(pts(score({ timeLeftSec: 0 }), 'time'), 0);
  assert.equal(pts(score({ timeLeftSec: 150 }), 'time'), 250);
  assert.equal(pts(score({ timeLeftSec: -10 }), 'time'), 0);
  assert.equal(score({ timeLeftSec: 150 }).total - score({ timeLeftSec: 0 }).total, 250);
});

test('total negatif olmaz; eksik alanlar çökmez', () => {
  const s = score({ undoUsed: 50, telemetry: tel([], { spent: 5000, massKg: 99999 }) });
  assert.equal(s.total, 0);
  assert.equal(s.stars, 1);
  const e = computeScore({ success: true, mission: null, telemetry: null });
  assert.equal(e.total, 1000);
  assert.deepEqual(e.breakdown.map((b) => b.key), KEYS);
  assert.deepEqual(computeScore().breakdown.map((b) => b.points), [0, 0, 0, 0, 0]);
});

test('yıldız eşikleri artan puanla artar', () => {
  const low = score({ undoUsed: 3, telemetry: tel([], { spent: 1000, massKg: 40000 }) });
  const high = score({ telemetry: tel([], { spent: 0, massKg: 10000 }), timeLeftSec: 300 });
  assert.equal(low.stars, 1);
  assert.equal(high.stars, 3);
});

// ---------- missions.json + gerçek physics ----------

test('missions.json: her kartta parMassKg sayı', () => {
  for (const m of missions) assert.ok(Number.isFinite(m.parMassKg) && m.parMassKg > 0, m.id);
});

// test/physics.test.js'teki yerleşimli sabit çözümler (kopya).
const R = (partId, slotId) => ({ role: 'rocket', partId, slotId });
const S = (partId, slotId) => ({ role: 'spacecraft', partId, slotId });
const Y = (partId, slotId) => ({ role: 'payload', partId, slotId });
const SOLUTIONS = {
  'lunar-relay': [
    { frameId: 'frame-swift', placements: [R('engine-kestrel', 'eng-1'), R('tank-large', 'tank-1'), R('fuel-methalox', 'fuel'),
      S('structure-frame', 'svc-1'), S('solar-small', 's2-e1'), S('solar-small', 's2-e2'), S('shield-light', 's1-s'), Y('relay-antenna', 's1-n')] },
    { frameId: 'frame-cargo', placements: [R('engine-kestrel', 'eng-c'), R('tank-large', 'tank-1'), R('fuel-hydrolox', 'fuel'),
      S('structure-frame', 'svc-1'), S('solar-small', 'p-n1'), S('solar-small', 'p-n2'), S('shield-light', 's1-w'), Y('relay-antenna', 's1-e')] },
  ],
  'mars-rover': [
    { frameId: 'frame-cargo', placements: [R('engine-heron', 'eng-c'), R('engine-kestrel', 'eng-e'), R('engine-kestrel', 'eng-w'),
      R('tank-large', 'tank-1'), R('tank-large', 'tank-2'), R('tank-large', 'tank-3'), R('fuel-hydrolox', 'fuel'),
      S('structure-frame', 'svc-1'), S('solar-large', 's1-w'), S('shield-heavy', 's1-e'),
      Y('rover', 'pl-1'), Y('drill', 'nose-1'), Y('camera', 'p-n1')] },
    { frameId: 'frame-heavy', placements: [R('engine-heron', 'eng-c'), R('engine-kestrel', 'eng-n'), R('engine-kestrel', 'bst-e-eng'),
      R('engine-kestrel', 'bst-w-eng'), R('tank-large', 'tank-1'), R('tank-large', 'tank-2'), R('tank-large', 'tank-3'),
      R('tank-large', 'bst-e-tank'), R('fuel-hydrolox', 'fuel'),
      S('structure-frame', 'svc-1'), S('solar-large', 's2-e'), S('shield-heavy', 's1-n'), S('shield-light', 's2-n'),
      Y('rover', 'pl-1'), Y('drill', 'svc-2'), Y('camera', 's1-s')] },
  ],
  'asteroid-sample': [
    { frameId: 'frame-cargo', placements: [R('engine-heron', 'eng-c'), R('engine-kestrel', 'eng-e'), R('tank-large', 'tank-1'),
      R('tank-small', 'tank-2'), R('tank-small', 'tank-3'), R('fuel-hydrolox', 'fuel'),
      S('structure-frame', 'svc-1'), S('solar-small', 'p-e'), S('shield-light', 's1-e'), S('shield-light', 'p-n1'),
      Y('sample-capsule', 'pl-1'), Y('camera', 's1-w'), Y('spectrometer', 'p-n2')] },
    { frameId: 'frame-heavy', placements: [R('engine-kestrel', 'eng-c'), R('engine-kestrel', 'eng-n'), R('tank-large', 'tank-1'),
      R('tank-large', 'tank-2'), R('tank-small', 'tank-3'), R('fuel-hydrolox', 'fuel'),
      S('structure-frame', 'svc-1'), S('solar-small', 's2-n'), S('shield-heavy', 's1-n'),
      Y('sample-capsule', 'pl-1'), Y('camera', 's1-s'), Y('spectrometer', 's2-e')] },
  ],
};

const framesData = require('../data/frames.json');
const { createLayout } = require('../server/layout.js');

test('gerçek physics + gövde: her görevin sabit çözümleri success ve >= 1 yıldız', () => {
  const phys = createPhysics(catalog);
  const layout = createLayout({ framesData, physics: phys });
  for (const m of missions) {
    const sols = SOLUTIONS[m.id];
    assert.ok(sols, m.id);
    let best = 0;
    for (const sol of sols) {
      const build = { rocket: [], spacecraft: [], payload: [] };
      sol.placements.forEach((pl, i) => {
        assert.equal(layout.canPlace(build, sol.frameId, pl.role, pl.partId, pl.slotId).ok, true, pl.partId + '@' + pl.slotId);
        build[pl.role].push({ uid: 'u' + i, partId: pl.partId, slotId: pl.slotId });
      });
      const t = phys.computeTelemetry(build, m, layout.getFrame(sol.frameId));
      const r = resolveLaunch(t, m);
      assert.equal(r.outcome, 'success', `${m.id} ${sol.frameId}: ${r.reasonText}`);
      const sc = computeScore({ success: r.success, mission: m, telemetry: t, undoUsed: 0, timeLeftSec: null });
      assert.ok(sc.stars >= 1, m.id);
      best = Math.max(best, pts(sc, 'mass'));
    }
    assert.equal(best, 300, `${m.id}: iyi çözüm par altında olmalı`);
  }
  // boş build ile fırlatma: kalkamaz (gövdeli de gövdesiz de)
  const empty = phys.computeTelemetry({ rocket: [], spacecraft: [], payload: [] }, missions[0]);
  assert.equal(resolveLaunch(empty, missions[0]).outcome, 'no-liftoff');
  const emptyF = phys.computeTelemetry({ rocket: [], spacecraft: [], payload: [] }, missions[0], framesData.frames[0]);
  assert.equal(resolveLaunch(emptyF, missions[0]).outcome, 'no-liftoff');
});
