'use strict';
// Aşama 5 birim testleri: setup fazı (gövde seçimi), yuvalı yerleşim, geri alma, görünümler ve gizlilik.
// SAHTE saat / physics / layout / launch / score kullanır (Modül Q'ya bağımlı değil).
// Çalıştır: node --test test/stage5.test.js

const test = require('node:test');
const assert = require('node:assert');

const { PHASES, GameError } = require('../server/constants');
const { createRoomManager } = require('../server/rooms');
const { viewFor } = require('../server/filter');

const T0 = 10_000_000;
const ROLES3 = ['rocket', 'spacecraft', 'payload'];

// ---------------- Sahte katalog (ayırt edici sayılar) ----------------
function mk(id, role, category, name, icon, model, cost, massKg, extra = {}) {
  return {
    id, role, category, name, icon, model, desc: `${name} açıklaması`, tags: [],
    massKg, cost, powerGenW: 0, powerUseW: 0, thrustKN: 0, isp: 0, heat: 0, heatShield: 0,
    fuelKg: 0, ispMult: 1, max: 2, requires: [], ...extra,
  };
}
const PARTS = [
  mk('eng', 'rocket', 'engine', 'Kerkenez Motoru', 'E', 'engine', 3331, 7771),
  mk('xtank', 'rocket', 'tank', 'Ek Tank', 'T', 'tank', 3332, 7772),
  mk('panel', 'spacecraft', 'solar', 'Güneş Paneli', 'P', 'panel', 3333, 7773, { tags: ['needs-sun'] }),
  mk('shield', 'spacecraft', 'shield', 'Isı Kalkanı', 'S', 'shield', 3334, 7774, { tags: ['ablative'] }),
  mk('bat', 'spacecraft', 'battery', 'Batarya', 'B', 'battery', 3335, 7775),
  mk('comp', 'spacecraft', 'computer', 'Yedek Bilgisayar', 'C', 'box', 3336, 7776),
  mk('cam', 'payload', 'instrument', 'Kamera', 'K', 'camera', 3337, 7777, { max: 1 }),
];
const PART_NUMS = PARTS.flatMap((p) => [String(p.cost), String(p.massKg)]);

const MISSION = {
  id: 'gorev-gizli', title: 'GIZLI-BASLIK', target: 'GIZLI-HEDEF', requiredDeltaV: 4321, requiredInstruments: ['cam'],
  budget: 9991, durationSec: 300, nasaFact: 'GIZLI-FACT', nasaReal: 'GIZLI-REAL', parMassKg: 8123,
};
const MISSION_B = { ...MISSION, id: 'gorev-gizli-b', title: 'GIZLI-BASLIK-B' };

// ---------------- Sahte gövdeler ----------------
function slot(id, name, segment, face, kind, accepts, neighbors = []) {
  return { id, name, zone: 'bolge', segment, face, kind, accepts, pos: [0, 1, 0], normal: [0, 0, 1], neighbors };
}
const FRAMES = [
  {
    id: 'govde-ince', name: 'İnce Gövde', desc: 'Hafif ve az yuvalı', massKg: 6661, cost: 5553,
    shape: { segments: [{ id: 'k1', name: 'Birinci kademe', y0: 0, y1: 4, radius: 1.2 }], nose: { y0: 9, y1: 11.5, radius: 1 },
      fins: 4, boosters: 0, massKg: 6661, gizli: { cost: 5553 } },
    slots: [
      slot('eng-c', 'Merkez motor yuvası', 'k1', 'C', 'mount', ['engine']),
      slot('tank-a', 'Paylaşılan bölme', 'k1', 'C', 'internal', ['tank', 'battery']),
      slot('bay-a', 'Faydalı yük bölmesi', 'k2', 'C', 'internal', ['instrument', 'computer']),
      slot('srf-n', 'Kuzey yüzey', 'k2', 'N', 'surface', ['solar', 'shield']),
      slot('srf-n2', 'Kuzey üst yüzey', 'k2', 'N', 'surface', ['solar', 'shield']),
      slot('srf-e', 'Doğu yüzey', 'k2', 'E', 'surface', ['solar', 'shield']),
    ],
  },
  {
    id: 'govde-agir', name: 'Ağır Gövde', desc: 'Yan iticili, pahalı', massKg: 6662, cost: 5554,
    shape: { segments: [{ id: 'k1', name: 'Ana kademe', y0: 0, y1: 6, radius: 2 }], nose: null, fins: 0, boosters: 2 },
    slots: [
      slot('eng-c', 'Ana motor yuvası', 'k1', 'C', 'mount', ['engine']),
      slot('bay-a', 'Geniş bölme', 'k1', 'C', 'internal', ['instrument', 'computer', 'tank', 'battery']),
    ],
  },
];
const RULES = [
  { id: 'shield-vs-solar', a: { tag: 'ablative' }, b: { tag: 'needs-sun' }, scope: 'same-face',
    reason: 'Isı kalkanı yüzeyi kaplar; altındaki panel güneş ışığı alamaz.' },
];

function fakePhysics() {
  const byId = new Map(PARTS.map((p) => [p.id, p]));
  const calls = { frames: [] };
  return {
    calls,
    getPart: (id) => byId.get(id),
    fullCatalog: () => {
      const out = { rocket: [], spacecraft: [], payload: [] };
      for (const p of PARTS) out[p.role].push(structuredClone(p));
      return out;
    },
    // kasıtlı olarak fiyat/kütle de döndürür: filtre beyaz liste uygulamalı
    publicCatalog: (role) => PARTS.filter((p) => p.role === role).map((p) => ({ ...p })),
    canAdd: (build, role, partId) => {
      const p = byId.get(partId);
      if (!p) return { ok: false, error: 'INVALID_PART' };
      if (p.role !== role) return { ok: false, error: 'NOT_ALLOWED' };
      if (build[role].filter((it) => it.partId === partId).length >= p.max) return { ok: false, error: 'PART_LIMIT' };
      return { ok: true };
    },
    computeTelemetry: (build, mission, frame) => {
      calls.frames.push(frame);
      const items = ROLES3.flatMap((r) => build[r]);
      const spent = items.reduce((s, it) => s + byId.get(it.partId).cost, 0) + (frame ? frame.cost : 0);
      return {
        massKg: 1_234_567, deltaV: mission ? 4444 : 0, spent, parts: items.length,
        frameMassKg: frame ? frame.massKg : 0, frameCost: frame ? frame.cost : 0,
        checks: { twr: items.length > 0, deltaV: true, power: true, payload: true, heat: true },
        missing: [], overBudget: false, ready: items.length > 0,
      };
    },
    partStatuses: () => ({}),
  };
}

// PLAN Aşama 5 "Yerleşim modülü" arayüzünü taklit eden sahte layout
function fakeLayout(physics) {
  const byId = new Map(FRAMES.map((f) => [f.id, f]));
  const where = (build, slotId) => {
    for (const r of ROLES3) for (const it of build[r]) if (it.slotId === slotId) return it;
    return null;
  };
  const match = (sel, part) => (sel.tag ? (part.tags || []).includes(sel.tag) : sel.category ? part.category === sel.category : part.id === sel.partId);
  const canPlace = (build, frameId, role, partId, slotId) => {
    const c = physics.canAdd(build, role, partId);
    if (!c.ok) return { ok: false, error: c.error, reason: 'Bu parça takılamaz' };
    const f = byId.get(frameId);
    const s = f && f.slots.find((x) => x.id === slotId);
    if (!s) return { ok: false, error: 'INVALID_SLOT', reason: 'Böyle bir yuva yok' };
    if (where(build, slotId)) return { ok: false, error: 'SLOT_TAKEN', reason: 'Bu yuva dolu' };
    const part = physics.getPart(partId);
    if (!s.accepts.includes(part.category)) return { ok: false, error: 'SLOT_MISMATCH', reason: 'Bu yuva bu parçayı kabul etmez' };
    for (const other of f.slots) {
      const it = other.id !== s.id && where(build, other.id);
      if (!it || other.segment !== s.segment || other.face !== s.face) continue;
      const op = physics.getPart(it.partId);
      for (const r of RULES) {
        if ((match(r.a, part) && match(r.b, op)) || (match(r.b, part) && match(r.a, op))) {
          return { ok: false, error: 'PART_CONFLICT', reason: r.reason };
        }
      }
    }
    return { ok: true };
  };
  return {
    listFrames: () => structuredClone(FRAMES),
    getFrame: (id) => byId.get(id),
    // kasıtlı olarak massKg/cost ve fazladan alan da döndürür: filtre beyaz liste uygulamalı
    publicFrame: (id) => (byId.has(id) ? { ...structuredClone(byId.get(id)), secret: 'SIZINTI' } : undefined),
    publicFrameOptions: () => FRAMES.map((f) => ({ ...structuredClone(f), secret: 'SIZINTI' })),
    canPlace,
    slotOptions: (build, frameId, role, partId) => {
      const f = byId.get(frameId);
      const part = physics.getPart(partId);
      if (!f || !part) return [];
      return f.slots.filter((s) => s.accepts.includes(part.category))
        .map((s) => ({ slotId: s.id, ...canPlace(build, frameId, role, partId, s.id) }));
    },
    // hiçbir yuvanın kategorisini kabul etmediği parçalar (boş build varsayımı)
    unfitParts: (frameId, partIds) => {
      const f = byId.get(frameId);
      if (!f) return [];
      return partIds.filter((id) => {
        const part = physics.getPart(id);
        return !part || !f.slots.some((s) => s.accepts.includes(part.category));
      });
    },
    slotName: (frameId, slotId) => {
      const f = byId.get(frameId);
      const s = f && f.slots.find((x) => x.id === slotId);
      return s ? s.name : slotId;
    },
  };
}

const fakeLaunch = () => (telemetry) => {
  const failed = Object.keys(telemetry.checks).filter((k) => !telemetry.checks[k]);
  return { success: !failed.length, outcome: failed.length ? 'no-liftoff' : 'success', title: 'Sonuç', reasonText: 'r', failedChecks: failed };
};
const fakeScore = () => () => ({ total: 1, stars: 1, breakdown: [] });

function throwsCode(fn, code, message) {
  assert.throws(fn, (err) => err instanceof GameError && err.code === code && err.message.length > 0
    && (message === undefined || err.message === message), `beklenen hata: ${code}`);
}

// p[0]=director, p[1]=rocket, p[2]=spacecraft, p[3]=payload. Varsayılan: setup fazında bırakır.
function setup({ config = { events: [], telemetryDelayMs: 0 }, missions = [MISSION], frameId = null } = {}) {
  const clock = { t: T0 };
  const physics = fakePhysics();
  const layout = fakeLayout(physics);
  const m = createRoomManager({
    missions, physics, layout, resolveLaunch: fakeLaunch(), computeScore: fakeScore(),
    rng: () => 0, now: () => clock.t, config,
  });
  const { room, player: p0 } = m.createRoom('Ayşe');
  const p = [p0, m.joinRoom(room.code, 'Bora').player, m.joinRoom(room.code, 'Cem').player, m.joinRoom(room.code, 'Deniz').player];
  ['director', 'rocket', 'spacecraft', 'payload'].forEach((r, i) => m.selectRole(room.code, p[i].id, r));
  if (frameId) m.selectFrame(room.code, p[0].id, frameId);
  const at = (sec) => { clock.t = T0 + sec * 1000; return m.tick(room.code); };
  const view = (i) => viewFor(room, p[i].id, physics, layout);
  return { m, room, p, physics, layout, clock, code: room.code, at, view };
}
const lastLog = (room) => room.log[room.log.length - 1];

// Çalışan JSON'u: kendi id/uid'leri maskelenir (rastgele hex rakam eşleşmesi olmasın)
function workerJson(s, i) {
  const v = s.view(i);
  let json = JSON.stringify(v).split(s.p[i].id).join('<ME>');
  const role = s.p[i].role;
  if (s.room.build[role]) for (const it of s.room.build[role]) json = json.split(it.uid).join('<UID>');
  return { v, json };
}
const WORKER_FORBIDDEN_KEYS = ['mission', 'telemetry', 'telemetryDelayMs', 'log', 'undoLeft', 'undo', 'build', 'result',
  'locks', 'pendingEvents', 'frames', 'frameInfo', 'budget'];
function assertWorkerClean(s, i) {
  const { v, json } = workerJson(s, i);
  for (const k of WORKER_FORBIDDEN_KEYS) assert.ok(!(k in v), `${k} anahtarı var`);
  for (const f of ['massKg', 'cost', 'thrustKN', 'max', 'requires', 'tags', 'error', 'secret', 'playerId', 'neighbors']) {
    assert.ok(!json.includes(`"${f}"`), `${f} alanı sızdı`);
  }
  // başka rollerin uid'leri hiç görünmez (kendi myParts uid'leri maskelendi)
  for (const r of ROLES3) {
    if (r !== s.p[i].role) for (const it of s.room.build[r]) assert.ok(!json.includes(it.uid), 'başka rolün uid sızdı');
  }
  for (const n of [...PART_NUMS, '6661', '6662', '5553', '5554', '9991', '4321', '4444', '8123', '1234567']) {
    assert.ok(!json.includes(n), `sayı sızdı: ${n}`);
  }
  for (const x of ['GIZLI', 'gorev-gizli', 'budget', 'checks', 'SIZINTI', 'SLOT_TAKEN', 'PART_CONFLICT', 'SLOT_MISMATCH']) {
    assert.ok(!json.includes(x), `sızdı: ${x}`);
  }
  for (const o of s.p) if (o.id !== s.p[i].id) assert.ok(!json.includes(o.id), 'başka oyuncunun playerId sızdı');
  return v;
}

// ---------------- Kurulum / setup fazı ----------------

test('layout zorunlu; PHASES.SETUP', () => {
  const physics = fakePhysics();
  assert.throws(() => createRoomManager({ missions: [MISSION], physics, resolveLaunch: fakeLaunch(), computeScore: fakeScore() }), TypeError);
  assert.strictEqual(PHASES.SETUP, 'setup');
  const m = createRoomManager({ missions: [MISSION], physics, layout: fakeLayout(physics), resolveLaunch: fakeLaunch(), computeScore: fakeScore() });
  assert.strictEqual(m.createRoom('A').room.frameId, null);
});

test('4 rol dolunca setup: görev var, gövde/sayaç/olay planı yok, tick boş', () => {
  const s = setup({ config: { events: [{ type: 'weather', atSec: 1 }], telemetryDelayMs: 0 } });
  const { room } = s;
  assert.strictEqual(room.phase, 'setup');
  assert.strictEqual(room.frameId, null);
  assert.deepStrictEqual(room.mission, MISSION);
  assert.strictEqual(room.timer, null);
  assert.deepStrictEqual(room.pendingEvents, []);
  assert.strictEqual(lastLog(room).text, 'Oyun başladı');
  assert.strictEqual(s.physics.calls.frames.length, 0);
  assert.strictEqual(s.at(5000), false);
  assert.strictEqual(room.phase, 'setup');
  assert.deepStrictEqual(room.events, []);
});

test('setup hataları: parça/anket/geri alma/oy WRONG_PHASE; selectFrame yetki ve geçersiz gövde', () => {
  const s = setup();
  const { m, code, p } = s;
  throwsCode(() => m.addPart(code, p[1].id, 'eng', 'eng-c'), 'WRONG_PHASE');
  throwsCode(() => m.removePart(code, p[1].id, 'x'), 'WRONG_PHASE');
  throwsCode(() => m.startPoll(code, p[0].id), 'WRONG_PHASE');
  throwsCode(() => m.undo(code, p[0].id, 'rocket'), 'WRONG_PHASE');
  throwsCode(() => m.vote(code, p[1].id, 'go'), 'WRONG_PHASE');
  throwsCode(() => m.restart(code, p[0].id), 'WRONG_PHASE');
  for (const i of [1, 2, 3]) throwsCode(() => m.selectFrame(code, p[i].id, 'govde-ince'), 'NOT_ALLOWED');
  throwsCode(() => m.selectFrame(code, 'yabanci', 'govde-ince'), 'NOT_IN_ROOM');
  for (const bad of ['yok-boyle', undefined, null, 7, '', {}]) throwsCode(() => m.selectFrame(code, p[0].id, bad), 'INVALID_FRAME');
  assert.strictEqual(s.room.phase, 'setup');
  // lobide selectFrame
  const physics = fakePhysics();
  const m2 = createRoomManager({ missions: [MISSION], physics, layout: fakeLayout(physics), resolveLaunch: fakeLaunch(), computeScore: fakeScore() });
  const { room: r2, player } = m2.createRoom('X');
  m2.selectRole(r2.code, player.id, 'director');
  throwsCode(() => m2.selectFrame(r2.code, player.id, 'govde-ince'), 'WRONG_PHASE');
});

test('selectFrame: building, sayaç + olay planı bu an başlar, telemetri gövdeyle, log', () => {
  const s = setup({ config: { events: [{ type: 'weather', atSec: 10 }], telemetryDelayMs: 0 } });
  const { m, code, p, room } = s;
  s.clock.t = T0 + 50_000;
  assert.strictEqual(m.selectFrame(code, p[0].id, 'govde-ince'), room);
  assert.strictEqual(room.phase, 'building');
  assert.strictEqual(room.frameId, 'govde-ince');
  assert.deepStrictEqual(room.timer, { window: 1, endsAt: T0 + 50_000 + 300_000 });
  assert.deepStrictEqual(room.pendingEvents, [{ type: 'weather', at: T0 + 60_000 }]);
  assert.strictEqual(s.physics.calls.frames.length, 1);
  assert.strictEqual(s.physics.calls.frames[0], FRAMES[0]); // computeTelemetry(build, mission, frame)
  assert.strictEqual(room.telemetry.frameCost, 5553);
  assert.strictEqual(room.telemetryShown.spent, 5553);
  const l = lastLog(room);
  assert.strictEqual(l.kind, 'system');
  assert.strictEqual(l.text, 'Yönetici gövdeyi seçti: İnce Gövde');
  throwsCode(() => m.selectFrame(code, p[0].id, 'govde-agir'), 'WRONG_PHASE'); // gövde tur boyunca değişmez
  throwsCode(() => m.selectFrame(code, p[1].id, 'govde-agir'), 'NOT_ALLOWED');
  assert.strictEqual(s.at(59.9), false);
  assert.strictEqual(s.at(60), true);
  assert.strictEqual(room.events[0].type, 'weather');
});

// ---------------- Yuvalı yerleşim ----------------

test('addPart: yuvaya takma, telemetri, log metni ve cost', () => {
  const s = setup({ frameId: 'govde-ince' });
  const { m, code, p, room } = s;
  assert.strictEqual(m.addPart(code, p[1].id, 'eng', 'eng-c'), room);
  const it = room.build.rocket[0];
  assert.deepStrictEqual(Object.keys(it).sort(), ['partId', 'slotId', 'uid']);
  assert.strictEqual(it.slotId, 'eng-c');
  assert.deepStrictEqual(room.lastMove.rocket, { type: 'add', uid: it.uid, partId: 'eng', slotId: 'eng-c' });
  assert.strictEqual(room.telemetry.spent, 5553 + 3331);
  assert.strictEqual(s.physics.calls.frames.at(-1), FRAMES[0]);
  let l = lastLog(room);
  assert.strictEqual(l.kind, 'part');
  assert.strictEqual(l.role, 'rocket');
  assert.strictEqual(l.text, 'Roket & Yakıt: Kerkenez Motoru → Merkez motor yuvası');
  assert.strictEqual(l.cost, 3331);
  m.removePart(code, p[1].id, it.uid);
  l = lastLog(room);
  assert.strictEqual(l.text, 'Roket & Yakıt: Kerkenez Motoru çıkardı (Merkez motor yuvası)');
  assert.strictEqual(l.cost, -3331);
  assert.deepStrictEqual(room.lastMove.rocket, { type: 'remove', uid: it.uid, partId: 'eng', slotId: 'eng-c' });
  for (const e of room.log) assert.ok(!/\d/.test(e.text), `log metninde sayı: ${e.text}`);
});

test('addPart hata yolları: INVALID_SLOT, SLOT_TAKEN (başka rol dahil), SLOT_MISMATCH, PART_CONFLICT, PART_LOCKED', () => {
  const s = setup({ frameId: 'govde-ince', config: { events: [{ type: 'supplier-delay', atSec: 5 }], telemetryDelayMs: 0 } });
  const { m, code, p, room } = s;
  // INVALID_SLOT
  throwsCode(() => m.addPart(code, p[1].id, 'eng', 'yok-yuva'), 'INVALID_SLOT', 'Böyle bir yuva yok');
  for (const bad of [undefined, null, '', 5]) throwsCode(() => m.addPart(code, p[1].id, 'eng', bad), 'INVALID_SLOT');
  // INVALID_PART / NOT_ALLOWED / PART_LIMIT layout üzerinden
  throwsCode(() => m.addPart(code, p[1].id, 'yok-parca', 'eng-c'), 'INVALID_PART');
  throwsCode(() => m.addPart(code, p[1].id, 'panel', 'srf-n'), 'NOT_ALLOWED');
  throwsCode(() => m.addPart(code, p[0].id, 'eng', 'eng-c'), 'NOT_ALLOWED'); // yönetici
  // SLOT_MISMATCH: motor faydalı yük bölmesine girmez
  throwsCode(() => m.addPart(code, p[1].id, 'eng', 'bay-a'), 'SLOT_MISMATCH', 'Bu yuva bu parçayı kabul etmez');
  // SLOT_TAKEN: kendi parçası
  m.addPart(code, p[1].id, 'eng', 'eng-c');
  throwsCode(() => m.addPart(code, p[1].id, 'eng', 'eng-c'), 'SLOT_TAKEN', 'Bu yuva dolu');
  // SLOT_TAKEN: paylaşılan bölmeyi roket aldı, uzay aracı bataryasını koyamaz
  m.addPart(code, p[1].id, 'xtank', 'tank-a');
  throwsCode(() => m.addPart(code, p[2].id, 'bat', 'tank-a'), 'SLOT_TAKEN');
  // paylaşılan iç bölme: uzay aracı bilgisayarı aldı, faydalı yük kamerası koyamaz
  m.addPart(code, p[2].id, 'comp', 'bay-a');
  throwsCode(() => m.addPart(code, p[3].id, 'cam', 'bay-a'), 'SLOT_TAKEN');
  // PART_CONFLICT: aynı yüzde kalkan ↔ panel; message = kuralın gerekçesi
  m.addPart(code, p[2].id, 'panel', 'srf-n');
  throwsCode(() => m.addPart(code, p[2].id, 'shield', 'srf-n2'), 'PART_CONFLICT', RULES[0].reason);
  m.addPart(code, p[2].id, 'shield', 'srf-e'); // farklı yüz serbest
  const before = structuredClone(room.build);
  // PART_LOCKED (supplier-delay: takılı olmayan ilk aday 'bat')
  s.at(5);
  assert.ok(room.locks.bat > s.clock.t);
  throwsCode(() => m.addPart(code, p[2].id, 'bat', 'tank-a'), 'PART_LOCKED');
  assert.deepStrictEqual(room.build, before, 'hatalı denemeler build\'i değiştirmemeli');
});

test('poll fazında yerleşim kilitli', () => {
  const s = setup({ frameId: 'govde-ince' });
  s.m.addPart(s.code, s.p[1].id, 'eng', 'eng-c');
  s.m.startPoll(s.code, s.p[0].id);
  throwsCode(() => s.m.addPart(s.code, s.p[1].id, 'xtank', 'tank-a'), 'WRONG_PHASE');
  throwsCode(() => s.m.removePart(s.code, s.p[1].id, s.room.build.rocket[0].uid), 'WRONG_PHASE');
});

// ---------------- Geri alma ----------------

test('undo: remove geri alınınca aynı yuvaya; yuva doluysa SLOT_TAKEN ve hak düşmez', () => {
  const s = setup({ frameId: 'govde-ince' });
  const { m, code, p, room } = s;
  m.addPart(code, p[1].id, 'xtank', 'tank-a');
  const uid = room.build.rocket[0].uid;
  m.removePart(code, p[1].id, uid);
  // başka rol aynı paylaşılan yuvayı kaptı
  m.addPart(code, p[2].id, 'bat', 'tank-a');
  throwsCode(() => m.undo(code, p[0].id, 'rocket'), 'SLOT_TAKEN');
  assert.strictEqual(room.undoLeft, 3);
  assert.strictEqual(room.undoUsed, 0);
  assert.deepStrictEqual(room.lastMove.rocket, { type: 'remove', uid, partId: 'xtank', slotId: 'tank-a' });
  assert.deepStrictEqual(room.build.rocket, []);
  // yuva boşalınca geri alma çalışır, aynı yuvaya yeni uid ile takılır
  m.removePart(code, p[2].id, room.build.spacecraft[0].uid);
  m.undo(code, p[0].id, 'rocket');
  assert.strictEqual(room.build.rocket.length, 1);
  assert.strictEqual(room.build.rocket[0].slotId, 'tank-a');
  assert.strictEqual(room.build.rocket[0].partId, 'xtank');
  assert.notStrictEqual(room.build.rocket[0].uid, uid);
  assert.strictEqual(room.undoLeft, 2);
  let l = lastLog(room);
  assert.strictEqual(l.kind, 'undo');
  assert.strictEqual(l.text, 'Yönetici, Roket & Yakıt son hamlesini geri aldı: Ek Tank geri takıldı');
  assert.strictEqual(l.cost, 3332);
  // add geri alınınca çıkarılır, cost negatif
  m.addPart(code, p[1].id, 'eng', 'eng-c');
  m.undo(code, p[0].id, 'rocket');
  l = lastLog(room);
  assert.strictEqual(l.text, 'Yönetici, Roket & Yakıt son hamlesini geri aldı: Kerkenez Motoru çıkarıldı');
  assert.strictEqual(l.cost, -3331);
  assert.ok(!room.build.rocket.some((it) => it.slotId === 'eng-c'));
});

// ---------------- Restart ----------------

test('restart → setup: gövde sıfır, yeni görev, Aşama 4 durumu sıfır; başka gövde seçilebilir', () => {
  const s = setup({ frameId: 'govde-ince', missions: [MISSION, MISSION_B], config: { events: [{ type: 'computer-fault', atSec: 1 }], telemetryDelayMs: 0 } });
  const { m, code, p, room } = s;
  m.addPart(code, p[1].id, 'eng', 'eng-c');
  s.at(1);
  m.startPoll(code, p[0].id);
  for (const i of [1, 2, 3]) m.vote(code, p[i].id, 'go');
  assert.strictEqual(room.phase, 'result');
  assert.deepStrictEqual(room.result.frame, { name: 'İnce Gövde' });
  assert.deepStrictEqual(room.result.build.rocket, [{ name: 'Kerkenez Motoru', icon: 'E', slotName: 'Merkez motor yuvası' }]);
  m.restart(code, p[0].id);
  assert.strictEqual(room.phase, 'setup');
  assert.strictEqual(room.frameId, null);
  assert.strictEqual(room.mission.id, 'gorev-gizli-b');
  assert.strictEqual(room.timer, null);
  assert.deepStrictEqual(room.pendingEvents, []);
  assert.deepStrictEqual(room.events, []);
  assert.strictEqual(room.needBackupComputer, false);
  assert.deepStrictEqual(room.build, { rocket: [], spacecraft: [], payload: [] });
  assert.strictEqual(room.result, null);
  assert.strictEqual(room.undoLeft, 3);
  assert.deepStrictEqual(room.log.map((e) => e.text), ['Yeni tur başladı']);
  m.selectFrame(code, p[0].id, 'govde-agir');
  assert.strictEqual(room.phase, 'building');
  assert.strictEqual(room.telemetry.frameCost, 5554);
  m.addPart(code, p[1].id, 'xtank', 'bay-a');
  assert.strictEqual(room.build.rocket[0].slotId, 'bay-a');
});

// ---------------- Görünümler ----------------

test('görünüm setup: yönetici (görev + sayılı gövdeler) ve çalışan (sayısız seçenekler)', () => {
  const s = setup();
  const d = s.view(0);
  assert.deepStrictEqual(Object.keys(d).sort(), ['catalog', 'code', 'frameOptions', 'frames', 'mission', 'phase', 'players', 'roles', 'undoLeft', 'you']);
  assert.deepStrictEqual(d.mission, MISSION);
  assert.deepStrictEqual(d.frames, FRAMES.map((f) => ({ ...f, unfit: [] })));
  assert.deepStrictEqual(d.catalog, s.physics.fullCatalog());
  assert.notStrictEqual(d.frames[0], FRAMES[0]);
  assert.strictEqual(d.frames[0].massKg, 6661);
  assert.strictEqual(d.undoLeft, 3);
  for (const o of d.frameOptions) assert.deepStrictEqual(Object.keys(o).sort(), ['desc', 'id', 'name', 'shape']);
  assert.deepStrictEqual(d.frameOptions.map((o) => o.id), ['govde-ince', 'govde-agir']);
  // shape içindeki fiyat/kütle anahtarları her derinlikte atılır; geometri kalır
  assert.deepStrictEqual(d.frameOptions[0].shape, {
    segments: [{ id: 'k1', name: 'Birinci kademe', y0: 0, y1: 4, radius: 1.2 }], nose: { y0: 9, y1: 11.5, radius: 1 },
    fins: 4, boosters: 0, gizli: {},
  });
  const dj = JSON.stringify(d);
  for (const o of s.p.slice(1)) assert.ok(!dj.includes(o.id));
  for (const i of [1, 2, 3]) {
    const v = assertWorkerClean(s, i);
    assert.deepStrictEqual(Object.keys(v).sort(), ['code', 'frameOptions', 'missionLabel', 'phase', 'players', 'roles', 'you']);
    assert.strictEqual(v.missionLabel, 'GİZLİ');
    assert.deepStrictEqual(v.frameOptions, d.frameOptions);
  }
  // rolsüz oyuncu da yalnız seçenek + etiket alır
  s.room.players[s.p[3].id].role = null;
  assert.deepStrictEqual(Object.keys(s.view(3)).sort(), ['code', 'frameOptions', 'missionLabel', 'phase', 'players', 'roles', 'you']);
});

test('görünüm setup: frames[i].unfit (zorunlu aletlerden gövdeye sığmayanlar) + tam katalog yalnız yöneticide', () => {
  const s = setup();
  // panel (solar) ağır gövdede hiçbir yuvaya girmez; bilinmeyen id adı yerine id
  s.room.mission = { ...MISSION, requiredInstruments: ['cam', 'panel', 'yok-alet'] };
  const d = s.view(0);
  const byId = Object.fromEntries(d.frames.map((f) => [f.id, f]));
  assert.deepStrictEqual(byId['govde-ince'].unfit, [{ partId: 'yok-alet', name: 'yok-alet' }]);
  assert.deepStrictEqual(byId['govde-agir'].unfit, [
    { partId: 'panel', name: 'Güneş Paneli' }, { partId: 'yok-alet', name: 'yok-alet' }]);
  assert.strictEqual(d.catalog.payload[0].cost, 3337);
  assert.strictEqual(byId['govde-ince'].massKg, 6661);
  // çalışanlara unfit / catalog gitmez, frameOptions değişmez
  for (const i of [1, 2, 3]) {
    const { v, json } = workerJson(s, i);
    assert.ok(!('catalog' in v) && !('frames' in v));
    assert.ok(!json.includes('unfit') && !json.includes('Güneş Paneli') && !json.includes('yok-alet'));
    assert.deepStrictEqual(v.frameOptions, d.frameOptions);
    for (const o of v.frameOptions) assert.deepStrictEqual(Object.keys(o).sort(), ['desc', 'id', 'name', 'shape']);
  }
  // unfitParts olmayan (eski/sahte) layout: unfit [] ve çökme yok
  delete s.layout.unfitParts;
  for (const f of s.view(0).frames) assert.deepStrictEqual(f.unfit, []);
  // hata atan unfitParts da çökertmez
  s.layout.unfitParts = () => { throw new Error('boom'); };
  for (const f of s.view(0).frames) assert.deepStrictEqual(f.unfit, []);
});

test('GÜVENLİK: building/poll çalışan görünümünde unfit, requiredInstrumentNames ve sayılı katalog yok', () => {
  const s = setup({ frameId: 'govde-ince' });
  s.m.addPart(s.code, s.p[3].id, 'cam', 'bay-a');
  const check = () => {
    for (const i of [1, 2, 3]) {
      const { v, json } = workerJson(s, i);
      assert.ok(!json.includes('unfit') && !json.includes('requiredInstrumentNames'));
      if (v.catalog) assert.ok(Array.isArray(v.catalog) && v.catalog.every((c) => !('cost' in c) && !('massKg' in c)));
    }
  };
  check();
  s.m.startPoll(s.code, s.p[0].id);
  check();
});

const DIRECTOR_LIVE_KEYS = ['budget', 'build', 'catalog', 'code', 'events', 'frame', 'frameInfo', 'holdUntil', 'locks', 'log', 'mission',
  'phase', 'players', 'roles', 'slots', 'telemetry', 'telemetryDelayMs', 'timer', 'undo', 'undoLeft', 'you'];
const WORKER_LIVE_KEYS = ['catalog', 'code', 'events', 'feed', 'frame', 'holdUntil', 'missionLabel', 'myParts', 'others', 'phase',
  'players', 'roles', 'slots', 'timer', 'you'];

test('görünüm building/poll: yönetici alanları, bütçe (gecikmeli), log cost, frameInfo', () => {
  const s = setup({ frameId: 'govde-ince', config: { events: [], telemetryDelayMs: 2000 } });
  const { m, code, p, room } = s;
  m.addPart(code, p[1].id, 'eng', 'eng-c');
  m.addPart(code, p[2].id, 'panel', 'srf-n');
  let d = s.view(0);
  assert.deepStrictEqual(Object.keys(d).sort(), DIRECTOR_LIVE_KEYS);
  assert.deepStrictEqual(d.frameInfo, { id: 'govde-ince', name: 'İnce Gövde', massKg: 6661, cost: 5553 });
  // spent gecikmeli telemetriyle aynı
  assert.deepStrictEqual(d.budget, { total: 9991, spent: 5553, left: 9991 - 5553 });
  assert.strictEqual(d.budget.spent, d.telemetry.spent);
  s.at(2);
  d = s.view(0);
  assert.deepStrictEqual(d.budget, { total: 9991, spent: 5553 + 3331 + 3333, left: 9991 - (5553 + 3331 + 3333) });
  assert.deepStrictEqual(d.build.rocket, [{
    uid: room.build.rocket[0].uid, partId: 'eng', name: 'Kerkenez Motoru', icon: 'E', slotId: 'eng-c', slotName: 'Merkez motor yuvası', cost: 3331,
  }]);
  const partLogs = d.log.filter((e) => e.kind === 'part');
  assert.deepStrictEqual(partLogs.map((e) => e.cost), [3331, 3333]);
  for (const e of d.log) if (e.kind !== 'part') assert.ok(!('cost' in e));
  for (const e of d.log) assert.ok(!('playerId' in e));
  // yöneticide occupant.mine hep false; catalog tam (sayılı)
  assert.ok(d.slots.every((x) => !x.occupant || x.occupant.mine === false));
  assert.strictEqual(d.catalog.rocket[0].cost, 3331);
  m.startPoll(code, p[0].id);
  d = s.view(0);
  assert.deepStrictEqual(Object.keys(d).sort(), [...DIRECTOR_LIVE_KEYS, 'poll'].sort());
  const dj = JSON.stringify(d);
  for (const o of p.slice(1)) assert.ok(!dj.includes(o.id), 'yöneticiye başka playerId sızdı');
  assert.ok(!dj.includes('pendingEvents'));
});

test('görünüm building: frame (beyaz liste) ve slots (sıra, occupant, mine)', () => {
  const s = setup({ frameId: 'govde-ince' });
  const { m, code, p } = s;
  m.addPart(code, p[1].id, 'eng', 'eng-c');
  m.addPart(code, p[2].id, 'bat', 'tank-a');
  for (const i of [0, 1, 2, 3]) {
    const v = s.view(i);
    assert.deepStrictEqual(Object.keys(v.frame).sort(), ['desc', 'id', 'name', 'shape', 'slots']);
    assert.strictEqual(v.frame.id, 'govde-ince');
    for (const sl of v.frame.slots) {
      assert.deepStrictEqual(Object.keys(sl).sort(), ['accepts', 'face', 'id', 'kind', 'name', 'normal', 'pos', 'segment', 'zone']);
    }
    assert.ok(!('massKg' in v.frame.shape));
    // tüm yuvalar gövdedeki sırayla
    assert.deepStrictEqual(v.slots.map((x) => x.id), FRAMES[0].slots.map((x) => x.id));
    for (const x of v.slots) assert.deepStrictEqual(Object.keys(x).sort(), ['id', 'occupant']);
    const eng = v.slots[0].occupant;
    assert.deepStrictEqual(Object.keys(eng).sort(), ['icon', 'mine', 'model', 'name', 'role']);
    assert.deepStrictEqual(eng, { role: 'rocket', name: 'Kerkenez Motoru', icon: 'E', model: 'engine', mine: i === 1 });
    assert.deepStrictEqual(v.slots[1].occupant, { role: 'spacecraft', name: 'Batarya', icon: 'B', model: 'battery', mine: i === 2 });
    assert.ok(v.slots.slice(2).every((x) => x.occupant === null));
  }
});

test('görünüm building: çalışan kataloğu (model + yuva seçenekleri, error yok), myParts, kilit', () => {
  const s = setup({ frameId: 'govde-ince', config: { events: [{ type: 'supplier-delay', atSec: 5 }], telemetryDelayMs: 0 } });
  const { m, code, p } = s;
  m.addPart(code, p[1].id, 'eng', 'eng-c');
  m.addPart(code, p[1].id, 'xtank', 'tank-a');
  m.addPart(code, p[2].id, 'panel', 'srf-n');
  const w = s.view(2);
  assert.deepStrictEqual(Object.keys(w).sort(), WORKER_LIVE_KEYS);
  for (const c of w.catalog) assert.deepStrictEqual(Object.keys(c).sort(), ['category', 'desc', 'icon', 'id', 'locked', 'model', 'name', 'slots']);
  const byId = Object.fromEntries(w.catalog.map((c) => [c.id, c]));
  assert.strictEqual(byId.shield.model, 'shield');
  // kalkan: srf-n dolu, srf-n2 aynı yüzde panelle çakışır, srf-e serbest
  assert.deepStrictEqual(byId.shield.slots, [
    { slotId: 'srf-n', ok: false, reason: 'Bu yuva dolu' },
    { slotId: 'srf-n2', ok: false, reason: RULES[0].reason },
    { slotId: 'srf-e', ok: true },
  ]);
  // batarya: paylaşılan bölme roketin tankıyla dolu
  assert.deepStrictEqual(byId.bat.slots, [{ slotId: 'tank-a', ok: false, reason: 'Bu yuva dolu' }]);
  for (const c of w.catalog) for (const o of c.slots) assert.ok(!('error' in o));
  assert.deepStrictEqual(w.myParts, [{
    uid: s.room.build.spacecraft[0].uid, partId: 'panel', name: 'Güneş Paneli', icon: 'P', status: 'green', slotId: 'srf-n', slotName: 'Kuzey yüzey',
  }]);
  // kilitli parça: tüm yuvalar engelli + gerekçe; locked alanı kalır
  s.at(5);
  assert.ok(s.room.locks.shield || s.room.locks.bat || s.room.locks.comp || s.room.locks.cam);
  const lockedId = Object.keys(s.room.locks)[0];
  const role = s.physics.getPart(lockedId).role;
  const wi = { rocket: 1, spacecraft: 2, payload: 3 }[role];
  const lc = s.view(wi).catalog.find((c) => c.id === lockedId);
  assert.strictEqual(lc.locked, true);
  assert.ok(lc.slots.length > 0);
  for (const o of lc.slots) assert.deepStrictEqual(Object.keys(o).sort(), ['ok', 'reason', 'slotId']);
  assert.ok(lc.slots.every((o) => o.ok === false && o.reason === 'Tedarikçi gecikmesi: parça kilitli'));
  // feed'de cost yok
  assert.ok(w.feed.length > 0 && w.feed.every((e) => Object.keys(e).sort().join() === 'role,t,text'));
});

test('GÜVENLİK: çalışan görünümleri (setup/building/poll) sızıntı yok; poll\'da katalog görünür kalır', () => {
  const s = setup({ config: { events: [{ type: 'computer-fault', atSec: 2 }, { type: 'supplier-delay', atSec: 3 }], telemetryDelayMs: 2000 } });
  for (const i of [1, 2, 3]) assertWorkerClean(s, i);
  s.m.selectFrame(s.code, s.p[0].id, 'govde-ince');
  s.m.addPart(s.code, s.p[1].id, 'eng', 'eng-c');
  s.m.addPart(s.code, s.p[2].id, 'panel', 'srf-n');
  s.m.addPart(s.code, s.p[3].id, 'cam', 'bay-a');
  s.at(3);
  for (const i of [1, 2, 3]) {
    const v = assertWorkerClean(s, i);
    assert.deepStrictEqual(Object.keys(v).sort(), WORKER_LIVE_KEYS);
    for (const x of v.slots) if (x.occupant) assert.ok(!('uid' in x.occupant) && !('partId' in x.occupant) && !('playerId' in x.occupant));
  }
  s.m.startPoll(s.code, s.p[0].id);
  for (const i of [1, 2, 3]) {
    const v = assertWorkerClean(s, i);
    assert.deepStrictEqual(Object.keys(v).sort(), [...WORKER_LIVE_KEYS, 'poll'].sort());
    assert.ok(v.catalog.length > 0 && v.catalog.every((c) => Array.isArray(c.slots)));
  }
  // rolsüz çalışan
  s.room.players[s.p[3].id].role = null;
  const r = assertWorkerClean(s, 3);
  assert.ok(!('catalog' in r) && 'frame' in r && 'slots' in r);
});

test('görünüm result: frame adı ve build slotName herkese; diğer alanlar yok', () => {
  const s = setup({ frameId: 'govde-ince' });
  s.m.addPart(s.code, s.p[1].id, 'eng', 'eng-c');
  s.m.addPart(s.code, s.p[3].id, 'cam', 'bay-a');
  s.m.startPoll(s.code, s.p[0].id);
  for (const i of [1, 2, 3]) s.m.vote(s.code, s.p[i].id, 'go');
  const views = [0, 1, 2, 3].map((i) => s.view(i));
  for (const [i, v] of views.entries()) {
    assert.deepStrictEqual(Object.keys(v).sort(), ['code', 'phase', 'players', 'result', 'roles', 'you']);
    assert.deepStrictEqual(v.result, views[0].result);
    assert.deepStrictEqual(v.result.frame, { name: 'İnce Gövde' });
    // alet adları requiredInstruments ile aynı sırada
    assert.deepStrictEqual(v.result.mission.requiredInstruments, ['cam']);
    assert.deepStrictEqual(v.result.mission.requiredInstrumentNames, ['Kamera']);
    assert.deepStrictEqual(v.result.build, {
      rocket: [{ name: 'Kerkenez Motoru', icon: 'E', slotName: 'Merkez motor yuvası' }],
      spacecraft: [],
      payload: [{ name: 'Kamera', icon: 'K', slotName: 'Faydalı yük bölmesi' }],
    });
    const json = JSON.stringify(v).split(s.p[i].id).join('<ME>');
    for (const o of s.p) if (o.id !== s.p[i].id) assert.ok(!json.includes(o.id));
    assert.ok(!json.includes('"uid"') && !json.includes('"partId"') && !json.includes('"slotId"'));
  }
});
