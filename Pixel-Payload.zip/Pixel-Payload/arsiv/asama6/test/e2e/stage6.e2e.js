// Aşama 6 e2e. PW_DIR gerekli. ONLY=a,b ile senaryo seçimi. SHOT_DIR=ekran görüntüleri.
const L = require('./stage6.lib.js');
const { ok, sleep, issues } = L;
const ONLY = (process.env.ONLY || '').split(',').filter(Boolean);
const SC = {};
const scenario = (n, f) => { SC[n] = f; };
const digitsIn = (t) => /\d/.test(t);
const noClock = (t) => t.replace(/\d{1,2}:\d{2}/g, '');

const FORBID_KEYS = ['telemetry', 'mission', 'log', 'undo', 'undoLeft', 'build', 'locks', 'pendingEvents', 'frames', 'frameInfo', 'budget', 'cost', 'massKg', 'thrustKN', 'isp',
  'power', 'heat', 'fuelKg', 'ispMult', 'max', 'requires', 'tags', 'neighbors', 'acceptsTags', 'deltaV', 'dv', 'price', 'spent', 'parMass', 'targetMass'];
function walkKeys(o, out, path) {
  if (Array.isArray(o)) { o.forEach((x) => walkKeys(x, out, path)); return; }
  if (o && typeof o === 'object') for (const [k, v] of Object.entries(o)) { out.push(k); walkKeys(v, out, path); }
}
// ham çerçeveler: yalnız çalışan sayfaları. resultIdx'ten sonrası sonuç aşaması (burada bazı alanlar meşru).
function segFrames(w) {
  // segs: [başlangıç, bitiş] çiftleri (tur başı -> sonuç aşaması). Yoksa sonuçtan öncesi.
  const segs = w.segs && w.segs.length ? w.segs : [[0, w.resultIdx !== undefined ? w.resultIdx : w.raw.length]];
  const out = [];
  for (const [a, b] of segs) out.push(...w.raw.slice(a, b).filter((f) => !f.startsWith('SENT')));
  return out;
}
function privacyCheck(workers, missions, label) {
  for (const w of workers) {
    const pre = segFrames(w);
    const keys = []; const bad = new Set(); const mhits = new Set();
    for (const f of pre) {
      const m = /^\d*(\[.*\])$/s.exec(f);
      if (m) { try { walkKeys(JSON.parse(m[1]), keys); } catch (e) { /* parça */ } }
      for (const ms of missions) {
        for (const s of [ms.title, ms.name, ms.summary, ms.description].filter(Boolean)) if (f.includes(s)) mhits.add(s);
      }
    }
    for (const k of keys) if (FORBID_KEYS.includes(k)) bad.add(k);
    ok(`gizlilik ${label} ${w.name}: yasak anahtar yok`, bad.size === 0, [...bad].join(','));
    ok(`gizlilik ${label} ${w.name}: görev metni ham çerçevede yok`, mhits.size === 0, [...mhits].join(' / '));
  }
}

// ham çerçevelerde sayısal parça değerleri: occupant/catalog nesnelerinde number alanları (id/slot dışı)
function numericLeak(workers, label) {
  for (const w of workers) {
    const pre = segFrames(w);
    const hits = new Set();
    const scan = (o, path) => {
      if (Array.isArray(o)) o.forEach((x, i) => scan(x, path));
      else if (o && typeof o === 'object') for (const [k, v] of Object.entries(o)) {
        if (typeof v === 'number' && !/^(ts|at|time|remaining|left|windowLeft|seconds|sec|index|order|x|y|w|h|pos|version|v|n|count|limit|ms|holdUntil|until|endsAt|startsAt|now|serverTime|t|uid|id|cols|rows|r|rx|ry|ox|oy)$/i.test(k)) hits.add(path + '.' + k + '=' + v);
        else scan(v, path + '.' + k);
      }
    };
    for (const f of pre) { const m = /^\d*(\[.*\])$/s.exec(f); if (m) { try { scan(JSON.parse(m[1]), ''); } catch (e) { /* */ } } }
    console.log(`  (bilgi) ${label} ${w.name} ham çerçevede sayı alanları:`, [...hits].slice(0, 25).join(' ; '));
  }
}

async function waitResult(room) {
  for (const p of room.all) await p.page.waitForSelector('#screen-result:not([hidden])', { timeout: 20000 });
  for (const p of room.all) markEnd(p);
}
function markEnd(p) { if (p.segStart === undefined) return; (p.segs = p.segs || []).push([p.segStart, p.raw.length]); p.segStart = undefined; }
function markStart(room) { for (const p of room.all) p.segStart = p.raw.length; }

async function startPollAndGo(room, goAll = true) {
  const D = room.D;
  await D.page.waitForFunction(() => { const b = document.querySelector('#poll-start-btn'); return b && !b.disabled; }, null, { timeout: 8000 });
  await D.page.click('#poll-start-btn');
  for (const p of room.all) await p.page.waitForSelector('#poll-box:not([hidden])', { timeout: 5000 });
}

// ============ A: tam tur (3 tur: kazanma, kazanma, başarısızlık) ============
scenario('round', async () => {
  const server = await L.startServer({ PP_EVENTS: 'none', PP_TELEMETRY_DELAY_MS: '0', PP_WINDOW_SEC: '300' });
  try {
    // ---- giriş ekranı kontrolleri (1 sayfa) ----
    const ep = await L.mkPlayer(server, 'E', { width: 1366, height: 768 });
    const pg = ep.page;
    await L.shot(ep, 'entry-initial');
    ok('giriş: #card-create #card-join #demo-link görünür', (await pg.locator('#card-create:visible, #card-join:visible, #demo-link:visible').count()) === 3);
    ok('giriş: #demo-link href=/demo.html', (await pg.getAttribute('#demo-link', 'href')) === '/demo.html');
    const formVisible0 = await pg.locator('#name-input').isVisible();
    ok('giriş: kart basmadan form kapalı (name-input gizli)', !formVisible0);
    await pg.click('#card-create');
    ok('giriş: oda kur formu açılır, #create-btn görünür', await pg.locator('#create-btn').isVisible() && await pg.locator('#name-input').isVisible());
    ok('giriş: #card-create aria-expanded=true', (await pg.getAttribute('#card-create', 'aria-expanded')) === 'true');
    await L.shot(ep, 'entry-create');
    await pg.click('#card-join');
    ok('giriş: katıl formu açılır (#code-input, #join-btn), create-btn gizlenir', await pg.locator('#join-btn').isVisible() && await pg.locator('#code-input').isVisible() && !(await pg.locator('#create-btn').isVisible()));
    ok('giriş: #name-input katıl formunda görünür', await pg.locator('#name-input').isVisible());
    await L.shot(ep, 'entry-join');
    await pg.fill('#code-input', 'ZZZZ'); await pg.fill('#name-input', 'X'); await pg.click('#join-btn');
    await sleep(500);
    ok('yanlış kod: #error-msg görünür', (await pg.locator('#error-msg').innerText()).trim().length > 0, await pg.locator('#error-msg').innerText());
    await L.shot(ep, 'entry-join-error');
    await ep.ctx.close();

    const missionsSeen = new Set();
    const missionsData = require('../../data/missions.json');
    const mlist = missionsData.missions || missionsData;
    let room = null; let wins = 0; let fails = 0;
    for (let round = 1; round <= 4; round++) {
      if (!room) {
        room = await L.setupRoom(server, 'r1');
        markStart(room);
      }
      const { D, R: Rk, S: Sp, X } = room;
      const mid = (await L.st(D)).mission.id; missionsSeen.add(mid);
      console.log(`\n--- tur ${round}: ${mid}`);
      if (round === 1) {
        // lobi gözlemleri yapıldı setupRoom'da; setup ekranı
        await L.shot(D, 'setup-director'); await L.shot(Rk, 'setup-worker');
        const unfit = await D.page.evaluate(() => [...document.querySelectorAll('#frame-select button[data-frame]')].map((b) => b.dataset.frame + ':' + b.dataset.unfit));
        console.log('  unfit:', unfit.join(' '));
        ok('setup: 3 gövde kartı', unfit.length === 3);
        for (const w of [Rk, Sp, X]) {
          const t = noClock(await w.page.locator('#screen-setup').innerText());
          ok(`çalışan setup ekranında sayı yok (${w.name})`, !digitsIn(t), t.replace(/\n/g, ' | ').slice(0, 200));
        }
      }
      // gövde seçimi: unfit uyarısı bir gövdede yoksa da doğrula
      const unfitAll = await D.page.evaluate(() => [...document.querySelectorAll('#frame-select button[data-frame]')].map((b) => ({ f: b.dataset.frame, u: b.dataset.unfit, t: b.innerText.replace(/\n/g, ' / ') })));
      const unfitCards = unfitAll.filter((x) => x.u && x.u !== 'false');
      if (mid === 'mars-rover') {
        ok('mars: Kırlangıç kartında unfit uyarısı var (data-unfit)', unfitAll.find((x) => x.f === 'frame-swift' && x.u && x.u !== 'false'), JSON.stringify(unfitAll.map((x) => x.f + ':' + x.u)));
      }
      console.log('  unfit kartlar:', JSON.stringify(unfitCards.map((x) => x.f + ':' + x.u + ' => ' + x.t.slice(-90))));
      const plan = L.SOLUTIONS[mid][round % 2 === 0 ? 1 : 0];
      await L.pickFrame(room, plan.frameId);
      ok(`tur ${round}: 4 sayfada oyun ekranı (${plan.frameId})`, true);
      if (round === 1) {
        await L.shot(D, 'game-director-empty'); await L.shot(Rk, 'game-worker-empty');
        for (const w of [Rk, Sp, X]) {
          const t = noClock(await w.page.locator('#screen-game').innerText());
          ok(`çalışan oyun ekranında sayaç dışında sayı yok (${w.name})`, !digitsIn(t), (t.match(/.{0,25}\d.{0,25}/g) || []).slice(0, 4).join(' || '));
          ok(`çalışan ekranı "GÖREV: GİZLİ" (${w.name})`, /GİZLİ/i.test(t));
        }
        await rulesAndUi(room, mid, plan);
      }
      // çözümü yerleştir: round 1 yarısı sahne tıklaması, round 3 başarısızlık
      if (round === 4) {
        // başarısızlık: eksik yapı (yalnız motor/tank, yakıt yok) ile anket
        const partial = { placements: plan.placements.filter((x) => x.role === 'rocket').slice(0, 3) };
        const f = await L.placeSolution(room, partial, 2);
        ok('tur 4: kısmi yapı yerleştirildi', f.length === 0, f.join(','));
        await sleep(300);
        const btnState = await D.page.evaluate(() => { const b = document.querySelector('#poll-start-btn'); return { dis: b.disabled, t: b.innerText, w: document.querySelector('#poll-warning').innerText }; });
        console.log('  eksik yapıda anket düğmesi:', JSON.stringify(btnState));
        ok('eksik yapıda anket başlatılabilir ya da gerekçe gösterilir', !btnState.dis || btnState.w.length > 0, JSON.stringify(btnState));
        if (btnState.dis) { fails++; /* başarısızlık için pencere kaçırma ayrı senaryoda */ break; }
      } else if (round > 1) {
        const fl = await L.placeSolution(room, plan, 3);
        ok(`tur ${round}: tüm çözüm yerleştirildi`, fl.length === 0, fl.join(','));
      }
      await sleep(800);
      const g = await L.gauges(D);
      ok(`tur ${round}: göstergelerin hepsi yeşil`, g.length >= 5 && g.every((x) => x.ok === 'true'), JSON.stringify(g));
      if (round === 1) {
        await L.shot(D, 'game-director-built'); await L.shot(Rk, 'game-worker-built');
        // anket iptal
        await startPollAndGo(room);
        await L.shot(D, 'poll-director'); await L.shot(Rk, 'poll-worker');
        const pollText = noClock(await Rk.page.locator('#poll-box').innerText());
        console.log('  anket metni (çalışan):', pollText.replace(/\n/g, ' | ').slice(0, 200));
        ok('anket: GO/NO-GO düğmeleri çalışan sayfasında', await Rk.page.locator('#vote-go-btn').isVisible() && await Rk.page.locator('#vote-nogo-btn').isVisible());
        ok('anket sırasında oyun gövdesi (#game-body) gizli', !(await Rk.page.locator('#game-body').isVisible()));
        await D.page.click('#poll-cancel-btn');
        for (const p of room.all) await p.page.waitForFunction(() => document.querySelector('#poll-box').hidden || getComputedStyle(document.querySelector('#poll-box')).display === 'none', null, { timeout: 5000 });
        ok('anket iptal: poll kutusu kapandı, oyun ekranı geri', await Rk.page.locator('#slot-panel, #catalog-panel').first().isVisible());
        // NO-GO
        await startPollAndGo(room);
        await Rk.page.click('#vote-nogo-btn'); await sleep(600);
        const afterNo = await D.page.locator('#poll-box').isVisible();
        ok('NO-GO sonrası anket kapanır (oyun ekranı)', !afterNo, 'poll görünür=' + afterNo);
      }
      await startPollAndGo(room);
      for (const w of [Rk, Sp, X]) await w.page.click('#vote-go-btn');
      // fırlatma
      for (const p of room.all) await p.page.waitForSelector('#screen-result:not([hidden])', { timeout: 20000 }).catch(() => {});
      const t0 = Date.now();
      for (const p of room.all) markEnd(p);
      await sleep(500);
      if (round === 1 || round === 3) {
        await L.shot(Rk, `launch-worker-r${round}`); await L.shot(D, `launch-director-r${round}`);
        const sk = await Rk.page.locator('#skip-launch-btn').isVisible();
        ok(`tur ${round}: fırlatma sırasında #skip-launch-btn görünür`, sk);
        const stage = await Rk.page.evaluate(() => { const r = document.querySelector('#result-scene-host'); return r ? r.getBoundingClientRect().height : 0; });
        ok(`tur ${round}: fırlatma sahnesi yüksekliği>200`, stage > 200, stage);
        if (round === 1) { // animasyon süresi
          const st0 = Date.now();
          await Rk.page.waitForFunction(() => document.querySelector('#result-panel') && getComputedStyle(document.querySelector('#result-panel')).display !== 'none' && !document.querySelector('#result-panel').hidden && document.querySelector('#result-panel').getBoundingClientRect().height > 50, null, { timeout: 15000 }).catch(() => {});
          console.log('  animasyon + sonuç gecikmesi ms:', Date.now() - st0 + 500);
        } else { await Rk.page.click('#skip-launch-btn').catch(() => {}); }
      } else { await Rk.page.click('#skip-launch-btn').catch(() => {}); await sleep(300); }
      await Rk.page.waitForSelector('#result-panel', { state: 'visible', timeout: 15000 });
      await sleep(400);
      const rt = await Rk.page.locator('#result-panel').innerText();
      const dr = await D.page.locator('#result-panel').innerText();
      console.log('  sonuç(çalışan):', rt.replace(/\n/g, ' | ').slice(0, 260));
      const win = /BAŞARI|Başarı|başardı|Görev tamam|TAMAMLANDI/i.test(rt) || (await Rk.page.locator('#result-badge').getAttribute('data-outcome').catch(() => '')) === 'success';
      ok(`tur ${round}: sonuç paneli dolu`, rt.length > 40);
      if (win) wins++;
      await L.shot(Rk, `result-worker-r${round}`); await L.shot(D, `result-director-r${round}`);
      ok(`tur ${round}: sonuçta başarı`, win, rt.replace(/\n/g, ' | ').slice(0, 120));
      ok(`tur ${round}: sonuçta "Gerçekte NASA" bölümü`, (await Rk.page.locator('#result-nasa').innerText()).length > 20);
      await D.page.waitForSelector('#restart-btn', { state: 'visible', timeout: 10000 }).catch(() => {});
      ok(`tur ${round}: yönetici restart-btn görünür (<=10 sn)`, await D.page.locator('#restart-btn').isVisible());
      ok(`tur ${round}: çalışan #restart-wait ya da restart-btn`, (await Rk.page.locator('#restart-wait').isVisible()) || (await Rk.page.locator('#restart-btn').isVisible()));
      if (round < 3) {
        await D.page.click('#restart-btn');
        for (const p of room.all) await p.page.waitForSelector('#screen-setup:not([hidden])', { timeout: 6000 });
        markStart(room);
        ok(`tur ${round}: yeni tur setup ekranı 4 sayfada`, true);
      }
      if (round === 3) break;
    }
    ok('en az 2 görev kazanıldı', wins >= 2, wins);
    privacyCheck([room.R, room.S, room.X], mlist, 'tam-tur');
    numericLeak([room.R], 'tam-tur');
    for (const w of [room.R, room.S, room.X]) ok(`dış istek yok (${w.name})`, w.ext.length === 0, w.ext.join(','));
    const threeReq = room.R.reqs.filter((u) => /three|scene3d/i.test(u));
    ok('three.js / scene3d.js isteği yok', threeReq.length === 0, threeReq.join(','));
    ok('scene2d.js istendi', room.R.reqs.some((u) => /scene2d\.js/.test(u)));
    await L.closeRoom(room);
  } finally { L.stopServer(server); }
});

// kurallar: dolu yuva, uyumsuzluk, geri alma, sahne etiketi/vurgu, çıkarma
async function rulesAndUi(room, mid, plan) {
  const { D, R: Rk, S: Sp, X } = room;
  const fid = plan.frameId;
  const slots = (p) => p.page.evaluate(() => [...document.querySelectorAll('g.pp2d-slot')].map((g) => g.dataset.slot + ':' + g.dataset.state));
  const rows = (p) => p.page.evaluate(() => [...document.querySelectorAll('#slot-list li')].map((li) => ({ ok: li.dataset.ok, slot: (li.querySelector('button[data-slot]') || {}).dataset && li.querySelector('button[data-slot]').dataset.slot, t: li.innerText.replace(/\n/g, ' | ') })));
  // 1) boş yuvaya tıkla -> etiket sahne tıklamasından sonra bayat mı?
  const rp = plan.placements.filter((x) => x.role === 'rocket');
  const first = rp[0];
  await Rk.page.click(`button[data-pick="${first.partId}"]`); await sleep(200);
  const stA = await slots(Rk);
  console.log('  vurgu durumları (motor seçili):', stA.join(' '));
  const okSlots = stA.filter((s) => s.endsWith(':ok')).length;
  ok('sahne: parça seçilince yeşil (ok) yuvalar var', okSlots > 0, okSlots);
  const rowsA = await rows(Rk);
  ok('liste ile sahne ok sayısı eşit', rowsA.filter((r) => r.ok === 'true').length === okSlots, `${rowsA.filter((r) => r.ok === 'true').length} vs ${okSlots}`);
  await L.shot(Rk, 'rules-picked');
  const pos = await L.slotPos(Rk, first.slotId);
  await Rk.page.mouse.click(pos.x, pos.y);
  await Rk.page.waitForFunction(() => document.querySelectorAll('#my-parts [data-remove]').length > 0, null, { timeout: 3000 });
  const lab1 = await Rk.page.evaluate(() => { const l = document.querySelector('.slot-label'); return l ? { hidden: l.hidden, t: l.innerText.replace(/\n/g, ' / ') } : null; });
  console.log('  tıkla-yerleştir sonrası etiket (fare oynamadan):', JSON.stringify(lab1));
  ok('sahne etiketi: yerleştirme sonrası dolu yuvada "(boş)" YAZMIYOR', !lab1 || lab1.hidden || !/\(boş\)/.test(lab1.t), JSON.stringify(lab1));
  await L.shot(Rk, 'rules-label-after-place');
  // fareyi uzaklaştır, tekrar üstüne getir: etiket doğru olmalı
  await Rk.page.mouse.move(5, 400); await sleep(150); const pos2 = await L.slotPos(Rk, first.slotId); await Rk.page.mouse.move(pos2.x, pos2.y); await sleep(250);
  const shiftY = Math.round(Math.abs(pos2.y - pos.y)); console.log('  yerleştirme sonrası yuva kayması px:', shiftY);
  ok('yerleştirme sonrası roket/yuva konumu kaymıyor (<=4px)', shiftY <= 4, shiftY + 'px');
  const lab2 = await Rk.page.evaluate(() => { const l = document.querySelector('.slot-label'); return l ? { hidden: l.hidden, t: l.innerText.replace(/\n/g, ' / ') } : null; });
  ok('sahne etiketi: dolu yuvaya gelince parça adı', lab2 && !lab2.hidden && !/\(boş\)/.test(lab2.t), JSON.stringify(lab2));
  // 2) dolu yuvaya ikinci parça: aynı tür parça seç
  const state1 = await slots(Rk);
  const mineSt = state1.find((s) => s.startsWith(first.slotId + ':'));
  ok('sahne: yerleşen yuva data-state=mine', mineSt === `${first.slotId}:empty` ? false : /mine|occupied/.test(mineSt), mineSt);
  await Rk.page.click(`button[data-pick="${first.partId}"]`); await sleep(250);
  const st2 = await slots(Rk); const rows2 = await rows(Rk);
  const blockedSt = st2.find((s) => s.startsWith(first.slotId + ':'));
  ok('dolu yuva: sahnede blocked', /blocked/.test(blockedSt), blockedSt);
  const rrow = rows2.find((r) => r.slot === first.slotId);
  ok('dolu yuva: listede ENGELLİ + gerekçe ("dolu")', rrow && rrow.ok === 'false' && /dolu/i.test(rrow.t), rrow && rrow.t);
  const dis = await Rk.page.locator(`#slot-list button[data-slot="${first.slotId}"]`).isDisabled();
  ok('dolu yuva: liste düğmesi disabled', dis);
  await L.shot(Rk, 'rules-occupied-blocked');
  // blocked yuvada parça simgesi görünüyor mu (g içinde svg çocuk sayısı) ve çarpı
  const art = await Rk.page.evaluate((id) => { const g = document.querySelector(`g.pp2d-slot[data-slot="${id}"]`); if (!g) return null; const cs = [...g.children].map((c) => c.tagName + '.' + (c.getAttribute('class') || '')); return { n: g.children.length, cs, text: g.textContent }; }, first.slotId);
  console.log('  blocked dolu yuva çocukları:', JSON.stringify(art));
  const lab3pos = await L.slotPos(Rk, first.slotId);
  await Rk.page.mouse.move(lab3pos.x, lab3pos.y); await sleep(250);
  const lab3 = await Rk.page.evaluate(() => { const l = document.querySelector('.slot-label'); return l ? { hidden: l.hidden, t: l.innerText.replace(/\n/g, ' / ') } : null; });
  ok('blocked dolu yuvada etiket parça adını gösterir (boş değil)', lab3 && !lab3.hidden && !/\(boş\)/.test(lab3.t), JSON.stringify(lab3));
  // dolu yuvaya sahne tıklaması: yeni yerleştirme olmamalı
  const cnt0 = await L.countParts(Rk);
  await Rk.page.mouse.click(lab3pos.x, lab3pos.y); await sleep(500);
  ok('dolu yuvaya sahne tıklaması ikinci parça koymaz', (await L.countParts(Rk)) === cnt0, await L.countParts(Rk));
  await L.shot(Rk, 'rules-occupied-click');
  await Rk.page.click('#unpick-btn').catch(() => {}); await sleep(200);
  // dolu yuva simgesi vurgu yokken
  const art2 = await Rk.page.evaluate((id) => { const g = document.querySelector(`g.pp2d-slot[data-slot="${id}"]`); return g ? g.querySelectorAll('svg, g, path, rect, circle, polygon').length : 0; }, first.slotId);
  console.log('  dolu yuva çizim öğesi sayısı:', art2);
  // 3) uyumsuzluk kuralları: diğer çalışanların parçalarıyla gerekçe ara
  const conflictReasons = new Set(['__skip']);
  const place = async (w, partId, slotId) => (await L.placeList(w, partId, slotId));
  // kuralı bulmak için: komşuluk çiftleri. Tüm olası çiftleri dene (çözüm parçalarına ek).
  // spacecraft shield-light/solar çifti: yuvalar çözümde zaten; çözümün DIŞINDA kalan ikinci parça seçilip engelli gerekçeler toplanır.
  const probe = async () => {
    for (const [w, ids] of [[Sp, ['shield-light', 'solar-small', 'battery']], [X, ['radar', 'camera', 'drill', 'relay-antenna']]]) {
      for (const id of ids) {
        const has = await w.page.locator(`button[data-pick="${id}"]`).count();
        if (!has) continue;
        await w.page.click(`button[data-pick="${id}"]`).catch(() => {}); await sleep(150);
        const rr = await rows(w);
        for (const r of rr) if (r.ok === 'false' && !/dolu|ENGELLİ \| *$/.test(r.t)) { const m = r.t.split('ENGELLİ')[1]; if (m && m.trim()) conflictReasons.add(m.replace(/\|/g, '').trim()); }
        await w.page.click('#unpick-btn').catch(() => {});
      }
    }
  };
  // spacecraft: solar yerleştir sonra shield seç (yan yana yuvalar), vb.: çözüm kısmını önce yerleştir, sonra probe
  for (const pl of plan.placements) { if (pl.role === 'rocket' && pl.slotId === first.slotId) continue; await place(room.workers[pl.role], pl.partId, pl.slotId); }
  await probe();
  // çözümde olmayan ek parçalarla da dene
  console.log('  uyumsuzluk gerekçeleri:', JSON.stringify([...conflictReasons]));

  // 4) çıkarma: listeden ve sahneden (parça tıklama)
  const n0 = await L.countParts(Rk);
  const rm = Rk.page.locator('#my-parts [data-remove]').first();
  await rm.click(); await sleep(600);
  const n1 = await L.countParts(Rk);
  ok('çıkarma düğmesi (listeden) parçayı çıkarır', n1 === n0 - 1, `${n0}->${n1}`);
  await L.shot(Rk, 'rules-removed');
  // yeniden yerleştir (sahne ile)
  const re = await L.placeScene(Rk, first.partId, first.slotId);
  ok('çıkarılan parça sahne tıklamasıyla geri takıldı', re);
  // sahnede dolu parçaya tıkla (onPartClick) -> çıkarma onayı
  const pp = await L.slotPos(Rk, first.slotId);
  await Rk.page.mouse.click(pp.x, pp.y); await sleep(500);
  const confirmTxt = await Rk.page.evaluate(() => { const els = [...document.querySelectorAll('button')].filter((b) => /ÇIKAR|VAZGEÇ|Vazgeç|Evet/i.test(b.innerText) && b.offsetParent); return els.map((b) => b.innerText.trim()); });
  console.log('  dolu parça tıklaması sonrası düğmeler:', JSON.stringify(confirmTxt));
  await L.shot(Rk, 'rules-part-click');
  ok('dolu parçaya sahne tıklaması: çıkarma onayı/seçeneği sunar', confirmTxt.length > 0, JSON.stringify(confirmTxt));
  // açık onay varsa vazgeç
  const vz = Rk.page.locator('button', { hasText: /Vazgeç/i }).first();
  if (await vz.isVisible().catch(() => false)) await vz.click();
  // yönetici ekranı: yuva işaretçileri örtüyor mu (silüet)
  await sleep(300);
  await L.shot(D, 'director-mid-build');
  // geri al: yönetici
  await sleep(300);
}

// ============ yardımcı: sahne geometrisi ============
async function geom(p) {
  return p.page.evaluate(() => {
    const host = document.querySelector('#scene3d');
    const hr = host.getBoundingClientRect();
    const gs = [...document.querySelectorAll('g.pp2d-slot')].map((g) => {
      const f = g.querySelector('.pp2d-frame') || g; const r = f.getBoundingClientRect();
      return { id: g.dataset.slot, x: r.left, y: r.top, w: r.width, h: r.height, st: g.dataset.state };
    });
    let overlap = 0; const ov = [];
    for (let i = 0; i < gs.length; i++) for (let j = i + 1; j < gs.length; j++) {
      const a = gs[i], b = gs[j];
      const ix = Math.min(a.x + a.w, b.x + b.w) - Math.max(a.x, b.x), iy = Math.min(a.y + a.h, b.y + b.h) - Math.max(a.y, b.y);
      if (ix > 1 && iy > 1) { overlap++; ov.push(a.id + '/' + b.id); }
    }
    const small = gs.filter((g) => g.w < 38 || g.h < 38).map((g) => g.id + ':' + Math.round(g.w) + 'x' + Math.round(g.h));
    const outside = gs.filter((g) => g.x < hr.left - 1 || g.y < hr.top - 1 || g.x + g.w > hr.right + 1 || g.y + g.h > hr.bottom + 1).map((g) => g.id);
    // gövde silueti
    const sil = document.querySelector('.pp2d-rocket, .pp2d-body, [class*=pp2d-hull], [class*=pp2d-frame-body]');
    return { n: gs.length, overlap, ov, small, outside, host: { w: Math.round(hr.width), h: Math.round(hr.height) }, hasSil: !!sil };
  });
}

// ============ B: sahne geometrisi (üç gövde x görünüm) ============
scenario('geometry', async () => {
  const server = await L.startServer({ PP_EVENTS: 'none', PP_WINDOW_SEC: '300' });
  try {
    for (const frameId of ['frame-swift', 'frame-cargo', 'frame-heavy']) {
      for (const vp of [{ width: 1366, height: 768 }, { width: 390, height: 844 }, { width: 360, height: 740 }]) {
        const room = await L.setupRoom(server, 'g', { viewport: vp });
        await L.pickFrame(room, frameId);
        for (const [nm, p] of [['çalışan', room.R], ['yönetici', room.D]]) {
          const g = await geom(p);
          console.log(`  ${frameId} ${vp.width}x${vp.height} ${nm}:`, JSON.stringify(g));
          ok(`yuva çakışması 0: ${frameId} ${vp.width} ${nm}`, g.overlap === 0, g.ov.join(','));
          ok(`yuva hücreleri >=38px: ${frameId} ${vp.width} ${nm}`, g.small.length === 0, g.small.join(','));
          ok(`yuvalar kap içinde: ${frameId} ${vp.width} ${nm}`, g.outside.length === 0, g.outside.join(','));
          if (vp.width === 1366 || nm === 'yönetici') await L.shot(p, `geom-${frameId}-${vp.width}-${nm === 'yönetici' ? 'dir' : 'wrk'}`);
        }
        // yönetici: roket siluetinin görünen alanı: silüet pikselleri yuva hücreleri tarafından ne kadar örtülüyor
        if (vp.width === 1366) {
          const cov = await room.D.page.evaluate(() => {
            const svg = document.querySelector('#scene3d svg'); if (!svg) return null;
            const sr = svg.getBoundingClientRect();
            const slots = [...document.querySelectorAll('g.pp2d-slot')].map((g) => (g.querySelector('.pp2d-frame') || g).getBoundingClientRect());
            // silüet: slot dışındaki ilk büyük path/polygon grubu
            const shapes = [...svg.querySelectorAll('path, polygon, rect')].filter((e) => !e.closest('.pp2d-slot')).map((e) => ({ r: e.getBoundingClientRect(), tag: e.tagName }));
            const big = shapes.filter((s) => s.r.width * s.r.height > 3000).sort((a, b) => b.r.width * b.r.height - a.r.width * a.r.height)[0];
            let area = 0, covered = 0;
            if (big) {
              const r = big.r; const step = 4;
              for (let x = r.left; x < r.right; x += step) for (let y = r.top; y < r.bottom; y += step) {
                area++; if (slots.some((s) => x >= s.left && x <= s.right && y >= s.top && y <= s.bottom)) covered++;
              }
            }
            return { area, covered, pct: area ? Math.round(100 * covered / area) : null, svgH: Math.round(sr.height) };
          });
          console.log(`  ${frameId} yönetici silüet örtülme:`, JSON.stringify(cov));
          if (cov && cov.pct !== null) ok(`yönetici ekranı: silüet çoğunlukla görünür (örtülme<%50) ${frameId}`, cov.pct < 50, cov.pct + '%');
        }
        await L.closeRoom(room);
      }
    }
  } finally { L.stopServer(server); }
});

require('./stage6.scen2.js')({ L, scenario, ok, sleep, digitsIn, noClock, privacyCheck });
try { require('./stage6.scen3.js')({ L, scenario, ok, sleep, digitsIn, noClock, privacyCheck }); } catch (e) { if (e.code !== 'MODULE_NOT_FOUND') throw e; }

(async () => {
  const names = Object.keys(SC).filter((n) => !ONLY.length || ONLY.includes(n));
  for (const n of names) {
    console.log('\n=== SENARYO ' + n + ' ===');
    try { await SC[n](); } catch (e) { ok('senaryo ' + n + ' istisnasız', false, e && e.stack ? e.stack.split('\n').slice(0, 5).join(' | ') : e); }
  }
  console.log('\n--- konsol/ağ sorunları (' + issues.length + ') ---');
  [...new Set(issues)].slice(0, 40).forEach((i) => console.log(i));
  const f = L.results.filter((r) => !r.pass);
  console.log(`\nSONUÇ: ${L.results.length - f.length}/${L.results.length} geçti`);
  f.forEach((r) => console.log('  FAIL: ' + r.name));
  await L.closeBrowser();
  process.exit(0);
})();
module.exports = { scenario };
