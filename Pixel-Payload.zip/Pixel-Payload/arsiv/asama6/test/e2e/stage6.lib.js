// Aşama 6 e2e yardımcıları. Playwright proje dışında (PW_DIR). Oyun koduna dokunmaz.
const path = require('path');
const fs = require('fs');
const { spawn } = require('child_process');
const PW = process.env.PW_DIR;
const { chromium } = require(path.join(PW, 'node_modules', 'playwright'));
const catalog = require('../../data/parts.json');
const framesData = require('../../data/frames.json');
const ROOT = path.join(__dirname, '..', '..');
const SHOT = process.env.SHOT_DIR || path.join(__dirname, 'shots6');
fs.mkdirSync(SHOT, { recursive: true });
const results = [], issues = [];
const ok = (name, cond, extra) => { results.push({ name, pass: !!cond }); console.log((cond ? 'PASS ' : 'FAIL ') + name + (extra !== undefined && extra !== '' ? ' :: ' + String(extra).slice(0, 500) : '')); };
const sleep = (ms) => new Promise((r) => setTimeout(r, ms));
const R = (partId, slotId) => ({ role: 'rocket', partId, slotId });
const S = (partId, slotId) => ({ role: 'spacecraft', partId, slotId });
const Y = (partId, slotId) => ({ role: 'payload', partId, slotId });
const SOLUTIONS = {
  'lunar-relay': [
    { frameId: 'frame-swift', placements: [R('engine-kestrel', 'eng-1'), R('tank-large', 'tank-1'), R('fuel-methalox', 'fuel'),
      S('structure-frame', 'svc-1'), S('solar-small', 's2-e1'), S('solar-small', 's2-e2'), S('shield-light', 's1-s'), Y('relay-antenna', 's1-n')] },
    { frameId: 'frame-cargo', placements: [R('engine-kestrel', 'eng-c'), R('tank-large', 'tank-1'), R('fuel-hydrolox', 'fuel'),
      S('structure-frame', 'svc-1'), S('solar-small', 'p-n1'), S('solar-small', 'p-n2'), S('shield-light', 's1-w'), Y('relay-antenna', 's1-e')] },
  ],
  'mars-rover': [
    { frameId: 'frame-cargo', placements: [R('engine-heron', 'eng-c'), R('engine-kestrel', 'eng-e'), R('engine-kestrel', 'eng-w'),
      R('tank-large', 'tank-1'), R('tank-large', 'tank-2'), R('tank-large', 'tank-3'), R('fuel-hydrolox', 'fuel'),
      S('structure-frame', 'svc-1'), S('solar-large', 's1-w'), S('shield-heavy', 's1-e'),
      Y('rover', 'pl-1'), Y('drill', 'nose-1'), Y('camera', 'p-n1')] },
    { frameId: 'frame-heavy', placements: [R('engine-heron', 'eng-c'), R('engine-kestrel', 'eng-n'), R('engine-kestrel', 'bst-e-eng'),
      R('engine-kestrel', 'bst-w-eng'), R('tank-large', 'tank-1'), R('tank-large', 'tank-2'), R('tank-large', 'tank-3'),
      R('tank-large', 'bst-e-tank'), R('fuel-hydrolox', 'fuel'),
      S('structure-frame', 'svc-1'), S('solar-large', 's2-e'), S('shield-heavy', 's1-n'), S('shield-light', 's2-n'),
      Y('rover', 'pl-1'), Y('drill', 'svc-2'), Y('camera', 's1-s')] },
  ],
  'asteroid-sample': [
    { frameId: 'frame-cargo', placements: [R('engine-heron', 'eng-c'), R('engine-kestrel', 'eng-e'), R('tank-large', 'tank-1'),
      R('tank-small', 'tank-2'), R('tank-small', 'tank-3'), R('fuel-hydrolox', 'fuel'),
      S('structure-frame', 'svc-1'), S('solar-small', 'p-e'), S('shield-light', 's1-e'), S('shield-light', 'p-n1'),
      Y('sample-capsule', 'pl-1'), Y('camera', 's1-w'), Y('spectrometer', 'p-n2')] },
    { frameId: 'frame-heavy', placements: [R('engine-kestrel', 'eng-c'), R('engine-kestrel', 'eng-n'), R('tank-large', 'tank-1'),
      R('tank-large', 'tank-2'), R('tank-small', 'tank-3'), R('fuel-hydrolox', 'fuel'),
      S('structure-frame', 'svc-1'), S('solar-small', 's2-n'), S('shield-heavy', 's1-n'),
      Y('sample-capsule', 'pl-1'), Y('camera', 's1-s'), Y('spectrometer', 's2-e')] },
  ],
};
const FAULT_SOLUTIONS = {
  'lunar-relay': { frameId: 'frame-swift', placements: [R('engine-kestrel', 'eng-1'), R('tank-large', 'tank-1'), R('fuel-methalox', 'fuel'),
    S('structure-frame', 'svc-1'), S('computer-backup', 'pl-1'), S('solar-small', 's2-e1'), S('solar-small', 's2-e2'), S('shield-light', 's1-s'),
    Y('relay-antenna', 's1-n')] },
  'mars-rover': { frameId: 'frame-cargo', placements: [R('engine-heron', 'eng-c'), R('engine-kestrel', 'eng-e'), R('engine-kestrel', 'eng-w'),
    R('tank-large', 'tank-1'), R('tank-large', 'tank-2'), R('tank-large', 'tank-3'), R('fuel-hydrolox', 'fuel'),
    S('structure-frame', 'svc-1'), S('computer-backup', 'pl-2'), S('solar-large', 's1-w'), S('shield-heavy', 's1-e'),
    Y('rover', 'pl-1'), Y('drill', 'nose-1'), Y('camera', 'p-n1')] },
  'asteroid-sample': { frameId: 'frame-cargo', placements: [R('engine-heron', 'eng-c'), R('engine-kestrel', 'eng-e'), R('tank-large', 'tank-1'),
    R('tank-small', 'tank-2'), R('tank-small', 'tank-3'), R('fuel-hydrolox', 'fuel'),
    S('structure-frame', 'svc-1'), S('computer-backup', 'pl-2'), S('solar-small', 'p-e'), S('solar-small', 'p-s1'),
    S('shield-light', 's1-e'), S('shield-light', 'p-n1'), Y('sample-capsule', 'pl-1'), Y('camera', 's1-w'), Y('spectrometer', 'p-n2')] },
};

let portCounter = Number(process.env.PORT_BASE || 3400);
async function startServer(env) {
  const port = portCounter++;
  const srv = spawn('node', ['server/index.js'], { cwd: ROOT, env: { ...process.env, PORT: String(port), ...env } });
  let stderr = '';
  srv.stderr.on('data', (d) => (stderr += d));
  await sleep(1500);
  return { srv, port, url: `http://localhost:${port}`, get stderr() { return stderr; } };
}
const stopServer = (s) => { try { s.srv.kill(); } catch (e) { /* */ } };
let browser = null;
async function getBrowser() { if (!browser) browser = await chromium.launch({}); return browser; }
async function closeBrowser() { if (browser) await browser.close().catch(() => {}); browser = null; }

async function mkPlayer(server, name, viewport, opts = {}) {
  const b = await getBrowser();
  const vp = viewport || { width: 1366, height: 768 };
  const ctx = await b.newContext(vp.width < 500 ? { viewport: vp, isMobile: true, hasTouch: true, deviceScaleFactor: 1 } : { viewport: vp });
  const page = await ctx.newPage();
  const p = { name, ctx, page, raw: [], ext: [], issues: [], reqs: [] };
  page.on('console', (m) => { if (m.type() === 'error' || m.type() === 'warning') { const t = `[${name}] console.${m.type()}: ${m.text()}`; issues.push(t); p.issues.push(t); } });
  page.on('pageerror', (e) => issues.push(`[${name}] pageerror: ${e.message}`));
  page.on('requestfailed', (r) => { if (!opts.abort || !r.url().match(opts.abort)) issues.push(`[${name}] requestfailed: ${r.url()} ${(r.failure() || {}).errorText}`); });
  page.on('request', (r) => { const u = r.url(); p.reqs.push(u); if (!/^(http:\/\/localhost|ws:\/\/localhost|data:|blob:|about:)/.test(u)) p.ext.push(u); });
  page.on('websocket', (ws) => { ws.on('framereceived', (f) => p.raw.push(String(f.payload))); ws.on('framesent', (f) => p.raw.push('SENT ' + String(f.payload))); });
  page.on('response', async (r) => {
    if (r.url().includes('/socket.io/')) { try { p.raw.push(await r.text()); } catch (e) { /* */ } }
    if (r.status() >= 400) issues.push(`[${name}] HTTP ${r.status()} ${r.url()}`);
  });
  await page.addInitScript(() => {
    let real; window.__socks = [];
    Object.defineProperty(window, 'io', { configurable: true, get() { return real; }, set(v) { real = function () { const s = v.apply(this, arguments); window.__socks.push(s); return s; }; Object.assign(real, v); } });
  });
  if (opts.abort) await page.route(opts.abort, (rt) => rt.abort());
  if (!opts.noGoto) { await page.goto(server.url); await page.waitForSelector('#screen-entry:not([hidden])'); }
  return p;
}
const st = async (p) => JSON.parse(await p.page.locator('#debug-state').textContent());
const shot = async (p, name) => { try { await p.page.screenshot({ path: path.join(SHOT, name + '.png') }); } catch (e) { /* */ } };

async function setupRoom(server, tag, opts = {}) {
  const vp = opts.viewport;
  const D = await mkPlayer(server, tag + 'D', vp, opts), Rk = await mkPlayer(server, tag + 'R', vp, opts);
  const Sp = await mkPlayer(server, tag + 'S', vp, opts), X = await mkPlayer(server, tag + 'X', vp, opts);
  await D.page.click('#card-create'); await D.page.fill('#name-input', 'Yon'); await D.page.click('#create-btn');
  await D.page.waitForSelector('#screen-lobby:not([hidden])');
  const code = (await D.page.locator('#room-code').innerText()).trim();
  for (const [p, n] of [[Rk, 'Rok'], [Sp, 'Uza'], [X, 'Yuk']]) {
    await p.page.click('#card-join'); await p.page.fill('#name-input', n); await p.page.fill('#code-input', code); await p.page.click('#join-btn');
    await p.page.waitForSelector('#screen-lobby:not([hidden])');
  }
  await D.page.click('[data-role="director"]'); await sleep(100);
  await Rk.page.click('[data-role="rocket"]'); await sleep(100);
  await Sp.page.click('[data-role="spacecraft"]'); await sleep(100);
  await X.page.click('[data-role="payload"]');
  for (const p of [D, Rk, Sp, X]) await p.page.waitForSelector('#screen-setup:not([hidden])', { timeout: 5000 });
  await sleep(200);
  const room = { D, R: Rk, S: Sp, X, code, workers: { rocket: Rk, spacecraft: Sp, payload: X }, all: [D, Rk, Sp, X] };
  room.mission = (await st(D)).mission;
  return room;
}
async function closeRoom(room) { for (const p of room.all) await p.ctx.close().catch(() => {}); }
async function roomWithMission(server, tag, missionId, opts) {
  for (let i = 0; i < 15; i++) {
    const room = await setupRoom(server, tag + i, opts);
    if (!missionId || (room.mission && room.mission.id === missionId)) return room;
    await closeRoom(room);
  }
  throw new Error('görev ' + missionId + ' çıkmadı');
}
async function pickFrame(room, frameId) {
  await room.D.page.click(`#frame-select button[data-frame="${frameId}"]`);
  for (const p of room.all) await p.page.waitForSelector('#screen-game:not([hidden])', { timeout: 5000 });
  await sleep(600);
}
const countParts = (p) => p.page.locator('#my-parts [data-remove]').count();
async function placeList(p, partId, slotId) {
  const before = await countParts(p);
  await p.page.click(`button[data-pick="${partId}"]`);
  const b = p.page.locator(`#slot-list button[data-slot="${slotId}"]`);
  try { await b.waitFor({ timeout: 1500 }); } catch (e) { return false; }
  if (await b.isDisabled()) { await p.page.click('#unpick-btn').catch(() => {}); return false; }
  await b.click();
  try { await p.page.waitForFunction((n) => document.querySelectorAll('#my-parts [data-remove]').length > n, before, { timeout: 2000 }); return true; } catch (e) { return false; }
}
async function slotPos(p, slotId) { return p.page.evaluate((s) => window.__ppScene && window.__ppScene.slotScreenPos(s), slotId); }
async function placeScene(p, partId, slotId) {
  const before = await countParts(p);
  await p.page.click(`button[data-pick="${partId}"]`);
  await sleep(150);
  const pos = await slotPos(p, slotId);
  if (!pos) return false;
  await p.page.mouse.click(pos.x, pos.y);
  try { await p.page.waitForFunction((n) => document.querySelectorAll('#my-parts [data-remove]').length > n, before, { timeout: 2000 }); return true; } catch (e) { return false; }
}
async function placeSolution(room, sol, sceneEvery) {
  const fails = []; let i = 0;
  for (const pl of sol.placements) {
    const w = room.workers[pl.role];
    let r = (sceneEvery && i % sceneEvery === 0) ? await placeScene(w, pl.partId, pl.slotId) : await placeList(w, pl.partId, pl.slotId);
    if (!r) { await w.page.click('#unpick-btn').catch(() => {}); r = await placeList(w, pl.partId, pl.slotId); if (!r) fails.push(pl.partId + '@' + pl.slotId); }
    i++;
  }
  return fails;
}
const gauges = (D) => D.page.evaluate(() => [...document.querySelectorAll('#gauges [data-check]')].map((e) => ({ c: e.getAttribute('data-check'), ok: e.getAttribute('data-ok') })));
const rawEmit = async (p, ev, payload) => p.page.evaluate(([ev, payload]) => new Promise((r) => window.__socks[0].emit(ev, payload, r)), [ev, payload]);
const overflow = (p) => p.page.evaluate(() => ({ sw: document.documentElement.scrollWidth, cw: document.documentElement.clientWidth, bw: document.body.scrollWidth }));
module.exports = { path, chromium, catalog, framesData, ROOT, SHOT, results, issues, ok, sleep, SOLUTIONS, FAULT_SOLUTIONS, R, S, Y, startServer, stopServer, getBrowser, closeBrowser,
  mkPlayer, st, shot, setupRoom, closeRoom, roomWithMission, pickFrame, countParts, placeList, placeScene, placeSolution, slotPos, gauges, rawEmit, overflow };
