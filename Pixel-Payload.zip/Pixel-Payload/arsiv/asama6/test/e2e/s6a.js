const L = require('./stage6.lib.js');
(async () => {
  const server = await L.startServer({ PP_EVENTS: 'none', PP_WINDOW_SEC: '300' });
  try {
    const room = await L.roomWithMission(server, 'a', 'lunar-relay');
    const Rk = room.R;
    await L.pickFrame(room, 'frame-swift');
    const lab = () => Rk.page.evaluate(() => { const l = document.querySelector('.slot-label'); return l ? { hidden: l.hidden, t: l.innerText.replace(/\n/g, ' / ') } : null; });
    // rocket sees tank-1 hover (empty); rocket picks tank-large to make it ok
    await Rk.page.click('button[data-pick="tank-large"]'); await L.sleep(200);
    const pos = await L.slotPos(Rk, 'tank-1');
    await Rk.page.mouse.move(pos.x, pos.y); await L.sleep(200);
    console.log('before:', JSON.stringify(await lab()));
    // başka rol? tank-1 yalnız roket... svc-1: spacecraft. Rk pick yok, svc-1 üzerinde dur
    await Rk.page.click('#unpick-btn').catch(() => {});
    const p3 = await L.slotPos(Rk, 'svc-1');
    await Rk.page.mouse.move(p3.x, p3.y); await L.sleep(300);
    console.log('svc-1 hover empty:', JSON.stringify(await lab()));
    await L.placeList(room.S, 'structure-frame', 'svc-1'); await L.sleep(700);
    console.log('after remote place (mouse still):', JSON.stringify(await lab()));
    await L.shot(Rk, 'a-stale');
    const g = await Rk.page.evaluate(() => document.querySelector('g.pp2d-slot[data-slot="svc-1"]').dataset.state);
    console.log('svc-1 state', g);
    // remote removal
    await Rk.page.mouse.move(p3.x + 1, p3.y); await L.sleep(100);
    await room.S.page.locator('#my-parts [data-remove]').first().click(); await L.sleep(700);
    console.log('after remote remove:', JSON.stringify(await lab()), await Rk.page.evaluate(() => document.querySelector('g.pp2d-slot[data-slot="svc-1"]').dataset.state));
  } catch (e) { console.log(e); }
  L.stopServer(server); await L.closeBrowser(); process.exit(0);
})();
