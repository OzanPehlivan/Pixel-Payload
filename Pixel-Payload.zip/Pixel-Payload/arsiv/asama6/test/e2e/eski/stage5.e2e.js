// Aşama 5 e2e. Playwright proje dışında: PW_DIR. SHOT_DIR = ekran görüntüleri. ONLY=a,b ile senaryo seçimi.
// Sunucuyu kendisi spawn eder (senaryo başına PP_* ortamı). Oyun koduna dokunmaz.
const path = require('path');
const { spawn } = require('child_process');
const PW = process.env.PW_DIR;
const { chromium } = require(path.join(PW, 'node_modules', 'playwright'));
const missions = require('../../data/missions.json');
const catalog = require('../../data/parts.json');
const framesData = require('../../data/frames.json');
const ROOT = path.join(__dirname, '..', '..');
const SHOT = process.env.SHOT_DIR || '.';
const ONLY = (process.env.ONLY || '').split(',').filter(Boolean);
const results = [];
const issues = [];
const ok = (name, cond, extra) => { results.push({ name, pass: !!cond }); console.log((cond ? 'PASS ' : 'FAIL ') + name + (extra !== undefined && extra !== '' ? ' :: ' + String(extra).slice(0, 400) : '')); };
const sleep = (ms) => new Promise((r) => setTimeout(r, ms));
const P = (id) => catalog.parts.find((p) => p.id === id);
const FR = (id) => framesData.frames.find((f) => f.id === id);

// Sabit çözümler: test/physics.test.js ile aynı (kopya).
const R = (partId, slotId) => ({ role: 'rocket', partId, slotId });
const S = (partId, slotId) => ({ role: 'spacecraft', partId, slotId });
const Y = (partId, slotId) => ({ role: 'payload', partId, slotId });
const SOLUTIONS = {
  'lunar-relay': [
    { frameId: 'frame-swift', placements: [R('engine-kestrel', 'eng-1'), R('tank-large', 'tank-1'), R('fuel-methalox', 'fuel'),
      S('structure-frame', 'svc-1'), S('solar-small', 's2-e1'), S('solar-small', 's2-e2'), S('shield-light', 's1-s'), Y('relay-antenna', 's1-n')] },
    { frameId: 'frame-cargo', placements: [R('engine-kestrel', 'eng-c'), R('tank-large', 'tank-1'), R('fuel-hydrolox', 'fuel'),
      S('structure-frame', 'svc-1'), S('solar-small', 'p-n1'), S('solar-small', 'p-n2'), S('shield-light', 's1-w'), Y('relay-antenna', 's1-e')] },
  ],
  'mars-rover': [
    { frameId: 'frame-cargo', placements: [R('engine-heron', 'eng-c'), R('engine-kestrel', 'eng-e'), R('engine-kestrel', 'eng-w'),
      R('tank-large', 'tank-1'), R('tank-large', 'tank-2'), R('tank-large', 'tank-3'), R('fuel-hydrolox', 'fuel'),
      S('structure-frame', 'svc-1'), S('solar-large', 's1-w'), S('shield-heavy', 's1-e'),
      Y('rover', 'pl-1'), Y('drill', 'nose-1'), Y('camera', 'p-n1')] },
    { frameId: 'frame-heavy', placements: [R('engine-heron', 'eng-c'), R('engine-kestrel', 'eng-n'), R('engine-kestrel', 'bst-e-eng'),
      R('engine-kestrel', 'bst-w-eng'), R('tank-large', 'tank-1'), R('tank-large', 'tank-2'), R('tank-large', 'tank-3'),
      R('tank-large', 'bst-e-tank'), R('fuel-hydrolox', 'fuel'),
      S('structure-frame', 'svc-1'), S('solar-large', 's2-e'), S('shield-heavy', 's1-n'), S('shield-light', 's2-n'),
      Y('rover', 'pl-1'), Y('drill', 'svc-2'), Y('camera', 's1-s')] },
  ],
  'asteroid-sample': [
    { frameId: 'frame-cargo', placements: [R('engine-heron', 'eng-c'), R('engine-kestrel', 'eng-e'), R('tank-large', 'tank-1'),
      R('tank-small', 'tank-2'), R('tank-small', 'tank-3'), R('fuel-hydrolox', 'fuel'),
      S('structure-frame', 'svc-1'), S('solar-small', 'p-e'), S('shield-light', 's1-e'), S('shield-light', 'p-n1'),
      Y('sample-capsule', 'pl-1'), Y('camera', 's1-w'), Y('spectrometer', 'p-n2')] },
    { frameId: 'frame-heavy', placements: [R('engine-kestrel', 'eng-c'), R('engine-kestrel', 'eng-n'), R('tank-large', 'tank-1'),
      R('tank-large', 'tank-2'), R('tank-small', 'tank-3'), R('fuel-hydrolox', 'fuel'),
      S('structure-frame', 'svc-1'), S('solar-small', 's2-n'), S('shield-heavy', 's1-n'),
      Y('sample-capsule', 'pl-1'), Y('camera', 's1-s'), Y('spectrometer', 's2-e')] },
  ],
};
const FAULT_SOLUTIONS = {
  'lunar-relay': { frameId: 'frame-swift', placements: [R('engine-kestrel', 'eng-1'), R('tank-large', 'tank-1'), R('fuel-methalox', 'fuel'),
    S('structure-frame', 'svc-1'), S('computer-backup', 'pl-1'), S('solar-small', 's2-e1'), S('solar-small', 's2-e2'), S('shield-light', 's1-s'),
    Y('relay-antenna', 's1-n')] },
  'mars-rover': { frameId: 'frame-cargo', placements: [R('engine-heron', 'eng-c'), R('engine-kestrel', 'eng-e'), R('engine-kestrel', 'eng-w'),
    R('tank-large', 'tank-1'), R('tank-large', 'tank-2'), R('tank-large', 'tank-3'), R('fuel-hydrolox', 'fuel'),
    S('structure-frame', 'svc-1'), S('computer-backup', 'pl-2'), S('solar-large', 's1-w'), S('shield-heavy', 's1-e'),
    Y('rover', 'pl-1'), Y('drill', 'nose-1'), Y('camera', 'p-n1')] },
  'asteroid-sample': { frameId: 'frame-cargo', placements: [R('engine-heron', 'eng-c'), R('engine-kestrel', 'eng-e'), R('tank-large', 'tank-1'),
    R('tank-small', 'tank-2'), R('tank-small', 'tank-3'), R('fuel-hydrolox', 'fuel'),
    S('structure-frame', 'svc-1'), S('computer-backup', 'pl-2'), S('solar-small', 'p-e'), S('solar-small', 'p-s1'),
    S('shield-light', 's1-e'), S('shield-light', 'p-n1'), Y('sample-capsule', 'pl-1'), Y('camera', 's1-w'), Y('spectrometer', 'p-n2')] },
};

// ---- altyapı ----
let portCounter = 3300 + Number(process.env.PORT_BASE || 0);
async function startServer(env) {
  const port = ++portCounter;
  const srv = spawn('node', ['server/index.js'], { cwd: ROOT, env: { ...process.env, PORT: String(port), ...env } });
  let stderr = '', stdout = '';
  srv.stderr.on('data', (d) => (stderr += d));
  srv.stdout.on('data', (d) => (stdout += d));
  await sleep(1500);
  return { srv, port, url: `http://localhost:${port}`, get stderr() { return stderr; }, get stdout() { return stdout; } };
}
function stopServer(s) { try { s.srv.kill(); } catch (e) { /* */ } }

let browserSingleton = null;
async function getBrowser(opts) {
  opts = opts || global.__browserOpts;
  const key = JSON.stringify(opts || {});
  if (browserSingleton && browserSingleton.key === key) return browserSingleton.b;
  if (browserSingleton) await browserSingleton.b.close().catch(() => {});
  const b = await chromium.launch(opts || { args: ['--use-gl=swiftshader', '--enable-unsafe-swiftshader', '--ignore-gpu-blocklist'] });
  browserSingleton = { key, b };
  return b;
}

async function mkPlayer(browser, server, name, viewport, extra) {
  const vp = viewport || { width: 1440, height: 900 };
  const ctx = await browser.newContext(vp.width < 500 ? { viewport: vp, isMobile: true, hasTouch: true, deviceScaleFactor: 1 } : { viewport: vp });
  const page = await ctx.newPage();
  const p = { name, ctx, page, raw: [], ext: [] };
  page.on('console', (m) => { if (m.type() === 'error') issues.push(`[${name}] console.error: ${m.text()}`); if (m.type() === 'warning' && /three|webgl/i.test(m.text())) issues.push(`[${name}] warn: ${m.text()}`); });
  page.on('pageerror', (e) => issues.push(`[${name}] pageerror: ${e.message}`));
  page.on('requestfailed', (r) => issues.push(`[${name}] requestfailed: ${r.url()} ${(r.failure() || {}).errorText}`));
  page.on('request', (r) => { const u = r.url(); if (!/^(http:\/\/localhost|ws:\/\/localhost|data:|blob:|about:)/.test(u)) p.ext.push(u); });
  page.on('websocket', (ws) => { ws.on('framereceived', (f) => p.raw.push(String(f.payload))); ws.on('framesent', (f) => p.raw.push('SENT ' + String(f.payload))); });
  page.on('response', async (r) => {
    if (r.url().includes('/socket.io/')) { try { p.raw.push(await r.text()); } catch (e) { /* */ } }
    if (r.status() >= 400 && !r.url().includes('/socket.io/')) issues.push(`[${name}] HTTP ${r.status()} ${r.url()}`);
  });
  await page.addInitScript(() => {
    let real; window.__socks = [];
    Object.defineProperty(window, 'io', { configurable: true, get() { return real; }, set(v) { real = function () { const s = v.apply(this, arguments); window.__socks.push(s); return s; }; Object.assign(real, v); } });
  });
  if (global.__abort) await page.route(global.__abort, (rt) => rt.abort());
  await page.goto(server.url);
  await page.waitForSelector('#screen-entry:not([hidden])');
  return p;
}
const st = async (p) => JSON.parse(await p.page.locator('#debug-state').textContent());

async function setupRoom(browser, server, tag, opts = {}) {
  const vp = opts.viewport;
  const D = await mkPlayer(browser, server, tag + 'D', vp, opts), Rk = await mkPlayer(browser, server, tag + 'R', vp, opts);
  const Sp = await mkPlayer(browser, server, tag + 'S', vp, opts), X = await mkPlayer(browser, server, tag + 'X', vp, opts);
  await D.page.fill('#name-input', 'Yon'); await D.page.click('#create-btn');
  await D.page.waitForSelector('#screen-lobby:not([hidden])');
  const code = (await D.page.locator('#room-code').innerText()).trim();
  for (const [p, n] of [[Rk, 'Rok'], [Sp, 'Uza'], [X, 'Yuk']]) {
    await p.page.fill('#name-input', n); await p.page.fill('#code-input', code); await p.page.click('#join-btn');
    await p.page.waitForSelector('#screen-lobby:not([hidden])');
  }
  if (opts.beforeRoles) await opts.beforeRoles({ D, R: Rk, S: Sp, X, code });
  await D.page.click('[data-role="director"]'); await sleep(100);
  await Rk.page.click('[data-role="rocket"]'); await sleep(100);
  await Sp.page.click('[data-role="spacecraft"]'); await sleep(100);
  await X.page.click('[data-role="payload"]');
  for (const p of [D, Rk, Sp, X]) await p.page.waitForSelector('#screen-setup:not([hidden])', { timeout: 5000 });
  await sleep(200);
  const room = { D, R: Rk, S: Sp, X, code, workers: { rocket: Rk, spacecraft: Sp, payload: X } };
  const ds = await st(D);
  room.mission = ds.mission;
  return room;
}
async function closeRoom(room) { for (const p of [room.D, room.R, room.S, room.X]) await p.ctx.close().catch(() => {}); }
// istenen göreve ulaşana kadar oda kur
async function roomWithMission(browser, server, tag, missionId, opts) {
  for (let i = 0; i < 12; i++) {
    const room = await setupRoom(browser, server, tag + i, opts);
    if (!missionId || (room.mission && room.mission.id === missionId)) return room;
    await closeRoom(room);
  }
  throw new Error('görev ' + missionId + ' çıkmadı');
}
async function pickFrame(room, frameId) {
  await room.D.page.click(`#frame-select button[data-frame="${frameId}"]`);
  for (const p of [room.D, room.R, room.S, room.X]) await p.page.waitForSelector('#screen-game:not([hidden])', { timeout: 5000 });
  await sleep(500);
}
const countParts = (p) => p.page.locator('#my-parts [data-remove]').count();
// UI ile yerleştir: parça seç, yuva seç (liste). Dönüş: true/false
async function placeUI(p, partId, slotId) {
  const before = await countParts(p);
  await p.page.click(`button[data-pick="${partId}"]`);
  const b = p.page.locator(`#slot-list button[data-slot="${slotId}"]`);
  try { await b.waitFor({ timeout: 1500 }); } catch (e) { return false; }
  if (await b.isDisabled()) { await p.page.click('#unpick-btn').catch(() => {}); return false; }
  await b.click();
  try { await p.page.waitForFunction((n) => document.querySelectorAll('#my-parts [data-remove]').length > n, before, { timeout: 2000 }); return true; } catch (e) { return false; }
}
async function placeSolution(room, sol) {
  let fails = [];
  for (const pl of sol.placements) {
    const okk = await placeUI(room.workers[pl.role], pl.partId, pl.slotId);
    if (!okk) fails.push(pl.partId + '@' + pl.slotId);
  }
  return fails;
}
async function gauges(D) {
  return D.page.evaluate(() => [...document.querySelectorAll('#gauges [data-check]')].map((e) => ({ c: e.getAttribute('data-check'), ok: e.getAttribute('data-ok') })));
}
async function shot(p, name) { try { await p.page.screenshot({ path: path.join(SHOT, name + '.png') }); } catch (e) { /* */ } }
const emitRaw = (p, ev, payload) => p.page.evaluate(([ev, payload]) => new Promise((res) => {
  // sayfanın kendi socket'i dışarıya açık değil: yeni bağlantı gerekir; burada io global'i varsa kullan
  res(null);
}), [ev, payload]);

// Sayfanın kendi socket'iyle ham olay gönder (addInitScript ile yakalanan).
async function rawEmit(room, who, ev, payload) {
  const p = room[who];
  const res = await p.page.evaluate(([ev, payload]) => new Promise((r) => window.__socks[0].emit(ev, payload, r)), [ev, payload]);
  return { res };
}

module.exports = { };
const lib = { path, spawn, chromium, missions, catalog, framesData, ROOT, SHOT, ONLY, results, issues, ok, sleep, P, FR, SOLUTIONS, FAULT_SOLUTIONS,
  startServer, stopServer, getBrowser, mkPlayer, st, setupRoom, closeRoom, roomWithMission, pickFrame, countParts, placeUI, placeSolution, gauges, shot, rawEmit, R, S, Y };

const SCENARIOS = {};
const scenario = (name, fn) => { SCENARIOS[name] = fn; };
lib.scenario = scenario;
global.__S5 = lib;
require('./stage5.scenarios.js'); require('./stage5.scenarios2.js'); require('./stage5.scenarios3.js'); require('./stage5.scenarios4.js'); require('./stage5.scenarios5.js'); require('./stage5.scenarios6.js');

(async () => {
  const names = Object.keys(SCENARIOS).filter((n) => !ONLY.length || ONLY.includes(n));
  for (const n of names) {
    console.log('\n=== SENARYO ' + n + ' ===');
    try { await SCENARIOS[n](lib); } catch (e) { ok('senaryo ' + n + ' istisnasız', false, e && e.stack ? e.stack.split('\n').slice(0, 4).join(' | ') : e); }
  }
  console.log('\n--- konsol/ağ sorunları (' + issues.length + ') ---');
  [...new Set(issues)].slice(0, 40).forEach((i) => console.log(i));
  const f = results.filter((r) => !r.pass);
  console.log(`\nSONUÇ: ${results.length - f.length}/${results.length} geçti`);
  f.forEach((r) => console.log('  FAIL: ' + r.name));
  if (browserSingleton) await browserSingleton.b.close().catch(() => {});
  process.exit(0);
})();
