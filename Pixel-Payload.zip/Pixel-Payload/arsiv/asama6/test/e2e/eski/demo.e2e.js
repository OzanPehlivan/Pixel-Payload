// Demo kontrol modu e2e. PW_DIR ortam değişkeni; SHOT_DIR ekran görüntüleri.
const path = require('path');
const fs = require('fs');
const { spawn } = require('child_process');
const { chromium } = require(path.join(process.env.PW_DIR, 'node_modules', 'playwright'));
const ROOT = path.join(__dirname, '..', '..');
const PORT = 3201, URL = `http://localhost:${PORT}`;
const SHOT = process.env.SHOT_DIR;
const sleep = (ms) => new Promise(r => setTimeout(r, ms));
const ok = (n, c, x) => console.log((c ? 'PASS ' : 'FAIL ') + n + (x !== undefined && x !== '' ? ' :: ' + x : ''));
const ROLES = ['director', 'rocket', 'spacecraft', 'payload'];

const SOL = {
  'lunar-relay': { rocket: ['engine-kestrel', 'tank-large', 'fuel-kerosene'], spacecraft: ['structure-frame', 'solar-small', 'solar-small', 'shield-light'] },
  'mars-rover': { rocket: ['engine-titan', 'tank-large', 'tank-large', 'fuel-hydrolox'], spacecraft: ['structure-frame', 'solar-large', 'shield-heavy'] },
  'asteroid-sample': { rocket: ['engine-heron', 'engine-heron', 'tank-large', 'fuel-hydrolox'], spacecraft: ['structure-frame', 'solar-small', 'shield-light', 'shield-light'] },
};
const INIT = () => {
  window.__raw = []; window.__msgs = [];
  const W = window.WebSocket;
  window.WebSocket = function (...a) { const ws = new W(...a); ws.addEventListener('message', e => window.__raw.push(String(e.data))); return ws; };
  window.WebSocket.prototype = W.prototype; Object.assign(window.WebSocket, { CONNECTING: 0, OPEN: 1, CLOSING: 2, CLOSED: 3 });
  const X = XMLHttpRequest.prototype.send;
  XMLHttpRequest.prototype.send = function (...a) { this.addEventListener('load', () => { try { window.__raw.push(String(this.responseText)); } catch (e) {} }); return X.apply(this, a); };
  if (window.top === window) window.addEventListener('message', e => window.__msgs.push(JSON.stringify(e.data)));
};

(async () => {
  const srv = spawn('node', ['server/index.js'], { cwd: ROOT, env: { ...process.env, PORT: String(PORT), PP_EVENTS: 'none', PP_TELEMETRY_DELAY_MS: '0' } });
  let stderr = ''; srv.stderr.on('data', d => stderr += d);
  await sleep(1500);
  const browser = await chromium.launch();
  const issues = [];
  const hook = (page, n) => {
    page.on('console', m => { if (m.type() === 'error') issues.push(`[${n}] console.error: ${m.text()}`); });
    page.on('pageerror', e => issues.push(`[${n}] pageerror: ${e.message}`));
    page.on('requestfailed', r => issues.push(`[${n}] requestfailed: ${r.url()}`));
    page.on('response', r => { if (r.status() >= 400) issues.push(`[${n}] HTTP ${r.status()} ${r.url()}`); });
  };
  const shot = (page, name) => SHOT ? page.screenshot({ path: path.join(SHOT, name + '.png') }).catch(() => {}) : null;
  const F = (page, role) => page.frames().find(f => f.url().includes('slot=demo-' + role));
  const phase = async (page, role) => { const f = F(page, role); if (!f) return null; try { return JSON.parse(await f.locator('#debug-state').textContent({ timeout: 500 })).phase; } catch (e) { return null; } };
  const waitPhases = async (page, ph, t = 8000, roles = ROLES) => { const e = Date.now() + t; while (Date.now() < e) { const r = await Promise.all(roles.map(x => phase(page, x))); if (r.every(x => x === ph)) return true; await sleep(200); } return false; };
  const dstate = async (page, role) => JSON.parse(await F(page, role).locator('#debug-state').textContent());

  try {
    for (const vp of [{ width: 1600, height: 900 }, { width: 1366, height: 768 }]) {
      const tag = vp.width;
      console.log('===== viewport', vp.width);
      const ctx = await browser.newContext({ viewport: vp });
      await ctx.addInitScript(INIT);
      const page = await ctx.newPage(); hook(page, 'demo' + tag);
      await page.goto(URL + '/demo.html');
      await sleep(300);
      await shot(page, `${tag}-0-bos`);
      await page.click('#demo-start-btn');
      ok(`${tag} 1 baslat: 4 panel building`, await waitPhases(page, 'building', 10000));
      const code = (await page.locator('#demo-code').innerText()).trim();
      ok(`${tag} 1 #demo-code 4 harf`, /^[A-Z0-9]{4}$/.test(code), code);
      const roles = {};
      for (const r of ROLES) { const s = await dstate(page, r); roles[r] = s.you && s.you.role; }
      ok(`${tag} 1 roller dogru`, Object.entries(roles).every(([k, v]) => k === v), JSON.stringify(roles));
      const dview = await F(page, 'director').locator('#director-view').isVisible();
      const wviews = await Promise.all(['rocket', 'spacecraft', 'payload'].map(r => F(page, r).locator('#worker-view').isVisible()));
      ok(`${tag} 1 yonetici/calisan gorunumleri`, dview && wviews.every(Boolean));
      await sleep(500); await shot(page, `${tag}-1-grid-building`);

      const secKeys = ['telemetry', 'mission', 'massKg', 'thrustKN', 'requiredDeltaV', 'budget', 'nasaFact', 'requiredInstruments', 'deltaV', 'durationSec', 'checks', 'undoLeft'];
      const mission = (await dstate(page, 'director')).mission;
      const secScan = async (label) => {
        const bad = [];
        for (const r of ['rocket', 'spacecraft', 'payload']) {
          const raw = (await F(page, r).evaluate(() => window.__raw.join('\n')));
          for (const k of secKeys) if (new RegExp('\\\\?"' + k + '\\\\?"\\s*:').test(raw)) bad.push(`${r}:${k}`);
          for (const s of [mission.title, mission.target, mission.nasaFact && mission.nasaFact.slice(0, 25)]) if (s && raw.includes(s)) bad.push(`${r}:gorev "${s.slice(0, 12)}"`);
        }
        ok(`${tag} 3 ${label} calisan ham WS/XHR'de sizinti yok`, bad.length === 0, bad.slice(0, 6).join('|'));
      };
      await secScan('building');
      const msgs = (await page.evaluate(() => window.__msgs)).map(m => JSON.parse(m));
      const allowed = new Set(['type', 'slot', 'code', 'phase', 'role', 'name']);
      const extra = msgs.filter(m => Object.keys(m).some(k => !allowed.has(k)));
      ok(`${tag} 3 postMessage yalniz izinli alanlar (${msgs.length} mesaj)`, msgs.length > 0 && extra.length === 0, JSON.stringify(extra[0] || ''));
      const topTxt = await page.evaluate(() => document.documentElement.outerHTML);
      ok(`${tag} 3 ust sayfa DOM'unda gorev bilgisi yok`, !mission.title || (!topTxt.includes(mission.title) && !topTxt.includes(mission.target)));
      const src = fs.readFileSync(path.join(ROOT, 'public/demo.js'), 'utf8') + fs.readFileSync(path.join(ROOT, 'public/demo.html'), 'utf8');
      ok(`${tag} 3 demo.js/html kaynaginda gorev metni yok`, !/lunar-relay|mars-rover|asteroid-sample|requiredDeltaV|telemetry/i.test(src));

      await page.evaluate(() => { for (const f of document.querySelectorAll('iframe')) f.contentWindow.__marker = 1; });
      for (const lay of ['director', 'row', 'grid']) {
        await page.click(`button[data-layout="${lay}"]`); await sleep(400);
        await shot(page, `${tag}-2-layout-${lay}`);
        const m = await page.evaluate(() => ({ ov: document.documentElement.scrollWidth > innerWidth || document.documentElement.scrollHeight > innerHeight + 1,
          w: [...document.querySelectorAll('.demo-panel')].map(p => Math.round(p.getBoundingClientRect().width)), h: [...document.querySelectorAll('.demo-panel')].map(p => Math.round(p.getBoundingClientRect().height)) }));
        ok(`${tag} 4 layout ${lay} tasma yok`, !m.ov, JSON.stringify(m));
        const io = [];
        for (const r of ROLES) { const o = await F(page, r).evaluate(() => [document.documentElement.scrollWidth, document.documentElement.clientWidth]); io.push(r + ':' + o.join('/')); }
        console.log('INFO ' + tag + ' ' + lay + ' iframe scrollW/clientW ' + io.join(' '));
      }
      for (const r of ['rocket', 'director']) {
        await page.click(`button[data-focus="${r}"]`); await sleep(400);
        await shot(page, `${tag}-3-focus-${r}`);
        ok(`${tag} 4 odak ${r} tasma yok`, !(await page.evaluate(() => document.documentElement.scrollWidth > innerWidth)));
        await page.click(`button[data-focus="${r}"]`); await sleep(200);
      }
      const reloaded = await page.evaluate(() => [...document.querySelectorAll('iframe')].some(f => !f.contentWindow.__marker));
      ok(`${tag} 4 iframe'ler yeniden yuklenmedi`, !reloaded);

      if (tag === 1366) { await ctx.close(); continue; }

      // 2. Tam tur
      const sol = SOL[mission.id];
      const add = async (role, id) => { await F(page, role).click(`[data-add="${id}"]`); await sleep(150); };
      for (const id of sol.rocket) await add('rocket', id);
      for (const id of sol.spacecraft) await add('spacecraft', id);
      for (const id of mission.requiredInstruments) await add('payload', id);
      await sleep(400);
      const dF = F(page, 'director');
      ok(`${tag} 2 geri alma dugmesi (rocket) etkin`, await dF.locator('button[data-undo="rocket"]').isEnabled());
      const before = await F(page, 'rocket').locator('#my-parts [data-remove]').count();
      await dF.click('button[data-undo="rocket"]'); await sleep(500);
      const after = await F(page, 'rocket').locator('#my-parts [data-remove]').count();
      ok(`${tag} 2 geri alma yonetici panelinden calisti`, after === before - 1, `${before}->${after}`);
      await add('rocket', sol.rocket[sol.rocket.length - 1]);
      await sleep(400);
      await shot(page, `${tag}-4-built`);
      await dF.waitForSelector('#poll-start-btn:not([disabled])', { timeout: 4000 }).catch(() => {});
      await dF.click('#poll-start-btn');
      ok(`${tag} 2 anket basladi (4 panel poll)`, await waitPhases(page, 'poll', 4000));
      await secScan('poll');
      await sleep(300); await shot(page, `${tag}-5-poll`);
      for (const r of ['rocket', 'spacecraft', 'payload']) await F(page, r).click('#vote-go-btn');
      ok(`${tag} 2 4 panel result`, await waitPhases(page, 'result', 10000));
      await sleep(300);
      for (const r of ROLES) await F(page, r).click('#skip-launch-btn', { timeout: 500 }).catch(() => {});
      await sleep(800);
      const succ = await Promise.all(ROLES.map(r => F(page, r).locator('#screen-result').getAttribute('data-success')));
      ok(`${tag} 2 dort panelde success`, succ.every(x => x === 'true'), succ.join(','));
      await shot(page, `${tag}-6-result`);
      const rb = dF.locator('#restart-btn');
      ok(`${tag} 2 yonetici panelinde Yeni tur gorunur`, await rb.isVisible());
      await rb.click();
      ok(`${tag} 2 yeni tur: 4 panel building`, await waitPhases(page, 'building', 6000));
      await shot(page, `${tag}-7-yeni-tur`);

      // 5. Yenileme
      await sleep(300);
      await page.reload(); await sleep(2500);
      const c2 = (await page.locator('#demo-code').innerText()).trim();
      ok(`${tag} 5 yenileme: ayni oda kodu`, c2 === code, c2 + ' vs ' + code);
      ok(`${tag} 5 yenileme: 4 panel building`, await waitPhases(page, 'building', 8000));
      const rr = {}; for (const r of ROLES) rr[r] = (await dstate(page, r)).you.role;
      ok(`${tag} 5 yenileme: roller ayni`, Object.entries(rr).every(([k, v]) => k === v), JSON.stringify(rr));
      await add('rocket', 'tank-small'); await sleep(300);
      await page.reload(); await sleep(2500);
      ok(`${tag} 5 yenileme sonrasi parca korunur`, (await F(page, 'rocket').locator('#my-parts [data-remove]').count()) === 1);
      await page.click('#demo-reset-btn'); await sleep(500);
      const srcs = await page.evaluate(() => [...document.querySelectorAll('iframe')].map(f => f.getAttribute('src')));
      ok(`${tag} 5 sifirla: iframe'ler bos, kod ----`, srcs.every(s => s === 'about:blank') && (await page.locator('#demo-code').innerText()).trim() === '----', srcs.join(','));
      await shot(page, `${tag}-8-sifirla`);
      await page.click('#demo-start-btn');
      ok(`${tag} 5 yeniden kur: building`, await waitPhases(page, 'building', 10000));
      const c3 = (await page.locator('#demo-code').innerText()).trim();
      ok(`${tag} 5 yeni oda kodu farkli`, c3 !== code && /^[A-Z0-9]{4}$/.test(c3), code + '->' + c3);
      await ctx.close();
    }

    // 6. Var olan odaya katılma
    console.log('===== join');
    const ctxN = await browser.newContext({ viewport: { width: 1600, height: 900 } });
    const pn = await ctxN.newPage(); hook(pn, 'normal');
    await pn.goto(URL + '/'); await pn.fill('#name-input', 'Gercek'); await pn.click('#create-btn');
    await pn.waitForSelector('#screen-lobby:not([hidden])');
    const jcode = (await pn.locator('#room-code').innerText()).trim();
    await pn.click('[data-role="director"]'); await sleep(300);
    const ctxD = await browser.newContext({ viewport: { width: 1600, height: 900 } });
    const dp = await ctxD.newPage(); hook(dp, 'demo-join');
    await dp.goto(URL + '/demo.html'); await sleep(300);
    await dp.fill('#demo-join-code', 'ZZZ9'); await dp.uncheck('input[data-demo-role="director"]'); await dp.click('#demo-join-btn'); await sleep(2500);
    console.log('INFO yanlis kod: error=', JSON.stringify(await dp.locator('#demo-error').innerText()), 'statuses=', JSON.stringify(await dp.locator('.demo-status').allInnerTexts()));
    const fr = F(dp, 'rocket');
    console.log('INFO yanlis kod iframe #error-msg=', JSON.stringify(fr ? await fr.locator('#error-msg').innerText().catch(() => '') : 'no-frame'));
    await shot(dp, '1600-9-yanlis-kod');
    await dp.click('#demo-reset-btn');
    await dp.uncheck('input[data-demo-role="director"]').catch(() => {});
    await dp.fill('#demo-join-code', jcode); await dp.click('#demo-join-btn');
    ok('6 join: 3 calisan building', await waitPhases(dp, 'building', 8000, ['rocket', 'spacecraft', 'payload']));
    const phTxt = await dp.locator('.demo-panel[data-role="director"] .demo-placeholder').innerText();
    ok('6 yonetici yerinde "telefonla katil: kod"', /telefonla/i.test(phTxt) && phTxt.includes(jcode), phTxt);
    ok('6 normal sayfa yonetici building', JSON.parse(await pn.locator('#debug-state').textContent()).phase === 'building');
    await shot(dp, '1600-10-join');
    await dp.click('#demo-reset-btn');
    await dp.check('input[data-demo-role="director"]');
    await dp.fill('#demo-join-code', jcode); await dp.click('#demo-join-btn'); await sleep(3000);
    console.log('INFO dolu rol: error=', JSON.stringify(await dp.locator('#demo-error').innerText()), 'statuses=', JSON.stringify(await dp.locator('.demo-status').allInnerTexts()));
    const fd = F(dp, 'director'); console.log('INFO dolu rol director iframe #error-msg=', JSON.stringify(fd ? await fd.locator('#error-msg').innerText().catch(() => '') : 'no-frame'));
    await shot(dp, '1600-11-dolu-rol');
    await ctxD.close();

    // 7. İki normal sekme ayrı oturum
    const ctx2 = await browser.newContext();
    const a = await ctx2.newPage(), b = await ctx2.newPage(); hook(a, 'nA'); hook(b, 'nB');
    await a.goto(URL + '/'); await b.goto(URL + '/');
    await a.fill('#name-input', 'A1'); await a.click('#create-btn'); await a.waitForSelector('#screen-lobby:not([hidden])');
    const ca = (await a.locator('#room-code').innerText()).trim();
    await b.fill('#name-input', 'B1'); await b.click('#create-btn'); await b.waitForSelector('#screen-lobby:not([hidden])');
    const cb = (await b.locator('#room-code').innerText()).trim();
    const sa = await a.evaluate(() => sessionStorage.getItem('pixelPayloadSession')), sb = await b.evaluate(() => sessionStorage.getItem('pixelPayloadSession'));
    ok('7 iki normal sekme ayri oturum kaydi (oda kodlari/oyuncu farkli)', !!sa && !!sb && sa !== sb && ca !== cb, ca + '/' + cb);
    const ldeb = JSON.parse(await a.locator('#debug-state').textContent()).code === ca && JSON.parse(await b.locator('#debug-state').textContent()).code === cb;
    ok('7 iki sekme kendi odasinda', ldeb);
    await ctx2.close(); await ctxN.close();
  } catch (e) { console.log('SCRIPT HATASI', e.stack); }
  console.log('--- ISSUES ---'); console.log(issues.length ? [...new Set(issues)].join('\n') : '(yok)');
  console.log('--- SERVER STDERR ---'); console.log(stderr || '(bos)');
  await browser.close(); srv.kill();
})();
