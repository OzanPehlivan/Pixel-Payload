// Tur 1 e2e testi. Playwright proje disinda kurulu: PW_DIR ortam degiskeni ile gosterilir.
const path = require('path');
const { spawn } = require('child_process');
const PW = process.env.PW_DIR;
const { chromium } = require(path.join(PW, 'node_modules', 'playwright'));
const missions = require('../../data/missions.json');
const ROOT = path.join(__dirname, '..', '..');
const PORT = 3101, URL = `http://localhost:${PORT}`;
const results = [];
const ok = (name, cond, extra) => { results.push({ name, pass: !!cond, extra }); console.log((cond ? 'PASS ' : 'FAIL ') + name + (extra ? ' :: ' + extra : '')); };
const sleep = (ms) => new Promise(r => setTimeout(r, ms));
const SHOT = process.env.SHOT_DIR;

(async () => {
  const srv = spawn('node', ['server/index.js'], { cwd: ROOT, env: { ...process.env, PORT: String(PORT) } });
  let stderr = '';
  srv.stderr.on('data', d => stderr += d);
  await sleep(1500);
  const browser = await chromium.launch();
  const issues = [];
  async function mk(name, viewport) {
    const ctx = await browser.newContext(viewport ? { viewport } : {});
    const page = await ctx.newPage();
    const p = { name, ctx, page, raw: [] };
    page.on('console', m => { if (m.type() === 'error') issues.push(`[${name}] console.error: ${m.text()} ${m.location().url}`); });
    page.on('pageerror', e => issues.push(`[${name}] pageerror: ${e.message}`));
    page.on('requestfailed', r => issues.push(`[${name}] requestfailed: ${r.url()} ${r.failure() && r.failure().errorText}`));
    page.on('websocket', ws => { ws.on('framereceived', f => p.raw.push(String(f.payload))); });
    page.on('response', async r => {
      if (r.url().includes('/socket.io/')) { try { p.raw.push(await r.text()); } catch (e) {} }
      if (r.status() >= 400 && !r.url().includes('/socket.io/')) issues.push(`[${name}] HTTP ${r.status()} ${r.url()}`);
    });
    await page.goto(URL);
    await page.waitForSelector('#screen-entry:not([hidden])');
    return p;
  }
  const err = (p) => p.page.locator('#error-msg').innerText();
  const vis = (p, sel) => p.page.locator(sel).isVisible();
  const sess = (p) => p.page.evaluate(() => JSON.parse(sessionStorage.getItem('pixelPayloadSession') || 'null'));
  const create = async (p, name) => { await p.page.fill('#name-input', name); await p.page.click('#create-btn'); };
  const join = async (p, name, code) => { await p.page.fill('#name-input', name); await p.page.fill('#code-input', code); await p.page.click('#join-btn'); };
  const role = (p, r) => p.page.click(`[data-role="${r}"]`);
  const lobbyShown = (p) => p.page.waitForSelector('#screen-lobby:not([hidden])', { timeout: 3000 });

  try {
    // 2
    const A = await mk('A');
    await A.page.fill('#name-input', ''); await A.page.click('#create-btn'); await sleep(400);
    const e1 = await err(A); ok('2a bos isim -> hata mesaji', e1.length > 0, e1);
    await A.page.fill('#name-input', '   '); await A.page.click('#create-btn'); await sleep(300);
    ok('2a2 bosluk isim -> hata', (await err(A)).length > 0);
    await create(A, 'Ayse'); await lobbyShown(A);
    const code = (await A.page.locator('#room-code').innerText()).trim();
    ok('2b lobi + 4 harfli kod I/O icermez', /^[A-HJ-NP-Z]{4}$/.test(code), code);
    ok('2c hata temizlendi', (await err(A)) === '', await err(A));
    // 3
    const B = await mk('B'); await join(B, 'Burak', code.toLowerCase());
    await lobbyShown(B).then(() => ok('3a kucuk harfli kodla katilma', true), async () => ok('3a kucuk harfli kodla katilma', false, await err(B)));
    const X = await mk('X'); await join(X, 'Xx', 'ZZZZ'); await sleep(400);
    ok('3b yanlis kod -> hata', (await err(X)).length > 0 && await vis(X, '#screen-entry'), await err(X));
    const C = await mk('C'); await join(C, 'Cem', code); await lobbyShown(C);
    const D = await mk('D'); await join(D, 'Deniz', code); await lobbyShown(D);
    const E = await mk('E'); await join(E, 'Emre', code); await sleep(400);
    const eE = await err(E);
    ok('3c 5. oyuncu -> hata, giris ekraninda kalir', eE.length > 0 && await vis(E, '#screen-entry'), eE);
    const codes = await E.page.evaluate((c) => new Promise(res => {
      const s = io(); const out = {};
      s.on('connect', () => s.emit('room:join', { code: c, name: 'Z' }, r1 => { out.full = r1;
        s.emit('room:join', { code: 'ZZZZ', name: 'Z' }, r2 => { out.nf = r2;
          s.emit('room:create', { name: 'x'.repeat(17) }, r4 => { out.long = r4;
            s.emit('room:create', { name: 'x'.repeat(16) }, r5 => { out.ok16 = r5; s.close(); res(out); }); }); }); }));
    }), code);
    ok('3d hata kodlari ROOM_FULL/ROOM_NOT_FOUND', codes.full.error === 'ROOM_FULL' && codes.nf.error === 'ROOM_NOT_FOUND', JSON.stringify(codes.full) + JSON.stringify(codes.nf));
    ok('3e 17 karakter isim reddedilir, 16 kabul', codes.long.ok === false && codes.ok16.ok === true, JSON.stringify(codes.long));
    // 4
    await role(A, 'director'); await sleep(300);
    const dis = await B.page.locator('[data-role="director"]').isDisabled();
    const txt = await B.page.locator('[data-role="director"]').innerText();
    ok('4a alinmis rol digerinde devre disi + isim yaziyor', dis && txt.includes('Ayse'), txt);
    ok('4b alinmamis rol acik', !(await B.page.locator('[data-role="rocket"]').isDisabled()));
    await B.page.evaluate(() => { const b = document.querySelector('[data-role="director"]'); b.disabled = false; b.click(); });
    await sleep(300);
    const rt = { error: (await err(B)).includes('başka') ? 'ROLE_TAKEN' : await err(B) };
    ok('4c ROLE_TAKEN ack', rt && rt.error === 'ROLE_TAKEN', JSON.stringify(rt));
    await role(A, 'director'); await sleep(300);
    ok('4d kendi rolune tekrar basinca birakir', !(await B.page.locator('[data-role="director"]').isDisabled()));
    await role(A, 'rocket'); await sleep(200); await role(A, 'director'); await sleep(300);
    ok('4e rol degistirme', !(await B.page.locator('[data-role="rocket"]').isDisabled()) && await B.page.locator('[data-role="director"]').isDisabled());
    // 8 leave
    await role(C, 'payload'); await sleep(200);
    await C.page.click('#leave-btn'); await sleep(400);
    ok('8a leave -> giris ekrani', await vis(C, '#screen-entry'));
    const lst = await A.page.locator('#player-list').innerText();
    ok('8b leave -> listeden dustu, rolu bosaldi', !lst.includes('Cem') && !(await A.page.locator('[data-role="payload"]').isDisabled()), lst);
    await join(C, 'Cem', code); await lobbyShown(C);
    // 7 lobide yenileme
    await D.page.reload(); await sleep(800);
    ok('7a lobide yenileme -> giris ekrani', await vis(D, '#screen-entry'), 'err=' + await err(D));
    const lst2 = await A.page.locator('#player-list').innerText();
    ok('7b lobide yenileyen listeden dustu', !lst2.includes('Deniz'), lst2);
    await join(D, 'Deniz', code); await lobbyShown(D);
    // 5
    await role(B, 'rocket'); await role(C, 'spacecraft'); await role(D, 'payload'); await sleep(800);
    for (const p of [A, B, C, D]) ok(`5a ${p.name} oyun ekrani`, await vis(p, '#screen-game') && !(await vis(p, '#screen-lobby')));
    ok('5b yonetici mission/telemetry/log gorunur', await vis(A, '#mission-box') && await vis(A, '#telemetry-box') && await vis(A, '#log-box'));
    const mtxt = await A.page.locator('#mission-box').innerText();
    const shown = missions.find(m => mtxt.includes(m.title));
    ok('5c yonetici gorev karti missions.json ile eslesir', shown && mtxt.includes(String(shown.requiredDeltaV)) && mtxt.includes(shown.target) && shown.requiredInstruments.every(i => mtxt.includes(i)), mtxt.slice(0, 300).replace(/\n/g, ' | '));
    const ltxt = await A.page.locator('#log-box').innerText();
    ok('5d log "Oyun basladi"', /Oyun başladı/.test(ltxt), ltxt.replace(/\n/g, ' | '));
    console.log('telemetri:', (await A.page.locator('#telemetry-box').innerText()).replace(/\n/g, ' | '));
    for (const p of [B, C, D]) {
      const hid = !(await vis(p, '#mission-box')) && !(await vis(p, '#telemetry-box')) && !(await vis(p, '#log-box'));
      ok(`5e ${p.name} calisan: kutular gizli`, hid);
      const ml = await p.page.locator('#mission-label').innerText();
      ok(`5f ${p.name} "Gorev: GIZLI"`, ml.includes('GİZLİ'), ml);
    }
    // 6
    await sleep(500);
    const ids = {}; for (const p of [A, B, C, D]) ids[p.name] = (await sess(p)).playerId;
    const forbidden = [];
    for (const m of missions) forbidden.push(m.title, m.target, m.nasaFact, m.nasaReal, ...m.requiredInstruments, String(m.requiredDeltaV));
    const keyPat = ['"telemetry"', '"mission"', '"log"', 'undoLeft', '"build"', 'nasaFact', 'requiredDeltaV', 'requiredInstruments', '"budget"', 'massKg', 'deltaV'];
    for (const p of [B, C, D]) {
      const dbg = await p.page.locator('#debug-state').textContent();
      const all = p.raw.join('\n') + '\n' + dbg + '\n' + await p.page.content();
      const hits = [];
      forbidden.forEach(f => { if (all.includes(f)) hits.push('deger:' + f.slice(0, 30)); });
      keyPat.forEach(k => { if (all.includes(k)) hits.push('anahtar:' + k); });
      for (const n of Object.keys(ids)) if (n !== p.name && all.includes(ids[n])) hits.push('playerId:' + n);
      ok(`6a ${p.name} calisan verisi sizintisiz`, hits.length === 0, `raw=${p.raw.length} kayit; ` + hits.join(','));
      ok(`6a' ${p.name} ham veri toplandi (missionLabel var)`, p.raw.some(r => r.includes('missionLabel')), `raw=${p.raw.length}`);
    }
    {
      const all = A.raw.join('\n') + (await A.page.locator('#debug-state').textContent());
      const hits = Object.keys(ids).filter(n => n !== 'A' && all.includes(ids[n]));
      ok('6b yonetici verisinde baska playerId yok', hits.length === 0, hits.join(','));
      ok('6c yonetici ham verisi mission iceriyor', A.raw.some(r => r.includes('requiredDeltaV')), `raw=${A.raw.length}`);
      const st = JSON.parse(await A.page.locator('#debug-state').textContent());
      ok('6d yonetici log girdilerinde playerId yok', st.log.every(e => !('playerId' in e)), JSON.stringify(st.log[0]));
    }
    // 8c
    const F = await mk('F'); await join(F, 'Fatma', code); await sleep(400);
    ok('8c baslamis oyuna katilamaz', (await vis(F, '#screen-entry')) && (await err(F)).length > 0, await err(F));
    const gs = await F.page.evaluate((c) => new Promise(res => { const s = io(); s.on('connect', () => s.emit('room:join', { code: c, name: 'F' }, r => { s.close(); res(r); })); }), code);
    ok('8d GAME_STARTED kodu', gs.error === 'GAME_STARTED', JSON.stringify(gs));
    // 7 oyunda yenileme
    const bBefore = await B.page.locator('#role-name').innerText();
    await B.page.reload();
    await B.page.waitForSelector('#screen-game:not([hidden])', { timeout: 4000 }).then(() => ok('7c yenileme -> oyuna geri doner', true), () => ok('7c yenileme -> oyuna geri doner', false));
    ok('7d ayni rol', (await B.page.locator('#role-name').innerText()) === bBefore, bBefore);
    await sleep(500);
    const lC = await C.page.locator('#player-list').innerText();
    ok('7e yenileme sonrasi kimse "koptu" gorunmuyor', !lC.includes('bağlantı koptu'), lC);
    const cB = await sess(B);
    ok('7e2 yenileme sonrasi sessionStorage korunur', !!cB, JSON.stringify(cB));
    // B'yi kapatmadan once disconnect gorunurlugu: sayfayi kapat
    await B.page.close(); await sleep(500);
    const lC2 = await C.page.locator('#player-list').innerText();
    ok('7f sayfa kapaninca digerlerinde [baglanti koptu]', lC2.includes('bağlantı koptu'), lC2);
    const B2 = await B.ctx.newPage();
    await B2.goto(URL); await sleep(400);
    const rj = await B2.evaluate((s) => new Promise(res => { const so = io(); window.__s = so; so.on('connect', () => so.emit('room:rejoin', s, r => res(r))); }), cB);
    ok('7h rejoin ack ok', rj.ok === true, JSON.stringify(rj));
    await sleep(300);
    ok('7i rejoin sonrasi koptu kalkti', !(await C.page.locator('#player-list').innerText()).includes('bağlantı koptu'));
    const rr = await B2.evaluate(() => new Promise(res => window.__s.emit('role:select', { role: 'payload' }, res)));
    ok('8e oyun basladiktan sonra rol degismez', rr.ok === false, JSON.stringify(rr));
    // 9
    const bad = await C.page.evaluate(() => new Promise(res => {
      const s = io(); const out = [];
      s.on('connect', () => {
        const cases = [['room:join', 5], ['room:join', null], ['room:join', {}], ['room:join', 'str'], ['room:join', [1, 2]], ['room:join', { code: 123, name: {} }], ['room:create', null], ['room:create', { name: { a: 1 } }], ['room:create', 5], ['room:rejoin', { code: 1, playerId: 2 }], ['room:rejoin', null], ['role:select', { role: 'hacker' }], ['role:select', null], ['role:select', { role: 5 }], ['role:select', { role: {} }], ['role:select', {}], ['role:select', undefined], ['room:leave', null]];
        let i = 0;
        const next = () => {
          if (i >= cases.length) {
            for (const [e, p] of cases) s.emit(e, p);
            s.emit('room:join'); s.emit('room:create', () => {}); s.emit('role:select'); s.emit('room:unknown', 1);
            setTimeout(() => { s.close(); res(out); }, 500); return;
          }
          const [e, p] = cases[i++]; let done = false;
          const t = setTimeout(() => { if (!done) { out.push([e, JSON.stringify(p), 'TIMEOUT']); next(); } }, 800);
          s.emit(e, p, r => { done = true; clearTimeout(t); out.push([e, JSON.stringify(p), JSON.stringify(r)]); next(); });
        };
        next();
      });
    }));
    const timeouts = bad.filter(b => b[2] === 'TIMEOUT');
    ok('9a bozuk payload: hepsi ack alir', timeouts.length === 0, JSON.stringify(timeouts));
    console.log('9 detay:', JSON.stringify(bad));
    await sleep(300);
    const alive = await fetch(URL).then(r => r.status).catch(() => 0);
    ok('9b sunucu ayakta', alive === 200 && srv.exitCode === null, 'status=' + alive);
    ok('9c stderr istisna yok', stderr.trim() === '', stderr.slice(0, 600));
    // 10
    const M = await mk('M', { width: 375, height: 812 });
    const ovf = (p) => p.page.evaluate(() => ({ sw: document.documentElement.scrollWidth, cw: document.documentElement.clientWidth }));
    let o = await ovf(M); ok('10a mobil giris: yatay tasma yok', o.sw <= o.cw, JSON.stringify(o));
    if (SHOT) await M.page.screenshot({ path: path.join(SHOT, 'mobile-entry.png'), fullPage: true });
    await create(M, 'Mobil'); await lobbyShown(M);
    const mc = (await M.page.locator('#room-code').innerText()).trim();
    o = await ovf(M); ok('10b mobil lobi: yatay tasma yok', o.sw <= o.cw, JSON.stringify(o));
    const bb = await M.page.locator('[data-role="director"]').boundingBox();
    ok('10c rol butonu ekranda, >=40px yuksek', bb && bb.x >= 0 && bb.x + bb.width <= 375 && bb.height >= 40, JSON.stringify(bb));
    if (SHOT) await M.page.screenshot({ path: path.join(SHOT, 'mobile-lobby.png'), fullPage: true });
    const M2 = await mk('M2', { width: 375, height: 812 }), M3 = await mk('M3', { width: 375, height: 812 }), M4 = await mk('M4', { width: 375, height: 812 });
    await join(M2, 'm2', mc); await join(M3, 'm3', mc); await join(M4, 'm4', mc);
    await lobbyShown(M2); await lobbyShown(M4);
    await role(M, 'director'); await role(M2, 'rocket'); await role(M3, 'spacecraft'); await role(M4, 'payload'); await sleep(700);
    ok('10d mobil 4 oyuncu oyun basladi', await vis(M, '#screen-game') && await vis(M4, '#screen-game'));
    for (const p of [M, M2]) { o = await ovf(p); ok(`10e ${p.name} oyun ekrani tasma yok`, o.sw <= o.cw, JSON.stringify(o)); }
    if (SHOT) { await M.page.screenshot({ path: path.join(SHOT, 'mobile-game-director.png'), fullPage: true }); await M2.page.screenshot({ path: path.join(SHOT, 'mobile-game-worker.png'), fullPage: true }); }
    ok('9d stderr hala temiz', stderr.trim() === '', stderr.slice(0, 600));
  } catch (e) { console.log('SCRIPT ERROR', e); ok('script calisti', false, e.message); }
  console.log('\n=== ISSUES (console/pageerror/netfail) ===\n' + (issues.join('\n') || 'yok'));
  console.log('\nstderr:', stderr || '(bos)');
  await browser.close();
  srv.kill();
  console.log('\nFAILS:', results.filter(r => !r.pass).map(r => r.name).join(' | ') || 'yok');
  process.exit(0);
})();
