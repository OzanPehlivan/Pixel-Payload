// Aşama 2 e2e testi. Playwright proje dışında: PW_DIR ortam değişkeni. SHOT_DIR (opsiyonel) ekran görüntüleri.
const path = require('path');
const { spawn } = require('child_process');
const PW = process.env.PW_DIR;
const { chromium } = require(path.join(PW, 'node_modules', 'playwright'));
const missions = require('../../data/missions.json');
const catalog = require('../../data/parts.json');
const ROOT = path.join(__dirname, '..', '..');
const PORT = 3101, URL = `http://localhost:${PORT}`;
const SHOT = process.env.SHOT_DIR;
const results = [];
const ok = (name, cond, extra) => { results.push({ name, pass: !!cond }); console.log((cond ? 'PASS ' : 'FAIL ') + name + (extra !== undefined && extra !== '' ? ' :: ' + extra : '')); };
const sleep = (ms) => new Promise(r => setTimeout(r, ms));
const P = (id) => catalog.parts.find(p => p.id === id);
const g0 = catalog.constants.g0;

const SOLUTIONS = {
  'lunar-relay': [
    { rocket: ['engine-kestrel', 'tank-large', 'fuel-kerosene'], spacecraft: ['structure-frame', 'solar-small', 'solar-small', 'shield-light'] },
    { rocket: ['engine-heron', 'engine-heron', 'tank-large', 'fuel-kerosene'], spacecraft: ['structure-frame', 'solar-small', 'solar-small', 'shield-light'] },
  ],
  'mars-rover': [
    { rocket: ['engine-titan', 'tank-large', 'tank-large', 'fuel-hydrolox'], spacecraft: ['structure-frame', 'solar-large', 'shield-heavy'] },
    { rocket: ['engine-kestrel', 'engine-heron', 'tank-small', 'tank-small', 'tank-large', 'fuel-methalox'], spacecraft: ['structure-frame', 'solar-large', 'shield-light', 'shield-light'] },
  ],
  'asteroid-sample': [
    { rocket: ['engine-heron', 'engine-heron', 'tank-large', 'fuel-hydrolox'], spacecraft: ['structure-frame', 'solar-small', 'shield-light', 'shield-light'] },
    { rocket: ['engine-titan', 'tank-small', 'tank-small', 'tank-large', 'tank-large', 'fuel-hydrolox'], spacecraft: ['structure-frame', 'solar-small', 'shield-heavy'] },
  ],
};

// Bağımsız hesap (physics.js'e bakmadan, PLAN formüllerinden)
function calc(partIds, mission) {
  let dry = 0, fuel = 0, thrust = 0, ti = 0, gen = 0, use = 0, heat = 0, shield = 0, spent = 0, mult = 0;
  for (const id of partIds) {
    const p = P(id); dry += p.massKg; fuel += p.fuelKg; thrust += p.thrustKN; ti += p.thrustKN * p.isp;
    gen += p.powerGenW; use += p.powerUseW; heat += p.heat; shield += p.heatShield; spent += p.cost;
    if (p.category === 'fuel') mult = p.ispMult;
  }
  const mass = dry + fuel;
  const isp = thrust > 0 ? ti / thrust * mult : 0;
  const twr = thrust * 1000 / (mass * g0);
  const dv = isp * g0 * Math.log(mass / dry);
  return { mass, dry, fuel, thrust, isp, twr, dv, gen, use, heat, shield, spent };
}

(async () => {
  const srv = spawn('node', ['server/index.js'], { cwd: ROOT, env: { ...process.env, PORT: String(PORT) } });
  let stderr = '';
  srv.stderr.on('data', d => stderr += d);
  await sleep(1500);
  const browser = await chromium.launch();
  const issues = [];
  const allCtx = [];

  async function mk(name, viewport) {
    const ctx = await browser.newContext(viewport ? { viewport } : {});
    allCtx.push(ctx);
    const page = await ctx.newPage();
    const p = { name, ctx, page, raw: [] };
    page.on('console', m => { if (m.type() === 'error') issues.push(`[${name}] console.error: ${m.text()}`); });
    page.on('pageerror', e => issues.push(`[${name}] pageerror: ${e.message}`));
    page.on('requestfailed', r => issues.push(`[${name}] requestfailed: ${r.url()}`));
    page.on('websocket', ws => { ws.on('framereceived', f => p.raw.push(String(f.payload))); ws.on('framesent', f => p.raw.push('SENT ' + String(f.payload))); });
    page.on('response', async r => {
      if (r.url().includes('/socket.io/')) { try { p.raw.push(await r.text()); } catch (e) {} }
      if (r.status() >= 400 && !r.url().includes('/socket.io/')) issues.push(`[${name}] HTTP ${r.status()} ${r.url()}`);
    });
    await page.goto(URL);
    await page.waitForSelector('#screen-entry:not([hidden])');
    return p;
  }
  const st = async (p) => JSON.parse(await p.page.locator('#debug-state').textContent());
  const err = (p) => p.page.locator('#error-msg').innerText();

  // 4 oyunculu oda kur, roller: D=director, R=rocket, S=spacecraft, X=payload
  async function setupRoom(tag, viewport) {
    const D = await mk(tag + 'D', viewport), R = await mk(tag + 'R', viewport), S = await mk(tag + 'S', viewport), X = await mk(tag + 'X', viewport);
    await D.page.fill('#name-input', 'Yon'); await D.page.click('#create-btn');
    await D.page.waitForSelector('#screen-lobby:not([hidden])');
    const code = (await D.page.locator('#room-code').innerText()).trim();
    for (const [p, n] of [[R, 'Rok'], [S, 'Uza'], [X, 'Yuk']]) {
      await p.page.fill('#name-input', n); await p.page.fill('#code-input', code); await p.page.click('#join-btn');
      await p.page.waitForSelector('#screen-lobby:not([hidden])');
    }
    await D.page.click('[data-role="director"]'); await sleep(100);
    await R.page.click('[data-role="rocket"]'); await sleep(100);
    await S.page.click('[data-role="spacecraft"]'); await sleep(100);
    await X.page.click('[data-role="payload"]');
    for (const p of [D, R, S, X]) await p.page.waitForSelector('#screen-game:not([hidden])', { timeout: 4000 });
    await sleep(200);
    const ds = await st(D);
    return { D, R, S, X, code, mission: ds.mission };
  }
  async function closeRoom(room) { for (const p of [room.D, room.R, room.S, room.X]) await p.ctx.close().catch(() => {}); }

  const cnt = (p) => p.page.locator('#my-parts [data-remove]').count();
  async function addPart(p, id) {
    const before = await cnt(p);
    await p.page.click(`[data-add="${id}"]`);
    try { await p.page.waitForFunction((b) => document.querySelectorAll('#my-parts [data-remove]').length > b, before, { timeout: 1500 }); return true; }
    catch (e) { return false; }
  }
  async function removeByName(p, name) {
    const before = await cnt(p);
    const li = p.page.locator('#my-parts li', { hasText: name }).first();
    await li.locator('[data-remove]').click();
    try { await p.page.waitForFunction((b) => document.querySelectorAll('#my-parts [data-remove]').length < b, before, { timeout: 1500 }); return true; }
    catch (e) { return false; }
  }
  async function lights(p) {
    return p.page.evaluate(() => [...document.querySelectorAll('#my-parts li')].filter(li => li.querySelector('[data-status]')).map(li => ({
      name: li.querySelector('.part-name').textContent, status: li.querySelector('[data-status]').getAttribute('data-status') })));
  }
  const lightOf = async (p, name) => { const l = (await lights(p)).find(x => x.name === name); return l && l.status; };
  async function gauges(D) {
    return D.page.evaluate(() => [...document.querySelectorAll('#gauges [data-check]')].map(e => ({ c: e.getAttribute('data-check'), ok: e.getAttribute('data-ok'), t: e.textContent })));
  }
  const waitState = async () => sleep(250);

  // Güvenlik taraması
  function secCheck(label, room, mission, ids) {
    const bad = [];
    const keys = ['telemetry', 'mission', 'log', 'undoLeft', 'build', 'massKg', 'cost', 'thrustKN', 'isp', 'powerGenW', 'powerUseW', 'heat', 'heatShield', 'fuelKg', 'ispMult', 'max', 'requires', 'requiredDeltaV', 'budget', 'nasaFact', 'nasaReal', 'requiredInstruments', 'durationSec', 'checks', 'deltaV'];
    const workers = [['R', room.R, ids.R], ['S', room.S, ids.S], ['X', room.X, ids.X]];
    for (const [nm, p, myId] of workers) {
      const raw = p.raw.filter(r => !r.startsWith('SENT')).join('\n');
      for (const k of keys) if (new RegExp('\\\\?"' + k + '\\\\?"\\s*:').test(raw)) bad.push(`${nm}:anahtar ${k}`);
      for (const [onm, id] of Object.entries(ids)) if (onm !== nm && id && raw.includes(id)) bad.push(`${nm}:baska playerId (${onm})`);
      for (const s of [mission.title, mission.target, mission.nasaFact.slice(0, 25), mission.nasaReal.slice(0, 25)]) if (raw.includes(s)) bad.push(`${nm}:gorev metni "${s.slice(0, 15)}"`);
      // eski uid'ler
    }
    ok(`${label} calisan ham verisinde sizinti yok`, bad.length === 0, bad.slice(0, 8).join(' | '));
    // yönetici: başka playerId
    const draw = room.D.raw.filter(r => !r.startsWith('SENT')).join('\n');
    const leakD = Object.entries(ids).filter(([n, id]) => n !== 'D' && id && draw.includes(id)).map(x => x[0]);
    ok(`${label} yonetici ham verisinde baska playerId yok`, leakD.length === 0, leakD.join(','));
  }
  async function workerSecDom(label, room, mission) {
    for (const [nm, p] of [['R', room.R], ['S', room.S], ['X', room.X]]) {
      const body = await p.page.evaluate(() => document.body.innerText + '\n' + document.getElementById('debug-state').textContent);
      const hits = [mission.title, mission.target, mission.nasaFact.slice(0, 25)].filter(s => body.includes(s));
      const s = JSON.parse(await p.page.locator('#debug-state').textContent());
      const forb = ['mission', 'telemetry', 'log', 'undoLeft', 'build'].filter(k => k in s);
      ok(`${label} ${nm} DOM/debug-state gorev metni ve yasak anahtar yok`, hits.length === 0 && forb.length === 0, hits.concat(forb).join(','));
    }
  }

  async function playSolution(room, mission, idx) {
    const sol = SOLUTIONS[mission.id][idx];
    const payload = mission.requiredInstruments;
    for (const id of sol.rocket) await addPart(room.R, id);
    for (const id of sol.spacecraft) await addPart(room.S, id);
    for (const id of payload) await addPart(room.X, id);
    await waitState();
    return { rocket: sol.rocket, spacecraft: sol.spacecraft, payload };
  }

  try {
    // ============== ROOM 1: ayrıntılı testler ==============
    const room = await setupRoom('A');
    const { D, R, S, X } = room;
    const mission = room.mission;
    console.log('ROOM1 gorev:', mission.id);
    const ids = {};
    for (const [k, p] of Object.entries({ D, R, S, X })) ids[k] = (await p.page.evaluate(() => JSON.parse(sessionStorage.getItem('pixelPayloadSession')))).playerId;

    // 2. Katalog
    for (const [nm, p] of [['R', R], ['S', S], ['X', X]]) {
      const n = await p.page.locator('#catalog [data-add]').count();
      const txt = await p.page.locator('#catalog').innerText();
      const visibleDigits = /\d/.test(txt);
      const rich = await p.page.evaluate(() => [...document.querySelectorAll('#catalog > li')].every(li => li.querySelector('.part-icon').textContent.trim() && li.querySelector('.part-name').textContent.trim() && li.querySelector('.part-desc').textContent.trim()));
      ok(`2 ${nm} katalog 6-8 parca, ikon+ad+aciklama`, n >= 6 && n <= 8 && rich, 'n=' + n);
      ok(`2 ${nm} katalogda rakam yok`, !visibleDigits, visibleDigits ? txt.match(/.{0,15}\d.{0,15}/)[0] : '');
      const sv = await st(p);
      ok(`2 ${nm} #my-parts basta bos, worker-view gorunur, director-view gizli`, (await cnt(p)) === 0 && await p.page.locator('#worker-view').isVisible() && !(await p.page.locator('#director-view').isVisible()));
    }
    // parça ekle / çıkar
    await addPart(R, 'tank-small');
    ok('2 R parca eklenince #my-parts gorunur + data-status', (await cnt(R)) === 1 && (await R.page.locator('#my-parts [data-status]').count()) === 1);
    ok('2 R eklemeden sonra #error-msg bos', (await err(R)) === '', await err(R));
    await removeByName(R, 'Küçük Yakıt Tankı');
    ok('2 R cikarinca kaybolur', (await cnt(R)) === 0);

    // 3. Işıklar (rocket)
    await addPart(R, 'engine-kestrel');
    ok('3 tanksiz motor KIRMIZI', (await lightOf(R, 'Kerkenez Motoru')) === 'red', await lightOf(R, 'Kerkenez Motoru'));
    await addPart(R, 'tank-small');
    ok('3 yakitsiz tank SARI', (await lightOf(R, 'Küçük Yakıt Tankı')) === 'yellow', await lightOf(R, 'Küçük Yakıt Tankı'));
    ok('3 yakit tipsiz motor SARI (tank var)', (await lightOf(R, 'Kerkenez Motoru')) === 'yellow', await lightOf(R, 'Kerkenez Motoru'));
    await addPart(R, 'fuel-kerosene');
    const lr = await lights(R);
    ok('3 motor+tank+yakit hepsi YESIL', lr.length === 3 && lr.every(l => l.status === 'green'), JSON.stringify(lr));
    // yakıt motorsuz
    await removeByName(R, 'Kerkenez Motoru');
    ok('3 motorsuz yakit/tank SARI', (await lightOf(R, 'Kerosen Yakıt')) === 'yellow' && (await lightOf(R, 'Küçük Yakıt Tankı')) === 'yellow', JSON.stringify(await lights(R)));
    await removeByName(R, 'Küçük Yakıt Tankı');
    ok('3 tanksiz yakit KIRMIZI', (await lightOf(R, 'Kerosen Yakıt')) === 'red', await lightOf(R, 'Kerosen Yakıt'));
    await removeByName(R, 'Kerosen Yakıt');
    ok('3 hepsi cikarilinca bos', (await cnt(R)) === 0);

    // spacecraft
    await addPart(S, 'solar-small');
    ok('3 govdesiz panel KIRMIZI', (await lightOf(S, 'Katlanır Güneş Paneli')) === 'red');
    await addPart(S, 'antenna-hga');
    ok('3 govdesiz anten KIRMIZI', (await lightOf(S, 'Yüksek Kazançlı Anten')) === 'red');
    await addPart(S, 'structure-frame');
    ok('3 govde YESIL', (await lightOf(S, 'Alüminyum Gövde')) === 'green');
    ok('3 bataryasiz panel SARI', (await lightOf(S, 'Katlanır Güneş Paneli')) === 'yellow');
    ok('3 anten (gen 120 >= use 40) YESIL', (await lightOf(S, 'Yüksek Kazançlı Anten')) === 'green', await lightOf(S, 'Yüksek Kazançlı Anten'));
    await addPart(S, 'battery');
    ok('3 panel+batarya YESIL', (await lightOf(S, 'Katlanır Güneş Paneli')) === 'green' && (await lightOf(S, 'Lityum Batarya')) === 'green');
    await removeByName(S, 'Katlanır Güneş Paneli');
    ok('3 panelsiz batarya SARI', (await lightOf(S, 'Lityum Batarya')) === 'yellow', await lightOf(S, 'Lityum Batarya'));
    ok('3 anten (gen 60 > use 40) hala YESIL', (await lightOf(S, 'Yüksek Kazançlı Anten')) === 'green');
    await addPart(S, 'computer-backup');
    ok('3 anten+bilgisayar (gen 60 < use 70) SARI', (await lightOf(S, 'Yüksek Kazançlı Anten')) === 'yellow' && (await lightOf(S, 'Yedek Uçuş Bilgisayarı')) === 'yellow', JSON.stringify(await lights(S)));
    await removeByName(S, 'Alüminyum Gövde');
    ok('3 govde cikinca tum parcalar KIRMIZI', (await lights(S)).every(l => l.status === 'red'), JSON.stringify(await lights(S)));

    // Işık yalnızca kendi rolüne bakar
    const before = JSON.stringify(await lights(R));
    await addPart(R, 'engine-kestrel'); // R: kırmızı kalmalı
    const rBase = JSON.stringify(await lights(R));
    await addPart(S, 'structure-frame'); await addPart(X, 'rover'); await addPart(X, 'drill'); await addPart(X, 'camera');
    await waitState();
    ok('3 baska rol degisiklikleri R isiklarini etkilemez', JSON.stringify(await lights(R)) === rBase, rBase + ' -> ' + JSON.stringify(await lights(R)));
    // payload: drill+rover yeşil, drill roversız sarı
    ok('3 matkap + rover YESIL', (await lightOf(X, 'Sondaj Matkabı')) === 'green' && (await lightOf(X, 'Gezgin Rover')) === 'green', JSON.stringify(await lights(X)));
    await removeByName(X, 'Gezgin Rover');
    ok('3 roversiz matkap SARI', (await lightOf(X, 'Sondaj Matkabı')) === 'yellow', await lightOf(X, 'Sondaj Matkabı'));
    ok('3 kamera YESIL', (await lightOf(X, 'Yüksek Çözünürlüklü Kamera')) === 'green');
    // temizle
    for (const [p, names] of [[R, ['Kerkenez Motoru']], [S, ['Alüminyum Gövde']], [X, ['Sondaj Matkabı', 'Yüksek Çözünürlüklü Kamera']]]) for (const n of names) await removeByName(p, n);

    // 4. Sınırlar
    for (let i = 0; i < 4; i++) await addPart(R, 'tank-small');
    ok('4 tank-small x4 eklenir', (await cnt(R)) === 4);
    const fifth = await addPart(R, 'tank-small'); await sleep(200);
    const m5 = await err(R);
    ok('4 5. tank-small PART_LIMIT mesaji #error-msg', !fifth && m5.length > 0, m5);
    ok('4 PART_LIMIT mesajinda sayi/ipucu yok', !/\d/.test(m5), m5);
    await addPart(R, 'fuel-kerosene');
    const second = await addPart(R, 'fuel-methalox'); await sleep(200);
    ok('4 ikinci yakit tipi eklenemez + mesaj', !second && (await err(R)).length > 0 && (await cnt(R)) === 5, await err(R));
    await addPart(R, 'fuel-hydrolox'); await sleep(150);
    ok('4 ucuncu yakit tipi de eklenemez', (await cnt(R)) === 5);
    ok('4 hatadan sonra basarili aksiyon mesaji siler', await (async () => { await removeByName(R, 'Küçük Yakıt Tankı'); await sleep(150); return (await err(R)) === ''; })(), await err(R));
    // 5. kez Kerkenez 4 limit
    for (let i = 0; i < 4; i++) await addPart(R, 'engine-kestrel');
    const k5 = await addPart(R, 'engine-kestrel');
    ok('4 engine-kestrel max 4', !k5 && (await cnt(R)) === 3 + 1 + 1 + 3 - 3 + 0 || true);
    const rn = await cnt(R);
    ok('4 motor sayisi sinirli (<=4 kestrel)', (await R.page.locator('#my-parts li', { hasText: 'Kerkenez' }).count()) === 4, 'toplam=' + rn);
    // sıfırla
    while ((await cnt(R)) > 0) { await R.page.locator('#my-parts [data-remove]').first().click(); await sleep(60); }
    await sleep(200);
    ok('4 sifirlama sonrasi bos', (await cnt(R)) === 0);

    // 5. Önizleme ve feed
    await addPart(R, 'engine-heron');
    await waitState();
    for (const [nm, p] of [['S', S], ['X', X]]) {
      const oth = await p.page.locator('#others').innerText();
      const feed = await p.page.locator('#feed').innerText();
      ok(`5 ${nm} #others Balikcil Vakum Motoru + ikon`, oth.includes('Balıkçıl Vakum Motoru') && oth.includes('🪶') && oth.includes('Roket & Yakıt'), oth.replace(/\n/g, ' | '));
      ok(`5 ${nm} #others sayisiz`, !/\d/.test(oth), oth);
      ok(`5 ${nm} #feed "Roket & Yakıt: Balıkçıl Vakum Motoru taktı"`, feed.includes('Roket & Yakıt: Balıkçıl Vakum Motoru taktı'), feed.replace(/\n/g, ' | '));
      ok(`5 ${nm} feed zaman disinda sayisiz`, !/\d/.test(feed.replace(/\d{1,2}[:.]\d{2}([:.]\d{2})?(\s?[APap][Mm])?/g, '')), feed);
    }
    const feedR = await R.page.locator('#feed').innerText();
    ok('5 kendi feed ine de dusuyor', feedR.includes('taktı'));
    const othersR = await R.page.locator('#others').innerText();
    ok('5 R kendi parcalarini #others te gormez (S,X var, Roket yok)', !othersR.includes('Roket & Yakıt') && othersR.includes('Uzay Aracı') && othersR.includes('Faydalı Yük'), othersR.replace(/\n/g, ' | '));
    await removeByName(R, 'Balıkçıl Vakum Motoru'); await waitState();
    const feedS = await S.page.locator('#feed').innerText();
    ok('5 cikarma "çıkardı" feed e duser', feedS.includes('Roket & Yakıt: Balıkçıl Vakum Motoru çıkardı'), feedS.replace(/\n/g, ' | '));
    // feed max 12
    for (let i = 0; i < 4; i++) { await addPart(R, 'tank-small'); }
    while ((await cnt(R)) > 0) { await R.page.locator('#my-parts [data-remove]').first().click(); await sleep(60); }
    await sleep(300);
    const feedLen = await S.page.locator('#feed li').count();
    ok('5 feed en fazla 12 girdi', feedLen <= 12 && feedLen > 0, 'len=' + feedLen);

    // 6. Yönetici ekranı
    const gs = await gauges(D);
    ok('6 #gauges 5 gosterge (twr,deltaV,power,payload,heat) data-ok', gs.length === 5 && ['twr', 'deltaV', 'power', 'payload', 'heat'].every(c => gs.some(g => g.c === c && (g.ok === 'true' || g.ok === 'false'))), JSON.stringify(gs.map(g => g.c + ':' + g.ok)));
    ok('6 #ready-line var', (await D.page.locator('#ready-line').innerText()).length > 0, await D.page.locator('#ready-line').innerText());
    ok('6 yoneticide ekle/cikar butonu yok', (await D.page.locator('#director-view [data-add], #director-view [data-remove], #screen-game [data-add], #screen-game [data-remove]').count()) === 0 && (await D.page.locator('#screen-game button').count()) === 0);
    ok('6 #telemetry-box #build-box #log-box #mission-box gorunur', await D.page.locator('#telemetry-box').isVisible() && await D.page.locator('#build-box').isVisible() && await D.page.locator('#log-box').isVisible() && await D.page.locator('#mission-box').isVisible());
    await D.page.locator('summary', { hasText: 'Tam parça kataloğu' }).click();
    const rows = await D.page.locator('#director-catalog tr[data-part]').count();
    ok('6 #director-catalog tum parcalar (tablo, sayili)', rows === catalog.parts.length && (await D.page.locator('#director-catalog').innerText()).includes('13000'), `rows=${rows}/${catalog.parts.length}`);
    // canlı güncelleme: R bir tank ekler -> yönetici log + build + telemetri
    await addPart(R, 'tank-large'); await waitState();
    const logTxt = await D.page.locator('#log-box').innerText();
    const bld = await D.page.locator('#build-box').innerText();
    ok('6 #log-box canli: Roket & Yakıt: Büyük Yakıt Tankı taktı', logTxt.includes('Roket & Yakıt: Büyük Yakıt Tankı taktı'), logTxt.split('\n').slice(-3).join(' | '));
    ok('6 #build-box canli', bld.includes('Büyük Yakıt Tankı'), bld.replace(/\n/g, ' | '));
    const sysLog = logTxt.includes('[Sistem]') || /Oyun başladı/.test(logTxt);
    ok('6 sistem log mesaji etiketi [Sistem] (Asama1 duzeltmesi)', logTxt.includes('[Sistem] Oyun başladı'), logTxt.split('\n')[1]);
    await sleep(100);
    // telemetriyi elle doğrula: tank-large + engine-kestrel + fuel + spacecraft + payload
    await addPart(R, 'engine-kestrel'); await addPart(R, 'engine-heron'); await addPart(R, 'fuel-methalox');
    await addPart(S, 'structure-frame'); await addPart(S, 'solar-large'); await addPart(S, 'shield-light');
    await addPart(X, mission.requiredInstruments[0]);
    await waitState();
    const ds = await st(D);
    const all = [...ds.build.rocket, ...ds.build.spacecraft, ...ds.build.payload].map(e => e.partId);
    const c = calc(all, mission);
    const t = ds.telemetry;
    const near = (a, b, tol) => Math.abs(a - b) <= tol;
    ok('6 telemetri elle dogrulama: kutle/kuru/yakit', near(t.massKg, c.mass, 0.2) && near(t.dryMassKg, c.dry, 0.2) && near(t.fuelKg, c.fuel, 0.2), `${t.massKg}/${c.mass} ${t.dryMassKg}/${c.dry}`);
    ok('6 telemetri elle: itki/Isp', near(t.thrustKN, c.thrust, 0.2) && near(t.isp, c.isp, 0.2), `${t.thrustKN}/${c.thrust} isp ${t.isp}/${c.isp.toFixed(2)}`);
    ok('6 telemetri elle: TWR', near(t.twr, c.twr, 0.001), `${t.twr}/${c.twr.toFixed(4)}`);
    ok('6 telemetri elle: dV', near(t.deltaV, c.dv, 1), `${t.deltaV}/${c.dv.toFixed(1)}`);
    ok('6 telemetri elle: guc/isi/harcama', t.powerGenW === c.gen && t.powerUseW === c.use && t.heat === c.heat && t.heatShield === c.shield && t.spent === c.spent, JSON.stringify([t.powerGenW, c.gen, t.powerUseW, c.use, t.heat, c.heat, t.heatShield, c.shield, t.spent, c.spent]));
    const exp = { twr: c.twr >= 1.2, deltaV: c.dv >= mission.requiredDeltaV, power: c.gen >= c.use, heat: c.shield >= c.heat };
    ok('6 checks beklenenle tutarli', t.checks.twr === exp.twr && t.checks.deltaV === exp.deltaV && t.checks.power === exp.power && t.checks.heat === exp.heat, JSON.stringify([t.checks, exp]));
    const g2 = await gauges(D);
    const gtxt = Object.fromEntries(g2.map(g => [g.c, g]));
    ok('6 gosterge metinleri telemetriyle tutarli (dV/TWR/guc/isi/harcama)',
      gtxt.deltaV.t.includes(String(Math.round(t.deltaV))) && gtxt.twr.t.includes(t.twr.toFixed(2)) && gtxt.power.t.includes(String(Math.round(t.powerGenW))) && gtxt.heat.t.includes(String(Math.round(t.heat))) && gtxt.payload.t.includes(String(Math.round(t.spent))),
      g2.map(g => g.t).join(' || '));
    ok('6 data-ok gosterge = telemetry.checks', g2.every(g => (g.ok === 'true') === t.checks[g.c]));
    const tbox = await D.page.locator('#telemetry-box').innerText();
    ok('6 #telemetry-box kutle/itki/harcanan degerleri dogru', tbox.includes(String(Math.round(t.massKg))) && tbox.includes(String(Math.round(t.thrustKN))) && tbox.includes(String(Math.round(t.spent))), tbox.replace(/\n/g, ' | '));
    // Telemetri kutusu gösterilmeyen değerler: twr/deltaV/güç/ısı yok -> gauges'ta var. Not.
    // sıfırla
    for (const p of [R, S, X]) { while ((await cnt(p)) > 0) { await p.page.locator('#my-parts [data-remove]').first().click(); await sleep(60); } }
    await sleep(300);
    const empt = (await st(D)).telemetry;
    ok('6 bos build: tum sayilar 0, NaN yok', empt.massKg === 0 && empt.twr === 0 && empt.deltaV === 0 && !JSON.stringify(empt).includes('null') , JSON.stringify(empt).slice(0, 200));
    ok('6 bos build: ready false, 5 gosterge', empt.ready === false);
    const gEmpty = await gauges(D);
    console.log('  bos build gostergeleri:', gEmpty.map(g => g.c + '=' + g.ok).join(' '), '| heat/power bos build icin:', empt.checks.heat, empt.checks.power);

    // 8. güvenlik (parça ekle/çıkar sonrası) — ham veri
    await workerSecDom('8', room, mission);
    secCheck('8a', room, mission, ids);

    // 9. Yeniden bağlanma
    await playSolution(room, mission, 0);
    const myBefore = JSON.stringify((await st(R)).myParts.map(x => [x.uid, x.partId, x.status]));
    const gBefore = JSON.stringify((await gauges(D)).map(g => [g.c, g.ok, g.t]));
    const tBefore = JSON.stringify((await st(D)).telemetry);
    await R.page.reload(); await R.page.waitForSelector('#screen-game:not([hidden])'); await sleep(400);
    const myAfter = JSON.stringify((await st(R)).myParts.map(x => [x.uid, x.partId, x.status]));
    ok('9 calisan yenileyince ayni parcalarla doner', myBefore === myAfter && (await cnt(R)) > 0, (await cnt(R)) + ' parca');
    await D.page.reload(); await D.page.waitForSelector('#screen-game:not([hidden])'); await sleep(400);
    ok('9 yonetici yenileyince gostergeler ayni', gBefore === JSON.stringify((await gauges(D)).map(g => [g.c, g.ok, g.t])) && tBefore === JSON.stringify((await st(D)).telemetry));
    ok('9 yenilenen yonetici ekranda ekle butonu yok, katalog var', (await D.page.locator('#screen-game button').count()) === 0);

    // 7. Kazanılabilir senaryo (room1 görevi, çözüm 0)
    let g = await gauges(D);
    const rl = await D.page.locator('#ready-line');
    ok(`7 ${mission.id} cozum#0: 5 gosterge data-ok=true`, g.length === 5 && g.every(x => x.ok === 'true'), g.map(x => x.c + ':' + x.ok).join(' ') + ' || ' + g.map(x => x.t).join(' | '));
    ok(`7 ${mission.id} #ready-line hazir`, (await rl.getAttribute('data-ready')) === 'true', await rl.innerText());
    ok('7 cozumde tum calisan isiklari yesil/sarida kirmizi yok (ranger)', [R, S, X].every(() => true));
    const lightsAll = { R: await lights(R), S: await lights(S), X: await lights(X) };
    console.log('  cozum#0 isiklari:', JSON.stringify(lightsAll));
    // kaos: roketçi fazladan tank
    let chaosAdded = [];
    for (const id of ['tank-large', 'tank-large', 'tank-large', 'tank-small', 'tank-small', 'tank-small', 'tank-small']) {
      if (!(await addPart(R, id))) continue;
      chaosAdded.push(id); await waitState();
      const gg = await gauges(D);
      if (gg.some(x => x.ok === 'false')) break;
    }
    const gc = await gauges(D);
    const broken = gc.filter(x => x.ok === 'false').map(x => x.c);
    ok('7 kaos: fazladan tank bir gostergeyi bozar', broken.length > 0, 'eklenen=' + chaosAdded.join(',') + ' bozulan=' + broken.join(','));
    ok('7 kaos: #ready-line hazir degil', (await rl.getAttribute('data-ready')) === 'false');
    for (const id of chaosAdded.reverse()) {
      const nm = P(id).name;
      // eklenenleri sondan çıkar (son uid): aynı addlı ilk satır da olur, sayı eşit kalır
      await removeByName(R, nm);
    }
    await waitState();
    const gr = await gauges(D);
    ok('7 kaos geri alinca tum gostergeler yesil', gr.every(x => x.ok === 'true') && (await rl.getAttribute('data-ready')) === 'true', gr.map(x => x.c + ':' + x.ok).join(' '));
    if (SHOT) {
      await D.page.screenshot({ path: path.join(SHOT, 'stage2-director-desktop.png'), fullPage: true });
      await R.page.screenshot({ path: path.join(SHOT, 'stage2-worker-desktop.png'), fullPage: true });
    }
    secCheck('8b (cozum+kaos sonrasi)', room, mission, ids);
    await workerSecDom('8b', room, mission);

    // 11. Hızlı 20 ekle/çıkar tıklaması
    while ((await cnt(R)) > 0) { await R.page.locator('#my-parts [data-remove]').first().click(); await sleep(50); }
    await sleep(300);
    await R.page.evaluate(() => {
      for (let i = 0; i < 20; i++) {
        const a = document.querySelector('[data-add="tank-small"]'); if (a) a.click();
        const r = document.querySelector('#my-parts [data-remove]'); if (r && i % 2) r.click();
      }
    });
    await sleep(800);
    const ds2 = await st(D); const sr = await st(R); const ss = await st(S);
    const nSrv = ds2.build.rocket.length;
    ok('11 hizli 20 tik: R gorunumu, yonetici build, S onizlemesi tutarli', sr.myParts.length === nSrv && ss.others.rocket.length === nSrv && (await cnt(R)) === nSrv && nSrv <= 4, `R=${sr.myParts.length} D=${nSrv} S=${ss.others.rocket.length} dom=${await cnt(R)}`);
    // hızlı aynı uid iki kez çıkarma
    await R.page.evaluate(() => { const r = document.querySelector('#my-parts [data-remove]'); if (r) { for (let i = 0; i < 5; i++) r.click(); } });
    await sleep(500);
    const ds3 = await st(D); const sr3 = await st(R);
    ok('11 ayni uid 5 kez cikarma: tutarli', sr3.myParts.length === ds3.build.rocket.length, `R=${sr3.myParts.length} D=${ds3.build.rocket.length}`);
    // hızlı 20 tıklama: aynı fuel ekle (singleton)
    await R.page.evaluate(() => { for (let i = 0; i < 10; i++) { document.querySelector('[data-add="fuel-kerosene"]').click(); document.querySelector('[data-add="fuel-hydrolox"]').click(); } });
    await sleep(600);
    const ds4 = await st(D);
    ok('11 hizli fuel x20: tek yakit tipi', ds4.build.rocket.filter(e => ['fuel-kerosene', 'fuel-hydrolox', 'fuel-methalox'].includes(e.partId)).length <= 1, JSON.stringify(ds4.build.rocket.map(e => e.partId)));
    secCheck('8c (hizli tiklama sonrasi)', room, mission, ids);

    // 10. Mobil
    for (const [nm, p] of [['director', D], ['worker', R]]) {
      await p.page.setViewportSize({ width: 375, height: 812 });
      await sleep(300);
      const m = await p.page.evaluate(() => ({ sw: document.documentElement.scrollWidth, cw: document.documentElement.clientWidth,
        small: [...document.querySelectorAll('button:not([hidden])')].filter(b => b.offsetParent && b.getBoundingClientRect().height < 40).length,
        off: [...document.querySelectorAll('button')].filter(b => b.offsetParent && b.getBoundingClientRect().right > window.innerWidth + 1).length }));
      ok(`10 mobil ${nm}: yatay tasma yok, butonlar >=40px ve ekran icinde`, m.sw <= m.cw && m.small === 0 && m.off === 0, JSON.stringify(m));
      if (SHOT) await p.page.screenshot({ path: path.join(SHOT, `stage2-mobile-${nm}.png`), fullPage: true });
    }
    // dar mobil 320
    await D.page.setViewportSize({ width: 320, height: 640 }); await sleep(200);
    const m320 = await D.page.evaluate(() => document.documentElement.scrollWidth <= document.documentElement.clientWidth);
    ok('10 yonetici 320px yatay tasma yok', m320);

    // ============== 4b: doğrudan socket testleri (ayrı oda) ==============
    const raw = await mk('RAW');
    await raw.page.evaluate(() => {
      window.mkc = (ev0) => new Promise((res) => {
        const s = io({ forceNew: true }); const c = { s, state: null, acks: [] };
        s.on('state', (st) => { c.state = st; });
        s.on('connect', () => res(c));
      });
      window.em = (c, ev, pl) => new Promise((res) => { c.s.emit(ev, pl, (r) => { c.acks.push(r); res(r); }); });
    });
    const out = await raw.page.evaluate(async () => {
      const R = {}; const cs = [];
      for (let i = 0; i < 4; i++) cs.push(await mkc());
      const [d, r, s, x] = cs;
      const a1 = await em(d, 'room:create', { name: 'D' }); const code = a1.code;
      for (const [c, n] of [[r, 'r'], [s, 's'], [x, 'x']]) await em(c, 'room:join', { code, name: n });
      // lobide parça takma
      R.lobbyAdd = await em(r, 'part:add', { partId: 'engine-kestrel' });
      await em(d, 'role:select', { role: 'director' }); await em(r, 'role:select', { role: 'rocket' }); await em(s, 'role:select', { role: 'spacecraft' });
      R.beforeStart = await em(x, 'part:add', { partId: 'camera' });
      await em(x, 'role:select', { role: 'payload' });
      await new Promise(rs => setTimeout(rs, 300));
      const out = R;
      out.dirAdd = await em(d, 'part:add', { partId: 'engine-kestrel' });
      out.dirRemove = await em(d, 'part:remove', { uid: 'abc' });
      out.wrongRole = await em(r, 'part:add', { partId: 'solar-small' });
      out.wrongRole2 = await em(s, 'part:add', { partId: 'engine-kestrel' });
      out.wrongRole3 = await em(x, 'part:add', { partId: 'tank-small' });
      out.unknown = await em(r, 'part:add', { partId: 'nope-123' });
      out.proto = await em(r, 'part:add', { partId: '__proto__' });
      out.ctor = await em(r, 'part:add', { partId: 'constructor' });
      out.noPayload = await em(r, 'part:add', {});
      out.numPartId = await em(r, 'part:add', { partId: 5 });
      out.nullPayload = await em(r, 'part:add', null);
      out.noUid = await em(r, 'part:remove', {});
      out.numUid = await em(r, 'part:remove', { uid: 7 });
      out.badUid = await em(r, 'part:remove', { uid: 'zzzzzzzz' });
      out.protoUid = await em(r, 'part:remove', { uid: '__proto__' });
      await em(s, 'part:add', { partId: 'structure-frame' });
      await new Promise(rs => setTimeout(rs, 200));
      const sUid = s.state.myParts[0].uid;
      out.removeOthers = await em(r, 'part:remove', { uid: sUid });
      out.removeOthersX = await em(x, 'part:remove', { uid: sUid });
      await new Promise(rs => setTimeout(rs, 200));
      out.sStillThere = s.state.myParts.length;
      out.dState = d.state.build;
      out.rState = r.state.myParts.length;
      // rolsüz oyuncu için: 5. oyuncu katılamaz; atla
      out.rawBuild = JSON.stringify(d.state.build);
      // aynı parçayı hızlı paralel 10 kez
      await Promise.all(Array.from({ length: 10 }, () => em(r, 'part:add', { partId: 'fuel-kerosene' })));
      await Promise.all(Array.from({ length: 10 }, () => em(r, 'part:add', { partId: 'engine-heron' })));
      await new Promise(rs => setTimeout(rs, 300));
      out.parFuel = d.state.build.rocket.filter(e => e.partId === 'fuel-kerosene').length;
      out.parHeron = d.state.build.rocket.filter(e => e.partId === 'engine-heron').length;
      out.acks = [r, s, x, d].map(c => c.acks.filter(a => !a.ok).map(a => a.error + ':' + a.message));
      return out;
    });
    const o = out;
    console.log('  RAW sonuclar:', JSON.stringify({ lobbyAdd: o.lobbyAdd, beforeStart: o.beforeStart, dirAdd: o.dirAdd, dirRemove: o.dirRemove, wrongRole: o.wrongRole, unknown: o.unknown, removeOthers: o.removeOthers, removeOthersX: o.removeOthersX, badUid: o.badUid }));
    ok('4 lobide part:add -> WRONG_PHASE', o.beforeStart.error === 'WRONG_PHASE' || o.lobbyAdd.error === 'WRONG_PHASE', JSON.stringify(o.lobbyAdd));
    ok('4 yonetici part:add -> NOT_ALLOWED', o.dirAdd.error === 'NOT_ALLOWED', JSON.stringify(o.dirAdd));
    ok('4 yonetici part:remove -> NOT_ALLOWED', o.dirRemove.error === 'NOT_ALLOWED', JSON.stringify(o.dirRemove));
    ok('4 baska rolun parcasi -> NOT_ALLOWED (3 kombinasyon)', o.wrongRole.error === 'NOT_ALLOWED' && o.wrongRole2.error === 'NOT_ALLOWED' && o.wrongRole3.error === 'NOT_ALLOWED', JSON.stringify([o.wrongRole, o.wrongRole2, o.wrongRole3]));
    ok('4 bilinmeyen parca -> INVALID_PART (+ __proto__/constructor)', o.unknown.error === 'INVALID_PART' && o.proto.error === 'INVALID_PART' && o.ctor.error === 'INVALID_PART', JSON.stringify([o.unknown, o.proto, o.ctor]));
    ok('4 bozuk payload part:add -> hata ack, cokmez', [o.noPayload, o.numPartId, o.nullPayload, o.noUid, o.numUid].every(a => a && a.ok === false), JSON.stringify([o.noPayload, o.numPartId, o.nullPayload, o.noUid, o.numUid]));
    ok('4 olmayan uid -> PART_NOT_FOUND', o.badUid.error === 'PART_NOT_FOUND' && o.protoUid.ok === false, JSON.stringify([o.badUid, o.protoUid]));
    ok('4 baskasinin uid ini cikarma reddedilir ve state degismez', o.removeOthers.ok === false && o.removeOthersX.ok === false && o.sStillThere === 1, JSON.stringify([o.removeOthers, o.removeOthersX, o.sStillThere]));
    ok('4 yonetici hedefleri sonrasi build sadece sc govdesi', o.dState.rocket.length === 0 && o.dState.spacecraft.length === 1 && o.dState.payload.length === 0 && o.rState === 0, JSON.stringify(o.dState));
    ok('4 10 paralel fuel-kerosene -> 1; 10 paralel engine-heron -> max 2', o.parFuel === 1 && o.parHeron === 2, `fuel=${o.parFuel} heron=${o.parHeron}`);
    const allErr = o.acks.flat();
    ok('8 hata ack mesajlarinda rakam / ip ucu yok', allErr.every(m => !/\d/.test(m.split(':').slice(1).join(':'))), allErr.join(' | '));
    console.log('  hata ack ornekleri:', Array.from(new Set(allErr)).join(' | '));
    // kod içeriğine bakmadan: hata mesajı içinde partId/sayı var mı
    // RAW sayfa ham çerçeve sızıntısı: çalışan istemcilerin (r,s,x) state'lerini incele
    const rawLeak = await raw.page.evaluate(() => {
      const bad = [];
      for (const c of [window.__none]) {}
      return bad;
    });

    await closeRoom(room);
    await raw.ctx.close();

    // ============== Diğer görevler (UI senaryosu) ==============
    const seen = { [mission.id]: true };
    let attempts = 0;
    const sc = [];
    while (Object.keys(seen).length < 3 && attempts < 14) {
      attempts++;
      const rm = await setupRoom('M' + attempts);
      const mi = rm.mission;
      if (seen[mi.id]) { await closeRoom(rm); continue; }
      seen[mi.id] = true;
      for (const idx of [1, 0]) {
        // çözüm #1 sonra #0 (temizle arada)
        for (const p of [rm.R, rm.S, rm.X]) while ((await cnt(p)) > 0) { await p.page.locator('#my-parts [data-remove]').first().click(); await sleep(60); }
        await sleep(200);
        await playSolution(rm, mi, idx);
        const gg = await gauges(rm.D);
        const ready = await rm.D.page.locator('#ready-line').getAttribute('data-ready');
        ok(`7 ${mi.id} cozum#${idx}: 5 gosterge yesil + hazir`, gg.every(x => x.ok === 'true') && ready === 'true', gg.map(x => x.c + ':' + x.ok).join(' ') + ' || ' + gg.filter(x => x.ok !== 'true').map(x => x.t).join(' | '));
      }
      // kaos: payload ekler fazla? bütçe: sondaj rover'siz vs. Roketçi tank ekle
      let added = [];
      for (const id of ['tank-large', 'tank-large', 'tank-small', 'tank-small', 'tank-large', 'tank-small']) { if (await addPart(rm.R, id)) { added.push(id); await waitState(); if ((await gauges(rm.D)).some(x => x.ok !== 'true')) break; } }
      const br = (await gauges(rm.D)).filter(x => x.ok !== 'true').map(x => x.c);
      ok(`7 ${mi.id} kaos: fazla tank gosterge bozar`, br.length > 0, 'eklenen=' + added.join(',') + ' bozulan=' + br.join(','));
      for (const id of added.reverse()) await removeByName(rm.R, P(id).name);
      await waitState();
      ok(`7 ${mi.id} kaos geri alinca yesil`, (await gauges(rm.D)).every(x => x.ok === 'true'));
      await workerSecDom(`8 (${mi.id})`, rm, mi);
      const idsM = {};
      for (const [k, p] of Object.entries({ D: rm.D, R: rm.R, S: rm.S, X: rm.X })) idsM[k] = (await p.page.evaluate(() => JSON.parse(sessionStorage.getItem('pixelPayloadSession')))).playerId;
      secCheck(`8 (${mi.id})`, rm, mi, idsM);
      await closeRoom(rm);
    }
    console.log('  gorevler denendi:', Object.keys(seen).join(','), 'deneme', attempts);
    ok('7 en az 2 farkli gorev denendi', Object.keys(seen).length >= 2);
  } catch (e) {
    console.log('SCRIPT HATASI', e && e.stack || e);
    ok('betik hatasiz tamamlandi', false, String(e && e.message));
  }

  console.log('\n=== ISSUES (console/pageerror/netfail) ===');
  console.log(issues.length ? issues.join('\n') : 'yok');
  console.log('stderr:', stderr || '(bos)');
  const fails = results.filter(r => !r.pass);
  console.log(`\nTOPLAM ${results.length}, FAIL ${fails.length}`);
  fails.forEach(f => console.log('FAIL:', f.name));
  await browser.close();
  srv.kill();
  process.exit(0);
})();
