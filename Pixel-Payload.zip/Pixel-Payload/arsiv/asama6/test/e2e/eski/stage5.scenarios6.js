// stage5 senaryoları (6): ağ/CDN/performans, 3B yuva kapsamı (her gövde), gerekçe sayı taraması.
const L0 = global.__S5;
const { ok, sleep, scenario, SOLUTIONS } = L0;

scenario('net', async (L) => {
  const server = await L.startServer({ PP_EVENTS: 'none', PP_TELEMETRY_DELAY_MS: '0', PP_WINDOW_SEC: '600' });
  const browser = await L.getBrowser();
  try {
    const room = await L.setupRoom(browser, server, 'k');
    const vendor = {};
    for (const p of [room.R]) p.page.on('response', (r) => { if (/\/vendor\//.test(r.url())) vendor[r.url().replace(server.url, '')] = r.status(); });
    await room.R.page.reload();
    await room.R.page.waitForSelector('#screen-setup:not([hidden])');
    await L.pickFrame(room, 'frame-cargo');
    await sleep(2000);
    console.log('vendor istekleri:', JSON.stringify(vendor));
    ok('vendor three/font istekleri 200', Object.keys(vendor).length >= 3 && Object.values(vendor).every((s) => s === 200), JSON.stringify(vendor).slice(0, 300));
    // fps
    const fps = await room.R.page.evaluate(() => new Promise((res) => { let n = 0; const t0 = performance.now(); const f = () => { n++; if (performance.now() - t0 < 2000) requestAnimationFrame(f); else res(n / 2); }; requestAnimationFrame(f); }));
    console.log('headless (swiftshader, 4 sayfa eşzamanlı) rAF/sn ~', fps);
    // gerekçe taraması: yuva reason metinleri sayısız
    await L.placeUI(room.R, 'tank-small', 'tank-3');
    await room.S.page.click('button[data-pick="battery"]');
    await sleep(500);
    await L.placeUI(room.S, 'shield-light', 'p-n1');
    await room.S.page.click('button[data-pick="solar-small"]');
    await sleep(500);
    for (const p of [room.R, room.S, room.X]) {
      const raw = p.raw.filter((r) => !r.startsWith('SENT')).join('\n');
      const reasons = [...raw.matchAll(/\\?"reason\\?":\\?"((?:[^"\\]|\\.)*?)\\?"/g)].map((m) => m[1]);
      const withDigits = reasons.filter((r) => /\d/.test(r.replace(/\\u[0-9a-f]{4}/gi, '')));
      ok(`çalışan trafiğinde gerekçe metinleri sayısız (${p.name}, ${reasons.length} gerekçe)`, withDigits.length === 0, withDigits.slice(0, 2).join(' | '));
      ok(`dış (CDN) istek yok (${p.name})`, p.ext.length === 0, p.ext.slice(0, 3).join(','));
    }
    // log/feed çalışanda sayı yok
    const feed = await room.S.page.locator('#feed').innerText();
    ok('çalışan #feed sayısız (saatler hariç)', !/\d/.test(feed.replace(/\d{1,2}:\d{2}(:\d{2})?/g, '')), feed.replace(/\n/g, ' | ').slice(0, 200));
    await L.closeRoom(room);
  } finally { L.stopServer(server); console.log('sunucu stderr:', JSON.stringify(server.stderr.slice(0, 300))); }
});

scenario('coverage3d', async (L) => {
  const server = await L.startServer({ PP_EVENTS: 'none', PP_TELEMETRY_DELAY_MS: '0', PP_WINDOW_SEC: '600' });
  const browser = await L.getBrowser();
  try {
    for (const f of L.framesData.frames) {
      const room = await L.setupRoom(browser, server, 'c' + f.id.slice(6, 8));
      await L.pickFrame(room, f.id);
      await sleep(1800);
      const res = await room.R.page.evaluate((slotIds) => {
        const cv = document.querySelector('#scene3d canvas'); const b = cv.getBoundingClientRect();
        const pts = slotIds.map((id) => ({ id, p: window.__ppScene.slotScreenPos(id) }));
        return { box: [Math.round(b.left), Math.round(b.top), Math.round(b.right), Math.round(b.bottom)], pts };
      }, f.slots.map((s) => s.id));
      const inside = res.pts.filter((q) => q.p && q.p.x >= res.box[0] && q.p.x <= res.box[2] && q.p.y >= res.box[1] && q.p.y <= res.box[3]);
      const missing = res.pts.filter((q) => !q.p).map((q) => q.id);
      const outside = res.pts.filter((q) => q.p && !inside.includes(q)).map((q) => q.id);
      // yakın üst üste binenler (<7px)
      const close = [];
      for (let i = 0; i < inside.length; i++) for (let j = i + 1; j < inside.length; j++) {
        const d = Math.hypot(inside[i].p.x - inside[j].p.x, inside[i].p.y - inside[j].p.y);
        if (d < 7) close.push(`${inside[i].id}~${inside[j].id}(${d.toFixed(1)})`);
      }
      console.log(`[${f.id}] yuva ${f.slots.length}; görünür ${inside.length}; konumsuz ${missing.join(',') || '-'}; tuval dışı ${outside.join(',') || '-'}; çok yakın ${close.join(' ') || '-'}`);
      ok(`[${f.id}] 3B: tüm yuvaların ekran konumu var ve tuval içinde`, missing.length === 0 && outside.length === 0, `missing=${missing} out=${outside}`);
      ok(`[${f.id}] 3B: yuva işaretçileri üst üste binmiyor`, close.length === 0, close.join(' '));
      await room.R.page.click('button[data-pick="tank-small"]').catch(() => {});
      await sleep(600);
      await L.shot(room.R, 'coverage-' + f.id);
      await L.closeRoom(room);
    }
  } finally { L.stopServer(server); }
});
