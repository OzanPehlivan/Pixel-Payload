// stage5 senaryoları (4): demo modu, görsel tur.
const L0 = global.__S5;
const { ok, sleep, scenario, SOLUTIONS } = L0;

async function demoRun(L, viewport, tag, full) {
  const server = await L.startServer({ PP_EVENTS: 'none', PP_TELEMETRY_DELAY_MS: '0', PP_WINDOW_SEC: '600' });
  const browser = await L.getBrowser();
  const ctx = await browser.newContext({ viewport });
  const page = await ctx.newPage();
  const msgs = [];
  const ext = [];
  page.on('console', (m) => { if (m.type() === 'error') L.issues.push(`[demo ${tag}] console.error: ${m.text()}`); });
  page.on('pageerror', (e) => L.issues.push(`[demo ${tag}] pageerror: ${e.message}`));
  page.on('request', (r) => { const u = r.url(); if (!/^(http:\/\/localhost|ws:\/\/localhost|data:|blob:|about:)/.test(u)) ext.push(u); });
  page.on('response', (r) => { if (r.status() >= 400 && !r.url().includes('/socket.io/')) L.issues.push(`[demo ${tag}] HTTP ${r.status()} ${r.url()}`); });
  await page.addInitScript(() => {
    window.__msgs = [];
    window.addEventListener('message', (e) => { try { window.__msgs.push(JSON.parse(JSON.stringify(e.data))); } catch (x) { /* */ } });
  });
  try {
    await page.goto(server.url + '/demo.html');
    await page.waitForSelector('#demo-start-btn');
    await page.click('#demo-start-btn');
    await sleep(500);
    const frames = {};
    const roles = ['director', 'rocket', 'spacecraft', 'payload'];
    // iframe'leri rolüne göre bul
    for (const r of roles) {
      const h = await page.locator(`section.demo-panel[data-role="${r}"] iframe`).elementHandle();
      frames[r] = await h.contentFrame();
    }
    for (const r of roles) await frames[r].waitForSelector('#screen-setup:not([hidden])', { timeout: 12000 });
    ok(`[demo ${tag}] 4 panel setup'a geldi`, true);
    await page.screenshot({ path: L.path.join(L.SHOT, `demo-${tag}-setup.png`) });
    // iframe'ler yeniden yüklenebilir: frame nesneleri değişebilir, yeniden al
    const getFrame = async (r) => { const h = await page.locator(`section.demo-panel[data-role="${r}"] iframe`).elementHandle(); return h.contentFrame(); };
    const cards = await frames.director.locator('#frame-select button[data-frame]').count();
    ok(`[demo ${tag}] yönetici panelinde 3 gövde kartı`, cards === 3, cards);
    const mission = JSON.parse(await frames.director.locator('#debug-state').textContent()).mission;
    const sol = SOLUTIONS[mission.id][0];
    console.log(`[demo ${tag}] görev ${mission.id}, gövde ${sol.frameId}`);
    await frames.director.click(`#frame-select button[data-frame="${sol.frameId}"]`);
    for (const r of roles) await frames[r].waitForSelector('#screen-game:not([hidden])', { timeout: 8000 });
    await sleep(2500);
    await page.screenshot({ path: L.path.join(L.SHOT, `demo-${tag}-building.png`) });
    const shim = (r) => ({ page: frames[r], name: 'demo-' + r });
    const W = { rocket: shim('rocket'), spacecraft: shim('spacecraft'), payload: shim('payload') };
    // 3B etkin mi + iframe içi 3B tıklama
    const sceneInfo = {};
    for (const r of ['rocket', 'spacecraft', 'payload']) {
      sceneInfo[r] = await frames[r].evaluate(() => { const c = document.querySelector('#scene3d'); const cv = c && c.querySelector('canvas'); const b = cv && cv.getBoundingClientRect(); return { ready: c && c.dataset.sceneReady, w: b && Math.round(b.width), h: b && Math.round(b.height), hook: !!window.__ppScene }; });
    }
    console.log(`[demo ${tag}] 3B alanı`, JSON.stringify(sceneInfo));
    ok(`[demo ${tag}] panellerde 3B hazır`, Object.values(sceneInfo).every((s) => s.ready === '1' && s.hook), JSON.stringify(sceneInfo));
    // 3B tıklama ile yerleştir (ilk roket parçası)
    const first = sol.placements.find((p) => p.role === 'rocket');
    await frames.rocket.click(`button[data-pick="${first.partId}"]`);
    await sleep(400);
    const pos = await frames.rocket.evaluate((id) => window.__ppScene.slotScreenPos(id), first.slotId);
    const box = await (await page.locator('section.demo-panel[data-role="rocket"] iframe').elementHandle()).boundingBox();
    console.log(`[demo ${tag}] yuva ${first.slotId} pos`, JSON.stringify(pos), 'iframe', JSON.stringify(box));
    if (pos) {
      // pos iframe-viewport koordinatı; sayfa koordinatına çevir
      await page.mouse.click(box.x + pos.x, box.y + pos.y);
      await sleep(600);
      const n = await L.countParts(W.rocket);
      ok(`[demo ${tag}] demo panelinde 3B tıklamayla yerleştirme`, n === 1, 'n=' + n);
      if (n !== 1) {
        L.issues.push(`[demo ${tag}] 3B tıklama yuvaya isabet etmedi pos=${JSON.stringify(pos)}`);
        await frames.rocket.click(`#slot-list button[data-slot="${first.slotId}"]`).catch(() => {});
      }
    }
    await page.screenshot({ path: L.path.join(L.SHOT, `demo-${tag}-picked-3d.png`) });
    const rest = { placements: sol.placements.filter((p) => !(p.role === 'rocket' && p.slotId === first.slotId)) };
    const fails = await L.placeSolution({ workers: W }, rest);
    ok(`[demo ${tag}] panellerden çözüm kuruldu`, fails.length === 0, fails.join(','));
    await sleep(600);
    const gg = await frames.director.evaluate(() => [...document.querySelectorAll('#gauges [data-check]')].map((e) => e.getAttribute('data-ok')));
    ok(`[demo ${tag}] yönetici panelinde göstergeler yeşil`, gg.length >= 5 && gg.every((x) => x === 'true'), gg.join(','));
    await page.screenshot({ path: L.path.join(L.SHOT, `demo-${tag}-ready.png`) });
    // yerleşim düğmeleri
    for (const lay of ['director', 'row', 'grid']) {
      await page.click(`button[data-layout="${lay}"]`);
      await sleep(700);
      const ov = await page.evaluate(() => document.documentElement.scrollWidth > window.innerWidth + 2);
      ok(`[demo ${tag}] yerleşim ${lay}: sayfa yatay taşma yok`, !ov);
      const sceneOk = await frames.rocket.evaluate(() => { const cv = document.querySelector('#scene3d canvas'); const b = cv && cv.getBoundingClientRect(); return b ? Math.round(b.width) + 'x' + Math.round(b.height) : null; }).catch(() => null);
      console.log(`[demo ${tag}] ${lay}: roket paneli 3B canvas`, sceneOk);
      await page.screenshot({ path: L.path.join(L.SHOT, `demo-${tag}-layout-${lay}.png`) });
    }
    await page.click('button[data-focus="rocket"]'); await sleep(600);
    await page.screenshot({ path: L.path.join(L.SHOT, `demo-${tag}-focus.png`) });
    await page.click('button[data-focus="rocket"]'); await sleep(300);
    if (full) {
      await frames.director.click('#poll-start-btn');
      for (const r of ['rocket', 'spacecraft', 'payload']) await frames[r].waitForSelector('#vote-go-btn', { state: 'visible', timeout: 5000 });
      await page.screenshot({ path: L.path.join(L.SHOT, `demo-${tag}-poll.png`) });
      for (const r of ['rocket', 'spacecraft', 'payload']) { await frames[r].click('#vote-go-btn'); await sleep(150); }
      for (const r of roles) await frames[r].waitForSelector('#screen-result:not([hidden])', { timeout: 8000 });
      await sleep(1800);
      await page.screenshot({ path: L.path.join(L.SHOT, `demo-${tag}-launch.png`) });
      for (const r of roles) await frames[r].locator('#skip-launch-btn').click({ timeout: 500 }).catch(() => {});
      await frames.director.waitForSelector('#result-panel', { state: 'visible', timeout: 15000 });
      await sleep(500);
      await page.screenshot({ path: L.path.join(L.SHOT, `demo-${tag}-result.png`) });
      const title = await frames.director.locator('#result-title').innerText();
      ok(`[demo ${tag}] demo tam tur: sonuç success`, /başarılı!/.test(title), title);
    }
    // postMessage içeriği
    const messages = await page.evaluate(() => window.__msgs);
    const okKeys = new Set(['type', 'slot', 'code', 'phase', 'role', 'name', 'error', 'message']);
    const badMsg = messages.filter((m) => Object.keys(m).some((k) => !okKeys.has(k)) || (m.type === 'pp-state' && Object.keys(m).some((k) => k === 'error' || k === 'message')));
    ok(`[demo ${tag}] postMessage anahtarları yalnız izinli (${messages.length} ileti)`, badMsg.length === 0, JSON.stringify(badMsg.slice(0, 2)));
    const js = JSON.stringify(messages);
    ok(`[demo ${tag}] postMessage görev/sayı sızdırmıyor`, !js.includes(mission.title) && !js.includes('requiredDeltaV'));
    ok(`[demo ${tag}] dışarıya (CDN) istek yok`, ext.length === 0, ext.slice(0, 3).join(','));
  } finally { await ctx.close().catch(() => {}); L.stopServer(server); }
}

scenario('demo', async (L) => {
  await demoRun(L, { width: 1600, height: 900 }, '1600', true);
  await demoRun(L, { width: 1366, height: 768 }, '1366', false);
});
