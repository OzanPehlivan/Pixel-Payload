// stage5.e2e.js'in senaryoları (tek dosya içinde ayrıldı; global.__S5 ile altyapıyı alır).
const L = global.__S5;
const { ok, sleep, scenario, SOLUTIONS, FAULT_SOLUTIONS, R, S, Y } = L;
const path = require('path');

const digitsIn = (t) => /\d/.test(t);

// ---------- 2 + 3 + 4: akış, yerleştirme, çakışma ----------
scenario('flow', async (L) => {
  const server = await L.startServer({ PP_EVENTS: 'none', PP_TELEMETRY_DELAY_MS: '0', PP_WINDOW_SEC: '300' });
  const browser = await L.getBrowser();
  try {
    const room = await L.setupRoom(browser, server, 'f');
    const { D, R: Rk, S: Sp, X } = room;
    ok('4 sayfada #screen-setup görünür', true);
    // yönetici gövde kartları
    const cards = await D.page.locator('#frame-select button[data-frame]').count();
    ok('yönetici 3 gövde kartı', cards === 3, cards);
    const cardTexts = await D.page.locator('#frame-select button[data-frame]').allInnerTexts();
    console.log('KART:', JSON.stringify(cardTexts));
    for (const f of L.framesData.frames) {
      const t = cardTexts.find((x) => x.includes(f.name)) || '';
      ok(`kart ${f.id}: ad+kütle+maliyet`, t && t.replace(/[.,]/g,'').includes(String(f.massKg)) && t.includes(String(f.cost)), t.replace(/\n/g, ' | '));
    }
    await L.shot(D, 'flow-setup-director');
    // çalışan bekleme ekranı sayısız
    for (const w of [Rk, Sp, X]) {
      const txt = await w.page.locator('#screen-setup').innerText();
      const clean = txt.replace(/\d{1,2}:\d{2}/g, '');
      ok(`çalışan setup ekranında sayı yok (${w.name})`, !digitsIn(clean), clean.replace(/\n/g, ' | ').slice(0, 300));
      const hasCardBtn = await w.page.locator('#screen-setup button[data-frame]').count();
      ok(`çalışan gövde seçemez (${w.name})`, hasCardBtn === 0);
    }
    await L.shot(Rk, 'flow-setup-worker');
    // sayaç setup'ta başlamıyor
    const t0 = await D.page.locator('#timer-value').innerText();
    await sleep(2200);
    const t1 = await D.page.locator('#timer-value').innerText();
    const dsSetup = await L.st(D);
    console.log('setup timer', t0, t1, 'state keys', Object.keys(dsSetup));
    ok('sayaç setup fazında sabit', t0 === t1, `${t0} -> ${t1}`);
    // çalışan gövde seçmeyi dener
    const w = await L.rawEmit(room, 'R', 'frame:select', { frameId: 'frame-cargo' });
    ok('çalışan frame:select reddedilir', w.res && w.res.ok === false, JSON.stringify(w));
    // gövde seç
    await L.pickFrame(room, 'frame-cargo');
    const a = await D.page.locator('#timer-value').innerText();
    await sleep(2100);
    const b = await D.page.locator('#timer-value').innerText();
    ok('#timer geri sayıyor', a !== b, `${a} -> ${b}`);
    const dsB = await L.st(D);
    ok('faz building', JSON.stringify(dsB).includes('building'));
    await L.shot(D, 'flow-director-building');
    await L.shot(Rk, 'flow-worker-building');

    // --- yerleştirme: roket çalışanı ---
    await Rk.page.click('button[data-pick="engine-kestrel"]');
    const pressed = await Rk.page.locator('button[data-pick="engine-kestrel"]').getAttribute('aria-pressed');
    ok('seçili parça aria-pressed=true', pressed === 'true', pressed);
    const slotInfo = await Rk.page.evaluate(() => [...document.querySelectorAll('#slot-list li')].map((li) => {
      const b = li.querySelector('button[data-slot]');
      return { slot: b && b.getAttribute('data-slot'), dis: b && b.disabled, txt: li.innerText.replace(/\n/g, ' | ') };
    }));
    console.log('SLOT LISTESI (motor, kargo):', JSON.stringify(slotInfo));
    const enabled = slotInfo.filter((s) => !s.dis).map((s) => s.slot).sort();
    ok('motor: yalnız motor yuvaları etkin', JSON.stringify(enabled) === JSON.stringify(['eng-c', 'eng-e', 'eng-w']), enabled.join(','));
    const nonEng = slotInfo.filter((s) => s.dis);
    ok('engelli yuva yok ya da gerekçeli', nonEng.every((s) => s.txt.split('|').length > 1), nonEng.slice(0, 2).map((s) => s.txt).join(' // '));
    await L.shot(Rk, 'flow-worker-picked');
    // yuvaya bas
    await Rk.page.click('#slot-list button[data-slot="eng-c"]');
    await sleep(500);
    const myText = await Rk.page.locator('#my-parts').innerText();
    ok('#my-parts parça + yuva adı', /Merkez motor yuvası/.test(myText), myText.replace(/\n/g, ' | '));
    ok('#my-parts sayı/fiyat yok', !/\$|\bTL\b|kg|kN/.test(myText) && !/\d/.test(myText.replace(/\s/g, '')), myText.replace(/\n/g, ' | '));
    const sel2 = await Rk.page.locator('button[data-pick][aria-pressed="true"]').count();
    ok('yerleştirince seçim sıfırlanır', sel2 === 0, sel2);
    // diğer sayfalar 3B / yuva doluluk: debug-state slots occupant
    await sleep(400);
    for (const p of [D, Sp, X]) {
      const s = await L.st(p);
      const j = JSON.stringify(s);
      ok(`diğer sayfa parçayı görüyor (${p.name})`, /eng-c/.test(j) && /engine-kestrel|Kerkenez/.test(j), j.length);
    }
    // 3B sahne hook
    const hook = await Rk.page.evaluate(() => ({ has: !!window.__ppScene, ready: document.querySelector('#scene3d') && document.querySelector('#scene3d').dataset.sceneReady }));
    ok('3B sahne hazır (sceneReady=1)', hook.has && hook.ready === '1', JSON.stringify(hook));
    // 3B tıklama ile yerleştir: tank
    await Rk.page.click('button[data-pick="tank-large"]');
    await sleep(400);
    const pos = await Rk.page.evaluate(() => window.__ppScene.slotScreenPos('tank-1'));
    console.log('slotScreenPos tank-1', JSON.stringify(pos));
    ok('slotScreenPos sayı döndürür', pos && Number.isFinite(pos.x), JSON.stringify(pos));
    await L.shot(Rk, 'flow-3d-highlight');
    if (pos) {
      await Rk.page.mouse.click(pos.x, pos.y);
      await sleep(600);
      const n = await L.countParts(Rk);
      ok('3B gerçek fare tıklamasıyla yerleştirme', n === 2, 'n=' + n);
    }
    // clickSlot ile
    await Rk.page.click('button[data-pick="tank-small"]'); await sleep(300);
    await Rk.page.evaluate(() => window.__ppScene.clickSlot('tank-2'));
    await sleep(600);
    ok('clickSlot ile yerleştirme', (await L.countParts(Rk)) === 3, await L.countParts(Rk));
    // kendi parçasını 3B'den çıkar (onaylı)
    const pos2 = await Rk.page.evaluate(() => window.__ppScene.slotScreenPos('tank-2'));
    if (pos2) {
      await Rk.page.mouse.click(pos2.x, pos2.y);
      await sleep(500);
      const info = await Rk.page.locator('#scene-info').innerText();
      console.log('scene-info:', info.replace(/\n/g, ' | '));
      await L.shot(Rk, 'flow-3d-remove-confirm');
      const confirmBtn = Rk.page.locator('#scene-info button');
      const nb = await confirmBtn.count();
      ok('3B parça tıklaması onay isteği gösterir', nb >= 1, nb + ' | ' + info.replace(/\n/g, ' '));
      if (nb >= 1) {
        const before = await L.countParts(Rk);
        const labels = await confirmBtn.allInnerTexts();
        console.log('onay düğmeleri', labels);
        // ilk düğme = çıkar varsayımı; değilse ikincisi
        const idx = labels.findIndex((t) => /çıkar|evet|onay/i.test(t));
        await confirmBtn.nth(idx >= 0 ? idx : 0).click();
        await sleep(600);
        ok('3B onayı ile parça çıkarıldı', (await L.countParts(Rk)) === before - 1, `${before} -> ${await L.countParts(Rk)}`);
      }
    }
    // listeden çıkar
    await Rk.page.locator('#my-parts li', { hasText: 'Merkez motor yuvası' }).locator('[data-remove]').click();
    await sleep(500);
    ok('listeden çıkarma', (await L.countParts(Rk)) === 1, await L.countParts(Rk));
    const sj = JSON.stringify(await L.st(D));
    ok('çıkarılan yuva yöneticide boş', !/"slotId":\s*"eng-c"/.test(sj));

    // ---- 4: yuva çakışması (tank-3 = tank/batarya) ----
    await L.placeUI(Rk, 'tank-small', 'tank-3');
    await sleep(500);
    await Sp.page.click('button[data-pick="battery-pack"]').catch(() => {});
    const batId = L.catalog.parts.find((p) => p.category === 'battery');
    console.log('batarya parçası:', batId && batId.id);
    await Sp.page.click(`button[data-pick="${batId.id}"]`);
    await sleep(400);
    const sp = await Sp.page.evaluate(() => [...document.querySelectorAll('#slot-list li')].map((li) => {
      const b = li.querySelector('button[data-slot]');
      return { slot: b.getAttribute('data-slot'), dis: b.disabled, txt: li.innerText.replace(/\n/g, ' | ') };
    }));
    const t3 = sp.find((s) => s.slot === 'tank-3');
    ok('paylaşılan yuva dolu: batarya için tank-3 engelli + "dolu" gerekçesi', t3 && t3.dis && /dolu/i.test(t3.txt), t3 && t3.txt);
    await L.shot(Sp, 'flow-slot-taken');
    const tk = await L.rawEmit(room, 'S', 'part:add', { partId: batId.id, slotId: 'tank-3' });
    ok('socket ile zorlayınca SLOT_TAKEN', tk.res && tk.res.error === 'SLOT_TAKEN', JSON.stringify(tk));
    // çıkar -> açılır
    await Rk.page.locator('#my-parts li', { hasText: 'Ek tank' }).locator('[data-remove]').click();
    await sleep(600);
    const sp2 = await Sp.page.evaluate(() => { const b = document.querySelector('#slot-list button[data-slot="tank-3"]'); return b ? !b.disabled : null; });
    ok('parça çıkınca yuva diğer role açılır', sp2 === true, sp2);
    // servis bölmesi (hem structure hem battery hem instrument hem computer): paylaşılan
    // yönetici part:add -> NOT_ALLOWED
    const da = await L.rawEmit(room, 'D', 'part:add', { partId: 'engine-kestrel', slotId: 'eng-c' });
    ok('yönetici part:add NOT_ALLOWED', da.res && da.res.error === 'NOT_ALLOWED', JSON.stringify(da));
    // yanlış yuva / geçersiz
    const mm = await L.rawEmit(room, 'R', 'part:add', { partId: 'engine-kestrel', slotId: 'tank-2' });
    ok('SLOT_MISMATCH', mm.res && mm.res.error === 'SLOT_MISMATCH', JSON.stringify(mm));
    const iv = await L.rawEmit(room, 'R', 'part:add', { partId: 'engine-kestrel', slotId: 'yok-yuva' });
    ok('INVALID_SLOT', iv.res && iv.res.error === 'INVALID_SLOT', JSON.stringify(iv));
    await L.closeRoom(room);
  } finally { L.stopServer(server); console.log('stderr:', server.stderr.slice(0, 400)); }
});

// ---------- yardımcılar ----------
async function slotState(p, partId) {
  await p.page.click(`button[data-pick="${partId}"]`);
  await sleep(250);
  const r = await p.page.evaluate(() => {
    const o = {};
    for (const li of document.querySelectorAll('#slot-list li')) {
      const b = li.querySelector('button[data-slot]');
      const rs = li.querySelector('.sl-reason');
      o[b.getAttribute('data-slot')] = { dis: b.disabled, reason: rs ? rs.textContent.trim() : '' };
    }
    return o;
  });
  await p.page.click('#unpick-btn').catch(() => {});
  await sleep(100);
  return r;
}
async function removeAll(p) {
  for (let i = 0; i < 30; i++) {
    const n = await L.countParts(p);
    if (!n) return;
    await p.page.locator('#my-parts [data-remove]').first().click();
    await sleep(250);
  }
}

// ---------- 5: uyumsuzluk kuralları ----------
scenario('rules', async (L) => {
  const server = await L.startServer({ PP_EVENTS: 'none', PP_TELEMETRY_DELAY_MS: '0', PP_WINDOW_SEC: '900' });
  const browser = await L.getBrowser();
  try {
    const room = await L.setupRoom(browser, server, 'r');
    await L.pickFrame(room, 'frame-cargo');
    const W = room.workers;
    const rules = Object.fromEntries(L.framesData.rules.map((r) => [r.id, r]));
    async function one(ruleId, A, B) {
      const rule = rules[ruleId];
      for (const [first, second, tag] of [[A, B, 'A->B'], [B, A, 'B->A (ters)']]) {
        const okA = await L.placeUI(W[first.role], first.part, first.slot);
        if (!okA) { ok(`${ruleId} ${tag}: ilk parça yerleşti`, false, JSON.stringify(first)); await removeAll(W.rocket); await removeAll(W.spacecraft); await removeAll(W.payload); continue; }
        const stt = await slotState(W[second.role], second.part);
        const e = stt[second.slot];
        ok(`${ruleId} ${tag}: yuva ${second.slot} engelli`, e && e.dis, JSON.stringify(e));
        ok(`${ruleId} ${tag}: gerekçe = kural reason`, e && e.reason.includes(rule.reason), e && e.reason);
        ok(`${ruleId} ${tag}: gerekçede sayı yok`, e && !digitsIn(e.reason));
        const f = await L.rawEmit(room, second.role === 'rocket' ? 'R' : second.role === 'spacecraft' ? 'S' : 'X', 'part:add', { partId: second.part, slotId: second.slot });
        ok(`${ruleId} ${tag}: socket PART_CONFLICT + aynı mesaj`, f.res && f.res.error === 'PART_CONFLICT' && f.res.message === rule.reason, JSON.stringify(f.res));
        // başka yuvalar (uzak) açık mı
        if (tag === 'A->B' && ruleId === 'shield-vs-solar') await L.shot(W[second.role], 'rule-blocked-reason');
        await removeAll(W.rocket); await removeAll(W.spacecraft); await removeAll(W.payload);
        await sleep(200);
      }
    }
    await one('shield-vs-solar', { role: 'spacecraft', part: 'shield-light', slot: 'p-n1' }, { role: 'spacecraft', part: 'solar-small', slot: 'p-n2' });
    await one('dish-vs-solar', { role: 'payload', part: 'relay-antenna', slot: 'p-s1' }, { role: 'spacecraft', part: 'solar-small', slot: 'p-s2' });
    await one('radar-vs-radio', { role: 'payload', part: 'radar', slot: 'p-e' }, { role: 'spacecraft', part: 'antenna-hga', slot: 'p-n1' });
    await one('optics-vs-engine', { role: 'payload', part: 'camera', slot: 's1-e' }, { role: 'rocket', part: 'engine-kestrel', slot: 'eng-e' });
    await one('cryo-vs-heat', { role: 'rocket', part: 'fuel-hydrolox', slot: 'fuel' }, { role: 'spacecraft', part: 'battery', slot: 'tank-3' });
    await one('drill-vs-optics', { role: 'payload', part: 'drill', slot: 'pl-3' }, { role: 'payload', part: 'camera', slot: 'p-n1' });
    // kontrol: kuralsız komşuluk serbest (güneş paneli farklı yüzde kalkana yakın)
    await L.placeUI(W.spacecraft, 'shield-light', 'p-n1');
    const st2 = await slotState(W.spacecraft, 'solar-small');
    ok('farklı yüzdeki panel kalkanla çakışmaz (p-e açık)', st2['p-e'] && !st2['p-e'].dis, JSON.stringify(st2['p-e']));
    await removeAll(W.spacecraft);
    // ikinci gövde: hidrojen + batarya komşuluğu Dev'de (tank-3 komşu fuel)
    await L.closeRoom(room);
  } finally { L.stopServer(server); console.log('stderr:', server.stderr.slice(0, 300)); }
});

// ---------- bağımsız hesap (physics.js'e bakmadan) ----------
function calc(build, frame) {
  const g0 = L.catalog.constants.g0;
  let dry = frame.massKg, fuel = 0, thrust = 0, ti = 0, gen = 0, use = 0, heat = 0, shield = 0, spent = frame.cost, mult = 0;
  for (const pl of build) {
    const p = L.P(pl.partId);
    dry += p.massKg; fuel += p.fuelKg; thrust += p.thrustKN; ti += p.thrustKN * p.isp;
    gen += p.powerGenW; use += p.powerUseW; heat += p.heat; shield += p.heatShield; spent += p.cost;
    if (p.category === 'fuel') mult = p.ispMult;
  }
  const mass = dry + fuel;
  const isp = thrust > 0 ? (ti / thrust) * mult : 0;
  return { mass, dry, fuel, thrust, isp, twr: (thrust * 1000) / (mass * g0), dv: isp * g0 * Math.log(mass / dry), gen, use, heat, shield, spent };
}

async function runWin(L, label, missionId, solIdx, envExtra, shotTag) {
  const server = await L.startServer({ PP_EVENTS: 'none', PP_TELEMETRY_DELAY_MS: '0', PP_WINDOW_SEC: '600', ...(envExtra || {}) });
  const browser = await L.getBrowser();
  try {
    const room = await L.roomWithMission(browser, server, label, missionId);
    const mission = room.mission;
    const sol = typeof solIdx === 'object' ? solIdx : SOLUTIONS[mission.id][solIdx];
    const frame = L.FR(sol.frameId);
    const { D } = room;
    console.log(`[${label}] görev=${mission.id} gövde=${sol.frameId}`);
    // yönetici setup görev kartı
    await L.shot(D, `${shotTag}-director-setup`);
    await L.pickFrame(room, sol.frameId);
    const gs = await D.page.locator('#frame-box').innerText();
    ok(`[${label}] #frame-box ad/kütle/maliyet`, gs.includes(frame.name) && gs.replace(/[.,\s]/g, '').includes(String(frame.massKg)) && gs.includes(String(frame.cost)), gs.replace(/\n/g, ' | '));
    const bb0 = await D.page.locator('#budget-box').innerText();
    ok(`[${label}] bütçe kutusu gövde maliyetini içerir (harcanan=${frame.cost})`, bb0.includes(String(frame.cost)), bb0.replace(/\n/g, ' | '));
    const t0 = Date.now();
    const fails = await L.placeSolution(room, sol);
    const dt = (Date.now() - t0) / 1000;
    ok(`[${label}] çözüm UI ile kuruldu (${sol.placements.length} parça, ${sol.placements.length * 2}+ tıklama, ${dt.toFixed(1)} sn betikle)`, fails.length === 0, fails.join(','));
    await sleep(600);
    const calcd = calc(sol.placements, frame);
    const gg = await L.gauges(D);
    console.log(`[${label}] gauges`, JSON.stringify(gg));
    ok(`[${label}] tüm göstergeler yeşil`, gg.length >= 5 && gg.every((g) => g.ok === 'true'), JSON.stringify(gg));
    const bb = await D.page.locator('#budget-box').innerText();
    const over = await D.page.locator('#budget-box').getAttribute('data-over');
    ok(`[${label}] bütçe harcanan = hesap (${calcd.spent})`, bb.replace(/[.,]/g, '').includes(String(calcd.spent)), bb.replace(/\n/g, ' | '));
    ok(`[${label}] data-over=false`, over === 'false', over);
    const strip = await D.page.locator('#gauge-strip').innerText();
    console.log(`[${label}] strip:`, strip.replace(/\n/g, ' | '));
    console.log(`[${label}] hesap: Δv=${calcd.dv.toFixed(0)} twr=${calcd.twr.toFixed(2)} kütle=${calcd.mass} güç=${calcd.gen}/${calcd.use} ısı=${calcd.heat}/${calcd.shield}`);
    const dvTxt = await D.page.locator('#g-deltav').innerText();
    ok(`[${label}] Δv göstergesi hesapla uyumlu`, dvTxt.replace(/[.,\s]/g, '').includes(String(Math.round(calcd.dv))) || dvTxt.replace(/[.,\s]/g, '').includes(String(Math.floor(calcd.dv))) || dvTxt.replace(/[.,\s]/g, '').includes(String(Math.ceil(calcd.dv))), dvTxt.replace(/\n/g, ' '));
    const twrTxt = await D.page.locator('#g-twr').innerText();
    ok(`[${label}] TWR göstergesi hesapla uyumlu`, twrTxt.includes(calcd.twr.toFixed(2)) || twrTxt.includes(calcd.twr.toFixed(1)), twrTxt.replace(/\n/g, ' '));
    const bld = await D.page.locator('#build-box').innerText();
    const missingSlots = sol.placements.filter((pl) => !D.page.locator(`#build-box li[data-slot-id="${pl.slotId}"]`));
    const nLi = await D.page.locator('#build-box li[data-slot-id]').count();
    ok(`[${label}] #build-box her parça için yuva satırı`, nLi === sol.placements.length, `${nLi}/${sol.placements.length}`);
    const log = await D.page.locator('#log-box').innerText();
    ok(`[${label}] log'da ± fiyat`, /[+\-−]\s?\d/.test(log), log.slice(0, 200).replace(/\n/g, ' | '));
    await L.shot(D, `${shotTag}-director-ready`);
    await L.shot(room.R, `${shotTag}-rocket-ready`);
    // anket
    await D.page.waitForSelector('#poll-start-btn:not([disabled])', { timeout: 4000 }).catch(() => {});
    await D.page.click('#poll-start-btn');
    for (const w of [room.R, room.S, room.X]) await w.page.waitForSelector('#vote-go-btn', { state: 'visible', timeout: 4000 });
    await L.shot(room.S, `${shotTag}-poll-worker`);
    await L.shot(D, `${shotTag}-poll-director`);
    for (const w of [room.R, room.S, room.X]) { await w.page.click('#vote-go-btn'); await sleep(150); }
    for (const p of [D, room.R, room.S, room.X]) await p.page.waitForSelector('#screen-result:not([hidden])', { timeout: 8000 });
    const stage = await D.page.locator('#screen-result').getAttribute('data-stage');
    ok(`[${label}] sonuç ekranı açıldı (stage=${stage})`, true);
    await sleep(1500);
    await L.shot(room.R, `${shotTag}-launch-anim`);
    const skip = room.R.page.locator('#skip-launch-btn');
    if (await skip.isVisible().catch(() => false)) { await skip.click(); ok(`[${label}] #skip-launch-btn çalışır`, true); }
    else ok(`[${label}] #skip-launch-btn göründü (animasyon bitmiş olabilir)`, (await room.R.page.locator('#screen-result').getAttribute('data-stage')) === 'panel', await room.R.page.locator('#screen-result').getAttribute('data-stage'));
    await room.R.page.waitForSelector('#result-panel', { state: 'visible', timeout: 15000 });
    await sleep(500);
    const title = await room.R.page.locator('#result-title').innerText();
    ok(`[${label}] sonuç success`, /başar|tamam|başarı/i.test(title) || (await L.st(room.R)).result?.success === true, title);
    const rp = await room.R.page.locator('#result-panel').innerText();
    ok(`[${label}] #result-panel dolu`, rp.length > 200, rp.length);
    await L.shot(room.R, `${shotTag}-result`);
    await L.shot(D, `${shotTag}-result-director`);
    console.log(`[${label}] result:`, rp.replace(/\n/g, ' | ').slice(0, 500));
    await L.closeRoom(room);
    return { server };
  } finally { L.stopServer(server); if (server.stderr) console.log('stderr:', server.stderr.slice(0, 300)); }
}

L.runWin = runWin; L.calc = calc;
scenario('win-mars', async (L) => { await runWin(L, 'mars-cargo', 'mars-rover', 0, null, 'win-mars'); });
scenario('win-lunar', async (L) => { await runWin(L, 'lunar-swift', 'lunar-relay', 0, null, 'win-lunar'); await runWin(L, 'lunar-cargo', 'lunar-relay', 1, null, 'win-lunar2'); });
scenario('win-mars2', async (L) => { await runWin(L, 'mars-heavy', 'mars-rover', 1, null, 'win-mars2'); });
scenario('win-ast', async (L) => { await runWin(L, 'ast-cargo', 'asteroid-sample', 0, null, 'win-ast'); await runWin(L, 'ast-heavy', 'asteroid-sample', 1, null, 'win-ast2'); });

// ---------- 9: GÜVENLİK ----------
const FORBID_KEYS = ['telemetry', 'telemetryDelayMs', 'mission', 'log', 'undoLeft', 'undo', 'build', 'result', 'locks', 'pendingEvents', 'frames', 'frameInfo', 'budget', 'cost',
  'massKg', 'dryMassKg', 'thrustKN', 'isp', 'powerGenW', 'powerUseW', 'heat', 'heatShield', 'fuelKg', 'ispMult', 'max', 'requires', 'tags', 'neighbors', 'acceptsTags',
  'requiredDeltaV', 'requiredInstruments', 'parMassKg', 'title', 'target', 'nasaFact', 'nasaReal', 'durationSec', 'checks', 'deltaV', 'spent', 'price', 'ready', 'missing'];
function scanText(txt, label, extraIds, mission, bad, opts = {}) {
  for (const k of FORBID_KEYS) {
    if (opts.allowResult && k === 'result') continue;
    if (new RegExp('\\?"' + k + '\\?"\s*:').test(txt)) bad.push(`${label}: yasak anahtar "${k}"`);
  }
  for (const [nm, id] of Object.entries(extraIds)) if (id && txt.includes(id)) bad.push(`${label}: başka kimlik ${nm}`);
  if (mission) for (const s of [mission.title, mission.target, mission.nasaFact.slice(0, 25), mission.nasaReal.slice(0, 25)]) if (txt.includes(s)) bad.push(`${label}: görev metni "${s.slice(0, 18)}"`);
}
scenario('security', async (L) => {
  const server = await L.startServer({ PP_EVENTS: 'none', PP_TELEMETRY_DELAY_MS: '300', PP_WINDOW_SEC: '600' });
  const browser = await L.getBrowser();
  try {
    const room = await L.setupRoom(browser, server, 'x');
    const { D, workers } = room;
    const mission = room.mission;
    const ids = {};
    for (const [k, p] of [['D', D], ['R', room.R], ['S', room.S], ['X', room.X]]) {
      ids[k] = await p.page.evaluate(() => { const v = sessionStorage.getItem(Object.keys(sessionStorage)[0]); return v ? JSON.parse(v).playerId : null; });
    }
    ok('playerId okundu', ids.D && ids.R && ids.S && ids.X);
    const bad = [];
    const snap = (phase) => {
      const o = {};
      for (const [k, p] of [['R', room.R], ['S', room.S], ['X', room.X]]) o[k] = { rawLen: p.raw.length };
      return o;
    };
    async function scanPhase(tag, domToo) {
      for (const [k, p] of [['R', room.R], ['S', room.S], ['X', room.X]]) {
        const others = Object.fromEntries(Object.entries(ids).filter(([kk]) => kk !== k));
        const raw = p.raw.filter((r) => !r.startsWith('SENT')).join('\n');
        scanText(raw, `${tag} ${k} ham`, others, mission, bad);
        const dbg = await p.page.locator('#debug-state').textContent();
        scanText(dbg, `${tag} ${k} debug-state`, others, mission, bad);
        if (domToo) {
          const t = await p.page.locator('#screen-game').innerText();
          const cleaned = t.replace(/\d{1,2}:\d{2}(:\d{2})?/g, '').replace(/\d\. pencere/g, '').replace(/3B/g, '');
          const lines = cleaned.split('\n').filter((l) => /\d/.test(l));
          if (lines.length) bad.push(`${tag} ${k} DOM'da sayı: ${lines.slice(0, 5).join(' // ')}`);
          const all = await p.page.evaluate(() => document.body.innerText);
          for (const s of [mission.title, mission.target, String(mission.requiredDeltaV)]) if (all.includes(s)) bad.push(`${tag} ${k} DOM görev metni ${s}`);
        }
      }
    }
    await sleep(300);
    await scanPhase('setup', false);
    const setupDom = await room.R.page.evaluate(() => document.body.innerText.replace(/\d{1,2}:\d{2}(:\d{2})?/g, ''));
    ok('setup çalışan DOM: sayı yok', !/\d/.test(setupDom), setupDom.split('\n').filter((l) => /\d/.test(l)).slice(0, 4).join(' // '));
    const dbgSetup = await L.st(room.R);
    console.log('çalışan setup debug anahtarları:', Object.keys(dbgSetup).join(','));
    await L.pickFrame(room, 'frame-cargo');
    // parça yerleştir (Kargo, Ay)
    const sol = SOLUTIONS['lunar-relay'][1];
    await L.placeSolution(room, sol);
    await sleep(800);
    const dbgB = await L.st(room.S);
    console.log('çalışan building debug anahtarları:', Object.keys(dbgB).join(','), '| catalog öğe anahtarları:', Object.keys((dbgB.catalog || [])[0] || {}).join(','), '| slots[0]:', JSON.stringify((dbgB.catalog || [])[0] && (dbgB.catalog[0].slots || [])[0]));
    await scanPhase('building', true);
    // yöneticide başka playerId olmamalı
    const dRaw = D.raw.filter((r) => !r.startsWith('SENT')).join('\n');
    for (const k of ['R', 'S', 'X']) ok(`yönetici ham trafiğinde başka playerId yok (${k})`, !dRaw.includes(ids[k]));
    const dDbg = await D.page.locator('#debug-state').textContent();
    for (const k of ['R', 'S', 'X']) ok(`yönetici debug-state başka playerId yok (${k})`, !dDbg.includes(ids[k]));
    // anket
    await D.page.click('#poll-start-btn');
    await room.R.page.waitForSelector('#vote-go-btn', { state: 'visible', timeout: 4000 });
    await sleep(600);
    await scanPhase('poll', true);
    // çalışan uid'leri: başkalarının uid'leri
    const dState = await L.st(D);
    const uidsByRole = {};
    const bd = dState.build || {};
    console.log('yönetici build şekli:', Array.isArray(bd) ? 'dizi' : Object.keys(bd).join(','), JSON.stringify(Array.isArray(bd) ? bd[0] : bd[Object.keys(bd)[0]]).slice(0, 200));
    if (Array.isArray(bd)) { for (const b of bd) (uidsByRole[b.role] = uidsByRole[b.role] || []).push(b.uid); }
    else for (const [role, arr] of Object.entries(bd)) uidsByRole[role] = (arr || []).map((b) => b.uid);
    const roleOf = { R: 'rocket', S: 'spacecraft', X: 'payload' };
    for (const k of ['R', 'S', 'X']) {
      const raw = workers[roleOf[k]].raw.filter((r) => !r.startsWith('SENT')).join('\n');
      for (const [role, us] of Object.entries(uidsByRole)) if (role !== roleOf[k]) for (const u of us) if (raw.includes(u)) { bad.push(`${k}: başka rolün uid'i (${role}) ${u}`); break; }
    }
    // gövde kütle/maliyet değerleri anahtarlı biçimde sızmasın (ekstra): "massKg":1300 benzeri
    for (const k of ['R', 'S', 'X']) {
      const raw = workers[roleOf[k]].raw.join('\n');
      if (/\?"(massKg|cost)\?"/.test(raw)) bad.push(`${k}: massKg/cost`);
    }
    ok('GÜVENLİK: çalışan ham trafik / debug / DOM sızıntısı yok', bad.length === 0, bad.slice(0, 12).join(' || '));
    bad.forEach((b) => console.log('  SIZINTI:', b));
    // polling yanıtları da toplandı mı?
    const kinds = { ws: room.R.raw.filter((r) => /^42/.test(r)).length, poll: room.R.raw.filter((r) => /^\d/.test(r) && !/^42/.test(r)).length };
    console.log('ham kayıt:', JSON.stringify(kinds), 'toplam', room.R.raw.length);
    await L.closeRoom(room);
  } finally { L.stopServer(server); }
});
