// Aşama 4 e2e testi. Playwright proje dışında: PW_DIR. SHOT_DIR (opsiyonel) ekran görüntüleri. ONLY=A1,B,... ile senaryo seçilir.
// Her senaryo kendi sunucusunu (kendi PP_* değerleriyle) spawn eder.
const path = require('path');
const { spawn } = require('child_process');
const PW = process.env.PW_DIR;
const { chromium } = require(path.join(PW, 'node_modules', 'playwright'));
const catalog = require('../../data/parts.json');
const ROOT = path.join(__dirname, '..', '..');
const SHOT = process.env.SHOT_DIR;
const ONLY = process.env.ONLY ? process.env.ONLY.split(',') : null;
const results = [];
const ok = (name, cond, extra) => { results.push({ name, pass: !!cond }); console.log((cond ? 'PASS ' : 'FAIL ') + name + (extra !== undefined && extra !== '' ? ' :: ' + extra : '')); };
const sleep = (ms) => new Promise(r => setTimeout(r, ms));
const P = (id) => catalog.parts.find(p => p.id === id);
const SOLUTIONS = {
  'lunar-relay': { rocket: ['engine-kestrel', 'tank-large', 'fuel-kerosene'], spacecraft: ['structure-frame', 'solar-small', 'solar-small', 'shield-light'] },
  'mars-rover': { rocket: ['engine-titan', 'tank-large', 'tank-large', 'fuel-hydrolox'], spacecraft: ['structure-frame', 'solar-large', 'shield-heavy'] },
  'asteroid-sample': { rocket: ['engine-heron', 'engine-heron', 'tank-large', 'fuel-hydrolox'], spacecraft: ['structure-frame', 'solar-small', 'shield-light', 'shield-light'] },
};
const mkSol = (m) => ({ ...SOLUTIONS[m.id], payload: m.requiredInstruments });
const ROLE_OF = { rocket: 'R', spacecraft: 'S', payload: 'X' };

let browser; const issues = []; const serverErr = {};
let portSeq = 3200;

async function scenario(name, env, fn) {
  if (ONLY && !ONLY.includes(name)) return;
  const PORT = ++portSeq, URL = `http://localhost:${PORT}`;
  const e = { ...process.env, PORT: String(PORT) };
  for (const k of Object.keys(e)) if (k.startsWith('PP_')) delete e[k];
  Object.assign(e, env);
  console.log(`\n=== Senaryo ${name} (PORT ${PORT}) env=${JSON.stringify(env)} ===`);
  const srv = spawn('node', ['server/index.js'], { cwd: ROOT, env: e });
  let stderr = ''; srv.stderr.on('data', d => stderr += d);
  await sleep(1200);
  const ctxs = [];
  const S = {
    URL, name,
    async mk(nm, viewport) {
      const ctx = await browser.newContext(viewport ? { viewport, isMobile: false } : {}); ctxs.push(ctx);
      const page = await ctx.newPage();
      const p = { name: nm, ctx, page, raw: [] };
      page.on('console', m => { if (m.type() === 'error') issues.push(`[${name}/${nm}] console.error: ${m.text()}`); });
      page.on('pageerror', er => issues.push(`[${name}/${nm}] pageerror: ${er.message}`));
      page.on('requestfailed', r => issues.push(`[${name}/${nm}] requestfailed: ${r.url()}`));
      page.on('websocket', ws => { ws.on('framereceived', f => p.raw.push(String(f.payload))); });
      page.on('response', async r => {
        if (r.url().includes('/socket.io/')) { try { p.raw.push(await r.text()); } catch (er) {} }
        if (r.status() >= 400 && !r.url().includes('/socket.io/')) issues.push(`[${name}/${nm}] HTTP ${r.status()} ${r.url()}`);
      });
      await page.goto(URL);
      await page.waitForSelector('#screen-entry:not([hidden])');
      return p;
    },
  };
  try { await fn(S); } catch (er) { ok(`${name}: senaryo çöktü`, false, er.stack); }
  for (const c of ctxs) await c.close().catch(() => {});
  srv.kill(); await sleep(300);
  serverErr[name] = stderr.trim();
  ok(`${name}: sunucu stderr boş`, stderr.trim() === '', stderr.trim().slice(0, 300));
}

// ---------- UI yardımcıları
const st = async (p) => JSON.parse(await p.page.locator('#debug-state').textContent());
const vis = (p, sel) => p.page.locator(sel).isVisible();
async function setupRoom(S, tag, viewport) {
  const D = await S.mk(tag + 'D', viewport), R = await S.mk(tag + 'R', viewport), Sp = await S.mk(tag + 'S', viewport), X = await S.mk(tag + 'X', viewport);
  await D.page.fill('#name-input', 'Yon'); await D.page.click('#create-btn');
  await D.page.waitForSelector('#screen-lobby:not([hidden])');
  const lobbyTimerHidden = !(await vis(D, '#timer'));
  const code = (await D.page.locator('#room-code').innerText()).trim();
  for (const [p, n] of [[R, 'Rok'], [Sp, 'Uza'], [X, 'Yuk']]) {
    await p.page.fill('#name-input', n); await p.page.fill('#code-input', code); await p.page.click('#join-btn');
    await p.page.waitForSelector('#screen-lobby:not([hidden])');
  }
  await D.page.click('[data-role="director"]'); await sleep(80);
  await R.page.click('[data-role="rocket"]'); await sleep(80);
  await Sp.page.click('[data-role="spacecraft"]'); await sleep(80);
  await X.page.click('[data-role="payload"]');
  for (const p of [D, R, Sp, X]) await p.page.waitForSelector('#screen-game:not([hidden])', { timeout: 4000 });
  const room = { D, R, S: Sp, X, code, lobbyTimerHidden, t0: Date.now() };
  room.mission = (await st(D)).mission;
  room.ids = {};
  for (const [k, p] of Object.entries({ D, R, S: Sp, X })) room.ids[k] = (await p.page.evaluate(() => JSON.parse(sessionStorage.getItem('pixelPayloadSession')))).playerId;
  return room;
}
const four = (room) => [room.D, room.R, room.S, room.X];
const workers = (room) => [['R', room.R], ['S', room.S], ['X', room.X]];
const cnt = (p) => p.page.locator('#my-parts [data-remove]').count();
async function addPart(p, id) {
  const before = await cnt(p);
  await p.page.click(`[data-add="${id}"]`);
  try { await p.page.waitForFunction((b) => document.querySelectorAll('#my-parts [data-remove]').length > b, before, { timeout: 2000 }); return true; } catch (e) { return false; }
}
async function buildUI(room, spec, order) {
  for (const id of spec.rocket || []) await addPart(room.R, id);
  for (const id of spec.spacecraft || []) await addPart(room.S, id);
  for (const id of spec.payload || []) await addPart(room.X, id);
}
const gauges = (D) => D.page.evaluate(() => [...document.querySelectorAll('#gauges [data-check]')].map(e => ({ c: e.getAttribute('data-check'), ok: e.getAttribute('data-ok'), t: e.textContent.trim() })));
const parseTimer = (p) => p.page.evaluate(() => { const t = document.getElementById('timer-value').textContent.trim(); const m = /^(\d+):(\d+)$/.exec(t); return { txt: t, sec: m ? (+m[1]) * 60 + (+m[2]) : null, win: document.getElementById('timer').getAttribute('data-window'), urg: document.getElementById('timer').getAttribute('data-urgent'), shown: !!document.getElementById('timer').offsetParent }; });
async function startPollUI(room) { await room.D.page.click('#poll-start-btn'); for (const p of four(room)) await p.page.waitForSelector('#poll-box:not([hidden])', { timeout: 3000 }); }
async function allGo(room) { for (const [, p] of workers(room)) { await p.page.click('#vote-go-btn'); await sleep(100); } }
async function waitResultPanel(room) { for (const p of four(room)) await p.page.waitForSelector('#result-panel:not([hidden])', { timeout: 9000 }); }
async function skipSeq(room) { for (const p of four(room)) { try { await p.page.click('#skip-launch-btn', { timeout: 1200 }); } catch (e) {} } }
async function launchUI(room) { await startPollUI(room); await allGo(room); for (const p of four(room)) await p.page.waitForSelector('#screen-result:not([hidden])', { timeout: 5000 }); await skipSeq(room); await waitResultPanel(room); await sleep(100); }

const FORB_KEYS = ['telemetry', 'telemetryDelayMs', 'mission', 'log', 'undoLeft', 'undo', 'build', 'result', 'locks', 'pendingEvents', 'massKg', 'cost', 'thrustKN', 'isp', 'powerGenW', 'powerUseW', 'heat', 'heatShield', 'fuelKg', 'ispMult', 'max', 'requires', 'requiredDeltaV', 'budget', 'nasaFact', 'nasaReal', 'requiredInstruments', 'durationSec', 'parMassKg', 'checks', 'deltaV', 'score', 'breakdown'];
function rawNoResult(p) { return p.raw.filter(r => !/phase\\?"\s*:\s*\\?"result/.test(r)).join('\n'); }
function leakWorkersFrames(label, room) {
  const bad = [];
  const m = room.mission;
  for (const [nm, p] of workers(room)) {
    const raw = rawNoResult(p);
    for (const k of FORB_KEYS) if (new RegExp('\\\\?"' + k + '\\\\?"\\s*:').test(raw)) bad.push(`${nm}:anahtar ${k}`);
    for (const [onm, id] of Object.entries(room.ids)) if (onm !== nm && raw.includes(id)) bad.push(`${nm}:baska playerId (${onm})`);
    for (const s of [m.title, m.target, m.nasaFact.slice(0, 25), m.nasaReal.slice(0, 25)]) if (raw.includes(s)) bad.push(`${nm}:gorev metni`);
  }
  const rawD = rawNoResult(room.D.page ? room.D : room.D);
  if (/\\?"pendingEvents\\?"\s*:/.test(rawD)) bad.push('D:pendingEvents');
  ok(`${label}: calisan ham verisinde (WS/polling) sizinti yok; yoneticide pendingEvents yok`, bad.length === 0, bad.slice(0, 8).join(' | '));
}
async function leakDom(label, room) {
  const m = room.mission;
  for (const [nm, p] of workers(room)) {
    const body = await p.page.evaluate(() => document.body.innerText + '\n' + document.getElementById('debug-state').textContent);
    const s = JSON.parse(await p.page.locator('#debug-state').textContent());
    const hits = [m.title, m.target, m.nasaFact.slice(0, 25), m.nasaReal.slice(0, 25), 'parMassKg', 'pendingEvents'].filter(x => body.includes(x));
    const forb = FORB_KEYS.filter(k => k in s);
    ok(`${label} ${nm} DOM/debug-state sizinti yok`, hits.length === 0 && forb.length === 0, hits.concat(forb).join(','));
  }
}

// ---------- ham socket odaları (in-page io)
async function installRaw(S) {
  const raw = await S.mk('RAW');
  await raw.page.evaluate((FORB) => {
    window.FORB = FORB;
    window.RM = {};
    window.sleepP = (ms) => new Promise(r => setTimeout(r, ms));
    window.walk = (o, p, out) => { if (o && typeof o === 'object') for (const k of Object.keys(o)) { if (window.FORB.includes(k)) out.push(p + '.' + k); window.walk(o[k], p + '.' + k, out); } };
    window.mkc = (isWorker) => new Promise((res) => {
      const s = io({ forceNew: true }); const c = { s, state: null, frames: [], problems: [], isWorker, nstates: 0 };
      s.on('state', (stt) => {
        c.state = stt; c.nstates++;
        const js = JSON.stringify(stt);
        if (stt.phase !== 'result') c.frames.push(js);
        if (/"pendingEvents"/.test(js)) c.problems.push('pendingEvents');
        if (isWorker && stt.phase !== 'result' && stt.phase !== 'lobby') { const out = []; window.walk(stt, '', out); out.forEach(x => c.problems.push(x)); }
      });
      s.on('connect', () => res(c));
    });
    window.em = (c, ev, pl) => new Promise((res) => { c.s.emit(ev, pl, (r) => res(r)); });
    window.mkRoom = async (key) => {
      const d = await mkc(false), r = await mkc(true), s = await mkc(true), x = await mkc(true);
      const a1 = await em(d, 'room:create', { name: 'D' }); const ids = { D: a1.playerId };
      for (const [c, n, k] of [[r, 'r', 'R'], [s, 's', 'S'], [x, 'x', 'X']]) { const a = await em(c, 'room:join', { code: a1.code, name: n }); ids[k] = a.playerId; }
      await em(d, 'role:select', { role: 'director' }); await em(r, 'role:select', { role: 'rocket' }); await em(s, 'role:select', { role: 'spacecraft' }); await em(x, 'role:select', { role: 'payload' });
      await sleepP(300);
      window.RM[key] = { code: a1.code, D: d, R: r, S: s, X: x, ids, t0: Date.now() };
      return { code: a1.code, phase: d.state.phase, mission: d.state.mission };
    };
    window.err = (a) => (a && a.ok ? 'ok' : (a && a.error));
    window.E = async (key, who, ev, pl) => err(await em(RM[key][who], ev, pl));
    window.buildR = async (key, spec) => {
      const o = RM[key]; const res = [];
      for (const [role, who] of [['rocket', 'R'], ['spacecraft', 'S'], ['payload', 'X']]) for (const id of (spec[role] || [])) res.push(await E(key, who, 'part:add', { partId: id }));
      await sleepP(150); return res;
    };
    window.allGoR = async (key) => { const o = RM[key]; const r = []; for (const w of ['R', 'S', 'X']) r.push(await E(key, w, 'poll:vote', { vote: 'go' })); return r; };
    window.snap = (key, who) => { const c = RM[key][who || 'D']; return JSON.parse(JSON.stringify(c.state)); };
    window.leakR = (key) => {
      const o = RM[key]; const m = o.D.state.mission || (o.missionSaved); const bad = [];
      for (const w of ['R', 'S', 'X']) {
        const c = o[w]; c.problems.forEach(p => bad.push(w + ':' + p));
        const all = c.frames.join('\n');
        for (const [k, id] of Object.entries(o.ids)) if (k !== w && all.includes(id)) bad.push(w + ':baska playerId ' + k);
        if (m) for (const sx of [m.title, m.target, m.nasaFact.slice(0, 25), m.nasaReal.slice(0, 25)]) if (all.includes(sx)) bad.push(w + ':gorev metni');
      }
      o.D.problems.forEach(p => bad.push('D:' + p));
      return bad;
    };
    window.closeR = (key) => { const o = RM[key]; for (const w of ['D', 'R', 'S', 'X']) o[w].s.disconnect(); };
  }, FORB_KEYS);
  return raw;
}
const rev = (raw, fn, ...a) => raw.page.evaluate(fn, ...a);

// ====================== SENARYOLAR ======================
(async () => {
  browser = await chromium.launch();

  // ---- A1: sayaç (UI), pencere geçişi, window-missed (tıklamasız)
  await scenario('A1', { PP_WINDOW_SEC: '40', PP_SECOND_WINDOW_SEC: '6', PP_EVENTS: 'none', PP_TELEMETRY_DELAY_MS: '0' }, async (S) => {
    const room = await setupRoom(S, 'A');
    ok('3 lobide #timer gizli', room.lobbyTimerHidden);
    for (const p of four(room)) await p.page.waitForSelector('#timer-bar:not([hidden])', { timeout: 2000 });
    const ts = await Promise.all(four(room).map(parseTimer));
    ok('3 4 sayfada #timer gorunur, dd:ss, data-window=1', ts.every(t => t.shown && t.sec !== null && t.win === '1'), JSON.stringify(ts.map(t => t.txt)));
    const secs = ts.map(t => t.sec);
    ok('3 sayfalar arasi fark <=1 sn', Math.max(...secs) - Math.min(...secs) <= 1, secs.join(','));
    ok('3 baslangic degeri ~40 (>=36)', secs[0] >= 36 && secs[0] <= 40, secs[0]);
    ok('3 baslangicta data-urgent=false', ts.every(t => t.urg === 'false'));
    await sleep(3000);
    const t2 = await parseTimer(room.D);
    ok('3 geri sayiyor (3 sn sonra 2-4 sn azaldi)', secs[0] - t2.sec >= 2 && secs[0] - t2.sec <= 4, `${secs[0]} -> ${t2.sec}`);
    // yerel guncelleme sikligi
    const samples = await room.D.page.evaluate(async () => { const out = []; const el = document.getElementById('timer-value'); let last = el.textContent; const t0 = performance.now(); let n = 0; const obs = new MutationObserver(() => { n++; }); obs.observe(el, { childList: true, characterData: true, subtree: true }); await new Promise(r => setTimeout(r, 2200)); obs.disconnect(); return n; });
    ok('3 sayac DOM guncelleme >=2 kez/sn tum bir pencerede (mutasyon 2.2 sn icinde >=2)', samples >= 2, 'mutasyon=' + samples);
    // urgent
    await room.D.page.waitForFunction(() => { const m = /^(\d+):(\d+)$/.exec(document.getElementById('timer-value').textContent.trim()); return m && (+m[1]) * 60 + (+m[2]) <= 28; }, null, { timeout: 20000 });
    await sleep(300);
    const tu = await Promise.all(four(room).map(parseTimer));
    ok('3 son 30 sn: 4 sayfada data-urgent=true', tu.every(t => t.urg === 'true'), JSON.stringify(tu.map(t => [t.txt, t.urg])));
    // pencere 2
    await room.D.page.waitForFunction(() => document.getElementById('timer').getAttribute('data-window') === '2', null, { timeout: 45000 });
    await sleep(300);
    const tw = await Promise.all(four(room).map(parseTimer));
    ok('3 pencere 1 bitince 4 sayfada data-window=2', tw.every(t => t.win === '2'), JSON.stringify(tw.map(t => [t.txt, t.win])));
    ok('3 pencere 2 sayaci ~6 sn ve urgent', tw.every(t => t.sec <= 6 && t.urg === 'true'), JSON.stringify(tw.map(t => [t.txt, t.urg])));
    const label = await room.D.page.locator('#timer-label').innerText();
    ok('3 pencere etiketi "2. pencere"', /2/.test(label), label);
    const dlog = await room.D.page.locator('#log-box').innerText();
    ok('3 yonetici log: "Firlatma penceresi kacirildi! Ikinci pencere acildi"', dlog.includes('Fırlatma penceresi kaçırıldı! İkinci pencere açıldı'), dlog.slice(-200));
    const feeds = await Promise.all([room.R, room.S, room.X].map(p => p.page.locator('#feed').innerText()));
    ok('3 calisan feed: pencere kacirildi satiri', feeds.every(f => f.includes('Fırlatma penceresi kaçırıldı')), feeds[0].slice(-150));
    // 00:00 takılı mı: örnekle
    const seen = [];
    for (let i = 0; i < 40; i++) { const t = await room.R.page.evaluate(() => ({ v: document.getElementById('timer-value').textContent, res: !document.getElementById('screen-result').hidden })); seen.push(t); if (t.res) break; await sleep(250); }
    for (const p of four(room)) await p.page.waitForSelector('#screen-result:not([hidden])', { timeout: 8000 });
    const outs = await Promise.all(four(room).map(p => p.page.locator('#screen-result').getAttribute('data-outcome')));
    ok('3 pencere 2 bitince TIKLAMASIZ 4 sayfada data-outcome=window-missed', outs.every(o => o === 'window-missed'), outs.join(','));
    const tail = seen.slice(-6).map(s => s.v).join(' ');
    console.log('  son sayac ornekleri:', tail);
    const stuck = seen.filter(s => s.v.trim() === '00:00' && !s.res).length;
    ok('3 sayac 00:00da uzun sure takili kalmadi (<=2 ornek=0.5 sn)', stuck <= 2, 'stuck=' + stuck);
    await sleep(300);
    const pan = await Promise.all(four(room).map(p => p.page.evaluate(() => ({ panel: !document.getElementById('result-panel').hidden, launch: !document.getElementById('launch-wrap').hidden, seqText: document.getElementById('launch-sequence').innerText.trim(), timerShown: !!document.getElementById('timer').offsetParent, title: document.getElementById('result-title').innerText, reason: document.getElementById('result-reason').innerText, score: document.getElementById('result-score').innerText, events: document.getElementById('result-events').innerText, time: document.getElementById('result-time').innerText, undo: document.getElementById('result-undo').innerText }))));
    ok('3 window-missed: geri sayim dizisi oynamadi, panel acik', pan.every(x => x.panel && !x.launch && x.seqText === ''), JSON.stringify(pan[0]));
    ok('3 sonucta #timer gizli', pan.every(x => !x.timerShown));
    const dsr = await st(room.D);
    ok('3 window-missed puan 0 / yildiz 0', dsr.result.score.total === 0 && dsr.result.score.stars === 0, JSON.stringify(dsr.result.score));
    console.log('  panel[D]:', JSON.stringify(pan[0]));
    console.log('  result obj:', JSON.stringify({ tl: dsr.result.timeLeftSec, w: dsr.result.window, uu: dsr.result.undoUsed, ev: dsr.result.events, fc: dsr.result.failedChecks }));
    ok('3 window-missed metni anlasilir (baslik/neden)', /kaçırıldı/i.test(pan[0].title) && pan[0].reason.length > 10, pan[0].title + ' | ' + pan[0].reason);
    if (SHOT) await room.R.page.screenshot({ path: path.join(SHOT, 'stage4-windowmissed.png'), fullPage: true });
    leakWorkersFrames('11 A1', room);
  });

  // ---- A2/A3: ham, anket açıkken pencere 2 biter; son saniyede 3. GO
  await scenario('A2', { PP_WINDOW_SEC: '5', PP_SECOND_WINDOW_SEC: '6', PP_EVENTS: 'none', PP_TELEMETRY_DELAY_MS: '0' }, async (S) => {
    const raw = await installRaw(S);
    const r = await rev(raw, () => mkRoom('a'));
    ok('3 A2 oyun basladi (building)', r.phase === 'building');
    const t0 = Date.now();
    const s1 = await rev(raw, () => E('a', 'D', 'poll:start', {}));
    const g1 = await rev(raw, () => E('a', 'R', 'poll:vote', { vote: 'go' }));
    ok('3 A2 pencere 1 icinde anket + 1 GO', s1 === 'ok' && g1 === 'ok', s1 + ',' + g1);
    await sleep(2000);
    const a = await rev(raw, () => snap('a', 'D'));
    ok('3 A2 anket suruyor (phase=poll, timer.window=1 sayaci ankette de isliyor)', a.phase === 'poll' && a.timer && a.timer.window === 1, a.phase + '/' + JSON.stringify(a.timer));
    await sleep(4000);
    const b = await rev(raw, () => snap('a', 'S'));
    ok('3 A2 anketteyken pencere 2ye gecti (phase poll, window 2)', (b.phase === 'poll' && b.timer.window === 2), b.phase + '/' + JSON.stringify(b.timer));
    await sleep(7500);
    const fin = await rev(raw, () => ['D', 'R', 'S', 'X'].map(w => { const s = snap('a', w); return { w, phase: s.phase, outcome: s.result && s.result.outcome, poll: s.poll, total: s.result && s.result.score.total }; }));
    ok('3 A2 anket acikken pencere 2 bitti -> 4 oyuncuda result/window-missed, puan 0, anket yok', fin.every(f => f.phase === 'result' && f.outcome === 'window-missed' && f.total === 0 && !f.poll), JSON.stringify(fin));
    console.log('  elapsed', Date.now() - t0);
    const bad = await rev(raw, () => leakR('a'));
    ok('11 A2 ham state sizinti yok (calisan anahtarlar, pendingEvents)', bad.length === 0, bad.join(','));
    await rev(raw, () => closeR('a'));
  });

  await scenario('A3', { PP_WINDOW_SEC: '3', PP_SECOND_WINDOW_SEC: '5', PP_EVENTS: 'none', PP_TELEMETRY_DELAY_MS: '0' }, async (S) => {
    const raw = await installRaw(S);
    // 3 oda paralel; farklı ofsetlerle 3. GO window 2 bitmeden 600/250/-50 ms
    const offs = [600, 250, -80];
    const outs = await Promise.all(offs.map(async (off, i) => {
      return await raw.page.evaluate(async ([key, off]) => {
        const r = await mkRoom(key);
        await E(key, 'D', 'poll:start', {});
        await E(key, 'R', 'poll:vote', { vote: 'go' }); await E(key, 'S', 'poll:vote', { vote: 'go' });
        // window 2 başlayana kadar bekle
        const D = RM[key].D;
        while (!(D.state.timer && D.state.timer.window === 2)) await sleepP(40);
        const endsAt = D.state.timer.endsAt, skew = D.state.timer.now - Date.now(); // sunucu - yerel
        const target = endsAt - skew - off;
        while (Date.now() < target) await sleepP(5);
        const ack = await E(key, 'X', 'poll:vote', { vote: 'go' });
        await sleepP(1500);
        const fin = ['D', 'R', 'S', 'X'].map(w => { const s = snap(key, w); return s.phase + ':' + (s.result && s.result.outcome); });
        await sleepP(1500);
        const fin2 = ['D', 'R', 'S', 'X'].map(w => { const s = snap(key, w); return s.phase + ':' + (s.result && s.result.outcome); });
        return { off, ack, fin, stable: JSON.stringify(fin) === JSON.stringify(fin2), bad: leakR(key) };
      }, [`e${i}`, off]);
    }));
    for (const o of outs) {
      const uniq = [...new Set(o.fin)];
      ok(`13 A3 son saniyede (ofset ${o.off}ms) 3. GO: ack=${o.ack}, 4 oyuncu ayni sonuc, kararli`, uniq.length === 1 && uniq[0].startsWith('result:') && o.stable, JSON.stringify(o));
    }
    ok('11 A3 sizinti yok', outs.every(o => o.bad.length === 0), JSON.stringify(outs.map(o => o.bad)));
  });

  // ---- B: telemetri gecikmesi (UI)
  await scenario('B', { PP_TELEMETRY_DELAY_MS: '2000', PP_EVENTS: 'none', PP_WINDOW_SEC: '300' }, async (S) => {
    const room = await setupRoom(S, 'B');
    ok('4 gecikme notu #telemetry-delay-note gorunur', await vis(room.D, '#telemetry-delay-note'), await room.D.page.locator('#telemetry-delay-note').innerText());
    console.log('  not:', await room.D.page.locator('#telemetry-delay-note').innerText());
    ok('6 olay yokken 6. gosterge (computer) YOK', (await room.D.page.locator('[data-check="computer"]').count()) === 0);
    await room.D.page.evaluate(() => {
      window.__tl = [];
      let last = {};
      setInterval(() => {
        const cur = { build: document.getElementById('build-box').textContent, log: document.getElementById('log-box').textContent, gauges: document.getElementById('gauges').textContent, tele: document.getElementById('telemetry-box').textContent, ready: document.getElementById('ready-line').textContent };
        for (const k of Object.keys(cur)) if (cur[k] !== last[k]) window.__tl.push({ k, t: Date.now() });
        last = cur;
      }, 25);
    });
    await sleep(500);
    async function measure(p, id, label) {
      const t0 = Date.now(); await room.D.page.evaluate(() => { window.__tl.length = 0; });
      await p.page.click(`[data-add="${id}"]`);
      await sleep(4200);
      const tl = await room.D.page.evaluate(() => window.__tl);
      const first = (k) => { const e = tl.find(x => x.k === k); return e ? e.t - t0 : null; };
      const r = { build: first('build'), log: first('log'), gauges: first('gauges'), ready: first('ready'), tele: first('tele') };
      console.log(`  ${label}:`, JSON.stringify(r));
      ok(`4 ${label}: #build-box ve #log-box HEMEN guncellendi (<800ms)`, r.build !== null && r.build < 800 && r.log !== null && r.log < 800, JSON.stringify(r));
      const g = r.gauges, te = r.tele;
      ok(`4 ${label}: #gauges ~2 sn SONRA guncellendi (1500-3000)`, g !== null && g >= 1500 && g <= 3000, 'gauges=' + g + ' tele=' + te);
      if (te !== null) ok(`4 ${label}: #telemetry-box da ~2 sn sonra (1500-3000)`, te >= 1500 && te <= 3000, 'tele=' + te);
      return r;
    }
    await measure(room.R, 'engine-kestrel', 'olcum1 motor');
    await measure(room.R, 'tank-large', 'olcum2 tank');
    // Çözümün geri kalanı; sonra HEMEN fırlat (gösterge henüz güncellenmeden)
    const sol = mkSol(room.mission);
    const rest = { rocket: sol.rocket.filter(x => x !== 'engine-kestrel' && x !== 'tank-large'), spacecraft: sol.spacecraft, payload: sol.payload };
    if (!sol.rocket.includes('engine-kestrel')) { // mars/asteroid: motor/tank farklı; kestrel+tank-large zaten takıldı, çözüm yerine yeniden değerlendir
      console.log('  not: gorev', room.mission.id, '- cozum kestrel+tank-large ile uyumsuz olabilir; yine de rest ekleniyor');
    }
    await buildUI(room, rest);
    const gBefore = await gauges(room.D); const rl = await room.D.page.locator('#ready-line').innerText();
    await startPollUI(room);
    const gAtPoll = await gauges(room.D); const rlPoll = await room.D.page.locator('#ready-line').innerText();
    console.log('  firlatma ani ready-line (gosterilen):', rlPoll, '| gosterge:', JSON.stringify(gAtPoll.map(g => g.c + '=' + g.ok)));
    await allGo(room);
    for (const p of four(room)) await p.page.waitForSelector('#screen-result:not([hidden])', { timeout: 5000 });
    const outs = await Promise.all(four(room).map(p => p.page.locator('#screen-result').getAttribute('data-outcome')));
    console.log('  sonuc:', outs.join(','), '| gorev', room.mission.id);
    // sonucun GERÇEK telemetriyle çözüldüğünü doğrula: gerçek telemetri result.telemetry
    const dsr = await st(room.D);
    const trueReady = dsr.result.telemetry && dsr.result.telemetry.ready;
    ok('4 firlatma GERCEK degerle cozuldu (sonuc = gercek telemetri ile uyumlu; gosterge bayat olsa da)', (trueReady === true && outs[0] === 'success') || (trueReady === false && outs[0] !== 'success'), `trueReady=${trueReady} outcome=${outs[0]} readyLine(poll ani)=${rlPoll}`);
    if (room.mission.id === 'lunar-relay') ok('4 lunar-relay cozumuyle success', outs.every(o => o === 'success'), outs.join(','));
    leakWorkersFrames('11 B', room);
  });
  // B2: gecikmeyi gösterge bayatken fırlatma — lunar-relay garantili çözümle (görev rastgele olduğundan çoklu oda dene)
  await scenario('B2', { PP_TELEMETRY_DELAY_MS: '2000', PP_EVENTS: 'none', PP_WINDOW_SEC: '300' }, async (S) => {
    const room = await setupRoom(S, 'B2');
    const sol = mkSol(room.mission);
    await buildUI(room, { rocket: sol.rocket, spacecraft: sol.spacecraft, payload: sol.payload.slice(0, -1) });
    await sleep(2600); // gösterge oturdu
    const gOld = await gauges(room.D);
    const lastInst = sol.payload[sol.payload.length - 1];
    await addPart(room.X, lastInst); // son parça: gerçek durum hazır, gösterge ~2 sn bayat
    await startPollUI(room);
    const rlStale = await room.D.page.locator('#ready-line').innerText();
    const warnStale = await vis(room.D, '#poll-warning');
    await allGo(room);
    for (const p of four(room)) await p.page.waitForSelector('#screen-result:not([hidden])', { timeout: 5000 });
    const o = await room.D.page.locator('#screen-result').getAttribute('data-outcome');
    console.log('  eski gosterge:', JSON.stringify(gOld.map(g => g.c + '=' + g.ok)), '| bayat ready-line:', rlStale, '| uyari:', warnStale, '| sonuc:', o, room.mission.id);
    ok('4 B2 son parca sonrasi hemen anket+3 GO -> success (gosterge bayat olsa da)', o === 'success', o);
    ok('16 B2 (gozlem) bayat gosterge yoneticiyi yaniltti mi: uyari/ready-line', true, `ready-line="${rlStale.replace(/\n/g, ' ')}" poll-warning=${warnStale}`);
  });

  // ---- C: weather
  await scenario('C', { PP_EVENTS: 'weather@3', PP_HOLD_SEC: '10', PP_TELEMETRY_DELAY_MS: '0', PP_WINDOW_SEC: '300' }, async (S) => {
    const raw = await installRaw(S);
    await rev(raw, () => mkRoom('w'));
    const room = await setupRoom(S, 'C');
    for (const p of four(room)) await p.page.waitForSelector('#events-box [data-event-type="weather"]', { timeout: 8000 });
    ok('5 4 sayfada #events-box weather olayi', true);
    const evt = await room.R.page.locator('#events-box [data-event-type="weather"]').first().innerText();
    console.log('  olay metni:', evt.replace(/\n/g, ' | '));
    const b1 = await Promise.all(four(room).map(p => p.page.evaluate(() => ({ v: !document.getElementById('hold-banner').hidden && !!document.getElementById('hold-banner').offsetParent, t: document.getElementById('hold-banner').textContent }))));
    ok('5 #hold-banner 4 sayfada gorunur', b1.every(b => b.v), JSON.stringify(b1.map(b => b.t)));
    await sleep(1500);
    const b2 = await Promise.all(four(room).map(p => p.page.locator('#hold-banner').textContent()));
    const n = (s) => +(/(\d+)\s*sn/.exec(s) || [])[1];
    ok('5 banner geri sayiyor', b1.every((b, i) => n(b.t) > n(b2[i])), JSON.stringify([b1.map(b => b.t), b2]));
    ok('5 yoneticide #poll-start-btn disabled', await room.D.page.locator('#poll-start-btn').isDisabled());
    // socket: raw odada HOLD
    await sleep(500);
    const rawHold = await rev(raw, () => E('w', 'D', 'poll:start', {}));
    ok('5 socket poll:start bekleme sirasinda -> HOLD', rawHold === 'HOLD', rawHold);
    const rs = await rev(raw, () => { const s = snap('w', 'D'); return { phase: s.phase, hold: s.holdUntil, ev: s.events.map(e => e.type) }; });
    ok('5 raw oda: phase building + holdUntil dolu', rs.phase === 'building' && rs.hold > 0, JSON.stringify(rs));
    leakWorkersFrames('11 C (bekleme)', room);
    // banner kalkar
    await room.D.page.waitForFunction(() => document.getElementById('hold-banner').hidden || !document.getElementById('hold-banner').offsetParent, null, { timeout: 14000 });
    await sleep(600);
    const bh = await Promise.all(four(room).map(p => p.page.evaluate(() => !document.getElementById('hold-banner').offsetParent)));
    ok('5 bekleme bitince banner 4 sayfada kalkti', bh.every(Boolean));
    ok('5 poll-start-btn bekleme sonrasi acildi', !(await room.D.page.locator('#poll-start-btn').isDisabled()));
    const dlog = await room.D.page.locator('#log-box').innerText();
    ok('5 log: "Hava acti: firlatma beklemesi kalkti"', dlog.includes('Hava açtı'), dlog.slice(-200));
    await startPollUI(room);
    ok('5 bekleme sonrasi anket baslatilabildi', (await st(room.D)).phase === 'poll');
    // raw oda: bekleme bitti -> poll:start ok
    const rawOk = await rev(raw, () => E('w', 'D', 'poll:start', {}));
    ok('5 raw: bekleme bitince poll:start ok', rawOk === 'ok', rawOk);
    // poll sırasında timer işliyor
    const tp = await parseTimer(room.R); const tp2 = (await sleep(1500), await parseTimer(room.R));
    ok('3 ankette sayac isliyor', tp.sec - tp2.sec >= 1, tp.txt + '->' + tp2.txt);
    leakWorkersFrames('11 C (anket)', room);
    const bad = await rev(raw, () => leakR('w')); ok('11 C raw sizinti yok', bad.length === 0, bad.join(','));
  });
  // C2: anket açıkken weather -> anket iptal
  await scenario('C2', { PP_EVENTS: 'weather@6', PP_HOLD_SEC: '5', PP_TELEMETRY_DELAY_MS: '0', PP_WINDOW_SEC: '300' }, async (S) => {
    const raw = await installRaw(S);
    await rev(raw, () => mkRoom('w'));
    await sleep(500);
    const s = await rev(raw, () => E('w', 'D', 'poll:start', {}));
    await rev(raw, () => E('w', 'R', 'poll:vote', { vote: 'go' }));
    const mid = await rev(raw, () => snap('w', 'S').phase);
    ok('5 C2 anket weather oncesi acik', s === 'ok' && mid === 'poll', s + '/' + mid);
    await sleep(6500);
    const after = await rev(raw, () => ['D', 'R', 'S', 'X'].map(w => { const x = snap('w', w); return { phase: x.phase, poll: x.poll, hold: x.holdUntil, ev: x.events.map(e => e.type), myVote: x.poll && x.poll.myVote }; }));
    ok('5 C2 anket iptal: herkes building, poll yok', after.every(a => a.phase === 'building' && !a.poll), JSON.stringify(after));
    const dlog = await rev(raw, () => JSON.stringify(snap('w', 'D').log.map(l => l.text || l.message || l)));
    ok('5 C2 log: "Hava nedeniyle anket iptal edildi"', dlog.includes('Hava nedeniyle anket iptal edildi'), dlog.slice(-300));
    const feed = await rev(raw, () => JSON.stringify(snap('w', 'R').feed));
    ok('5 C2 calisan feed anket iptalini gosteriyor', feed.includes('Hava nedeniyle'), feed.slice(-300));
    const again = await rev(raw, () => E('w', 'D', 'poll:start', {}));
    ok('5 C2 bekleme sirasinda poll:start -> HOLD', again === 'HOLD', again);
    await sleep(5200);
    const again2 = await rev(raw, () => E('w', 'D', 'poll:start', {}));
    ok('5 C2 bekleme bitince anket yeniden baslar', again2 === 'ok', again2);
    const bad = await rev(raw, () => leakR('w')); ok('11 C2 raw sizinti yok', bad.length === 0, bad.join(','));
  });

  // ---- D: computer-fault
  await scenario('D', { PP_EVENTS: 'computer-fault@3', PP_TELEMETRY_DELAY_MS: '0', PP_WINDOW_SEC: '300' }, async (S) => {
    let room;
    for (let i = 0; i < 10; i++) { room = await setupRoom(S, 'D1' + i); if (room.mission.id !== 'mars-rover') break; for (const p of four(room)) await p.ctx.close().catch(() => {}); }
    ok('6 D1 mars-rover disinda gorev (yedek bilgisayar kutlesi/gucu mars icin marjinal; test kurgusu)', room.mission.id !== 'mars-rover', room.mission.id);
    const sol = mkSol(room.mission);
    if (room.mission.id === 'lunar-relay') sol.rocket = ['engine-kestrel', 'tank-large', 'fuel-methalox'];
    if (room.mission.id === 'asteroid-sample') sol.spacecraft = [...sol.spacecraft, 'solar-small'];
    await buildUI(room, sol);
    await sleep(500);
    for (const p of four(room)) await p.page.waitForSelector('#events-box [data-event-type="computer-fault"]', { timeout: 5000 });
    const evt = await room.S.page.locator('#events-box [data-event-type="computer-fault"]').first().innerText();
    console.log('  olay:', evt.replace(/\n/g, ' | '));
    ok('6 4 sayfada computer-fault olayi gorunur', true);
    let g = await gauges(room.D);
    const comp = g.find(x => x.c === 'computer');
    console.log('  gostergeler:', JSON.stringify(g.map(x => x.c + '=' + x.ok)));
    ok('6 6. gosterge [data-check=computer] var ve ok=false', comp && comp.ok === 'false', JSON.stringify(comp));
    ok('6 diger tum gostergeler yesil iken', g.filter(x => x.c !== 'computer').every(x => x.ok === 'true'), JSON.stringify(g.map(x => x.c + '=' + x.ok)));
    ok('6 #ready-line hazir degil', (await room.D.page.locator('#ready-line').getAttribute('data-ready')) === 'false', await room.D.page.locator('#ready-line').innerText());
    ok('6 (olay) yoneticide #poll-warning gorunur', await vis(room.D, '#poll-warning'));
    leakWorkersFrames('11 D', room);
    // yedek bilgisayar
    ok('6 S yedek bilgisayari takti', await addPart(room.S, 'computer-backup'));
    await sleep(400);
    g = await gauges(room.D);
    ok('6 yedek bilgisayar sonrasi computer gostergesi ok=true', g.find(x => x.c === 'computer').ok === 'true', JSON.stringify(g.find(x => x.c === 'computer')));
    ok('6 #ready-line hazir', (await room.D.page.locator('#ready-line').getAttribute('data-ready')) === 'true', await room.D.page.locator('#ready-line').innerText());
    await launchUI(room);
    const o = await room.D.page.locator('#screen-result').getAttribute('data-outcome');
    ok('6 yedek bilgisayarla firlatma success', o === 'success', o);
    // oda 2: bilgisayarsız
    const r2 = await setupRoom(S, 'D2');
    await buildUI(r2, mkSol(r2.mission));
    await sleep(3500);
    const g2 = await gauges(r2.D);
    ok('6 oda2: computer ok=false', (g2.find(x => x.c === 'computer') || {}).ok === 'false', JSON.stringify(g2.map(x => x.c + '=' + x.ok)));
    await launchUI(r2);
    const r = await r2.D.page.evaluate(() => ({ o: document.getElementById('screen-result').getAttribute('data-outcome'), s: document.getElementById('screen-result').getAttribute('data-success'), title: document.getElementById('result-title').innerText, reason: document.getElementById('result-reason').innerText, score: document.getElementById('result-score').innerText }));
    const dsr = await st(r2.D);
    ok('6 bilgisayarsiz firlatma -> data-outcome=computer-failure, puan 0', r.o === 'computer-failure' && r.s === 'false' && dsr.result.score.total === 0, JSON.stringify(r));
    console.log('  computer-failure:', r.title, '|', r.reason);
    ok('6 computer-failure basligi/metni anlasilir', /bilgisayar/i.test(r.title) && /bilgisayar/i.test(r.reason), r.title + ' | ' + r.reason);
    const ev = await r2.D.page.locator('#result-events').innerText();
    ok('10 #result-events olaylari listeliyor', /bilgisayar/i.test(ev), ev);
    if (SHOT) await r2.R.page.screenshot({ path: path.join(SHOT, 'stage4-computer-failure.png'), fullPage: true });
  });

  // ---- E: supplier-delay
  await scenario('E', { PP_EVENTS: 'supplier-delay@3', PP_LOCK_SEC: '8', PP_TELEMETRY_DELAY_MS: '0', PP_WINDOW_SEC: '300' }, async (S) => {
    const raw = await installRaw(S);
    await rev(raw, () => mkRoom('l'));
    await sleep(3600);
    const info = await rev(raw, () => { const s = snap('l', 'D'); return { locks: s.locks, ev: s.events.map(e => ({ type: e.type, text: e.text, until: e.until, t: e.t })), wLocks: ['R', 'S', 'X'].map(w => snap('l', w).catalog.filter(c => c.locked).map(c => c.id)) }; });
    const lockedId = Object.keys(info.locks || {})[0];
    console.log('  kilit:', JSON.stringify(info));
    ok('7 raw: yoneticide locks[partId], olay supplier-delay', !!lockedId && info.ev[0] && info.ev[0].type === 'supplier-delay', JSON.stringify(info));
    const role = P(lockedId).role; const who = ROLE_OF[role];
    const e1 = await rev(raw, ([w, id]) => E('l', w, 'part:add', { partId: id }), [who, lockedId]);
    ok('7 raw: part:add kilitli parca -> PART_LOCKED', e1 === 'PART_LOCKED', e1);
    ok('7 raw: yalniz ilgili calisan katalogunda locked', info.wLocks.map((l, i) => ['R', 'S', 'X'][i] === who ? l.includes(lockedId) : l.length === 0).every(Boolean), JSON.stringify(info.wLocks));
    ok('7 olay metni parca adini iceriyor, sayi/gorev bilgisi yok', info.ev[0].text.includes(P(lockedId).name) && !/\d/.test(info.ev[0].text.replace(P(lockedId).name, '')), info.ev[0].text);
    await sleep(8500);
    const e2 = await rev(raw, ([w, id]) => E('l', w, 'part:add', { partId: id }), [who, lockedId]);
    ok('7 raw: kilit suresi dolunca eklenebilir', e2 === 'ok', e2);
    const bad = await rev(raw, () => leakR('l')); ok('11 E raw sizinti yok (locks calisana gitmiyor)', bad.length === 0, bad.join(','));
    // UI
    const room = await setupRoom(S, 'E');
    for (const p of four(room)) await p.page.waitForSelector('#events-box [data-event-type="supplier-delay"]', { timeout: 8000 });
    const ds = await st(room.D);
    const lid = Object.keys(ds.locks)[0]; const lw = ROLE_OF[P(lid).role]; const lp = room[lw];
    const li = lp.page.locator(`#catalog li:has([data-add="${lid}"])`);
    const bt = lp.page.locator(`[data-add="${lid}"]`);
    ok('7 UI: ilgili calisanda katalog ogesi data-locked=true', (await li.getAttribute('data-locked')) === 'true');
    ok('7 UI: buton disabled ve "KILITLI" yazili', (await bt.isDisabled()) && /KİLİTLİ/.test(await bt.innerText()), await bt.innerText());
    const lockedCount = await lp.page.locator('#catalog [data-locked="true"]').count();
    ok('7 UI: yalniz 1 oge kilitli', lockedCount === 1, lockedCount);
    const dRows = await room.D.page.locator('#director-catalog tr[data-locked="true"]').count();
    ok('7 UI: yonetici katalogunda tek satir data-locked=true', dRows === 1, dRows);
    const dEv = await room.D.page.locator('#events-box [data-event-type="supplier-delay"]').first().innerText();
    console.log('  UI olay:', dEv.replace(/\n/g, ' | '), '| yonetici satir:', await room.D.page.locator('#director-catalog tr[data-locked="true"]').first().innerText());
    ok('7 UI: olay metninde parca adi', dEv.includes(P(lid).name), dEv);
    // süre dolunca açılır
    await lp.page.waitForFunction((id) => !document.querySelector(`[data-add="${id}"]`).disabled, lid, { timeout: 12000 });
    ok('7 UI: kilit acilinca buton aktif', (await li.getAttribute('data-locked')) === 'false');
    ok('7 UI: kilit acilinca eklenebilir', await addPart(lp, lid));
    const dlog = await room.D.page.locator('#log-box').innerText();
    ok('7 log: "<parca> yeniden kullanilabilir"', dlog.includes('yeniden kullanılabilir'), dlog.slice(-200));
    leakWorkersFrames('11 E UI', room);
    await leakDom('11 E', room);
  });

  // ---- F: rastgele olaylar
  await scenario('F', { PP_WINDOW_SEC: '40', PP_SECOND_WINDOW_SEC: '8', PP_HOLD_SEC: '5', PP_LOCK_SEC: '5', PP_TELEMETRY_DELAY_MS: '0' }, async (S) => {
    const raw = await installRaw(S);
    const NR = 6;
    const res = await raw.page.evaluate(async (NR) => {
      for (let i = 0; i < NR; i++) await mkRoom('f' + i);
      const seen = Array.from({ length: NR }, () => ({}));
      const t0 = Date.now();
      while (Date.now() - t0 < 41000) {
        for (let i = 0; i < NR; i++) { const s = RM['f' + i].D.state; if (s.events) for (const e of s.events) if (!seen[i][e.id]) seen[i][e.id] = { type: e.type, at: Math.round((e.t - (s.timer.endsAt - 40000)) / 100) / 10 }; }
        await sleepP(200);
      }
      return { seen, leak: Array.from({ length: NR }, (_, i) => leakR('f' + i)), phases: Array.from({ length: NR }, (_, i) => RM['f' + i].D.state.phase + ':' + (RM['f' + i].D.state.timer && RM['f' + i].D.state.timer.window)) };
    }, NR);
    console.log('  olaylar:', JSON.stringify(res.seen), res.phases.join(' '));
    const cnts = res.seen.map(s => Object.keys(s).length);
    ok('8 her turda 1-2 olay geldi', cnts.every(c => c >= 1 && c <= 2), cnts.join(','));
    ok('8 tur icinde turler farkli', res.seen.every(s => { const t = Object.values(s).map(x => x.type); return new Set(t).size === t.length; }), JSON.stringify(res.seen));
    const alltypes = new Set(res.seen.flatMap(s => Object.values(s).map(x => x.type)));
    ok('8 turler arasi cesitlilik (>=2 farkli tur)', alltypes.size >= 2, [...alltypes].join(','));
    const times = res.seen.flatMap(s => Object.values(s).map(x => x.at));
    ok('8 olay zamanlari pencere 1 icinde (>=5 ve <=33 sn)', times.every(t => t >= 4 && t <= 34), times.join(','));
    const gaps = res.seen.map(s => { const a = Object.values(s).map(x => x.at).sort((x, y) => x - y); return a.length > 1 ? a[1] - a[0] : null; }).filter(x => x !== null);
    ok('8 iki olay arasi >= ~6 sn (45*40/300)', gaps.every(g => g >= 5.5), gaps.join(','));
    ok('11 F raw sizinti/pendingEvents yok', res.leak.every(l => l.length === 0), JSON.stringify(res.leak));
    ok('8 odalar window 1/2 beklenen durumda, cokme yok', res.phases.every(p => p.startsWith('building') || p.startsWith('result') || p.startsWith('poll')), res.phases.join(' '));
  });

  // ---- G: geri alma (UI + raw)
  await scenario('G', { PP_EVENTS: 'none', PP_TELEMETRY_DELAY_MS: '0', PP_WINDOW_SEC: '300' }, async (S) => {
    const raw = await installRaw(S);
    const room = await setupRoom(S, 'G');
    const D = room.D, R = room.R;
    ok('9 yoneticide #undo-box gorunur, 3/3', (await vis(D, '#undo-box')) && /3\s*\/\s*3/.test(await D.page.locator('#undo-left').innerText()), await D.page.locator('#undo-left').innerText());
    const dis = async () => D.page.evaluate(() => [...document.querySelectorAll('button[data-undo]')].map(b => b.getAttribute('data-undo') + ':' + b.disabled));
    ok('9 baslangicta 3 geri alma butonu disabled', (await dis()).every(x => x.endsWith('true')), (await dis()).join(','));
    ok('9 yoneticide #screen-game icinde buton sayisi 0', (await D.page.locator('#screen-game button').count()) === 0);
    ok('9 calisanda #undo-box gorunmez', !(await vis(R, '#undo-box')));
    await R.page.click('[data-add="engine-kestrel"]'); await sleep(400);
    let d = await dis();
    ok('9 roketci parca takinca rocket butonu acildi, digerleri kapali', d.join(',') === 'rocket:false,spacecraft:true,payload:true', d.join(','));
    await D.page.click('button[data-undo="rocket"]'); await sleep(400);
    ok('9 undo: parca roketci #my-parts\'tan kalkti', (await cnt(R)) === 0);
    ok('9 sayac 2/3', /2\s*\/\s*3/.test(await D.page.locator('#undo-left').innerText()), await D.page.locator('#undo-left').innerText());
    const lg = await D.page.locator('#log-box').innerText();
    ok('9 yonetici log: "Yonetici, Roket & Yakit son hamlesini geri aldi: ... cikarildi"', /Yönetici, Roket & Yakıt son hamlesini geri aldı: .*çıkarıldı/.test(lg), lg.slice(-200));
    const fd = await R.page.locator('#feed').innerText();
    ok('9 calisan feed: geri alma satiri', /geri aldı/.test(fd), fd.slice(-200));
    ok('9 ayni rolde ikinci undo kapali (NOTHING_TO_UNDO)', (await dis()).includes('rocket:true'), (await dis()).join(','));
    // remove undo
    await addPart(R, 'engine-kestrel');
    await R.page.locator('#my-parts li', { hasText: 'Kerkenez' }).first().locator('[data-remove]').click(); await sleep(400);
    ok('9 parca cikarildi', (await cnt(R)) === 0);
    d = await dis(); ok('9 remove sonrasi rocket butonu acik', d[0] === 'rocket:false', d.join(','));
    await D.page.click('button[data-undo="rocket"]'); await sleep(400);
    ok('9 cikarma geri alinca parca geri geldi', (await cnt(R)) === 1);
    const lg2 = await D.page.locator('#log-box').innerText();
    ok('9 log: "geri takildi"', /geri takıldı/.test(lg2), lg2.slice(-200));
    ok('9 sayac 1/3', /1\s*\/\s*3/.test(await D.page.locator('#undo-left').innerText()), await D.page.locator('#undo-left').innerText());
    ok('9 ayni rolde art arda 2. undo kapali', (await dis())[0] === 'rocket:true');
    await addPart(room.S, 'structure-frame'); await sleep(300);
    await D.page.click('button[data-undo="spacecraft"]'); await sleep(400);
    ok('9 3. geri alma kullanildi: sayac 0/3', /0\s*\/\s*3/.test(await D.page.locator('#undo-left').innerText()), await D.page.locator('#undo-left').innerText());
    await addPart(R, 'tank-large'); await addPart(room.X, P('relay-antenna') ? 'relay-antenna' : 'camera'); await sleep(300);
    d = await dis(); ok('9 hak bitince TUM butonlar disabled (hamle olsa bile)', d.every(x => x.endsWith('true')), d.join(','));
    ok('9 yoneticide #screen-game button 0 (geri alma sonrasi da)', (await D.page.locator('#screen-game button').count()) === 0);
    leakWorkersFrames('11 G UI', room);
    // anket fazı: butonlar disabled
    await startPollUI(room);
    ok('9 poll fazinda undo butonlari disabled', (await dis()).every(x => x.endsWith('true')));
    // --- raw socket
    await rev(raw, () => mkRoom('u'));
    const o = await raw.page.evaluate(async () => {
      const O = {};
      O.lobbyless = await E('u', 'D', 'undo:use', { role: 'rocket' });          // hamle yok
      O.badRole = [await E('u', 'D', 'undo:use', { role: 'director' }), await E('u', 'D', 'undo:use', { role: 'xyz' }), await E('u', 'D', 'undo:use', {}), await E('u', 'D', 'undo:use', { role: 5 })];
      O.workerUndo = [await E('u', 'R', 'undo:use', { role: 'rocket' }), await E('u', 'S', 'undo:use', { role: 'spacecraft' })];
      await E('u', 'R', 'part:add', { partId: 'tank-small' });
      O.workerUndoWithMove = await E('u', 'R', 'undo:use', { role: 'rocket' });
      O.ok1 = await E('u', 'D', 'undo:use', { role: 'rocket' });
      O.again = await E('u', 'D', 'undo:use', { role: 'rocket' });
      await E('u', 'S', 'part:add', { partId: 'structure-frame' }); O.ok2 = await E('u', 'D', 'undo:use', { role: 'spacecraft' });
      await E('u', 'X', 'part:add', { partId: 'camera' }); O.ok3 = await E('u', 'D', 'undo:use', { role: 'payload' });
      await E('u', 'R', 'part:add', { partId: 'tank-small' });
      O.noLeft = await E('u', 'D', 'undo:use', { role: 'rocket' });
      O.noLeftNothing = await E('u', 'D', 'undo:use', { role: 'payload' });
      O.left = snap('u', 'D').undo; O.undoLeft = snap('u', 'D').undoLeft;
      // WRONG_PHASE: poll
      await E('u', 'D', 'poll:start', {});
      O.poll = await E('u', 'D', 'undo:use', { role: 'rocket' });
      // rol tipi: null payload
      O.nullPayload = err(await new Promise(r => RM.u.D.s.emit('undo:use', null, r)));
      O.noAck = 'ok'; RM.u.D.s.emit('undo:use');
      await sleepP(200);
      O.bad = leakR('u');
      return O;
    });
    console.log('  raw undo:', JSON.stringify(o));
    ok('9 raw: hamle yokken -> NOTHING_TO_UNDO', o.lobbyless === 'NOTHING_TO_UNDO', o.lobbyless);
    ok('9 raw: gecersiz rol -> BAD_REQUEST (director/xyz/yok/sayi)', o.badRole.every(x => x === 'BAD_REQUEST'), JSON.stringify(o.badRole));
    ok('9 raw: calisandan undo:use -> NOT_ALLOWED', o.workerUndo.every(x => x === 'NOT_ALLOWED') && o.workerUndoWithMove === 'NOT_ALLOWED', JSON.stringify([o.workerUndo, o.workerUndoWithMove]));
    ok('9 raw: undo ok, ayni rolde 2. -> NOTHING_TO_UNDO', o.ok1 === 'ok' && o.again === 'NOTHING_TO_UNDO', o.ok1 + '/' + o.again);
    ok('9 raw: 3 undo sonrasi -> NO_UNDO_LEFT (hamle olsa da; hamlesiz da)', o.ok2 === 'ok' && o.ok3 === 'ok' && o.noLeft === 'NO_UNDO_LEFT', JSON.stringify(o));
    console.log('  hamlesiz+hak0:', o.noLeftNothing);
    ok('9 raw: undo.left=0, undoLeft=0', o.left && o.left.left === 0 && o.undoLeft === 0, JSON.stringify([o.left, o.undoLeft]));
    ok('9 raw: poll fazinda undo -> WRONG_PHASE (ya da NO_UNDO_LEFT ancak hak 0: oncelik gozlemi)', o.poll === 'WRONG_PHASE', o.poll);
    ok('11 G raw sizinti yok (undo/undoLeft calisana gitmiyor)', o.bad.length === 0, o.bad.join(','));
    // poll fazı hak varken WRONG_PHASE
    await rev(raw, () => mkRoom('u2'));
    const w2 = await raw.page.evaluate(async () => { await E('u2', 'R', 'part:add', { partId: 'tank-small' }); await E('u2', 'D', 'poll:start', {}); return await E('u2', 'D', 'undo:use', { role: 'rocket' }); });
    ok('9 raw: poll fazinda (hak var) undo -> WRONG_PHASE', w2 === 'WRONG_PHASE', w2);
    // poll iptali sonrası geri alma yine çalışır mı
    const w3 = await raw.page.evaluate(async () => { await E('u2', 'D', 'poll:cancel', {}); return await E('u2', 'D', 'undo:use', { role: 'rocket' }); });
    ok('9 raw: anket iptalinden sonra undo calisir', w3 === 'ok', w3);
  });
  // G2: geri alma cezası + süre puanı (UI)
  await scenario('G2', { PP_EVENTS: 'none', PP_TELEMETRY_DELAY_MS: '0', PP_WINDOW_SEC: '300' }, async (S) => {
    const room = await setupRoom(S, 'G2');
    const sol = mkSol(room.mission);
    // 2 geri alma kullan
    await addPart(room.R, 'tank-small'); await room.D.page.click('button[data-undo="rocket"]'); await sleep(300);
    await addPart(room.S, 'solar-small'); await room.D.page.click('button[data-undo="spacecraft"]'); await sleep(300);
    await buildUI(room, sol); await sleep(300);
    await startPollUI(room);
    const tBefore = await room.D.page.evaluate(() => { const s = JSON.parse(document.getElementById('debug-state').textContent); return { endsAt: s.timer.endsAt, now: s.timer.now, localAt: Date.now() }; });
    await allGo(room);
    const tVote = Date.now();
    for (const p of four(room)) await p.page.waitForSelector('#screen-result:not([hidden])', { timeout: 5000 });
    await skipSeq(room); await waitResultPanel(room);
    const dsr = await st(room.D);
    const r = dsr.result;
    const bd = Object.fromEntries(r.score.breakdown.map(b => [b.key, b.points]));
    console.log('  result:', JSON.stringify({ ok: r.success, outcome: r.outcome, tl: r.timeLeftSec, win: r.window, uu: r.undoUsed, bd, total: r.score.total, stars: r.score.stars }));
    ok('9/10 ' + room.mission.id + ' basarili', r.success === true, r.outcome + ' ' + r.reasonText);
    ok('9 sonuc: undoUsed=2, ceza -200', r.undoUsed === 2 && bd.undo === -200, `${r.undoUsed} ${bd.undo}`);
    const ru = await room.D.page.locator('#result-undo').innerText();
    ok('9 #result-undo kullanilan geri alma sayisini gosteriyor', /2/.test(ru), ru);
    const endsRem = (tBefore.endsAt - tBefore.now) / 1000 - (tVote - tBefore.localAt) / 1000;
    ok('10 timeLeftSec kalan sureyle uyumlu (+/-3 sn)', Math.abs(r.timeLeftSec - endsRem) <= 3 && r.window === 1, `tl=${r.timeLeftSec} beklenen~${endsRem.toFixed(1)}`);
    const dur = r.mission.durationSec;
    ok('10 sure kalemi = round(500*timeLeft/durationSec)', bd.time === Math.round(500 * r.timeLeftSec / dur) && bd.time > 0, `${bd.time} vs ${Math.round(500 * r.timeLeftSec / dur)} (dur=${dur})`);
    const cost = r.telemetry.spent, bud = r.mission.budget;
    ok('10 butce kalemi dogru', bd.budget === Math.round(500 * (bud - cost) / bud), `${bd.budget} vs ${Math.round(500 * (bud - cost) / bud)}`);
    const sum = r.score.breakdown.reduce((a, b) => a + b.points, 0);
    ok('10 toplam = kalemlerin toplami', r.score.total === Math.max(0, sum), `${r.score.total} vs ${sum}`);
    const stars = r.score.total >= 1700 ? 3 : r.score.total >= 1400 ? 2 : 1;
    ok('10 yildiz esikleri', r.score.stars === stars, `${r.score.stars} vs ${stars}`);
    const rt = await room.D.page.locator('#result-time').innerText();
    ok('10 #result-time kalan sure gosteriyor', rt.length > 0 && /\d/.test(rt), rt);
    const bdUI = await room.D.page.locator('#result-breakdown').innerText();
    console.log('  breakdown UI:', bdUI.replace(/\n/g, ' | '), '| result-time:', rt, '| result-undo:', ru);
    ok('10 dokumde sure kalemi artik gercek deger (— degil)', !/Kalan süre[^\n]*—/.test(bdUI), bdUI);
    // restart
    await room.D.page.click('#restart-btn');
    for (const p of four(room)) await p.page.waitForSelector('#screen-game:not([hidden])', { timeout: 4000 });
    await sleep(400);
    const tt = await parseTimer(room.R);
    ok('12 restart: sayac bastan (~5:00 = 300 sn civari)', tt.sec >= 290, tt.txt);
    ok('12 restart: geri alma 3/3', /3\s*\/\s*3/.test(await room.D.page.locator('#undo-left').innerText()), await room.D.page.locator('#undo-left').innerText());
    ok('12 restart: undo butonlari disabled', await room.D.page.evaluate(() => [...document.querySelectorAll('button[data-undo]')].every(b => b.disabled)));
  });

  // ---- W2: pencere 2 puanı + restart sıfırlaması + boş oda
  await scenario('W2', { PP_EVENTS: 'none', PP_TELEMETRY_DELAY_MS: '0', PP_WINDOW_SEC: '8', PP_SECOND_WINDOW_SEC: '60' }, async (S) => {
    const raw = await installRaw(S);
    const m = await rev(raw, () => mkRoom('p'));
    const sol = mkSol(m.mission);
    await rev(raw, (sp) => buildR('p', sp), sol);
    await raw.page.evaluate(async () => { const D = RM.p.D; while (!(D.state.timer && D.state.timer.window === 2)) await sleepP(50); });
    await sleep(7500); // pencere 2'nin ~7.5 sn'si geçti → kalan ~52.5
    const r = await raw.page.evaluate(async () => {
      await E('p', 'D', 'poll:start', {}); await sleepP(200);
      const D = RM.p.D; const tm = D.state.timer; const remAt = (tm.endsAt - tm.now) / 1000 - (Date.now() - RM.p.t0) * 0 ; // sunucu now ile
      const skew = tm.now - Date.now(); const rem = (tm.endsAt - (Date.now() + skew)) / 1000;
      const a = await allGoR('p'); await sleepP(300);
      const s = snap('p', 'D');
      return { rem, a, phase: s.phase, result: s.result };
    });
    console.log('  W2:', JSON.stringify({ rem: r.rem, tl: r.result && r.result.timeLeftSec, win: r.result && r.result.window, sc: r.result && r.result.score, outcome: r.result && r.result.outcome }));
    ok('10 W2 pencere 2 basarili fircatma (outcome success)', r.result && r.result.success === true, r.result && r.result.outcome);
    if (r.result) {
      const exp = Math.floor(r.rem / 2);
      ok('10 W2 window=2 ve timeLeftSec = floor(kalan/2) (+/-1)', r.result.window === 2 && Math.abs(r.result.timeLeftSec - exp) <= 1, `tl=${r.result.timeLeftSec} exp=${exp} (kalan ${r.rem.toFixed(1)})`);
      const bt = r.result.score.breakdown.find(b => b.key === 'time').points;
      ok('10 W2 sure kalemi = round(500*tl/durationSec)', bt === Math.round(500 * r.result.timeLeftSec / r.result.mission.durationSec), `${bt} dur=${r.result.mission.durationSec}`);
    }
    // --- window 1 başarılı mı: yeni oda hızlı
    const m2 = await rev(raw, () => mkRoom('q'));
    await rev(raw, (sp) => buildR('q', sp), mkSol(m2.mission));
    await sleep(0);
    await raw.page.evaluate(async () => { await E('q', 'D', 'poll:start', {}); });
    const snapq = await rev(raw, () => { const s = snap('q', 'D'); return s.phase + ':' + (s.timer && s.timer.window); });
    console.log('  W1 hizli oda:', snapq);
    await rev(raw, () => closeR('p'));
  });

  // ---- RST: restart sıfırlama + boş oda tick
  await scenario('RST', { PP_EVENTS: 'weather@2,supplier-delay@3,computer-fault@4', PP_HOLD_SEC: '60', PP_LOCK_SEC: '60', PP_TELEMETRY_DELAY_MS: '0', PP_WINDOW_SEC: '12', PP_SECOND_WINDOW_SEC: '4' }, async (S) => {
    const raw = await installRaw(S);
    await rev(raw, () => mkRoom('r'));
    await sleep(300);
    await rev(raw, () => E('r', 'R', 'part:add', { partId: 'tank-small' }));
    await rev(raw, () => E('r', 'D', 'undo:use', { role: 'rocket' }));
    await sleep(5000);
    const mid = await rev(raw, () => { const s = snap('r', 'D'); return { ev: s.events.map(e => e.type), hold: s.holdUntil, locks: Object.keys(s.locks), undo: s.undo.left, comp: s.telemetry.checks && 'computer' in s.telemetry.checks }; });
    console.log('  restart oncesi:', JSON.stringify(mid));
    ok('12 RST: 3 olay ateslendi (weather, supplier, computer), hold dolu, kilit, computer kontrolu, undo 2', mid.ev.length === 3 && mid.hold && mid.locks.length === 1 && mid.comp && mid.undo === 2, JSON.stringify(mid));
    await sleep(14000);
    const res = await rev(raw, () => ['D', 'R', 'S', 'X'].map(w => { const s = snap('r', w); return s.phase + ':' + (s.result && s.result.outcome); }));
    ok('12 RST: bekleme+pencereler bitti -> window-missed (hold sirasinda firlatilamaz)', res.every(x => x === 'result:window-missed'), res.join(','));
    const rr = await rev(raw, () => snap('r', 'D').result);
    console.log('  result:', JSON.stringify({ ev: rr.events, uu: rr.undoUsed, tl: rr.timeLeftSec, win: rr.window }));
    ok('10 RST: result.events olaylari listeliyor (type,text), undoUsed=1', rr.events.length === 3 && rr.undoUsed === 1, JSON.stringify(rr.events));
    const rs = await rev(raw, () => E('r', 'D', 'game:restart', {}));
    await sleep(400);
    const after = await rev(raw, () => { const s = snap('r', 'D'); return { phase: s.phase, ev: s.events, hold: s.holdUntil, locks: s.locks, undo: s.undo, timer: s.timer, comp: s.telemetry && s.telemetry.checks && ('computer' in s.telemetry.checks), log: s.log.length, rem: (s.timer.endsAt - s.timer.now) / 1000, w: snap('r', 'R').holdUntil, wev: snap('r', 'R').events, wcat: snap('r', 'R').catalog.filter(c => c.locked).length }; });
    console.log('  restart sonrasi:', JSON.stringify(after));
    ok('12 RST: restart ok; sayac baştan (window 1, ~12 sn); olay/kilit/bekleme temiz; undo 3; computer kontrolu yok', rs === 'ok' && after.phase === 'building' && after.timer.window === 1 && after.rem > 10 && after.ev.length === 0 && after.hold === null && Object.keys(after.locks).length === 0 && after.undo.left === 3 && !after.comp && after.w === null && after.wev.length === 0 && after.wcat === 0, JSON.stringify(after));
    await sleep(6000);
    const again = await rev(raw, () => { const s = snap('r', 'D'); return { ev: s.events.map(e => e.type), hold: !!s.holdUntil }; });
    ok('12 RST: yeni turda olaylar yeniden ateslenir (plan yenilendi)', again.ev.length >= 2, JSON.stringify(again));
    const bad = await rev(raw, () => leakR('r')); ok('11 RST raw sizinti yok (olaylar, kilit, restart sonrasi)', bad.length === 0, bad.join(','));
    // boş oda / oyuncular ayrılınca tick
    await rev(raw, () => mkRoom('z'));
    await rev(raw, () => closeR('z')); // hepsi kopar (disconnect)
    await rev(raw, () => { for (const w of ['R', 'S']) RM.r[w].s.emit('room:leave'); });
    await sleep(4500);
    await rev(raw, () => closeR('r'));
    await sleep(2500);
    ok('13 bos oda / ayrilan oyuncularla tick dongusu calisiyor (stderr senaryo sonunda kontrol edilir)', true);
  });

  // ---- RC: yeniden bağlanma (UI)
  await scenario('RC', { PP_EVENTS: 'weather@2,supplier-delay@3', PP_HOLD_SEC: '60', PP_LOCK_SEC: '60', PP_TELEMETRY_DELAY_MS: '0', PP_WINDOW_SEC: '120' }, async (S) => {
    const room = await setupRoom(S, 'RC');
    for (const p of four(room)) await p.page.waitForSelector('#events-box [data-event-type="supplier-delay"]', { timeout: 7000 });
    await sleep(1500);
    const ds = await st(room.D); const lid = Object.keys(ds.locks)[0]; const lw = ROLE_OF[P(lid).role]; const lp = room[lw];
    const before = await Promise.all(four(room).map(parseTimer));
    console.log('  oncesi:', before.map(b => b.txt).join(' '));
    for (const p of [lp, room.D]) { await p.page.reload(); await p.page.waitForSelector('#screen-game:not([hidden])', { timeout: 6000 }); }
    await sleep(600);
    const after = await Promise.all(four(room).map(parseTimer));
    console.log('  sonrasi:', after.map(b => b.txt).join(' '));
    ok('12 yenilenen sayfalarda sayac dogru degerden devam (digerleriyle fark <=2, ~1:5x)', Math.abs(after[0].sec - after[2].sec) <= 2 && Math.abs(after[1].sec - after[2].sec) <= 2 && after[0].sec < 118, after.map(t => t.txt).join(' '));
    const holdTxt = await Promise.all([room.D, lp].map(p => p.page.evaluate(() => ({ v: !!document.getElementById('hold-banner').offsetParent, t: document.getElementById('hold-banner').textContent }))));
    ok('12 yenilemeden sonra bekleme banner korundu (D ve calisan)', holdTxt.every(h => h.v), JSON.stringify(holdTxt));
    ok('12 yenilemeden sonra #poll-start-btn disabled (D)', await room.D.page.locator('#poll-start-btn').isDisabled());
    const evs = await Promise.all([room.D, lp].map(p => p.page.locator('#events-box [data-event-type]').count()));
    ok('12 yenilemeden sonra olaylar korundu', evs.every(c => c === 2), evs.join(','));
    const lockedAfter = await lp.page.locator(`#catalog li:has([data-add="${lid}"])`).getAttribute('data-locked');
    ok('12 yenilemeden sonra kilit korundu (calisan)', lockedAfter === 'true' && await lp.page.locator(`[data-add="${lid}"]`).isDisabled());
    ok('12 yenilemeden sonra yonetici katalog kilidi korundu', (await room.D.page.locator('#director-catalog tr[data-locked="true"]').count()) === 1);
    ok('12 yenilemeden sonra undo kutusu ok', /3\s*\/\s*3/.test(await room.D.page.locator('#undo-left').innerText()));
    leakWorkersFrames('11 RC (yenileme sonrasi)', room);
  });

  // ---- M: mobil
  await scenario('M', { PP_EVENTS: 'weather@2,supplier-delay@3,computer-fault@4', PP_HOLD_SEC: '8', PP_LOCK_SEC: '60', PP_TELEMETRY_DELAY_MS: '2000', PP_WINDOW_SEC: '300' }, async (S) => {
    const room = await setupRoom(S, 'M', { width: 375, height: 812 });
    for (const p of four(room)) await p.page.waitForSelector('#events-box [data-event-type="computer-fault"]', { timeout: 8000 });
    await sleep(800);
    const m1 = await Promise.all(four(room).map(p => p.page.evaluate(() => ({ sw: document.documentElement.scrollWidth, iw: window.innerWidth, bar: document.getElementById('timer-bar').getBoundingClientRect().height, hold: !document.getElementById('hold-banner').hidden, events: document.getElementById('events-box').getBoundingClientRect().height, undo: document.getElementById('undo-box').hidden ? 0 : document.getElementById('undo-box').getBoundingClientRect().height }))));
    console.log('  mobil building:', JSON.stringify(m1));
    ok('14 mobil building: yatay tasma yok (4 sayfa)', m1.every(m => m.sw <= m.iw), JSON.stringify(m1.map(m => [m.sw, m.iw])));
    if (SHOT) { await room.D.page.screenshot({ path: path.join(SHOT, 'stage4-mobile-D-building.png') }); await room.R.page.screenshot({ path: path.join(SHOT, 'stage4-mobile-R-building.png') }); await room.S.page.screenshot({ path: path.join(SHOT, 'stage4-mobile-S-building.png') }); await room.D.page.screenshot({ path: path.join(SHOT, 'stage4-mobile-D-full.png'), fullPage: true }); }
    // kaydır: sticky sayaç içeriği kapatıyor mu
    await room.D.page.evaluate(() => window.scrollTo(0, 700)); await sleep(200);
    if (SHOT) await room.D.page.screenshot({ path: path.join(SHOT, 'stage4-mobile-D-scrolled.png') });
    // hold bitince anket
    await room.D.page.evaluate(() => window.scrollTo(0, 0));
    await room.D.page.waitForFunction(() => !document.getElementById('poll-start-btn').disabled, null, { timeout: 14000 });
    await sleep(2500);
    await startPollUI(room);
    await sleep(500);
    const m2 = await Promise.all(four(room).map(p => p.page.evaluate(() => { const r = (id) => { const e = document.getElementById(id); return e && !e.hidden ? Math.round(e.getBoundingClientRect().height) : 0; }; return { sw: document.documentElement.scrollWidth, iw: window.innerWidth, ih: window.innerHeight, bar: r('timer-bar'), poll: r('poll-controls'), undo: r('undo-box'), events: r('events-box') }; })));
    console.log('  mobil poll:', JSON.stringify(m2));
    ok('14 mobil poll: yatay tasma yok', m2.every(m => m.sw <= m.iw));
    const sticky = m2.map(m => m.bar + m.poll);
    ok('14 mobil poll: sticky alanlar (sayac+anket) ekranin <=%45i', sticky.every((h, i) => h <= m2[i].ih * 0.45), JSON.stringify(sticky) + ' ih=' + m2[0].ih);
    // kaydırılmış halde oy butonu basılabilir mi
    for (const [nm, p] of workers(room)) {
      await p.page.evaluate(() => window.scrollTo(0, 900)); await sleep(150);
      const cov = await p.page.evaluate(() => { const b = document.getElementById('vote-go-btn'); b.scrollIntoView({ block: 'center' }); const r = b.getBoundingClientRect(); const el = document.elementFromPoint(r.left + r.width / 2, r.top + r.height / 2); return { on: el === b || b.contains(el), h: r.height }; });
      ok(`14 mobil ${nm}: oy butonu kaydirilinca ortulmuyor, yuksekligi >=48`, cov.on && cov.h >= 48, JSON.stringify(cov));
    }
    await room.R.page.evaluate(() => window.scrollTo(0, 0)); await sleep(200);
    if (SHOT) { await room.R.page.screenshot({ path: path.join(SHOT, 'stage4-mobile-R-poll.png') }); await room.D.page.screenshot({ path: path.join(SHOT, 'stage4-mobile-D-poll.png') }); await room.R.page.evaluate(() => window.scrollTo(0, 800)); await sleep(150); await room.R.page.screenshot({ path: path.join(SHOT, 'stage4-mobile-R-poll-scrolled.png') }); }
    // D: undo butonu basılabilirlik (anket dışına dönmek için iptal)
    await room.D.page.click('#poll-cancel-btn'); await sleep(400);
    const ub = await room.D.page.evaluate(() => { const b = document.querySelector('button[data-undo="rocket"]'); b.scrollIntoView({ block: 'center' }); const r = b.getBoundingClientRect(); const el = document.elementFromPoint(r.left + r.width / 2, r.top + r.height / 2); return { on: el === b || b.contains(el), h: r.height, bar: document.getElementById('timer-bar').getBoundingClientRect().height }; });
    ok('14 mobil D: undo butonu ortulmuyor', ub.on && ub.h >= 40, JSON.stringify(ub));
    leakWorkersFrames('11 M', room);
  });

  await browser.close();
  console.log('\nKONSOL/HATA SORUNLARI:', issues.length ? '\n' + [...new Set(issues)].join('\n') : '(yok)');
  console.log('SUNUCU STDERR:', JSON.stringify(serverErr));
  const fails = results.filter(r => !r.pass);
  console.log(`\nTOPLAM ${results.length}, FAIL ${fails.length}`);
  fails.forEach(f => console.log('FAIL: ' + f.name));
  process.exit(0);
})().catch(e => { console.error('FATAL', e); process.exit(1); });
