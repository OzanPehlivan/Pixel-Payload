// Aşama 3 e2e testi. Playwright proje dışında: PW_DIR ortam değişkeni. SHOT_DIR (opsiyonel) ekran görüntüleri.
const path = require('path');
const { spawn } = require('child_process');
const PW = process.env.PW_DIR;
const { chromium } = require(path.join(PW, 'node_modules', 'playwright'));
const catalog = require('../../data/parts.json');
const ROOT = path.join(__dirname, '..', '..');
const PORT = 3101, URL = `http://localhost:${PORT}`;
const SHOT = process.env.SHOT_DIR;
const results = [];
const ok = (name, cond, extra) => { results.push({ name, pass: !!cond }); console.log((cond ? 'PASS ' : 'FAIL ') + name + (extra !== undefined && extra !== '' ? ' :: ' + extra : '')); };
const sleep = (ms) => new Promise(r => setTimeout(r, ms));
const P = (id) => catalog.parts.find(p => p.id === id);

const SOLUTIONS = {
  'lunar-relay': [
    { rocket: ['engine-kestrel', 'tank-large', 'fuel-kerosene'], spacecraft: ['structure-frame', 'solar-small', 'solar-small', 'shield-light'] },
    { rocket: ['engine-heron', 'engine-heron', 'tank-large', 'fuel-kerosene'], spacecraft: ['structure-frame', 'solar-small', 'solar-small', 'shield-light'] },
  ],
  'mars-rover': [
    { rocket: ['engine-titan', 'tank-large', 'tank-large', 'fuel-hydrolox'], spacecraft: ['structure-frame', 'solar-large', 'shield-heavy'] },
    { rocket: ['engine-kestrel', 'engine-heron', 'tank-small', 'tank-small', 'tank-large', 'fuel-methalox'], spacecraft: ['structure-frame', 'solar-large', 'shield-light', 'shield-light'] },
  ],
  'asteroid-sample': [
    { rocket: ['engine-heron', 'engine-heron', 'tank-large', 'fuel-hydrolox'], spacecraft: ['structure-frame', 'solar-small', 'shield-light', 'shield-light'] },
    { rocket: ['engine-titan', 'tank-small', 'tank-small', 'tank-large', 'tank-large', 'fuel-hydrolox'], spacecraft: ['structure-frame', 'solar-small', 'shield-heavy'] },
  ],
};
const isSolar = (id) => P(id).category === 'solar';
const isShield = (id) => P(id).category === 'shield';

(async () => {
  const srv = spawn('node', ['server/index.js'], { cwd: ROOT, env: { ...process.env, PORT: String(PORT) } });
  let stderr = '';
  srv.stderr.on('data', d => stderr += d);
  await sleep(1500);
  const browser = await chromium.launch();
  const issues = [];

  async function mk(name, viewport) {
    const ctx = await browser.newContext(viewport ? { viewport } : {});
    const page = await ctx.newPage();
    const p = { name, ctx, page, raw: [] };
    page.on('console', m => { if (m.type() === 'error') issues.push(`[${name}] console.error: ${m.text()}`); });
    page.on('pageerror', e => issues.push(`[${name}] pageerror: ${e.message}`));
    page.on('requestfailed', r => issues.push(`[${name}] requestfailed: ${r.url()}`));
    page.on('websocket', ws => { ws.on('framereceived', f => p.raw.push(String(f.payload))); ws.on('framesent', f => p.raw.push('SENT ' + String(f.payload))); });
    page.on('response', async r => {
      if (r.url().includes('/socket.io/')) { try { p.raw.push(await r.text()); } catch (e) {} }
      if (r.status() >= 400 && !r.url().includes('/socket.io/')) issues.push(`[${name}] HTTP ${r.status()} ${r.url()}`);
    });
    await page.goto(URL);
    await page.waitForSelector('#screen-entry:not([hidden])');
    return p;
  }
  const st = async (p) => JSON.parse(await p.page.locator('#debug-state').textContent());
  const txt = (p, sel) => p.page.locator(sel).innerText();
  const vis = (p, sel) => p.page.locator(sel).isVisible();

  async function setupRoom(tag, viewport) {
    const D = await mk(tag + 'D', viewport), R = await mk(tag + 'R', viewport), S = await mk(tag + 'S', viewport), X = await mk(tag + 'X', viewport);
    await D.page.fill('#name-input', 'Yon'); await D.page.click('#create-btn');
    await D.page.waitForSelector('#screen-lobby:not([hidden])');
    const code = (await D.page.locator('#room-code').innerText()).trim();
    for (const [p, n] of [[R, 'Rok'], [S, 'Uza'], [X, 'Yuk']]) {
      await p.page.fill('#name-input', n); await p.page.fill('#code-input', code); await p.page.click('#join-btn');
      await p.page.waitForSelector('#screen-lobby:not([hidden])');
    }
    await D.page.click('[data-role="director"]'); await sleep(100);
    await R.page.click('[data-role="rocket"]'); await sleep(100);
    await S.page.click('[data-role="spacecraft"]'); await sleep(100);
    await X.page.click('[data-role="payload"]');
    for (const p of [D, R, S, X]) await p.page.waitForSelector('#screen-game:not([hidden])', { timeout: 4000 });
    await sleep(250);
    const room = { D, R, S, X, code, mission: (await st(D)).mission };
    room.ids = {};
    for (const [k, p] of Object.entries({ D, R, S, X })) room.ids[k] = (await p.page.evaluate(() => JSON.parse(sessionStorage.getItem('pixelPayloadSession')))).playerId;
    return room;
  }
  async function closeRoom(room) { for (const p of [room.D, room.R, room.S, room.X]) await p.ctx.close().catch(() => {}); }
  const cnt = (p) => p.page.locator('#my-parts [data-remove]').count();
  async function addPart(p, id) {
    const before = await cnt(p);
    await p.page.click(`[data-add="${id}"]`);
    try { await p.page.waitForFunction((b) => document.querySelectorAll('#my-parts [data-remove]').length > b, before, { timeout: 1500 }); return true; }
    catch (e) { return false; }
  }
  async function removeByName(p, name) {
    const before = await cnt(p);
    await p.page.locator('#my-parts li', { hasText: name }).first().locator('[data-remove]').click();
    try { await p.page.waitForFunction((b) => document.querySelectorAll('#my-parts [data-remove]').length < b, before, { timeout: 1500 }); return true; }
    catch (e) { return false; }
  }
  async function build(room, spec) {
    for (const id of spec.rocket || []) await addPart(room.R, id);
    for (const id of spec.spacecraft || []) await addPart(room.S, id);
    for (const id of spec.payload || []) await addPart(room.X, id);
    await sleep(300);
  }
  async function gauges(D) {
    return D.page.evaluate(() => [...document.querySelectorAll('#gauges [data-check]')].map(e => ({ c: e.getAttribute('data-check'), ok: e.getAttribute('data-ok'), t: e.textContent })));
  }
  const waitPhase = (p, ph, to = 5000) => p.page.waitForFunction((x) => { try { return JSON.parse(document.getElementById('debug-state').textContent).phase === x; } catch (e) { return false; } }, ph, { timeout: to });
  const mkSol = (m, idx) => ({ ...SOLUTIONS[m.id][idx], payload: m.requiredInstruments });
  const four = (room) => [room.D, room.R, room.S, room.X];
  const workers = (room) => [['R', room.R], ['S', room.S], ['X', room.X]];

  // ---- güvenlik taraması: ham çerçeve dilimi
  const BASE_KEYS = ['telemetry', 'mission', 'log', 'undoLeft', 'build', 'result', 'massKg', 'cost', 'thrustKN', 'isp', 'powerGenW', 'powerUseW', 'heat', 'heatShield', 'fuelKg', 'ispMult', 'max', 'requires', 'requiredDeltaV', 'budget', 'nasaFact', 'nasaReal', 'requiredInstruments', 'durationSec', 'parMassKg', 'checks', 'deltaV', 'score', 'breakdown'];
  function rawOf(p, from, to) { return p.raw.slice(from || 0, to === undefined ? undefined : to).filter(r => !r.startsWith('SENT')).join('\n'); }
  function leakWorkers(label, room, mission, from, to, extraNote) {
    const bad = [];
    for (const [nm, p] of workers(room)) {
      const raw = rawOf(p, from && from[nm], to && to[nm]);
      for (const k of BASE_KEYS) if (new RegExp('\\\\?"' + k + '\\\\?"\\s*:').test(raw)) bad.push(`${nm}:anahtar ${k}`);
      for (const [onm, id] of Object.entries(room.ids)) if (onm !== nm && raw.includes(id)) bad.push(`${nm}:baska playerId (${onm})`);
      for (const s of [mission.title, mission.target, mission.nasaFact.slice(0, 25), mission.nasaReal.slice(0, 25)]) if (raw.includes(s)) bad.push(`${nm}:gorev metni "${s.slice(0, 15)}"`);
    }
    ok(`${label}: calisan ham verisinde sizinti yok${extraNote || ''}`, bad.length === 0, bad.slice(0, 10).join(' | '));
  }
  async function leakDom(label, room, mission) {
    for (const [nm, p] of workers(room)) {
      const body = await p.page.evaluate(() => document.body.innerText + '\n' + document.getElementById('debug-state').textContent);
      const hits = [mission.title, mission.target, mission.nasaFact.slice(0, 25), mission.nasaReal.slice(0, 25), String(mission.requiredDeltaV) + ' ', 'parMassKg'].filter(s => body.includes(s));
      const s = JSON.parse(await p.page.locator('#debug-state').textContent());
      const forb = ['mission', 'telemetry', 'log', 'undoLeft', 'build', 'result'].filter(k => k in s);
      const pollNums = s.poll ? JSON.stringify(s.poll).match(/\d{3,}/g) : null;
      ok(`${label} ${nm} DOM/debug-state sizinti yok`, hits.length === 0 && forb.length === 0 && !pollNums, hits.concat(forb).join(',') + (pollNums || ''));
    }
  }
  function markIdx(room) { return { R: room.R.raw.length, S: room.S.raw.length, X: room.X.raw.length, D: room.D.raw.length }; }
  function leakPlayerIdsAll(label, room, from) {
    const bad = [];
    for (const [nm, p] of Object.entries({ D: room.D, R: room.R, S: room.S, X: room.X })) {
      const raw = rawOf(p, from && from[nm]);
      for (const [onm, id] of Object.entries(room.ids)) if (onm !== nm && raw.includes(id)) bad.push(`${nm} <- ${onm}`);
    }
    ok(`${label}: hicbir ham veride baska playerId yok`, bad.length === 0, bad.join(','));
  }
  function leakUids(label, room, uids) {
    const bad = [];
    for (const [nm, p] of Object.entries({ D: room.D, R: room.R, S: room.S, X: room.X })) {
      const frames = p.raw.filter(r => !r.startsWith('SENT') && /phase\\?"\s*:\s*\\?"result/.test(r));
      const raw = frames.join('\n');
      if (!frames.length) bad.push(nm + ': result cercevesi bulunamadi');
      for (const [role, list] of Object.entries(uids)) for (const u of list) if (raw.includes(u)) bad.push(nm + '<-' + role + ':' + u);
    }
    ok(label + ': result cercevelerinde hicbir parca uid i yok', bad.length === 0, bad.slice(0, 5).join(','));
  }
  async function collectUids(room) {
    const ds = await st(room.D);
    return { rocket: ds.build.rocket.map(e => e.uid), spacecraft: ds.build.spacecraft.map(e => e.uid), payload: ds.build.payload.map(e => e.uid) };
  }

  // Poll başlat -> 3 GO -> result paneli
  async function startPollUI(room) { await room.D.page.click('#poll-start-btn'); for (const p of four(room)) await p.page.waitForSelector('#poll-box:not([hidden])', { timeout: 3000 }); }
  async function allGo(room) { for (const [, p] of workers(room)) { await p.page.click('#vote-go-btn'); await sleep(120); } }
  async function resultDetails(p) {
    return p.page.evaluate(() => ({
      outcome: document.getElementById('screen-result').getAttribute('data-outcome'),
      success: document.getElementById('screen-result').getAttribute('data-success'),
      title: document.getElementById('result-title').innerText,
      reason: document.getElementById('result-reason').innerText,
      score: document.getElementById('result-score').innerText,
      breakdown: [...document.querySelectorAll('#result-breakdown li')].map(l => l.innerText),
      mission: document.getElementById('result-mission').innerText,
      telemetry: document.getElementById('result-telemetry').innerText,
      build: document.getElementById('result-build').innerText,
      nasa: document.getElementById('result-nasa').innerText,
      restartVisible: !!document.getElementById('restart-btn').offsetParent,
    }));
  }
  async function launchAndWait(room, skip = true) {
    await startPollUI(room);
    await allGo(room);
    for (const p of four(room)) await p.page.waitForSelector('#screen-result:not([hidden])', { timeout: 4000 });
    if (skip) { for (const p of four(room)) { try { await p.page.click('#skip-launch-btn', { timeout: 1500 }); } catch (e) {} } }
    for (const p of four(room)) await p.page.waitForSelector('#result-panel:not([hidden])', { timeout: 8000 });
    await sleep(150);
  }

  // Başarısız fırlatma senaryosu
  async function failScenario(label, buildFn, expectOutcome, reasonCheck, opts = {}) {
    const room = await setupRoom('F' + label.replace(/\W/g, '').slice(0, 4));
    const m = room.mission;
    const spec = await buildFn(room, m);
    if (!spec) { ok(`6 ${label}: kurulamadi`, false, 'senaryo kurulamadi'); await closeRoom(room); return; }
    const ds = await st(room.D); const t = ds.telemetry;
    const gs = await gauges(room.D);
    const warnVisible = await vis(room.D, '#poll-warning');
    await launchAndWait(room);
    const r = await resultDetails(room.D);
    const dsr = await st(room.D);
    ok(`6 ${label} [${m.id}]: data-outcome=${expectOutcome}`, r.outcome === expectOutcome && r.success === 'false', `outcome=${r.outcome} success=${r.success}; yanlis gostergeler: ${gs.filter(g => g.ok !== 'true').map(g => g.c)}`);
    ok(`6 ${label}: puan 0, yildiz 0`, /\b0\b/.test(r.score) && dsr.result.score.total === 0 && dsr.result.score.stars === 0, r.score.replace(/\n/g, ' '));
    ok(`6 ${label}: neden anlasilir ve dogru sayilar`, reasonCheck(r.reason, t, m), r.reason);
    ok(`6 ${label}: 4 sayfada ayni outcome`, (await Promise.all([room.R, room.S, room.X].map(p => p.page.locator('#screen-result').getAttribute('data-outcome')))).every(o => o === expectOutcome));
    ok(`6 ${label}: warning/ready: yonetici hazir degilken uyari gosterdi`, warnVisible === true || (opts.expectReady === true));
    console.log(`  [${label}] ${m.id} -> ${r.outcome} | ${r.title} | ${r.reason}`);
    await closeRoom(room);
    return { r, t };
  }

  try {
    if (!process.env.RAW_ONLY) {
    // ================= 1. ROOM A: ana akış =================
    const room = await setupRoom('A');
    const { D, R, S, X } = room;
    const m = room.mission;
    console.log('ROOM A gorev:', m.id);
    const gaugeInit = await gauges(D);

    // 2. yönetici building
    ok('2 yonetici #poll-start-btn gorunur', await vis(D, '#poll-start-btn'));
    ok('2 bos build: #poll-warning gorunur', await vis(D, '#poll-warning'), await txt(D, '#poll-start-btn'));
    ok('2 bos build: buton etkin (disabled degil)', !(await D.page.locator('#poll-start-btn').isDisabled()));
    for (const [nm, p] of workers(room)) ok(`2 ${nm} calisanda baslat butonu yok`, !(await vis(p, '#poll-start-btn')) && !(await vis(p, '#poll-warning')) && !(await vis(p, '#poll-cancel-btn')));
    ok('2 building fazinda #poll-box kimseye gorunmez', (await Promise.all(four(room).map(p => vis(p, '#poll-box')))).every(v => !v));
    // kısmi build -> hala uyarı; sonra çözüm -> uyarı gizli
    await build(room, { rocket: SOLUTIONS[m.id][0].rocket });
    ok('2 kismi build (yalniz roket): uyari hala var', await vis(D, '#poll-warning'));
    await build(room, { spacecraft: SOLUTIONS[m.id][0].spacecraft, payload: m.requiredInstruments });
    const gReady = await gauges(D);
    ok('2 tam cozum: 5 gosterge yesil', gReady.length === 5 && gReady.every(g => g.ok === 'true'), gReady.map(g => g.c + ':' + g.ok).join(' '));
    ok('2 hazirken #poll-warning gizli, buton gorunur', !(await vis(D, '#poll-warning')) && await vis(D, '#poll-start-btn'));
    // hazır değil -> uyarı geri gelir
    await removeByName(S, P(SOLUTIONS[m.id][0].spacecraft.find(isSolar)).name);
    await sleep(300);
    ok('2 bozulunca uyari tekrar gorunur', await vis(D, '#poll-warning'));
    await addPart(S, SOLUTIONS[m.id][0].spacecraft.find(isSolar)); await sleep(300);
    ok('2 duzelince uyari gizlenir', !(await vis(D, '#poll-warning')));
    const uidsBuild = await collectUids(room);

    // güvenlik: building (anket öncesi)
    await leakDom('8 building', room, m);
    leakWorkers('8 building', room, m);

    // 3. Anket başlat (HAZIR değilken: önce bozup başlatmak 6'da; burada hazır)
    await startPollUI(room);
    const pollMark = markIdx(room);
    for (const p of four(room)) {
      const roles = await p.page.evaluate(() => [...document.querySelectorAll('#poll-box [data-vote-role]')].map(e => [e.getAttribute('data-vote-role'), e.getAttribute('data-vote'), e.innerText.trim()]));
      ok(`3 ${p.name} 3 rol pending`, roles.length === 3 && roles.every(r => r[1] === 'pending'), JSON.stringify(roles));
    }
    ok('3 calisanlarda GO/NO-GO butonlari, yoneticide yok', (await Promise.all([R, S, X].map(async p => (await vis(p, '#vote-go-btn')) && (await vis(p, '#vote-nogo-btn') )))).every(v => v) && !(await vis(D, '#vote-go-btn')) && !(await vis(D, '#vote-nogo-btn')));
    ok('3 yoneticide #poll-cancel-btn, calisanda yok', await vis(D, '#poll-cancel-btn') && !(await vis(R, '#poll-cancel-btn')) && !(await vis(S, '#poll-cancel-btn')) && !(await vis(X, '#poll-cancel-btn')));
    ok('3 anket sirasinda #poll-start-btn gizli', !(await vis(D, '#poll-start-btn')));
    // ekle/çıkar disabled
    const dis = await Promise.all([R, S, X].map(p => p.page.evaluate(() => {
      const adds = [...document.querySelectorAll('[data-add]')], rem = [...document.querySelectorAll('#my-parts [data-remove]')];
      return { adds: adds.length, addsDis: adds.filter(b => b.disabled).length, rem: rem.length, remDis: rem.filter(b => b.disabled).length };
    })));
    ok('3 anket sirasinda calisan ekle/cikar butonlari devre disi', dis.every(d => d.adds > 0 && d.addsDis === d.adds && d.rem > 0 && d.remDis === d.rem), JSON.stringify(dis));
    // zorla tıklama -> sunucu WRONG_PHASE
    const forced = await R.page.evaluate(async () => {
      const b = document.querySelector('[data-add="tank-small"]'); b.disabled = false; b.click();
      await new Promise(r => setTimeout(r, 400));
      return document.getElementById('error-msg').innerText;
    });
    const dsAfterForce = await st(D);
    ok('3 zorla part:add -> hata, build degismedi', forced.length > 0 && dsAfterForce.build.rocket.length === SOLUTIONS[m.id][0].rocket.length, 'mesaj=' + forced);
    // R GO -> herkeste go
    await R.page.click('#vote-go-btn'); await sleep(300);
    for (const p of four(room)) {
      const v = await p.page.evaluate(() => Object.fromEntries([...document.querySelectorAll('#poll-box [data-vote-role]')].map(e => [e.getAttribute('data-vote-role'), e.getAttribute('data-vote')])));
      ok(`3 ${p.name} rocket=go, digerleri pending`, v.rocket === 'go' && v.spacecraft === 'pending' && v.payload === 'pending', JSON.stringify(v));
    }
    const sR = await st(R);
    ok('3 R debug-state poll.myVote=go', sR.poll && sR.poll.myVote === 'go', JSON.stringify(sR.poll));
    const sS = await st(S);
    ok('3 S poll.myVote null/pending', sS.poll && (sS.poll.myVote == null), JSON.stringify(sS.poll));
    // R oyunu değiştirebilir mi: go -> go  (zaten go). Oy korunur: R sayfası yenile
    await R.page.reload(); await R.page.waitForSelector('#poll-box:not([hidden])', { timeout: 4000 }); await sleep(400);
    const vR = await R.page.evaluate(() => document.querySelector('#poll-box [data-vote-role="rocket"]').getAttribute('data-vote'));
    ok('9 poll fazinda R yenile -> poll ekrani, oy korundu (go)', vR === 'go' && (await st(R)).poll.myVote === 'go', vR);
    ok('9 yenilenen R sayfasinda result/oyun ekrani yok, poll-box var', await vis(R, '#poll-box') && !(await vis(R, '#screen-result')));
    leakWorkers('8 poll', room, m);
    await leakDom('8 poll', room, m);

    // 4. NO-GO
    await S.page.click('#vote-nogo-btn');
    for (const p of four(room)) await waitPhase(p, 'building');
    await sleep(200);
    for (const p of four(room)) ok(`4 ${p.name} NO-GO sonrasi building`, !(await vis(p, '#poll-box')) && await vis(p, '#screen-game') && !(await vis(p, '#screen-result')));
    const feeds = await Promise.all([R, X].map(p => txt(p, '#feed')));
    const logD = await txt(D, '#log-box');
    ok('4 calisan feed: "Uzay Aracı NO-GO dedi — anket iptal"', feeds.every(f => f.includes('Uzay Aracı NO-GO dedi — anket iptal')), feeds[0].split('\n').slice(0, 3).join(' | '));
    ok('4 yonetici log: NO-GO satiri', logD.includes('NO-GO dedi — anket iptal'), logD.split('\n').slice(0, 4).join(' | '));
    ok('4 NO-GO sonrasi parca eklenebilir', await addPart(R, 'tank-small'), await txt(R, '#error-msg'));
    await removeByName(R, P('tank-small').name);
    // yönetici iptal
    await startPollUI(room);
    await X.page.click('#vote-go-btn'); await sleep(200);
    await D.page.click('#poll-cancel-btn');
    for (const p of four(room)) await waitPhase(p, 'building');
    await sleep(200);
    ok('4 yonetici iptal -> herkes building', (await Promise.all(four(room).map(async p => !(await vis(p, '#poll-box')) && await vis(p, '#screen-game')))).every(v => v));
    const logD2 = await txt(D, '#log-box');
    console.log('  yonetici log (iptal sonrasi):', logD2.split('\n').slice(0, 6).join(' | '));
    ok('4 iptal sonrasi parca eklenip cikarilabilir', await addPart(S, 'battery') && await removeByName(S, P('battery').name));
    ok('4 iptal log satiri var', /iptal/i.test(logD2), logD2.split('\n').slice(0, 5).join(' | '));
    // yeni anket: oylar sıfırlanmış mı
    await startPollUI(room);
    const v2 = await R.page.evaluate(() => [...document.querySelectorAll('#poll-box [data-vote-role]')].map(e => e.getAttribute('data-vote')));
    ok('4 iptalden sonra yeni ankette oylar sifirlanmis', v2.every(x => x === 'pending'), v2.join(','));
    await D.page.click('#poll-cancel-btn'); for (const p of four(room)) await waitPhase(p, 'building');
    leakWorkers('8 poll/nogo/iptal sonrasi building', room, m, undefined, undefined, ' (tum zaman)');
    await leakDom('8 nogo sonrasi', room, m);

    // 11. çift tık: poll:start iki kez
    await D.page.evaluate(() => { const b = document.getElementById('poll-start-btn'); b.click(); b.click(); b.click(); });
    await sleep(500);
    const dd = await st(D);
    ok('11 poll-start 3x tik: poll fazinda, tek anket, tutarli', dd.phase === 'poll' && Object.values(dd.poll.votes).every(v => v == null), JSON.stringify(dd.poll) + ' hata=' + await txt(D, '#error-msg'));
    console.log('  poll-start 3x tik #error-msg:', JSON.stringify(await txt(D, '#error-msg')));
    // GO'ya art arda
    await R.page.evaluate(() => { const b = document.getElementById('vote-go-btn'); for (let i = 0; i < 6; i++) b.click(); });
    await sleep(400);
    const dd2 = await st(D);
    ok('11 R GO 6x tik: tek oy, phase poll', dd2.phase === 'poll' && dd2.poll.votes.rocket === 'go' && dd2.poll.votes.spacecraft == null, JSON.stringify(dd2.poll));
    // GO ve NO-GO art arda hızlı
    await S.page.evaluate(() => { document.getElementById('vote-go-btn').click(); document.getElementById('vote-nogo-btn').click(); });
    await sleep(500);
    const dd3 = await st(D);
    console.log('  S GO+NOGO hizli -> faz:', dd3.phase, dd3.poll && JSON.stringify(dd3.poll.votes));
    ok('11 S GO sonra NO-GO hizli: faz building (iptal) ve sunucu tutarli', dd3.phase === 'building');
    // tüm sayfalar aynı fazda
    ok('11 hizli oy sonrasi 4 sayfa ayni fazda (building)', (await Promise.all([R, S, X].map(async p => (await st(p)).phase))).every(f => f === 'building'));

    // 5. BAŞARILI fırlatma: ana akış
    await startPollUI(room);
    const uids2 = await collectUids(room);
    const preResultMark = markIdx(room);
    for (const [, p] of workers(room)) { await p.page.click('#vote-go-btn'); await sleep(100); }
    const t0 = Date.now();
    for (const p of four(room)) await p.page.waitForSelector('#screen-result:not([hidden])', { timeout: 4000 });
    for (const p of four(room)) {
      ok(`5 ${p.name} result ekrani: game gizli, data-success=true data-outcome=success`, !(await vis(p, '#screen-game')) && (await p.page.locator('#screen-result').getAttribute('data-success')) === 'true' && (await p.page.locator('#screen-result').getAttribute('data-outcome')) === 'success');
    }
    ok('5 launch-sequence gorunur, result-panel henuz gizli', await vis(D, '#launch-sequence') && !(await vis(D, '#result-panel')));
    const seq0 = await txt(D, '#launch-sequence');
    await sleep(1200);
    const seq1 = await txt(D, '#launch-sequence');
    ok('5 dizi oynuyor (metin degisti/buyudu)', seq1 !== seq0 || seq1.length > 0, JSON.stringify(seq0) + ' -> ' + JSON.stringify(seq1.slice(0, 80)));
    await D.page.waitForSelector('#result-panel:not([hidden])', { timeout: 8000 });
    const dur = (Date.now() - t0) / 1000;
    ok('5 dizi ~4 sn surdu (2.5-6.5)', dur > 2.5 && dur < 6.5, dur.toFixed(2) + ' sn');
    console.log('  launch dizisi son metin:', JSON.stringify(seq1));
    for (const p of [R, S, X]) await p.page.waitForSelector('#result-panel:not([hidden])', { timeout: 8000 });
    // skip
    // (bu odada skip denenmedi; failScenario'larda skip kullanılıyor)
    const markAfterRes = markIdx(room);
    const rD = await resultDetails(D);
    const dsRes = await st(D);
    const res = dsRes.result;
    const t = res.telemetry;
    ok('5 #result-title / #result-reason dolu', rD.title.length > 0 && rD.reason.length > 0, rD.title + ' / ' + rD.reason);
    ok('5 puan > 0, yildiz gosterimi', res.score.total > 0 && res.score.stars >= 1 && /★|⭐|\*/.test(rD.score), rD.score.replace(/\n/g, ' '));
    ok('5 breakdown 5 kalem', rD.breakdown.length === 5 && res.score.breakdown.length === 5, rD.breakdown.join(' | '));
    // formül: base 1000, time 0 (null), budget, mass, undo
    const bud = Math.round(500 * Math.max(0, Math.min(1, (m.budget - t.spent) / m.budget)));
    const massP = Math.round(300 * Math.max(0, Math.min(1, 1 - Math.max(0, t.massKg - m.parMassKg) / m.parMassKg)));
    const expTotal = 1000 + 0 + bud + massP + 0;
    const bk = Object.fromEntries(res.score.breakdown.map(b => [b.key, b.points]));
    ok('5 puan formulu elle dogrulandi (base1000,time0,budget,mass,undo0)', bk.base === 1000 && bk.time === 0 && bk.budget === bud && bk.mass === massP && bk.undo === 0 && res.score.total === expTotal,
      `beklenen budget=${bud} mass=${massP} total=${expTotal}; gelen ${JSON.stringify(bk)} total=${res.score.total} spent=${t.spent}/${m.budget} kutle=${t.massKg}/par ${m.parMassKg}`);
    const expStars = expTotal >= 1700 ? 3 : expTotal >= 1400 ? 2 : 1;
    ok('5 yildiz esikleri dogru', res.score.stars === expStars, `${res.score.stars} vs ${expStars}`);
    ok('5 #result-mission: gorev basligi/hedef/Δv gorunur (yonetici)', rD.mission.includes(m.title) && rD.mission.includes(String(m.requiredDeltaV)), rD.mission.replace(/\n/g, ' | '));
    for (const [nm, p] of workers(room)) {
      const rr = await resultDetails(p);
      ok(`5 ${nm} #result-mission gorevi artik goruyor`, rr.mission.includes(m.title) && rr.mission.includes(m.target), rr.mission.replace(/\n/g, ' | ').slice(0, 120));
      ok(`5 ${nm} #result-nasa nasaReal metni`, rr.nasa.includes(m.nasaReal.slice(0, 40)), rr.nasa.slice(0, 80));
      ok(`5 ${nm} telemetri + build + puan paneli`, rr.telemetry.length > 20 && rr.build.length > 5 && rr.breakdown.length === 5 && rr.score === rD.score, '');
      ok(`5 ${nm} #restart-btn yok`, !rr.restartVisible);
    }
    ok('5 yonetici #restart-btn var', rD.restartVisible);
    ok('5 yonetici #result-nasa nasaReal', rD.nasa.includes(m.nasaReal.slice(0, 40)));
    console.log('  SONUC PANELI:\n', JSON.stringify(rD, null, 1));
    console.log('  telemetry kutu:', rD.telemetry.replace(/\n/g, ' | '));
    ok('5 #result-telemetry 5 kontrol + sayilar', /TWR|itki|İtki/i.test(rD.telemetry) && rD.telemetry.includes(String(Math.round(t.deltaV))), rD.telemetry.replace(/\n/g, ' | ').slice(0, 200));
    ok('5 #result-build: parca adlari', rD.build.includes(P('structure-frame').name), rD.build.replace(/\n/g, ' | '));
    if (SHOT) { await D.page.screenshot({ path: path.join(SHOT, 'stage3-result-director.png'), fullPage: true }); await R.page.screenshot({ path: path.join(SHOT, 'stage3-result-worker.png'), fullPage: true }); }
    // result: playerId / uid sızıntısı
    leakPlayerIdsAll('8 result', room);
    leakUids('8 result', room, { rocket: uids2.rocket, spacecraft: uids2.spacecraft, payload: uids2.payload });
    // sonuç öncesi çerçeveler
    leakWorkers('8 result ONCESI (anket + 2 GO dahil)', room, m, undefined, { R: preResultMark.R, S: preResultMark.S, X: preResultMark.X });
    // result görünümünde sayısal alan/uid: yönetici/çalışan görünümlerinin üst düzey anahtarları
    const topKeys = await Promise.all(four(room).map(async p => Object.keys(await st(p)).sort().join(',')));
    console.log('  result debug-state ust anahtarlar:', topKeys);
    ok('8 result: 4 gorunum ayni ust anahtar kumesi', new Set(topKeys).size <= 2, topKeys.join(' || '));
    ok('8 result: you.id disinda uid yok (result.build yalniz name/icon)', (() => { const b = res.build; return ['rocket', 'spacecraft', 'payload'].every(k => b[k].every(e => Object.keys(e).sort().join() === 'icon,name')); })(), JSON.stringify(res.build).slice(0, 150));
    // result fazında yenile
    await R.page.reload(); await R.page.waitForSelector('#screen-result:not([hidden])', { timeout: 4000 }); await sleep(500);
    ok('9 result fazinda yenile: dizi oynamadan panel gorunur', await vis(R, '#result-panel') && !(await vis(R, '#launch-sequence')), '');
    await D.page.reload(); await D.page.waitForSelector('#screen-result:not([hidden])', { timeout: 4000 }); await sleep(500);
    ok('9 yonetici result yenile: panel + restart', await vis(D, '#result-panel') && await vis(D, '#restart-btn') && !(await vis(D, '#launch-sequence')));
    // mobil benzeri kontrol: bu oda masaüstü; yenileme sonrası farklı oyuncu leak yok
    leakPlayerIdsAll('8 result+yenile', room);

    // 7. restart (yetki raw testleri ayrı odada)
    const preRestartMark = markIdx(room);
    const oldMission = m.id;
    await D.page.click('#restart-btn');
    for (const p of four(room)) await waitPhase(p, 'building');
    await sleep(300);
    for (const p of four(room)) ok(`7 ${p.name} restart sonrasi building ekrani`, await vis(p, '#screen-game') && !(await vis(p, '#screen-result')) && !(await vis(p, '#poll-box')) && !(await vis(p, '#result-panel')));
    const dsNew = await st(D);
    ok('7 build bos', dsNew.build.rocket.length + dsNew.build.spacecraft.length + dsNew.build.payload.length === 0);
    const logNew = await txt(D, '#log-box');
    ok('7 log temiz + "Yeni tur başladı"', logNew.includes('Yeni tur başladı') && !logNew.includes('taktı') && !logNew.includes('NO-GO') , logNew.replace(/\n/g, ' | '));
    ok('7 telemetri sifirlandi, undoLeft 3', dsNew.telemetry.massKg === 0 && dsNew.undoLeft === 3 && dsNew.telemetry.ready === false);
    ok('7 yeni gorev (kayit): ' + oldMission + ' -> ' + dsNew.mission.id, true, dsNew.mission.id !== oldMission ? 'farkli' : 'AYNI');
    ok('7 yeni gorev oncekinden farkli', dsNew.mission.id !== oldMission, `${oldMission} -> ${dsNew.mission.id}`);
    for (const [nm, p] of workers(room)) {
      const body = await p.page.evaluate(() => document.body.innerText);
      const s = await st(p);
      ok(`7 ${nm} "Görev: GİZLİ", parca yok, result anahtari yok`, body.includes('GİZLİ') && s.missionLabel === 'GİZLİ' && !('result' in s) && !('mission' in s) && (await cnt(p)) === 0, '');
    }
    ok('7 yonetici #poll-warning gorunur (bos build)', await vis(D, '#poll-warning'));
    // yeni tur güvenlik (restart SONRASI yeni görev): yeni görev metni sızmamalı
    const m2 = dsNew.mission;
    leakWorkers('8 restart sonrasi yeni tur (yeni gorev)', room, m2, preRestartMark, undefined);
    leakWorkers('8 restart sonrasi yeni tur (ESKI gorev metni de gelmemeli)', room, m, preRestartMark, undefined);
    await leakDom('8 restart sonrasi', room, m2);
    leakPlayerIdsAll('8 restart sonrasi', room, preRestartMark);
    // yeni turda poll + nogo da güvenli
    await build(room, mkSol(m2, 0));
    await startPollUI(room);
    await R.page.click('#vote-go-btn'); await sleep(150);
    await X.page.click('#vote-nogo-btn');
    for (const p of four(room)) await waitPhase(p, 'building');
    await sleep(200);
    leakWorkers('8 restart sonrasi poll+nogo', room, m2, preRestartMark, undefined);
    ok('7 yeni turda NO-GO feed', (await txt(S, '#feed')).includes('Faydalı Yük NO-GO dedi — anket iptal'), (await txt(S, '#feed')).split('\n').slice(0, 3).join(' | '));
    // yeni turda başarılı fırlat -> restart akışı iki kez
    await startPollUI(room); await allGo(room);
    for (const p of four(room)) await p.page.waitForSelector('#result-panel:not([hidden])', { timeout: 9000 });
    const rD2 = await resultDetails(D);
    ok('7 2. turda sonuc paneli ' + rD2.outcome, rD2.outcome === 'success', rD2.reason);
    ok('7 2. tur sonucu: gorev yeni gorev', rD2.mission.includes(m2.title));
    const dsRes2 = await st(D);
    ok('7 2. tur sonucu puan formulu', (() => { const t2 = dsRes2.result.telemetry; const b = Math.round(500 * Math.max(0, Math.min(1, (m2.budget - t2.spent) / m2.budget))); const ms = Math.round(300 * Math.max(0, Math.min(1, 1 - Math.max(0, t2.massKg - m2.parMassKg) / m2.parMassKg))); return dsRes2.result.score.total === 1000 + b + ms; })(), JSON.stringify(dsRes2.result.score));
    await closeRoom(room);

    // ================= 6. BAŞARISIZ FIRLATMALAR =================
    const sc = (m) => SOLUTIONS[m.id][0];
    await failScenario('a no-liftoff (agir, tek motor, +guc yok)', async (room, m) => {
      await build(room, { rocket: ['engine-kestrel', 'tank-large', 'tank-large', 'tank-large', 'fuel-kerosene'], spacecraft: sc(m).spacecraft.filter(id => !isSolar(id)), payload: m.requiredInstruments });
      return true;
    }, 'no-liftoff', (r, t) => r.includes(t.twr.toFixed(2)) && /1[.,]2/.test(r) && /kalk/i.test(r));
    await failScenario('a2 no-liftoff (yalniz tanksiz motor)', async (room, m) => {
      await build(room, { rocket: ['engine-heron'], spacecraft: sc(m).spacecraft, payload: m.requiredInstruments });
      return true;
    }, 'out-of-fuel', (r, t, m) => /gereken/i.test(r) || /kalk/i.test(r));
    await failScenario('b1 out-of-fuel (yakit tipi yok + guc/isi bozuk)', async (room, m) => {
      await build(room, { rocket: ['engine-kestrel', 'tank-small'], spacecraft: sc(m).spacecraft.filter(id => !isSolar(id) && !isShield(id)), payload: m.requiredInstruments });
      return true;
    }, 'out-of-fuel', (r, t, m) => r.includes(String(m.requiredDeltaV)) && /yakıt tipi/i.test(r));
    await failScenario('b2 out-of-fuel (kucuk tank + yakit)', async (room, m) => {
      await build(room, { rocket: ['engine-kestrel', 'tank-small', 'fuel-kerosene'], spacecraft: sc(m).spacecraft, payload: m.requiredInstruments });
      return true;
    }, 'out-of-fuel', (r, t, m) => r.includes(String(m.requiredDeltaV)) && r.includes(String(Math.round(t.deltaV))));
    await failScenario('c1 power-loss (guc yok)', async (room, m) => {
      await build(room, { rocket: sc(m).rocket, spacecraft: sc(m).spacecraft.filter(id => !isSolar(id)), payload: m.requiredInstruments });
      return true;
    }, 'power-loss', (r, t) => r.includes(String(Math.round(t.powerGenW))) && r.includes(String(Math.round(t.powerUseW))));
    await failScenario('c2 power-loss oncelik (guc+isi+alet eksik)', async (room, m) => {
      await build(room, { rocket: sc(m).rocket, spacecraft: sc(m).spacecraft.filter(id => !isSolar(id) && !isShield(id)), payload: m.requiredInstruments.slice(0, -1) });
      return true;
    }, 'power-loss', (r, t) => r.includes(String(Math.round(t.powerUseW))));
    await failScenario('d1 overheat (kalkan yok)', async (room, m) => {
      await build(room, { rocket: sc(m).rocket, spacecraft: sc(m).spacecraft.filter(id => !isShield(id)), payload: m.requiredInstruments });
      return true;
    }, 'overheat', (r, t) => r.includes(String(Math.round(t.heat))) && r.includes(String(Math.round(t.heatShield))));
    await failScenario('d2 overheat oncelik (isi + alet eksik)', async (room, m) => {
      await build(room, { rocket: sc(m).rocket, spacecraft: sc(m).spacecraft.filter(id => !isShield(id)), payload: m.requiredInstruments.slice(0, -1) });
      return true;
    }, 'overheat', (r, t) => r.includes(String(Math.round(t.heat))));
    await failScenario('e1 mission-failed (zorunlu alet eksik)', async (room, m) => {
      await build(room, { rocket: sc(m).rocket, spacecraft: sc(m).spacecraft, payload: m.requiredInstruments.slice(0, -1) });
      return m.requiredInstruments.length > 0;
    }, 'mission-failed', (r, t, m) => /Eksik/i.test(r) && r.includes(m.requiredInstruments[m.requiredInstruments.length - 1]));
    await failScenario('e2 mission-failed (butce asimi)', async (room, m) => {
      await build(room, mkSol(m, 0));
      // açgözlü ekstra: bütçeyi aşana kadar, diğer 4 kontrol bozulmadan
      const groups = [
        [['R','engine-kestrel'],['R','tank-small'],['R','tank-small'],['R','tank-small'],['S','shield-light']],
        [['R','tank-small']], [['R','tank-small'],['R','tank-small']], [['S','solar-large']], [['S','battery']], [['S','antenna-hga']], [['S','computer-backup']], [['X','camera']], [['X','spectrometer']], [['R','tank-large']],
      ];
      for (const g of groups) {
        const added = [];
        for (const [r, id] of g) { const p = { R: room.R, S: room.S, X: room.X }[r]; if (await addPart(p, id)) added.push([p, id]); }
        await sleep(300);
        const tl0 = (await st(room.D)).telemetry; const c = tl0.checks;
        if (!(c.twr && c.deltaV && c.power && c.heat)) { for (const [p, id] of added.reverse()) { await removeByName(p, P(id).name); await sleep(150); } await sleep(200); continue; }
        if (tl0.overBudget) break;
      }
      const tl = (await st(room.D)).telemetry;
      console.log('  e2 son durum: spent', tl.spent, 'overBudget', tl.overBudget, 'checks', JSON.stringify(tl.checks));
      return tl.overBudget && tl.checks.twr && tl.checks.deltaV && tl.checks.power && tl.checks.heat;
    }, 'mission-failed', (r, t, m) => /Bütçe/i.test(r) && r.includes(String(Math.round(t.spent))) && r.includes(String(m.budget)));
    await failScenario('e3 oncelik: twr+dv+guc+isi+alet hepsi bozuk -> no-liftoff', async (room, m) => {
      await build(room, { rocket: ['engine-heron', 'tank-large', 'tank-large', 'tank-large', 'fuel-kerosene'], spacecraft: ['structure-frame'], payload: [] });
      return true;
    }, 'no-liftoff', (r, t) => r.includes(t.twr.toFixed(2)));
    await failScenario('e4 bos build', async () => true, 'no-liftoff', (r, t) => /0[.,]00/.test(r));

    // ================= 5b. başarı: atla butonu + mobil + ekran görüntüleri =================
    const mob = await setupRoom('MB', { width: 375, height: 812 });
    {
      const mm = mob.mission;
      await build(mob, mkSol(mm, 1));
      const gmob = await gauges(mob.D);
      console.log('  mobil oda gorev', mm.id, 'cozum#1 yesil:', gmob.every(g => g.ok === 'true'));
      // yönetici mobil (building, poll başlat butonu)
      const chk = async (label, p, sel) => p.page.evaluate((s) => {
        const bs = [...document.querySelectorAll(s)].filter(b => b.offsetParent);
        return { sw: document.documentElement.scrollWidth, cw: document.documentElement.clientWidth, n: bs.length,
          small: bs.filter(b => b.getBoundingClientRect().height < 44 || b.getBoundingClientRect().width < 44).length,
          off: bs.filter(b => b.getBoundingClientRect().right > window.innerWidth + 1 || b.getBoundingClientRect().left < -1).length,
          heights: bs.map(b => Math.round(b.getBoundingClientRect().height)) };
      }, sel);
      const mD = await chk('D building', mob.D, '#poll-start-btn');
      ok('10 mobil yonetici building: #poll-start-btn gorunur, tasma yok', mD.n === 1 && mD.sw <= mD.cw && mD.off === 0 && mD.small === 0, JSON.stringify(mD));
      if (SHOT) await mob.D.page.screenshot({ path: path.join(SHOT, 'stage3-mobile-director-building.png'), fullPage: true });
      await startPollUI(mob);
      await mob.R.page.click('#vote-go-btn'); await sleep(250);
      for (const [nm, p] of [['R', mob.R], ['S', mob.S], ['D', mob.D]]) {
        const sel = nm === 'D' ? '#poll-cancel-btn' : '#vote-go-btn, #vote-nogo-btn';
        const c = await chk('poll ' + nm, p, sel);
        ok(`10 mobil poll ${nm}: butonlar >=44px, ekran icinde, yatay tasma yok`, c.n >= 1 && c.sw <= c.cw && c.off === 0 && c.small === 0, JSON.stringify(c));
        // butonun ekranda (viewport içinde dikey) olup olmadığı ve tıklanabilirliği
        if (nm !== 'D') {
          const vis2 = await p.page.evaluate(() => { const b = document.getElementById('vote-go-btn'); b.scrollIntoView(); const r = b.getBoundingClientRect(); const el = document.elementFromPoint(r.left + r.width / 2, r.top + r.height / 2); return { top: r.top, bottom: r.bottom, vh: innerHeight, hit: el === b || b.contains(el) }; });
          ok(`10 mobil ${nm} GO butonu tiklanabilir (ustunde baska oge yok)`, vis2.hit, JSON.stringify(vis2));
        }
        if (SHOT) await p.page.screenshot({ path: path.join(SHOT, `stage3-mobile-poll-${nm}.png`), fullPage: true });
      }
      await mob.S.page.click('#vote-go-btn'); await sleep(200); await mob.X.page.click('#vote-go-btn');
      for (const p of four(mob)) await p.page.waitForSelector('#screen-result:not([hidden])', { timeout: 4000 });
      await sleep(1000);
      const cL = await chk('launch', mob.R, '#skip-launch-btn');
      ok('10 mobil launch-sequence: tasma yok', cL.sw <= cL.cw, JSON.stringify(cL));
      if (SHOT) await mob.R.page.screenshot({ path: path.join(SHOT, 'stage3-mobile-launch.png'), fullPage: true });
      // atla
      const ts = Date.now();
      for (const p of four(mob)) await p.page.click('#skip-launch-btn');
      for (const p of four(mob)) await p.page.waitForSelector('#result-panel:not([hidden])', { timeout: 1500 });
      ok('5 #skip-launch-btn dizi atlar (panel hemen gorunur)', Date.now() - ts < 1500 && !(await vis(mob.R, '#launch-sequence')), (Date.now() - ts) + ' ms');
      await sleep(200);
      for (const [nm, p] of [['D', mob.D], ['R', mob.R]]) {
        const c = await chk('result', p, '#restart-btn, #skip-launch-btn');
        const ov = await p.page.evaluate(() => { const els = [...document.querySelectorAll('#result-panel *')].filter(e => e.offsetParent); return { sw: document.documentElement.scrollWidth, cw: document.documentElement.clientWidth, wide: els.filter(e => e.getBoundingClientRect().right > innerWidth + 1).map(e => e.id || e.tagName).slice(0, 5), h: document.documentElement.scrollHeight }; });
        ok(`10 mobil sonuc ${nm}: yatay tasma yok`, ov.sw <= ov.cw && ov.wide.length === 0, JSON.stringify(ov));
        if (nm === 'D') ok('10 mobil sonuc yonetici: #restart-btn >=44px ve ekranda', c.n === 1 && c.small === 0 && c.off === 0, JSON.stringify(c));
        if (SHOT) await p.page.screenshot({ path: path.join(SHOT, `stage3-mobile-result-${nm}.png`), fullPage: true });
      }
      // dar 320
      await mob.R.page.setViewportSize({ width: 320, height: 640 }); await sleep(200);
      ok('10 320px sonuc yatay tasma yok', await mob.R.page.evaluate(() => document.documentElement.scrollWidth <= document.documentElement.clientWidth));
      // restart double click
      await mob.D.page.evaluate(() => { const b = document.getElementById('restart-btn'); b.click(); b.click(); b.click(); });
      await sleep(700);
      const dsm = await st(mob.D);
      ok('11 restart 3x tik: building, tutarli, hata mesaji', dsm.phase === 'building' && dsm.build.rocket.length === 0, 'faz=' + dsm.phase + ' hata=' + JSON.stringify(await txt(mob.D, '#error-msg')));
      console.log('  restart 3x tik #error-msg:', JSON.stringify(await txt(mob.D, '#error-msg')));
      ok('11 restart tik sonrasi 4 sayfa ayni faz', (await Promise.all(four(mob).map(async p => (await st(p)).phase))).every(f => f === 'building'));
    }
    await closeRoom(mob);

    // ================= 9c. bir çalışanın sekmesi kapalıyken anket =================
    const rc = await setupRoom('RC');
    {
      await build(rc, mkSol(rc.mission, 0));
      await startPollUI(rc);
      await rc.S.ctx.close();
      await sleep(600);
      await rc.R.page.click('#vote-go-btn'); await sleep(150); await rc.X.page.click('#vote-go-btn');
      await sleep(700);
      const d = await st(rc.D);
      ok('9 calisan sekmesi kapali: anket bekler (phase poll, spacecraft oy yok)', d.phase === 'poll' && d.poll.votes.rocket === 'go' && d.poll.votes.payload === 'go' && d.poll.votes.spacecraft == null, JSON.stringify(d.poll));
      ok('9 anket beklerken yonetici #poll-cancel-btn gorunur', await vis(rc.D, '#poll-cancel-btn'));
      console.log('  yonetici poll-box metni (S kopuk):', (await txt(rc.D, '#poll-box')).replace(/\n/g, ' | '));
      await rc.D.page.click('#poll-cancel-btn');
      await waitPhase(rc.D, 'building'); await sleep(300);
      ok('9 yonetici iptal -> kalanlar building', (await st(rc.R)).phase === 'building' && (await st(rc.X)).phase === 'building');
      // Yeniden anket + S yine kopuk: GO'lar sonuç vermez
      await rc.D.page.click('#poll-start-btn'); await sleep(500);
      ok('9 S kopukken yeni anket baslar', (await st(rc.D)).phase === 'poll');
      await rc.D.page.click('#poll-cancel-btn'); await sleep(300);
    }
    await closeRoom(rc);

    }
    // ================= 3/4/7/8. doğrudan socket testleri =================
    const raw = await mk('RAW');
    await raw.page.evaluate(() => {
      window.mkc = () => new Promise((res) => {
        const s = io({ forceNew: true }); const c = { s, state: null, frames: [], acks: [] };
        s.onAny((ev, ...a) => { c.frames.push(JSON.stringify([ev, a])); });
        s.on('state', (st) => { c.state = st; });
        s.on('connect', () => res(c));
      });
      window.em = (c, ev, pl) => new Promise((res) => { c.s.emit(ev, pl, (r) => { c.acks.push(r); res(r); }); });
      window.wait = (ms) => new Promise(r => setTimeout(r, ms));
    });
    const o = await raw.page.evaluate(async () => {
      const O = {}; const cs = [];
      for (let i = 0; i < 4; i++) cs.push(await mkc());
      const [d, r, s, x] = cs;
      const a1 = await em(d, 'room:create', { name: 'D' }); const code = a1.code;
      const ids = { d: a1.playerId };
      for (const [c, n, k] of [[r, 'r', 'r'], [s, 's', 's'], [x, 'x', 'x']]) { const a = await em(c, 'room:join', { code, name: n }); ids[k] = a.playerId; }
      O.lobby = { start: (await em(d, 'poll:start', {})).error, cancel: (await em(d, 'poll:cancel', {})).error, vote: (await em(r, 'poll:vote', { vote: 'go' })).error, restart: (await em(d, 'game:restart', {})).error };
      await em(d, 'role:select', { role: 'director' }); await em(r, 'role:select', { role: 'rocket' }); await em(s, 'role:select', { role: 'spacecraft' }); await em(x, 'role:select', { role: 'payload' });
      await wait(300);
      const mission = d.state.mission;
      O.mission = mission;
      // building
      O.b = {
        wStart: (await em(r, 'poll:start', {})).error, wCancel: (await em(s, 'poll:cancel', {})).error, wRestart: (await em(x, 'game:restart', {})).error,
        dVote: (await em(d, 'poll:vote', { vote: 'go' })).error, dCancel: (await em(d, 'poll:cancel', {})).error, dRestart: (await em(d, 'game:restart', {})).error,
        wVote: (await em(r, 'poll:vote', { vote: 'go' })).error,
      };
      // poll
      O.p = {};
      const sp = await Promise.all([em(d, 'poll:start', {}), em(d, 'poll:start', {}), em(d, 'poll:start', {})]);
      O.p.startsParallel = sp.map(a => a.ok ? 'ok' : a.error);
      O.p.start2 = (await em(d, 'poll:start', {})).error;
      O.p.add = (await em(r, 'part:add', { partId: 'tank-small' })).error;
      O.p.remove = (await em(r, 'part:remove', { uid: 'abcdef12' })).error;
      O.p.badVote = [(await em(r, 'poll:vote', { vote: 'maybe' })).error, (await em(r, 'poll:vote', { vote: 5 })).error, (await em(r, 'poll:vote', null)).error, (await em(r, 'poll:vote', {})).error, (await em(r, 'poll:vote', { vote: '__proto__' })).error, (await em(r, 'poll:vote', { vote: 'GO' })).error];
      O.p.dVote = (await em(d, 'poll:vote', { vote: 'go' })).error;
      O.p.wStart = (await em(r, 'poll:start', {})).error; O.p.wCancel = (await em(r, 'poll:cancel', {})).error; O.p.wRestart = (await em(r, 'game:restart', {})).error; O.p.dRestart = (await em(d, 'game:restart', {})).error;
      const before = d.state.poll && JSON.stringify(d.state.poll.votes);
      const sp2 = await Promise.all(Array.from({ length: 10 }, () => em(r, 'poll:vote', { vote: 'go' })));
      O.p.rGoSpam = sp2.map(a => a.ok ? 'ok' : a.error).join(',');
      await wait(250);
      O.p.votesAfterSpam = JSON.stringify(d.state.poll && d.state.poll.votes); O.p.phaseAfterSpam = d.state.phase;
      O.p.rState = JSON.stringify(r.state.poll); O.p.sState = JSON.stringify(s.state.poll); O.p.xState = JSON.stringify(x.state.poll);
      // NO-GO
      const framesBeforeNogo = [r, s, x, d].map(c => c.frames.length);
      O.p.nogo = (await em(s, 'poll:vote', { vote: 'nogo' })).ok;
      await wait(250);
      O.p.afterNogoPhase = [d, r, s, x].map(c => c.state.phase);
      O.p.vAfter = (await em(x, 'poll:vote', { vote: 'go' })).error;
      O.p.cancelAfter = (await em(d, 'poll:cancel', {})).error;
      O.p.feedNogo = JSON.stringify(r.state.feed.slice(-3));
      O.p.poll_after_nogo = ['poll' in r.state, 'poll' in d.state];
      // yeni anket, 2 go, sonra 3.: hızlı çift
      await em(d, 'poll:start', {}); await wait(250);
      O.p.freshVotes = JSON.stringify(d.state.poll.votes);
      await em(r, 'poll:vote', { vote: 'go' }); await em(s, 'poll:vote', { vote: 'go' });
      const mark = [r, s, x, d].map(c => c.frames.length);
      O.mark = mark;
      const last = await Promise.all([em(x, 'poll:vote', { vote: 'go' }), em(x, 'poll:vote', { vote: 'go' }), em(x, 'poll:vote', { vote: 'go' })]);
      O.p.lastParallel = last.map(a => a.ok ? 'ok' : a.error);
      await wait(350);
      O.res = { phases: [d, r, s, x].map(c => c.state.phase), outcome: d.state.result && d.state.result.outcome };
      O.res.dKeys = Object.keys(d.state).sort().join(','); O.res.rKeys = Object.keys(r.state).sort().join(',');
      O.res.resultKeysSame = [d, r, s, x].map(c => JSON.stringify(c.state.result)).every((v, i, a) => v === a[0]);
      O.res.uidLeak = [d, r, s, x].map(c => JSON.stringify(c.state)).filter(j => /"uid"/.test(j)).length;
      // result fazında
      O.r = {
        vote: (await em(r, 'poll:vote', { vote: 'go' })).error, start: (await em(d, 'poll:start', {})).error, cancel: (await em(d, 'poll:cancel', {})).error,
        add: (await em(r, 'part:add', { partId: 'tank-small' })).error, wRestart: (await em(r, 'game:restart', {})).error, sRestart: (await em(s, 'game:restart', {})).error,
        rolesel: (await em(r, 'role:select', { role: null })).error,
      };
      const mark2 = [r, s, x, d].map(c => c.frames.length);
      O.r.dRestart = (await em(d, 'game:restart', {})).ok;
      O.r.dRestart2 = (await em(d, 'game:restart', {})).error;
      await wait(300);
      O.after = { phases: [d, r, s, x].map(c => c.state.phase), rKeys: Object.keys(r.state).sort().join(','), label: r.state.missionLabel, mission2: d.state.mission.id, rolesKept: d.state.players.map(p => p.role).join(',') };
      // frame sızıntı kontrolü (iç)
      const leaks = [];
      const strs = [mission.title, mission.target, mission.nasaFact.slice(0, 25), mission.nasaReal.slice(0, 25)];
      const keys = ['telemetry', 'mission', 'log', 'undoLeft', 'build', 'result', 'requiredDeltaV', 'budget', 'nasaFact', 'nasaReal', 'requiredInstruments', 'checks', 'deltaV', 'parMassKg', 'massKg'];
      const idList = Object.entries(ids);
      [['r', r, 0], ['s', s, 1], ['x', x, 2]].forEach(([nm, c, i]) => {
        // 1) sonuç öncesi: mark[i]'ye kadar
        const pre = c.frames.slice(0, mark[i]).join('\n');
        keys.forEach(k => { if (new RegExp('"' + k + '"\\s*:').test(pre)) leaks.push(nm + ' pre key ' + k); });
        strs.forEach(sx => { if (pre.includes(sx)) leaks.push(nm + ' pre str ' + sx.slice(0, 12)); });
        // 2) tüm zaman: başka playerId
        const all = c.frames.join('\n');
        idList.forEach(([k, id]) => { if (k !== nm && all.includes(id)) leaks.push(nm + ' <- id ' + k); });
        // 3) restart sonrası: yeni tur
        const post = c.frames.slice(mark2[i] + 0).join('\n');
        // restart'tan önceki result çerçevesi hariç: mark2 restart öncesi alındı
        keys.forEach(k => { if (new RegExp('"' + k + '"\\s*:').test(post)) leaks.push(nm + ' post-restart key ' + k); });
      });
      const dall = d.frames.join('\n');
      idList.forEach(([k, id]) => { if (k !== 'd' && dall.includes(id)) leaks.push('d <- id ' + k); });
      O.leaks = leaks;
      O.acks = cs.map(c => c.acks.filter(a => !a.ok).map(a => a.error + ':' + a.message));
      return O;
    });
    console.log('  RAW:', JSON.stringify({ lobby: o.lobby, b: o.b, p: o.p, res: o.res, r: o.r, after: o.after, leaks: o.leaks }, null, 1));
    ok('3 lobide poll:start/cancel/vote/restart -> WRONG_PHASE', Object.values(o.lobby).every(e => e === 'WRONG_PHASE' || e === 'NOT_ALLOWED'), JSON.stringify(o.lobby));
    ok('3 building: calisandan poll:start/cancel/restart -> NOT_ALLOWED', o.b.wStart === 'NOT_ALLOWED' && o.b.wCancel === 'NOT_ALLOWED' && o.b.wRestart === 'NOT_ALLOWED', JSON.stringify(o.b));
    ok('3 building: yoneticiden poll:vote -> NOT_ALLOWED', o.b.dVote === 'NOT_ALLOWED', JSON.stringify(o.b.dVote));
    ok('3 building: yonetici poll:cancel / game:restart -> WRONG_PHASE; calisan vote -> WRONG_PHASE', o.b.dCancel === 'WRONG_PHASE' && o.b.dRestart === 'WRONG_PHASE' && o.b.wVote === 'WRONG_PHASE', JSON.stringify(o.b));
    ok('11 poll:start 3 paralel -> 1 ok, 2 WRONG_PHASE', o.p.startsParallel.filter(x => x === 'ok').length === 1 && o.p.startsParallel.filter(x => x === 'WRONG_PHASE').length === 2, o.p.startsParallel.join(','));
    ok('3 poll: 4. poll:start -> WRONG_PHASE', o.p.start2 === 'WRONG_PHASE');
    ok('3 poll: part:add/remove -> WRONG_PHASE', o.p.add === 'WRONG_PHASE' && o.p.remove === 'WRONG_PHASE', o.p.add + ',' + o.p.remove);
    ok('3 poll: bozuk oy degerleri -> BAD_REQUEST', o.p.badVote.every(e => e === 'BAD_REQUEST'), o.p.badVote.join(','));
    ok('3 poll: yoneticiden poll:vote NOT_ALLOWED; calisandan start/cancel/restart NOT_ALLOWED; yonetici restart WRONG_PHASE', o.p.dVote === 'NOT_ALLOWED' && o.p.wStart === 'NOT_ALLOWED' && o.p.wCancel === 'NOT_ALLOWED' && o.p.wRestart === 'NOT_ALLOWED' && o.p.dRestart === 'WRONG_PHASE', JSON.stringify(o.p));
    ok('11 R GO x10 paralel: hepsi ok, tek oy', o.p.rGoSpam.split(',').every(x => x === 'ok') && JSON.parse(o.p.votesAfterSpam).rocket === 'go' && JSON.parse(o.p.votesAfterSpam).spacecraft == null, o.p.rGoSpam + ' ' + o.p.votesAfterSpam);
    ok('3 poll: calisan state.poll.myVote; sayi yok', /myVote/.test(o.p.rState) && !/myVote/.test(o.p.sState) || /"myVote":null/.test(o.p.sState), o.p.rState + ' | ' + o.p.sState);
    ok('4 NO-GO -> 4 istemci building', o.p.nogo && o.res && o.p.afterNogoPhase.every(p => p === 'building'), o.p.afterNogoPhase.join(','));
    ok('4 NO-GO sonrasi oy/iptal -> WRONG_PHASE', o.p.vAfter === 'WRONG_PHASE' && o.p.cancelAfter === 'WRONG_PHASE', o.p.vAfter + ',' + o.p.cancelAfter);
    ok('4 NO-GO feed', /NO-GO dedi — anket iptal/.test(o.p.feedNogo), o.p.feedNogo);
    ok('4 NO-GO sonrasi building state de poll anahtari yok', o.p.poll_after_nogo[0] === false && o.p.poll_after_nogo[1] === false, JSON.stringify(o.p.poll_after_nogo));
    ok('4 yeni anket oylari sifir', Object.values(JSON.parse(o.p.freshVotes)).every(v => v == null), o.p.freshVotes);
    ok('11 son oy 3 paralel -> tek fırlatma, fazlalar WRONG_PHASE/ok', o.res.phases.every(p => p === 'result') && o.p.lastParallel.filter(x => x === 'ok').length >= 1, o.p.lastParallel.join(','));
    ok('5 result: 4 istemci result, bos build -> no-liftoff', o.res.outcome === 'no-liftoff', o.res.outcome);
    ok('8 result: herkese ayni result nesnesi', o.res.resultKeysSame, '');
    ok('8 result: state icinde "uid" yok', o.res.uidLeak === 0, String(o.res.uidLeak));
    console.log('  result ust anahtarlar D:', o.res.dKeys, '| R:', o.res.rKeys);
    ok('3 result fazinda oy/start/cancel/add -> WRONG_PHASE', ['vote', 'start', 'cancel', 'add'].every(k => o.r[k] === 'WRONG_PHASE'), JSON.stringify(o.r));
    ok('7 calisan game:restart -> NOT_ALLOWED (result fazinda)', o.r.wRestart === 'NOT_ALLOWED' && o.r.sRestart === 'NOT_ALLOWED', JSON.stringify([o.r.wRestart, o.r.sRestart]));
    ok('7 yonetici restart ok, 2. restart -> WRONG_PHASE', o.r.dRestart === true && o.r.dRestart2 === 'WRONG_PHASE', JSON.stringify([o.r.dRestart, o.r.dRestart2]));
    ok('7 restart sonrasi building, roller korunur, label GİZLİ, calisan result/mission anahtari yok', o.after.phases.every(p => p === 'building') && o.after.label === 'GİZLİ' && !/result|mission,|telemetry/.test(o.after.rKeys.replace('missionLabel', '')) && o.after.rolesKept === 'director,rocket,spacecraft,payload', JSON.stringify(o.after));
    console.log('  role:select result fazinda:', o.r.rolesel);
    ok('8 RAW: sizinti yok (sonuc oncesi anahtar/gorev metni, tum zaman baska playerId, restart sonrasi anahtar)', o.leaks.length === 0, o.leaks.join(' | '));
    ok('8 RAW: hata ack mesajlarinda gorev/sayi ipucu yok', o.acks.flat().every(m => !/\d{3,}/.test(m)), o.acks.flat().slice(0, 4).join(' | '));
    await raw.ctx.close();
  } catch (e) {
    console.log('SCRIPT HATASI', e && e.stack || e);
    ok('betik hatasiz tamamlandi', false, String(e && e.message));
  }

  console.log('\n=== ISSUES (console/pageerror/netfail) ===');
  console.log(issues.length ? issues.join('\n') : 'yok');
  console.log('stderr:', stderr || '(bos)');
  const fails = results.filter(r => !r.pass);
  console.log(`\nTOPLAM ${results.length}, FAIL ${fails.length}`);
  fails.forEach(f => console.log('FAIL:', f.name));
  await browser.close();
  srv.kill();
  process.exit(0);
})();
