// stage5 senaryoları (3): yeniden bağlanma, yanlış gövde, bütçe aşımı, 3B'siz oyun, yönetici kısıtları.
const L0 = global.__S5;
const { ok, sleep, scenario, SOLUTIONS, R, S, Y } = L0;

scenario('reconnect', async (L) => {
  const server = await L.startServer({ PP_EVENTS: 'none', PP_TELEMETRY_DELAY_MS: '0', PP_WINDOW_SEC: '600' });
  const browser = await L.getBrowser();
  try {
    const room = await L.setupRoom(browser, server, 'q');
    // setup'ta yenile
    await room.D.page.reload(); await room.R.page.reload();
    await room.D.page.waitForSelector('#screen-setup:not([hidden])', { timeout: 5000 });
    await room.R.page.waitForSelector('#screen-setup:not([hidden])', { timeout: 5000 });
    ok('setup: yönetici yenileyince setup + kartlar', (await room.D.page.locator('#frame-select button[data-frame]').count()) === 3);
    ok('setup: çalışan yenileyince setup', await room.R.page.locator('#screen-setup').isVisible());
    await L.pickFrame(room, 'frame-cargo');
    await L.placeUI(room.R, 'engine-kestrel', 'eng-c');
    await L.placeUI(room.R, 'tank-large', 'tank-1');
    await sleep(400);
    // building: parça seçiliyken yenile
    await room.R.page.click('button[data-pick="tank-small"]');
    await room.R.page.reload();
    await room.R.page.waitForSelector('#screen-game:not([hidden])', { timeout: 6000 });
    await room.R.page.waitForSelector('#scene3d[data-scene-ready="1"], #scene3d', { timeout: 4000 });
    await sleep(2500);
    ok('building yenile: oyun ekranı', true);
    ok('building yenile: parçalar korundu (2)', (await L.countParts(room.R)) === 2, await L.countParts(room.R));
    const ready = await room.R.page.evaluate(() => ({ r: document.querySelector('#scene3d') && document.querySelector('#scene3d').dataset.sceneReady, h: !!window.__ppScene, c: document.querySelectorAll('#scene3d canvas').length }));
    ok('building yenile: 3B yeniden kuruldu', ready.r === '1' && ready.h && ready.c >= 1, JSON.stringify(ready));
    const posAfter = await room.R.page.evaluate(() => window.__ppScene.slotScreenPos('eng-c'));
    ok('yenileme sonrası 3B yuvalar konumlanıyor', posAfter && Number.isFinite(posAfter.x), JSON.stringify(posAfter));
    const sel = await room.R.page.locator('button[data-pick][aria-pressed="true"]').count();
    console.log('yenileme sonrası seçili parça sayısı (beklenen 0, bilgi):', sel);
    // diğer sayfada R parçaları 3B tarafında görünür (state)
    ok('yenileme sonrası yönetici hâlâ iki parçayı görüyor', (await room.D.page.locator('#build-box li[data-slot-id]').count()) === 2);
    await L.shot(room.R, 'reconnect-building');
    // yönetici yenile (building)
    await room.D.page.reload();
    await room.D.page.waitForSelector('#screen-game:not([hidden])', { timeout: 6000 });
    await sleep(1500);
    ok('yönetici yenile: build-box dolu', (await room.D.page.locator('#build-box li[data-slot-id]').count()) === 2);
    // timer devam ediyor mu
    const tv = await room.D.page.locator('#timer-value').innerText();
    ok('yönetici yenile: sayaç devam (--:-- değil)', /^\d\d:\d\d$/.test(tv), tv);
    // result'ta yenile: başarısız hızlı sonuç için anket
    await L.goPoll(room); await L.allGo(room); await L.waitResult(room);
    await sleep(800);
    await room.R.page.reload();
    await room.R.page.waitForSelector('#screen-result:not([hidden])', { timeout: 6000 });
    const rp = await L.resultPanel(room.R);
    ok('result yenile: sonuç ekranı ve panel', rp.panel.length > 150, rp.title);
    await L.closeRoom(room);
  } finally { L.stopServer(server); }
});

scenario('wrongframe', async (L) => {
  const server = await L.startServer({ PP_EVENTS: 'none', PP_TELEMETRY_DELAY_MS: '0', PP_WINDOW_SEC: '600' });
  const browser = await L.getBrowser();
  try {
    const room = await L.roomWithMission(browser, server, 'z', 'mars-rover');
    await L.pickFrame(room, 'frame-swift');
    await room.X.page.click('button[data-pick="rover"]');
    await sleep(400);
    const txt = await room.X.page.locator('#slot-panel').innerText();
    const items = await room.X.page.evaluate(() => [...document.querySelectorAll('#slot-list li')].map((li) => li.innerText.replace(/\n/g, ' | ')));
    console.log('Mars+Kırlangıç, rover seçili. slot panel:', txt.replace(/\n/g, ' | '));
    console.log('slot-list girdileri:', JSON.stringify(items));
    await L.shot(room.X, 'wrongframe-worker');
    const enabled = await room.X.page.locator('#slot-list button[data-slot]:not([disabled])').count();
    ok('Mars+Kırlangıç: rover için etkin yuva yok', enabled === 0, enabled);
    ok('Mars+Kırlangıç: ekranda açıklayıcı bir mesaj var', /uygun|sığ|yer yok|yuva yok|sığmaz/i.test(txt), txt.replace(/\n/g, ' | ').slice(0, 300));
    // yönetici ne görüyor: gösterge payload kırmızı, görev kartı rover istiyor
    await L.shot(room.D, 'wrongframe-director');
    await L.closeRoom(room);
  } finally { L.stopServer(server); }
});

scenario('budget', async (L) => {
  const server = await L.startServer({ PP_EVENTS: 'none', PP_TELEMETRY_DELAY_MS: '0', PP_WINDOW_SEC: '600' });
  const browser = await L.getBrowser();
  try {
    const room = await L.roomWithMission(browser, server, 'b', 'lunar-relay');
    await L.pickFrame(room, 'frame-heavy'); // 220 maliyet, bütçe 800
    const bb0 = await room.D.page.locator('#budget-box').getAttribute('data-over');
    ok('bütçe başta data-over=false', bb0 === 'false', bb0);
    await L.placeUI(room.R, 'engine-titan', 'eng-c');
    await L.placeUI(room.R, 'engine-titan', 'eng-n');
    await L.placeUI(room.R, 'engine-titan', 'eng-s');
    await L.placeUI(room.R, 'tank-large', 'tank-1');
    await sleep(500);
    const bb = await room.D.page.locator('#budget-box').innerText();
    const over = await room.D.page.locator('#budget-box').getAttribute('data-over');
    console.log('bütçe:', bb.replace(/\n/g, ' | '), 'data-over=', over);
    ok('bütçe aşımında data-over=true', over === 'true', over);
    const gg = await L.gauges(room.D);
    console.log('aşımda göstergeler:', JSON.stringify(gg));
    await L.shot(room.D, 'budget-over');
    // çalışan harcamayı görmüyor
    const wt = await room.R.page.locator('#screen-game').innerText();
    ok('çalışan ekranında bütçe/fiyat sözcüğü yok', !/bütçe|maliyet/i.test(wt), (wt.match(/.{0,20}(bütçe|maliyet).{0,20}/i) || [''])[0]);
    // log ± fiyat; çıkarınca -
    await room.R.page.locator('#my-parts li', { hasText: 'Titan' }).first().locator('[data-remove]').click();
    await sleep(500);
    const log = await room.D.page.locator('#log-box').innerText();
    ok('çıkarma logu − fiyat', /[−-]\s?230/.test(log), log.slice(0, 160).replace(/\n/g, ' | '));
    await L.closeRoom(room);
  } finally { L.stopServer(server); }
});

scenario('no3d-webgl', async (L) => {
  global.__browserOpts = { args: ['--disable-gpu', '--disable-webgl', '--disable-3d-apis'] };
  try { await L.runWin(L, 'nowebgl', 'lunar-relay', 0, null, 'no3d-webgl'); } finally { global.__browserOpts = undefined; }
});
scenario('no3d-abort', async (L) => {
  global.__abort = /scene3d\.js|\/vendor\/three\//;
  try { await L.runWin(L, 'noabort', 'lunar-relay', 1, null, 'no3d-abort'); } finally { global.__abort = undefined; }
});

scenario('no3d-view', async (L) => {
  global.__browserOpts = { args: ['--disable-gpu', '--disable-webgl', '--disable-3d-apis'] };
  const server = await L.startServer({ PP_EVENTS: 'none', PP_TELEMETRY_DELAY_MS: '0', PP_WINDOW_SEC: '600' });
  try {
    const browser = await L.getBrowser();
    const room = await L.setupRoom(browser, server, 'v');
    await L.pickFrame(room, 'frame-cargo');
    await room.R.page.click('button[data-pick="engine-kestrel"]');
    await sleep(400);
    const info = await room.R.page.locator('#scene-panel').innerText();
    console.log('3B yok: scene-panel metni:', info.replace(/\n/g, ' | '));
    ok('3B yok: "desteklenmiyor" notu', /desteklen|3B|WebGL/i.test(info));
    await L.shot(room.R, 'no3d-worker');
    await L.shot(room.D, 'no3d-director');
    await L.closeRoom(room);
  } finally { L.stopServer(server); global.__browserOpts = undefined; }
});
