// stage5 senaryoları (5): görsel/kullanılabilirlik turu (ekran görüntüsü + ölçümler).
const L0 = global.__S5;
const { ok, sleep, scenario, SOLUTIONS } = L0;

async function measure(p, tag, L) {
  const m = await p.page.evaluate(() => {
    const vis = (e) => { const r = e.getBoundingClientRect(); const cs = getComputedStyle(e); return r.width > 0 && r.height > 0 && cs.visibility !== 'hidden' && cs.display !== 'none'; };
    const out = { overflowX: document.documentElement.scrollWidth - window.innerWidth, smallBtns: [], tiny: [], sticky: [], canvas: null, dim: [window.innerWidth, window.innerHeight] };
    for (const b of document.querySelectorAll('button, [role="tab"], input[type="checkbox"]')) {
      if (!vis(b)) continue;
      const r = b.getBoundingClientRect();
      if (r.bottom < 0 || r.top > window.innerHeight * 3) continue;
      if (r.height < 40 || r.width < 40) out.smallBtns.push((b.innerText || b.getAttribute('aria-label') || b.id || b.tagName).trim().slice(0, 24) + ` ${Math.round(r.width)}x${Math.round(r.height)}`);
    }
    const seen = new Set();
    for (const e of document.querySelectorAll('body *')) {
      if (!vis(e)) continue;
      let own = ''; for (const n of e.childNodes) if (n.nodeType === 3) own += n.textContent;
      own = own.trim(); if (!own) continue;
      const fs = parseFloat(getComputedStyle(e).fontSize);
      if (fs < 11) { const k = own.slice(0, 20) + fs; if (!seen.has(k)) { seen.add(k); out.tiny.push(`${fs}px "${own.slice(0, 22)}"`); } }
    }
    let stickyH = 0;
    for (const e of document.querySelectorAll('body *')) {
      const cs = getComputedStyle(e);
      if ((cs.position === 'sticky' || cs.position === 'fixed') && vis(e)) { const r = e.getBoundingClientRect(); if (r.top <= 2 && r.height > 20) { out.sticky.push((e.id || e.className || e.tagName).toString().slice(0, 20) + ' h=' + Math.round(r.height)); stickyH += r.height; } }
    }
    out.stickyTotal = Math.round(stickyH);
    const cv = document.querySelector('#scene3d canvas, #result-scene-host canvas');
    if (cv && vis(cv)) { const r = cv.getBoundingClientRect(); out.canvas = Math.round(r.width) + 'x' + Math.round(r.height); }
    return out;
  });
  console.log(`  [${tag}] overflowX=${m.overflowX} küçükDüğme(${m.smallBtns.length})=${m.smallBtns.slice(0, 8).join(' | ')} tinyText(${m.tiny.length})=${m.tiny.slice(0, 5).join(' | ')} sticky=${m.sticky.join(',')}(${m.stickyTotal}/${m.dim[1]}) canvas=${m.canvas}`);
  return m;
}

async function visualRun(L, vp, tag) {
  const server = await L.startServer({ PP_EVENTS: 'none', PP_TELEMETRY_DELAY_MS: '0', PP_WINDOW_SEC: '600' });
  const browser = await L.getBrowser();
  const results = {};
  try {
    // giriş ekranı
    const e = await L.mkPlayer(browser, server, 'e' + tag, vp);
    await L.shot(e, `vis-${tag}-entry`);
    results.entry = await measure(e, tag + ' giriş', L);
    await e.ctx.close();
    const room = await L.roomWithMission(browser, server, 'v' + tag, 'mars-rover', {
      viewport: vp,
      beforeRoles: async (r) => {
        await sleep(400);
        await L.shot(r.D, `vis-${tag}-lobby-director`);
        await L.shot(r.R, `vis-${tag}-lobby-worker`);
        results.lobby = await measure(r.R, tag + ' lobi', L);
      },
    });
    await sleep(400);
    await L.shot(room.D, `vis-${tag}-setup-director`);
    await L.shot(room.R, `vis-${tag}-setup-worker`);
    results.setupD = await measure(room.D, tag + ' setup yönetici', L);
    results.setupW = await measure(room.R, tag + ' setup çalışan', L);
    const sol = SOLUTIONS['mars-rover'][0];
    await L.pickFrame(room, sol.frameId);
    await sleep(1200);
    await L.shot(room.D, `vis-${tag}-director-empty`);
    await L.shot(room.X, `vis-${tag}-worker-empty`);
    // yarım çözüm + parça seçili
    const half = { placements: sol.placements.filter((p) => ['rocket'].includes(p.role)).slice(0, 4) };
    await L.placeSolution(room, half);
    await L.placeSolution(room, { placements: sol.placements.filter((p) => p.role === 'spacecraft') });
    await L.placeSolution(room, { placements: sol.placements.filter((p) => p.role === 'payload').slice(0, 1) });
    await sleep(500);
    await room.X.page.click('button[data-pick="camera"]');
    await sleep(700);
    await L.shot(room.X, `vis-${tag}-worker-picked`);
    results.workerPicked = await measure(room.X, tag + ' çalışan parça seçili', L);
    // yuva listesi alanına kaydır/sekme
    const slotsVisible = await room.X.page.evaluate(() => { const e = document.querySelector('#slot-list'); if (!e) return null; const r = e.getBoundingClientRect(); return { top: Math.round(r.top), h: Math.round(r.height), vh: window.innerHeight }; });
    console.log(`  [${tag}] #slot-list konumu`, JSON.stringify(slotsVisible));
    await room.X.page.evaluate(() => document.querySelector('#slot-list') && document.querySelector('#slot-list').scrollIntoView({ block: 'center' }));
    await sleep(400);
    await L.shot(room.X, `vis-${tag}-worker-slotlist`);
    // 3B vurguları: yuva pozisyonları görünür mü (ekran içinde)
    const hl = await room.X.page.evaluate(() => {
      const out = [];
      document.querySelectorAll('#slot-list button[data-slot]:not([disabled])').forEach((b) => { const id = b.getAttribute('data-slot'); const p = window.__ppScene && window.__ppScene.slotScreenPos(id); out.push({ id, p: p && { x: Math.round(p.x), y: Math.round(p.y) } }); });
      return { out, vw: window.innerWidth, vh: window.innerHeight };
    });
    const inView = hl.out.filter((o) => o.p && o.p.x >= 0 && o.p.y >= 0 && o.p.x <= hl.vw && o.p.y <= hl.vh).length;
    console.log(`  [${tag}] etkin yuva ${hl.out.length}, ekranda görünen işaretçi ${inView}`);
    await room.X.page.click('#unpick-btn').catch(() => {});
    await L.shot(room.D, `vis-${tag}-director-building`);
    results.dirB = await measure(room.D, tag + ' yönetici building', L);
    // tamamla
    const rest = { placements: [...sol.placements.filter((p) => p.role === 'rocket').slice(4), ...sol.placements.filter((p) => p.role === 'payload').slice(1)] };
    await L.placeSolution(room, rest);
    await sleep(600);
    await L.shot(room.D, `vis-${tag}-director-ready`);
    await L.goPoll(room);
    await sleep(400);
    await L.shot(room.D, `vis-${tag}-poll-director`);
    await L.shot(room.S, `vis-${tag}-poll-worker`);
    results.pollW = await measure(room.S, tag + ' anket çalışan', L);
    results.pollD = await measure(room.D, tag + ' anket yönetici', L);
    await L.allGo(room);
    await L.waitResult(room);
    await sleep(1500);
    await L.shot(room.R, `vis-${tag}-launch`);
    results.launch = await measure(room.R, tag + ' fırlatma', L);
    await room.R.page.locator('#skip-launch-btn').click({ timeout: 800 }).catch(() => {});
    await room.R.page.waitForSelector('#result-panel', { state: 'visible', timeout: 15000 });
    await sleep(500);
    await L.shot(room.R, `vis-${tag}-result-worker`);
    await L.shot(room.D, `vis-${tag}-result-director`);
    results.res = await measure(room.R, tag + ' sonuç', L);
    await L.closeRoom(room);
  } finally { L.stopServer(server); }
  for (const [k, m] of Object.entries(results)) if (m && m.overflowX > 2) L.issues.push(`[görsel ${tag}] yatay taşma ${m.overflowX}px: ${k}`);
  ok(`[${tag}] hiçbir ekranda yatay taşma yok`, Object.values(results).every((m) => !m || m.overflowX <= 2), Object.entries(results).filter(([, m]) => m && m.overflowX > 2).map(([k, m]) => k + ':' + m.overflowX).join(','));
}

scenario('visual-1440', async (L) => { await visualRun(L, { width: 1440, height: 900 }, '1440'); });
scenario('visual-1366', async (L) => { await visualRun(L, { width: 1366, height: 768 }, '1366'); });
scenario('visual-390', async (L) => { await visualRun(L, { width: 390, height: 844 }, '390'); });
scenario('visual-360', async (L) => { await visualRun(L, { width: 360, height: 740 }, '360'); });
