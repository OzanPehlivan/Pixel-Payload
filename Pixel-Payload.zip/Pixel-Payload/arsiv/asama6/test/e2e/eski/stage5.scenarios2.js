// stage5 senaryoları (2): başarısızlıklar, pencere, olaylar, geri alma. global.__S5 altyapısı.
const L0 = global.__S5;
const { ok, sleep, scenario, SOLUTIONS, R, S, Y } = L0;

async function waitResult(room, ms = 9000) {
  for (const p of [room.D, room.R, room.S, room.X]) await p.page.waitForSelector('#screen-result:not([hidden])', { timeout: ms });
}
async function resultPanel(p) {
  await p.page.locator('#skip-launch-btn').click({ timeout: 800 }).catch(() => {});
  await p.page.waitForSelector('#result-panel', { state: 'visible', timeout: 15000 });
  await sleep(300);
  return { title: await p.page.locator('#result-title').innerText(), reason: await p.page.locator('#result-reason').innerText(), panel: await p.page.locator('#result-panel').innerText() };
}
async function goPoll(room) {
  await room.D.page.click('#poll-start-btn');
  for (const w of [room.R, room.S, room.X]) await w.page.waitForSelector('#vote-go-btn', { state: 'visible', timeout: 4000 });
}
async function allGo(room) { for (const w of [room.R, room.S, room.X]) { await w.page.click('#vote-go-btn'); await sleep(150); } }
Object.assign(L0, { waitResult, resultPanel, goPoll, allGo });

scenario('fail', async (L) => {
  const server = await L.startServer({ PP_EVENTS: 'none', PP_TELEMETRY_DELAY_MS: '0', PP_WINDOW_SEC: '600' });
  const browser = await L.getBrowser();
  try {
    let room = await L.setupRoom(browser, server, 'n');
    await L.pickFrame(room, 'frame-cargo');
    const heavy = { placements: [R('engine-kestrel', 'eng-c'), R('tank-large', 'tank-1'), R('tank-large', 'tank-2'), R('tank-large', 'tank-3'), R('fuel-hydrolox', 'fuel')] };
    ok('no-liftoff build kuruldu', (await L.placeSolution(room, heavy)).length === 0);
    await sleep(500);
    console.log('gauges', JSON.stringify(await L.gauges(room.D)));
    const warn = await room.D.page.locator('#poll-warning').innerText().catch(() => '');
    console.log('poll-warning:', warn.replace(/\n/g, ' '));
    await goPoll(room);
    await L.shot(room.D, 'fail-poll-notready');
    await allGo(room);
    await waitResult(room);
    let rp = await resultPanel(room.R);
    ok('no-liftoff sonucu (başarısız, kalkamadı)', /kalk/i.test(rp.reason + rp.title) && !/başarılı!/.test(rp.title), rp.title + ' // ' + rp.reason);
    await L.shot(room.R, 'fail-no-liftoff-result');
    await room.D.page.click('#restart-btn');
    for (const p of [room.D, room.R, room.S, room.X]) await p.page.waitForSelector('#screen-setup:not([hidden])', { timeout: 5000 });
    ok('restart -> 4 sayfada setup', true);
    const cards = await room.D.page.locator('#frame-select button[data-frame]').count();
    ok('yeni turda gövde yeniden seçilebilir (3 kart)', cards === 3, cards);
    await L.pickFrame(room, 'frame-swift');
    const bb = await room.D.page.locator('#budget-box').innerText();
    ok('yeni tur: bütçe gövde maliyetiyle başlar, parça yok', bb.includes('60') && (await L.countParts(room.R)) === 0, bb.replace(/\n/g, ' | '));
    await L.closeRoom(room);

    room = await L.roomWithMission(browser, server, 'm', 'lunar-relay');
    const sol = SOLUTIONS['lunar-relay'][0];
    await L.pickFrame(room, sol.frameId);
    await L.placeSolution(room, { placements: sol.placements.filter((p) => p.partId !== 'relay-antenna') });
    await sleep(500);
    const gg = await L.gauges(room.D);
    ok('anten yok: payload göstergesi kırmızı', gg.find((g) => g.c === 'payload').ok === 'false', JSON.stringify(gg));
    await goPoll(room); await allGo(room); await waitResult(room);
    rp = await resultPanel(room.R);
    ok('mission-failed sonucu', !/başarılı!/.test(rp.title), rp.title + ' // ' + rp.reason);
    console.log('mission-failed metni:', rp.title, '|', rp.reason);
    await L.shot(room.R, 'fail-mission-failed');
    await L.closeRoom(room);

    room = await L.roomWithMission(browser, server, 'g', 'lunar-relay');
    await L.pickFrame(room, sol.frameId);
    await L.placeSolution(room, sol);
    await goPoll(room);
    await room.R.page.click('#vote-go-btn'); await sleep(150);
    await room.S.page.click('#vote-nogo-btn'); await sleep(800);
    console.log('NO-GO sonrası faz:', (await L.st(room.D)).phase);
    ok('NO-GO: sonuç ekranı açılmadı', !(await room.D.page.locator('#screen-result').isVisible()));
    await L.shot(room.D, 'fail-nogo-director');
    await L.shot(room.S, 'fail-nogo-worker');
    console.log('NO-GO sonrası pollStart görünür:', await room.D.page.locator('#poll-start-btn').isVisible().catch(() => false));
    await L.closeRoom(room);
  } finally { L.stopServer(server); if (server.stderr) console.log('stderr:', server.stderr.slice(0, 300)); }
});

scenario('window', async (L) => {
  const server = await L.startServer({ PP_EVENTS: 'none', PP_TELEMETRY_DELAY_MS: '0', PP_WINDOW_SEC: '9', PP_SECOND_WINDOW_SEC: '6' });
  const browser = await L.getBrowser();
  try {
    const room = await L.setupRoom(browser, server, 'w');
    await L.pickFrame(room, 'frame-swift');
    await sleep(1000);
    const t1 = await room.D.page.locator('#timer-value').innerText();
    for (const p of [room.D, room.R, room.S, room.X]) await p.page.waitForSelector('#screen-result:not([hidden])', { timeout: 30000 });
    const rp = await resultPanel(room.R);
    console.log('window result:', rp.title, '|', rp.reason, '| timer@1s=', t1);
    ok('pencere kaçırma: iki pencere sonrası sonuç, başarısız', !/başarılı!/.test(rp.title), rp.title + ' // ' + rp.reason);
    ok('pencere kaçırma gerekçesi anlaşılır', /pencere|süre/i.test(rp.reason + rp.title), rp.reason);
    await L.shot(room.D, 'window-missed');
    await L.closeRoom(room);
  } finally { L.stopServer(server); }
});

scenario('events', async (L) => {
  const browser = await L.getBrowser();
  let server = await L.startServer({ PP_EVENTS: 'weather@4', PP_TELEMETRY_DELAY_MS: '0', PP_WINDOW_SEC: '600', PP_HOLD_SEC: '8' });
  try {
    const room = await L.roomWithMission(browser, server, 'e', 'lunar-relay');
    const sol = SOLUTIONS['lunar-relay'][0];
    await L.pickFrame(room, sol.frameId);
    await L.placeSolution(room, sol);
    await sleep(2500);
    ok('weather: #hold-banner yönetici', await room.D.page.locator('#hold-banner').isVisible().catch(() => false));
    ok('weather: çalışanda da bekleme afişi', await room.R.page.locator('#hold-banner').isVisible().catch(() => false));
    await L.shot(room.D, 'event-weather-director');
    ok('weather: #events-box girdisi', (await room.D.page.locator('#events-box [data-event-type]').count()) >= 1);
    await L.closeRoom(room);
  } finally { L.stopServer(server); }
  server = await L.startServer({ PP_EVENTS: 'computer-fault@4', PP_TELEMETRY_DELAY_MS: '0', PP_WINDOW_SEC: '600' });
  try {
    const room = await L.roomWithMission(browser, server, 'c', 'lunar-relay');
    const sol = SOLUTIONS['lunar-relay'][0];
    await L.pickFrame(room, sol.frameId);
    await L.placeSolution(room, sol);
    await sleep(5500);
    let gg = await L.gauges(room.D);
    console.log('arıza sonrası göstergeler', JSON.stringify(gg));
    ok('computer-fault: 6. gösterge var ve kırmızı', gg.length === 6 && gg.some((g) => g.ok === 'false'), JSON.stringify(gg));
    await L.shot(room.D, 'event-computer-fault');
    ok('yedek bilgisayar bir yuvaya takıldı (pl-1)', await L.placeUI(room.S, 'computer-backup', 'pl-1'));
    await sleep(600);
    gg = await L.gauges(room.D);
    ok('yedek bilgisayarla 6 gösterge de yeşil', gg.length === 6 && gg.every((g) => g.ok === 'true'), JSON.stringify(gg));
    await goPoll(room); await allGo(room); await waitResult(room);
    const rp = await resultPanel(room.R);
    ok('computer-fault + yedek: başarılı', /başarılı!/.test(rp.title), rp.title + ' // ' + rp.reason);
    await L.closeRoom(room);
  } finally { L.stopServer(server); }
  server = await L.startServer({ PP_EVENTS: 'supplier-delay@4', PP_TELEMETRY_DELAY_MS: '0', PP_WINDOW_SEC: '600', PP_LOCK_SEC: '10' });
  try {
    const room = await L.setupRoom(browser, server, 's');
    await L.pickFrame(room, 'frame-cargo');
    await sleep(5000);
    const info = {};
    for (const [k, p] of [['R', room.R], ['S', room.S], ['X', room.X]]) {
      info[k] = await p.page.evaluate(() => [...document.querySelectorAll('#catalog li[data-locked="true"]')].map((li) => {
        const b = li.querySelector('button[data-pick]');
        return { t: li.innerText.replace(/\n/g, ' | '), dis: !!(b && b.disabled), id: b ? b.getAttribute('data-pick') : null };
      }));
    }
    console.log('kilitli parçalar:', JSON.stringify(info));
    const who = Object.keys(info).find((k) => info[k].length);
    ok('supplier-delay: bir çalışanda kilitli parça var', !!who);
    if (who) {
      const p = { R: room.R, S: room.S, X: room.X }[who];
      const ent = info[who][0];
      await L.shot(p, 'event-supplier-locked');
      if (ent.id) await p.page.evaluate((id) => { const b = document.querySelector(`button[data-pick="${id}"]`); if (b && !b.disabled) b.click(); }, ent.id);
      await sleep(300);
      const pr = await p.page.locator('button[data-pick][aria-pressed="true"]').count();
      ok('kilitli parça seçilemiyor', ent.dis || pr === 0, JSON.stringify(ent) + ' pr=' + pr);
      const slotFor = { R: 'eng-w', S: 'p-n1', X: 'p-n1' }[who];
      const f = await L.rawEmit(room, who, 'part:add', { partId: ent.id, slotId: slotFor });
      ok('kilitli parça socket ile reddedilir', f.res && f.res.ok === false, JSON.stringify(f.res));
      console.log('kilit ack:', JSON.stringify(f.res));
    }
    await L.closeRoom(room);
  } finally { L.stopServer(server); }
});

scenario('undo', async (L) => {
  const server = await L.startServer({ PP_EVENTS: 'none', PP_TELEMETRY_DELAY_MS: '0', PP_WINDOW_SEC: '600' });
  const browser = await L.getBrowser();
  try {
    const room = await L.setupRoom(browser, server, 'u');
    await L.pickFrame(room, 'frame-cargo');
    await L.placeUI(room.R, 'tank-small', 'tank-3');
    await L.placeUI(room.R, 'engine-kestrel', 'eng-c');
    await sleep(500);
    console.log('undo-box:', (await room.D.page.locator('#undo-box').innerText()).replace(/\n/g, ' | '));
    await room.R.page.locator('#my-parts li', { hasText: 'Ek tank' }).locator('[data-remove]').click();
    await sleep(500);
    await room.D.page.locator('button[data-undo="rocket"]').click();
    await sleep(700);
    const my = await room.R.page.locator('#my-parts').innerText();
    ok('geri alma: çıkarılan parça AYNI yuvaya geri geldi', /Ek tank/.test(my), my.replace(/\n/g, ' | '));
    console.log('undo-left:', (await room.D.page.locator('#undo-left').innerText()).replace(/\n/g, ' | '));
    await room.R.page.locator('#my-parts li', { hasText: 'Ek tank' }).locator('[data-remove]').click();
    await sleep(500);
    await L.placeUI(room.S, 'battery', 'tank-3');
    await sleep(500);
    const before = await room.D.page.locator('#undo-box').innerText();
    await room.D.page.locator('button[data-undo="rocket"]').click();
    await sleep(700);
    const err = await room.D.page.locator('#error-msg').innerText().catch(() => '');
    const after = await room.D.page.locator('#undo-box').innerText();
    console.log('undo çakışma hata metni:', err, '| önce/sonra:', before.replace(/\n/g, ' '), '/', after.replace(/\n/g, ' '));
    ok('yuva dolu iken undo: hata gösterilir (yuva dolu)', /dolu/i.test(err), err);
    ok('yuva dolu iken undo: hak düşmedi', before === after, before.replace(/\n/g, ' ') + ' -> ' + after.replace(/\n/g, ' '));
    ok('yuva dolu iken undo: parça geri gelmedi', !/Ek tank/.test(await room.R.page.locator('#my-parts').innerText()));
    await L.shot(room.D, 'undo-slot-taken');
    await L.closeRoom(room);
  } finally { L.stopServer(server); }
});
