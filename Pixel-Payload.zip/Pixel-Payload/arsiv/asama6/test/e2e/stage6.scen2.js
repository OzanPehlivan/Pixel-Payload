// Aşama 6: ek senaryolar (kurallar, olaylar, pencere). stage6.e2e.js tarafından yüklenir.
module.exports = function ({ L, scenario, ok, sleep, digitsIn, noClock, privacyCheck }) {
  // ============ C: uyumsuzluk kuralları + dolu yuva + geri alma (Kargo) ============
  scenario('rules', async () => {
    const server = await L.startServer({ PP_EVENTS: 'none', PP_WINDOW_SEC: '300' });
    try {
      const room = await L.setupRoom(server, 'u');
      const { D, R: Rk, S: Sp, X } = room;
      await L.pickFrame(room, 'frame-cargo');
      const rows = (p) => p.page.evaluate(() => [...document.querySelectorAll('#slot-list li')].map((li) => ({ ok: li.dataset.ok, slot: li.querySelector('button[data-slot]') && li.querySelector('button[data-slot]').dataset.slot, t: li.innerText.replace(/\n/g, ' | ') })));
      const sstates = (p) => p.page.evaluate(() => Object.fromEntries([...document.querySelectorAll('g.pp2d-slot')].map((g) => [g.dataset.slot, g.dataset.state])));
      const reasons = {};
      const probe = async (label, w, pickId, expectBlocked) => {
        await w.page.click(`button[data-pick="${pickId}"]`); await sleep(250);
        const rr = await rows(w); const ss = await sstates(w);
        const blocked = rr.filter((r) => r.ok === 'false' && expectBlocked.includes(r.slot));
        const reason = blocked.map((r) => r.t.split('ENGELLİ')[1].replace(/\|/g, '').trim());
        console.log(`  ${label}: engelli(${expectBlocked.join(',')}) =>`, JSON.stringify(reason), 'sahne:', expectBlocked.map((s) => s + '=' + ss[s]).join(' '));
        reasons[label] = reason;
        ok(`kural ${label}: ilgili yuvalar listede engelli + gerekçe`, blocked.length === expectBlocked.length && reason.every((x) => x.length > 8 && !/dolu/i.test(x)), JSON.stringify(reason));
        ok(`kural ${label}: sahnede ilgili yuvalar blocked (kırmızı)`, expectBlocked.every((s) => ss[s] === 'blocked'), JSON.stringify(expectBlocked.map((s) => ss[s])));
        ok(`kural ${label}: gerekçede sayı yok`, !reason.some((x) => /\d/.test(x)));
        await L.shot(w, `rule-${label}`);
        await w.page.click('#unpick-btn').catch(() => {});
        return reason;
      };
      ok('solar-small p-n1 yerleştirildi', await L.placeList(Sp, 'solar-small', 'p-n1'));
      await probe('kalkan-gunes', Sp, 'shield-light', ['p-n2', 'p-e', 'p-w']);
      ok('shield-light p-s2 yerleştirildi', await L.placeList(Sp, 'shield-light', 'p-s2'));
      await probe('gunes-kalkan-ters-yon', Sp, 'solar-small', ['p-s1']);
      ok('drill nose-1 yerleştirildi', await L.placeList(X, 'drill', 'nose-1'));
      await probe('matkap-optik', X, 'camera', ['pl-3']);
      const distinct = new Set(Object.values(reasons).flat());
      ok('en az 2 farklı uyumsuzluk gerekçesi', distinct.size >= 2, [...distinct].join(' // '));
      ok('motor eng-c', await L.placeList(Rk, 'engine-kestrel', 'eng-c'));
      await Rk.page.click('button[data-pick="engine-kestrel"]'); await sleep(250);
      const rr = await rows(Rk); const full = rr.find((r) => r.slot === 'eng-c');
      ok('dolu yuva engelli + "dolu" gerekçesi', full && full.ok === 'false' && /dolu/i.test(full.t), full && full.t);
      await Rk.page.click('#unpick-btn').catch(() => {});
      ok('rocket tank-large tank-3', await L.placeList(Rk, 'tank-large', 'tank-3'));
      await sleep(400);
      await Sp.page.click('button[data-pick="battery"]'); await sleep(300);
      const sr = await rows(Sp); const t3 = sr.find((r) => r.slot === 'tank-3');
      const ss3 = await sstates(Sp);
      ok('başka oyuncunun dolu yuvası: engelli + dolu, sahnede blocked', t3 && t3.ok === 'false' && /dolu/i.test(t3.t) && ss3['tank-3'] === 'blocked', (t3 && t3.t) + ' / ' + ss3['tank-3']);
      const iconN = await Sp.page.evaluate(() => { const g = document.querySelector('g.pp2d-slot[data-slot="tank-3"]'); return { kids: g.children.length, art: g.querySelectorAll('g,path,rect,circle,ellipse,polygon').length, opacity: g.getAttribute('opacity') }; });
      console.log('  blocked dolu yuva (başkası) çizim:', JSON.stringify(iconN));
      ok('blocked dolu yuvada parça simgesi çizili', iconN.art >= 4, JSON.stringify(iconN));
      await L.shot(Sp, 'rule-occupied-other');
      const tp = await L.slotPos(Sp, 'tank-3'); await Sp.page.mouse.move(tp.x, tp.y); await sleep(250);
      const lbl = await Sp.page.evaluate(() => { const l = document.querySelector('.slot-label'); return l && !l.hidden ? l.innerText.replace(/\n/g, ' / ') : null; });
      ok('etiket başkasının parçasını gösterir ("(boş)" değil)', lbl && !/\(boş\)/.test(lbl), lbl);
      await Sp.page.click('#unpick-btn').catch(() => {});
      const left0 = await D.page.locator('#undo-left').innerText();
      const undoBtns = await D.page.evaluate(() => [...document.querySelectorAll('#undo-box button')].map((b) => ({ t: b.innerText.trim(), dis: b.disabled })));
      console.log('  undo düğmeleri:', JSON.stringify(undoBtns), 'hak:', left0);
      const nBefore = await L.countParts(Rk);
      await D.page.locator('#undo-box button', { hasText: /Roket/ }).first().click(); await sleep(700);
      const nAfter = await L.countParts(Rk);
      ok('geri al: roket çalışanının son parçası kalktı', nAfter === nBefore - 1, `${nBefore}->${nAfter}`);
      const left1 = await D.page.locator('#undo-left').innerText();
      ok('geri al hakkı azaldı', left1 !== left0, `${left0} -> ${left1}`);
      const rt = noClock(await Rk.page.locator('#screen-game').innerText());
      ok('geri alma sonrası çalışan ekranında sayı yok', !digitsIn(rt), (rt.match(/.{0,20}\d.{0,20}/g) || []).join(' || '));
      await L.closeRoom(room);
    } finally { L.stopServer(server); }
  });

  // ============ D: olaylar ============
  scenario('events', async () => {
    const server = await L.startServer({ PP_EVENTS: 'weather@5,computer-fault@14,supplier-delay@24', PP_WINDOW_SEC: '300', PP_HOLD_SEC: '8', PP_LOCK_SEC: '15' });
    try {
      const room = await L.roomWithMission(server, 'v', 'lunar-relay');
      const { D, R: Rk, S: Sp, X } = room;
      await L.pickFrame(room, 'frame-swift');
      const vis = (id) => { const e = document.querySelector(id); return e && !e.hidden && getComputedStyle(e).display !== 'none' && e.offsetParent !== null ? e.innerText.replace(/\n/g, ' | ') : null; };
      const seen = { hold: null, evbox: new Set(), fault: null, locked: null, rocketHold: null };
      const t0 = Date.now();
      while (Date.now() - t0 < 38000) {
        const s = await D.page.evaluate(() => {
          const v = (id) => { const e = document.querySelector(id); return e && !e.hidden && getComputedStyle(e).display !== 'none' && e.offsetParent !== null ? e.innerText.replace(/\n/g, ' | ') : null; };
          return { hold: v('#hold-banner'), ev: v('#events-box'), gc: v('#g-computer') };
        });
        if (s.hold && !seen.hold) {
          seen.hold = s.hold; await L.shot(D, 'event-hold-director'); await L.shot(Rk, 'event-hold-worker');
          seen.rocketHold = await Rk.page.evaluate(() => { const e = document.querySelector('#hold-banner'); return e && !e.hidden && getComputedStyle(e).display !== 'none' && e.offsetParent !== null ? e.innerText.replace(/\n/g, ' | ') : null; });
        }
        if (s.ev) seen.evbox.add(s.ev);
        if (s.gc && !seen.fault) { seen.fault = s.gc; await L.shot(D, 'event-fault-director'); }
        const lockedR = await Rk.page.evaluate(() => [...document.querySelectorAll('button[data-pick]')].filter((b) => b.disabled || b.dataset.avail === 'locked').map((b) => b.dataset.pick + ':' + b.dataset.avail + ':' + b.innerText.replace(/\n/g, ' ').slice(0, 60)));
        if (lockedR.length && !seen.locked) { seen.locked = lockedR; await L.shot(Rk, 'event-locked-worker'); }
        await sleep(500);
      }
      console.log('  hold:', seen.hold, '| çalışan hold:', seen.rocketHold);
      console.log('  events-box:', JSON.stringify([...seen.evbox]));
      console.log('  g-computer:', JSON.stringify(seen.fault), '| kilitli:', JSON.stringify(seen.locked));
      ok('hava beklemesi: yönetici banner görünür', !!seen.hold, seen.hold);
      ok('hava beklemesi: çalışanda da banner/bildirim', !!seen.rocketHold, seen.rocketHold);
      ok('olay şeridi (#events-box) olay sırasında görünür', seen.evbox.size > 0);
      ok('bilgisayar arızası: #g-computer görünür', !!seen.fault, seen.fault);
      ok('tedarikçi kilidi: bir parça kilitli (çalışan)', !!seen.locked, JSON.stringify(seen.locked));
      for (const w of [Rk, Sp, X]) { const t = noClock(await w.page.locator('#screen-game').innerText()); ok(`olay sonrası çalışan ekranı sayısız (${w.name})`, !digitsIn(t), (t.match(/.{0,25}\d.{0,25}/g) || []).slice(0, 3).join(' || ')); }
      const sol = L.FAULT_SOLUTIONS['lunar-relay'];
      await sleep(8000); // kilit/bekleme bitsin
      const fl = await L.placeSolution(room, sol, 0);
      console.log('  arıza çözümü eksikleri:', fl.join(','));
      await sleep(2500);
      const g = await L.gauges(D);
      console.log('  göstergeler:', JSON.stringify(g));
      ok('yedek bilgisayarla tüm göstergeler yeşil (computer dahil)', g.length >= 6 && g.every((x) => x.ok === 'true'), JSON.stringify(g));
      await L.shot(D, 'event-fault-solved');
      privacyCheck([Rk, Sp, X], [], 'olaylı');
      await L.closeRoom(room);
    } finally { L.stopServer(server); }
  });

  // ============ E: pencere kaçırma ============
  scenario('window', async () => {
    const server = await L.startServer({ PP_EVENTS: 'none', PP_WINDOW_SEC: '14', PP_SECOND_WINDOW_SEC: '10' });
    try {
      const room = await L.setupRoom(server, 'w');
      await L.pickFrame(room, 'frame-cargo');
      const { D, R: Rk } = room;
      const tState = await D.page.evaluate(() => { const t = document.querySelector('#timer'); return { cls: t.className, d: JSON.stringify({ ...t.dataset }), html: document.documentElement.dataset.phase }; });
      console.log('  sayaç (son 30 sn):', JSON.stringify(tState));
      await L.shot(D, 'window-urgent-director');
      await sleep(15000);
      await L.shot(D, 'window-after-1'); await L.shot(Rk, 'window-after-1-worker');
      console.log('  pencere 1 sonrası (çalışan):', (await Rk.page.evaluate(() => document.body.innerText.replace(/\n/g, ' | ').slice(0, 350))));
      await Rk.page.waitForSelector('#screen-result:not([hidden])', { timeout: 40000 }).catch(() => {});
      await Rk.page.waitForSelector('#result-panel', { state: 'visible', timeout: 15000 }).catch(() => {});
      const txt = await Rk.page.locator('#screen-result').innerText().catch(() => '');
      console.log('  sonuç metni:', txt.replace(/\n/g, ' | ').slice(0, 300));
      ok('pencere kaçırma: sonuç ekranı gelir ve neden belirtir', /pencere|kaçır|süre/i.test(txt), txt.slice(0, 200));
      await L.shot(Rk, 'window-result-worker'); await L.shot(D, 'window-result-director');
      await L.closeRoom(room);
    } finally { L.stopServer(server); }
  });
};
