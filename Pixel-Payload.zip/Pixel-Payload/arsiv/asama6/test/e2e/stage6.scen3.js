// Aşama 6: telefon, sahnesiz, demo, yeniden bağlanma/yardım/çekmece senaryoları.
module.exports = function ({ L, scenario, ok, sleep, digitsIn, noClock, privacyCheck }) {
  const small = (p) => p.page.evaluate(() => {
    const out = [];
    for (const b of document.querySelectorAll('button, a[href], input, select, [role=button]')) {
      if (!b.offsetParent && getComputedStyle(b).position !== 'fixed') continue;
      const r = b.getBoundingClientRect(); if (r.width < 2 || r.height < 2) continue;
      if (r.bottom < 0 || r.top > innerHeight * 3) continue;
      if (r.height < 40 || r.width < 40) out.push((b.id || b.dataset.pick || b.dataset.slot || b.dataset.remove || b.className || b.tagName) + ':' + Math.round(r.width) + 'x' + Math.round(r.height) + ':' + (b.innerText || '').trim().slice(0, 14));
    }
    return out;
  });
  const ovf = async (p, label) => {
    const o = await L.overflow(p);
    ok(`yatay taşma yok: ${label}`, o.sw <= o.cw + 1 && o.bw <= o.cw + 1, JSON.stringify(o));
  };

  async function phoneRound(vp) {
    const tag = `p${vp.width}`;
    const server = await L.startServer({ PP_EVENTS: 'none', PP_WINDOW_SEC: '300', PP_TELEMETRY_DELAY_MS: '0' });
    try {
      const ep = await L.mkPlayer(server, tag + 'E', vp);
      await L.shot(ep, `${tag}-entry`); await ovf(ep, `${tag} giriş`);
      await ep.page.click('#card-create'); await sleep(300);
      await L.shot(ep, `${tag}-entry-create`); await ovf(ep, `${tag} giriş formu`);
      const vis = await ep.page.evaluate(() => { const b = document.querySelector('#create-btn').getBoundingClientRect(); return { top: b.top, bottom: b.bottom, h: innerHeight }; });
      ok(`${tag} giriş: oda kur butonu ekranda`, vis.bottom <= vis.h + 2 && vis.top >= 0, JSON.stringify(vis));
      await ep.page.click('#card-join'); await sleep(300); await L.shot(ep, `${tag}-entry-join`);
      const vis2 = await ep.page.evaluate(() => { const b = document.querySelector('#join-btn').getBoundingClientRect(); return { top: b.top, bottom: b.bottom, h: innerHeight }; });
      ok(`${tag} giriş: katıl butonu ekranda (kaydırmadan)`, vis2.bottom <= vis2.h + 2, JSON.stringify(vis2));
      console.log(`  ${tag} küçük hedefler giriş:`, JSON.stringify(await small(ep)));
      await ep.ctx.close();

      const room = await L.setupRoom(server, tag, { viewport: vp });
      const { D, R: Rk, S: Sp, X } = room;
      await L.shot(D, `${tag}-setup-director`); await L.shot(Rk, `${tag}-setup-worker`);
      await ovf(D, `${tag} setup yönetici`); await ovf(Rk, `${tag} setup çalışan`);
      console.log(`  ${tag} küçük hedefler setup:`, JSON.stringify(await small(D)));
      const mid = (await L.st(D)).mission.id;
      const plan = L.SOLUTIONS[mid][0];
      await L.pickFrame(room, plan.frameId);
      await L.shot(D, `${tag}-game-director`); await L.shot(Rk, `${tag}-game-worker`);
      await ovf(D, `${tag} oyun yönetici`); await ovf(Rk, `${tag} oyun çalışan`);
      // parça seç: roket + yuva listesi birlikte görünür
      const firstR = plan.placements.find((x) => x.role === 'rocket');
      await Rk.page.click(`button[data-pick="${firstR.partId}"]`); await sleep(500);
      await L.shot(Rk, `${tag}-worker-picked`);
      const both = await Rk.page.evaluate(() => {
        const sc = document.querySelector('#scene3d').getBoundingClientRect(); const sl = document.querySelector('#slot-list');
        const first = sl.querySelector('button[data-slot]'); const fr = first ? first.getBoundingClientRect() : null;
        return { sceneTop: Math.round(sc.top), sceneBottom: Math.round(sc.bottom), sceneH: Math.round(sc.height), listTop: fr && Math.round(fr.top), listBottom: fr && Math.round(fr.bottom), h: innerHeight, scrollY: scrollY };
      });
      console.log(`  ${tag} roket+liste:`, JSON.stringify(both));
      ok(`${tag} parça seçiliyken roket ekranda`, both.sceneTop >= -2 && both.sceneBottom <= both.h + 2 && both.sceneH >= 150, JSON.stringify(both));
      ok(`${tag} parça seçiliyken yuva listesinin ilk satırı AYNI ekranda`, both.listTop !== null && both.listBottom <= both.h + 2 && both.listTop >= 0, JSON.stringify(both));
      console.log(`  ${tag} küçük hedefler oyun (çalışan, seçili):`, JSON.stringify(await small(Rk)));
      // sahneye dokunma ile yerleştir
      const pos = await L.slotPos(Rk, firstR.slotId);
      if (pos) {
        const n0 = await L.countParts(Rk);
        await Rk.page.touchscreen.tap(pos.x, pos.y).catch(() => {}); await sleep(600);
        const n1 = await L.countParts(Rk);
        ok(`${tag} sahneye dokunarak yerleştirme`, n1 === n0 + 1, `${n0}->${n1} pos ${JSON.stringify(pos)}`);
        await L.shot(Rk, `${tag}-worker-placed`);
      }
      // etiket dokununca
      const g = await Rk.page.evaluate(() => { const gs = [...document.querySelectorAll('g.pp2d-slot')].map((g) => (g.querySelector('.pp2d-frame') || g).getBoundingClientRect()); return gs.filter((r) => r.width < 38 || r.height < 38).length; });
      ok(`${tag} yuva dokunma hedefi >=38px (tümü)`, g === 0, g + ' küçük yuva');
      // tamamla
      const rest = { placements: plan.placements.filter((x) => !(x.role === 'rocket' && x.slotId === firstR.slotId)) };
      const fl = await L.placeSolution(room, rest, 0);
      ok(`${tag} çözüm yerleştirildi`, fl.length === 0, fl.join(','));
      await sleep(800);
      await L.shot(D, `${tag}-director-built`); await ovf(D, `${tag} yönetici dolu`);
      const sm = await small(D); console.log(`  ${tag} küçük hedefler yönetici:`, JSON.stringify(sm));
      await D.page.waitForFunction(() => { const b = document.querySelector('#poll-start-btn'); return b && !b.disabled; }, null, { timeout: 8000 });
      await D.page.click('#poll-start-btn');
      for (const p of room.all) await p.page.waitForSelector('#poll-box:not([hidden])', { timeout: 5000 });
      await L.shot(D, `${tag}-poll-director`); await L.shot(Rk, `${tag}-poll-worker`); await ovf(Rk, `${tag} anket`);
      const goVis = await Rk.page.evaluate(() => { const b = document.querySelector('#vote-go-btn').getBoundingClientRect(); const n = document.querySelector('#vote-nogo-btn').getBoundingClientRect(); return { go: [b.width, b.height, b.bottom], nogo: [n.width, n.height, n.bottom], h: innerHeight }; });
      ok(`${tag} GO/NO-GO ekranda ve >=44px`, goVis.go[1] >= 44 && goVis.nogo[1] >= 44 && goVis.go[2] <= goVis.h && goVis.nogo[2] <= goVis.h, JSON.stringify(goVis));
      for (const w of [Rk, Sp, X]) await w.page.click('#vote-go-btn');
      await sleep(1500);
      await L.shot(Rk, `${tag}-launch-worker`); await L.shot(D, `${tag}-launch-director`); await ovf(Rk, `${tag} fırlatma`);
      await Rk.page.waitForSelector('#result-panel', { state: 'visible', timeout: 15000 });
      await sleep(500);
      await L.shot(Rk, `${tag}-result-worker`); await ovf(Rk, `${tag} sonuç çalışan`); await ovf(D, `${tag} sonuç yönetici`);
      await Rk.page.evaluate(() => scrollTo(0, 99999)); await sleep(200); await L.shot(Rk, `${tag}-result-worker-bottom`);
      console.log(`  ${tag} küçük hedefler sonuç:`, JSON.stringify(await small(Rk)));
      // lobi (ayrı kısa oda değil): yeni tur + setup çalışanı
      await L.closeRoom(room);
    } finally { L.stopServer(server); }
  }
  scenario('phone390', () => phoneRound({ width: 390, height: 844 }));
  scenario('phone360', () => phoneRound({ width: 360, height: 740 }));

  // lobi ekranı ayrı (telefon): 1 oda ile
  scenario('lobby', async () => {
    const server = await L.startServer({ PP_EVENTS: 'none' });
    try {
      for (const vp of [{ width: 1366, height: 768 }, { width: 390, height: 844 }, { width: 360, height: 740 }]) {
        const D = await L.mkPlayer(server, 'lbD', vp); const J = await L.mkPlayer(server, 'lbJ', vp);
        await D.page.click('#card-create'); await D.page.fill('#name-input', 'Yon'); await D.page.click('#create-btn');
        await D.page.waitForSelector('#screen-lobby:not([hidden])');
        const code = (await D.page.locator('#room-code').innerText()).trim();
        await J.page.click('#card-join'); await J.page.fill('#name-input', 'Rok'); await J.page.fill('#code-input', code); await J.page.click('#join-btn');
        await J.page.waitForSelector('#screen-lobby:not([hidden])');
        await D.page.click('[data-role="director"]'); await sleep(300);
        await L.shot(D, `lobby-${vp.width}`);
        await ovf(D, `lobi ${vp.width}`);
        const lt = await D.page.locator('#screen-lobby').innerText();
        ok(`lobi ${vp.width}: "4 rol dolunca görev başlar" notu`, /4 rol|dört rol/i.test(lt), lt.replace(/\n/g, ' | ').slice(0, 200));
        const dataRoles = await D.page.evaluate(() => [...document.querySelectorAll('[data-role]')].filter((e) => e.offsetParent).map((e) => e.dataset.role + ':' + Math.round(e.getBoundingClientRect().height)));
        console.log(`  lobi ${vp.width} rol kartları:`, JSON.stringify(dataRoles));
        await D.ctx.close(); await J.ctx.close();
      }
    } finally { L.stopServer(server); }
  });

  // ============ sahne yüklenemez ============
  scenario('noscene', async () => {
    const server = await L.startServer({ PP_EVENTS: 'none', PP_WINDOW_SEC: '300', PP_TELEMETRY_DELAY_MS: '0' });
    try {
      const room = await L.roomWithMission(server, 'ns', 'lunar-relay', { abort: /scene2d\.js/ });
      const { D, R: Rk } = room;
      const plan = L.SOLUTIONS['lunar-relay'][0];
      await L.pickFrame(room, plan.frameId);
      await L.shot(Rk, 'noscene-worker'); await L.shot(D, 'noscene-director');
      ok('sahnesiz: data-scene=none', (await Rk.page.evaluate(() => document.documentElement.dataset.scene)) === 'none', await Rk.page.evaluate(() => document.documentElement.dataset.scene));
      const note = await Rk.page.evaluate(() => { const n = document.querySelector('#scene-note'); return n && n.offsetParent ? n.innerText : null; });
      console.log('  sahne notu:', note);
      await Rk.page.click('button[data-pick="engine-kestrel"]'); await sleep(300); await L.shot(Rk, 'noscene-worker-picked');
      const list = await Rk.page.locator('#slot-list button[data-slot]').count();
      ok('sahnesiz: yuva listesi dolu ve kullanılabilir', list > 0, list);
      await Rk.page.click('#unpick-btn').catch(() => {});
      const fl = await L.placeSolution(room, plan, 0);
      ok('sahnesiz: çözüm listeyle yerleştirildi', fl.length === 0, fl.join(','));
      await sleep(800);
      await D.page.waitForFunction(() => { const b = document.querySelector('#poll-start-btn'); return b && !b.disabled; }, null, { timeout: 8000 });
      await D.page.click('#poll-start-btn');
      for (const w of [room.R, room.S, room.X]) { await w.page.waitForSelector('#vote-go-btn', { state: 'visible', timeout: 5000 }); await w.page.click('#vote-go-btn'); }
      for (const p of room.all) await p.page.waitForSelector('#screen-result:not([hidden])', { timeout: 20000 });
      await sleep(800);
      await L.shot(Rk, 'noscene-launch'); // fırlatma sahnesi yok
      await Rk.page.click('#skip-launch-btn').catch(() => {});
      await Rk.page.waitForSelector('#result-panel', { state: 'visible', timeout: 15000 });
      const rt = await Rk.page.locator('#result-panel').innerText();
      ok('sahnesiz: sonuç başarı', /BAŞARI/i.test(rt), rt.replace(/\n/g, ' | ').slice(0, 120));
      await L.shot(Rk, 'noscene-result');
      await L.closeRoom(room);
    } finally { L.stopServer(server); }
  });

  // ============ misc: yeniden bağlanma, yardım, çekmeceler ============
  scenario('misc', async () => {
    const server = await L.startServer({ PP_EVENTS: 'none', PP_WINDOW_SEC: '300', PP_TELEMETRY_DELAY_MS: '0' });
    try {
      const room = await L.roomWithMission(server, 'm', 'lunar-relay');
      const { D, R: Rk, S: Sp, X } = room;
      // setup'ta yenile (yönetici + çalışan)
      await D.page.reload(); await D.page.waitForSelector('#screen-setup:not([hidden])', { timeout: 8000 }).catch(() => {});
      ok('setup: yönetici yenilemede rejoin (setup ekranı)', await D.page.locator('#screen-setup').isVisible());
      await Rk.page.reload(); await Rk.page.waitForSelector('#screen-setup:not([hidden])', { timeout: 8000 }).catch(() => {});
      ok('setup: çalışan yenilemede rejoin', await Rk.page.locator('#screen-setup').isVisible());
      const plan = L.SOLUTIONS['lunar-relay'][0];
      await L.pickFrame(room, plan.frameId);
      await L.placeList(Rk, 'engine-kestrel', 'eng-1'); await L.placeList(Rk, 'tank-large', 'tank-1');
      await Rk.page.click('button[data-pick="fuel-methalox"]'); await sleep(200);
      await Rk.page.reload();
      await Rk.page.waitForSelector('#screen-game:not([hidden])', { timeout: 8000 }).catch(() => {});
      await Rk.page.waitForFunction(() => document.querySelector('#scene3d') && document.querySelector('#scene3d').dataset.sceneReady === '1', null, { timeout: 8000 }).catch(() => {});
      await sleep(600);
      ok('oyun: yenilemede rejoin, 2 parça korunur', (await L.countParts(Rk)) === 2, await L.countParts(Rk));
      ok('oyun: yenilemede sahne hazır (sceneReady=1)', (await Rk.page.evaluate(() => document.querySelector('#scene3d').dataset.sceneReady)) === '1');
      const states = await Rk.page.evaluate(() => [...document.querySelectorAll('g.pp2d-slot')].filter((g) => /mine|occupied/.test(g.dataset.state)).map((g) => g.dataset.slot));
      ok('yenileme sonrası sahnede dolu yuvalar', states.includes('eng-1') && states.includes('tank-1'), states.join(','));
      await L.shot(Rk, 'misc-after-reload-worker');
      await D.page.reload(); await D.page.waitForSelector('#screen-game:not([hidden])', { timeout: 8000 }).catch(() => {});
      await sleep(700);
      ok('yönetici yenilemede oyun ekranı + sayaç sürüyor', await D.page.locator('#timer-value').isVisible() && /\d\d:\d\d/.test(await D.page.locator('#timer-value').innerText()));
      await L.shot(D, 'misc-after-reload-director');
      // yardım
      for (const [nm, p] of [['çalışan', Rk], ['yönetici', D]]) {
        await p.page.click('#help-btn'); await sleep(300);
        ok(`yardım katmanı açılır (${nm})`, await p.page.locator('#help-panel').isVisible());
        const ht = await p.page.locator('#help-panel').innerText();
        ok(`yardım metni sayısız (${nm})`, !digitsIn(ht), (ht.match(/.{0,20}\d.{0,20}/g) || []).join(' || '));
        await L.shot(p, `misc-help-${nm}`);
        await p.page.keyboard.press('Escape'); await sleep(250);
        ok(`yardım Escape ile kapanır (${nm})`, !(await p.page.locator('#help-panel').isVisible()));
        await p.page.click('#help-btn'); await sleep(200); await p.page.click('#help-close'); await sleep(200);
        ok(`yardım #help-close ile kapanır (${nm})`, !(await p.page.locator('#help-panel').isVisible()));
      }
      // çekmeceler
      for (const [nm, p, ds] of [['yönetici', D, ['log', 'parts', 'catalog']], ['çalışan', Rk, ['log']]]) {
        for (const d of ds) {
          const b = p.page.locator(`button[data-drawer="${d}"]`);
          if (!(await b.count()) || !(await b.first().isVisible())) { ok(`çekmece düğmesi görünür ${nm}/${d}`, false, 'yok/gizli'); continue; }
          await b.first().click(); await sleep(400);
          const open = await p.page.locator('#drawer').isVisible();
          ok(`çekmece açılır ${nm}/${d}`, open);
          await L.shot(p, `misc-drawer-${nm}-${d}`);
          if (nm === 'çalışan') { const dt = noClock(await p.page.locator('#drawer').innerText()); ok(`çalışan çekmecesi sayısız (${d})`, !digitsIn(dt), (dt.match(/.{0,20}\d.{0,20}/g) || []).slice(0, 3).join(' || ')); }
          await p.page.keyboard.press('Escape'); await sleep(300);
          ok(`çekmece Escape ile kapanır ${nm}/${d}`, !(await p.page.locator('#drawer').isVisible()));
          await b.first().click(); await sleep(300); await p.page.click('#drawer-scrim').catch(() => {}); await sleep(300);
          ok(`çekmece scrim ile kapanır ${nm}/${d}`, !(await p.page.locator('#drawer').isVisible()));
          await b.first().click(); await sleep(300); await p.page.click('#drawer-close').catch(() => {}); await sleep(300);
          ok(`çekmece #drawer-close ile kapanır ${nm}/${d}`, !(await p.page.locator('#drawer').isVisible()));
        }
      }
      await L.closeRoom(room);
    } finally { L.stopServer(server); }
  });

  // ============ demo ============
  scenario('demo', async () => {
    const server = await L.startServer({ PP_EVENTS: 'none', PP_WINDOW_SEC: '300', PP_TELEMETRY_DELAY_MS: '0' });
    try {
      const b = await L.getBrowser();
      // ana menü -> demo
      const ctx0 = await b.newContext({ viewport: { width: 1366, height: 768 } }); const mp = await ctx0.newPage();
      mp.on('pageerror', (e) => L.issues.push('[menu] pageerror ' + e.message)); mp.on('console', (m) => { if (['error', 'warning'].includes(m.type())) L.issues.push('[menu] console.' + m.type() + ': ' + m.text()); });
      await mp.goto(server.url); await mp.click('#demo-link'); await mp.waitForURL(/demo\.html/, { timeout: 5000 }).catch(() => {});
      ok('ana menü 03 kartı demoya gider', /\/demo\.html/.test(mp.url()), mp.url());
      await ctx0.close();

      const ctx = await b.newContext({ viewport: { width: 1600, height: 1000 } }); const page = await ctx.newPage();
      const msgs = [];
      page.on('pageerror', (e) => L.issues.push('[demo] pageerror ' + e.message)); page.on('console', (m) => { if (['error', 'warning'].includes(m.type())) L.issues.push('[demo] console.' + m.type() + ': ' + m.text()); });
      page.on('requestfailed', (r) => L.issues.push('[demo] requestfailed ' + r.url()));
      page.on('response', (r) => { if (r.status() >= 400) L.issues.push('[demo] HTTP ' + r.status() + ' ' + r.url()); });
      await page.goto(server.url + '/demo.html'); await sleep(600);
      await L.shot({ page }, 'demo-empty');
      ok('demo: boş durum kartı görünür', await page.locator('#demo-empty').isVisible());
      ok('demo: #demo-empty-start görünür', await page.locator('#demo-empty-start').isVisible());
      ok('demo: boşken paneller gizli', !(await page.locator('#demo-panels').isVisible()) || (await page.locator('.demo-panel iframe:visible').count()) === 0);
      ok('demo: #demo-home href "/"', (await page.getAttribute('#demo-home', 'href')) === '/', await page.getAttribute('#demo-home', 'href'));
      await page.click('#demo-start-btn'); // ana "Demo odası kur"
      await page.waitForFunction(() => document.querySelector('#demo-code') && /[A-Z0-9]{4}/i.test(document.querySelector('#demo-code').innerText), null, { timeout: 10000 }).catch(() => {});
      await sleep(3000);
      ok('demo: kurulumdan sonra 4 panel görünür', (await page.locator('.demo-panel').evaluateAll((e) => e.filter((x) => x.offsetParent).length)) === 4);
      ok('demo: boş durum kartı gizlendi', !(await page.locator('#demo-empty').isVisible()));
      const roles = ['director', 'rocket', 'spacecraft', 'payload'];
      const fr = {};
      for (const r of roles) fr[r] = await (await page.locator(`.demo-panel[data-role="${r}"] iframe`).elementHandle()).contentFrame();
      for (const r of roles) await fr[r].waitForSelector('#screen-setup:not([hidden])', { timeout: 12000 }).catch(() => {});
      for (const r of roles) ok(`demo: ${r} paneli setup ekranında`, await fr[r].locator('#screen-setup').isVisible().catch(() => false));
      await L.shot({ page }, 'demo-setup');
      // yerleşimler
      for (const lay of ['director', 'row', 'grid']) {
        await page.click(`button[data-layout="${lay}"]`); await sleep(500);
        const cls = await page.getAttribute('#demo-panels', 'class');
        ok(`demo: yerleşim ${lay}`, new RegExp('layout-' + lay).test(cls), cls);
        const o = await L.overflow({ page }); ok(`demo: yatay taşma yok (${lay})`, o.sw <= o.cw + 1, JSON.stringify(o));
        await L.shot({ page }, `demo-layout-${lay}`);
      }
      await page.click('button[data-focus="rocket"]'); await sleep(500);
      ok('demo: odak (Büyüt) has-focus', /has-focus/.test(await page.getAttribute('#demo-panels', 'class')));
      await L.shot({ page }, 'demo-focus'); await page.click('button[data-focus="rocket"]'); await sleep(300);
      // tam hamle (panel içinden)
      const dstate = JSON.parse(await fr.director.locator('#debug-state').textContent());
      const mid = dstate.mission.id; const plan = L.SOLUTIONS[mid][0];
      await fr.director.click(`#frame-select button[data-frame="${plan.frameId}"]`);
      for (const r of roles) await fr[r].waitForSelector('#screen-game:not([hidden])', { timeout: 8000 });
      await sleep(600);
      await L.shot({ page }, 'demo-game');
      const wf = { rocket: fr.rocket, spacecraft: fr.spacecraft, payload: fr.payload };
      let miss = 0;
      for (const pl of plan.placements) {
        const f = wf[pl.role];
        try {
          await f.click(`button[data-pick="${pl.partId}"]`, { timeout: 4000 });
          await f.click(`#slot-list button[data-slot="${pl.slotId}"]`, { timeout: 4000 });
          await sleep(120);
        } catch (e) { miss++; console.log('  demo yerleştirme hatası', pl.partId, pl.slotId, String(e.message).split('\n')[0]); }
      }
      ok('demo: panellerden tüm çözüm yerleştirildi', miss === 0, miss);
      await sleep(1000);
      await L.shot({ page }, 'demo-built');
      await fr.director.waitForFunction(() => { const b = document.querySelector('#poll-start-btn'); return b && !b.disabled; }, null, { timeout: 8000 }).catch(() => {});
      await fr.director.click('#poll-start-btn', { timeout: 4000 }).catch(() => {});
      for (const r of ['rocket', 'spacecraft', 'payload']) await fr[r].click('#vote-go-btn', { timeout: 6000 }).catch(() => {});
      for (const r of roles) await fr[r].waitForSelector('#screen-result:not([hidden])', { timeout: 20000 }).catch(() => {});
      await sleep(5000);
      await L.shot({ page }, 'demo-result');
      const rtxt = await fr.rocket.locator('#screen-result').innerText().catch(() => '');
      ok('demo: sonuç (başarı) panellerde', /BAŞARI/i.test(rtxt), rtxt.replace(/\n/g, ' | ').slice(0, 100));
      // sıfırla
      await page.click('#demo-reset-btn'); await sleep(1500);
      await L.shot({ page }, 'demo-after-reset');
      ok('demo: sıfırla sonrası boş durum kartı geri', await page.locator('#demo-empty').isVisible(), '');
      // yanlış kod
      await page.fill('#demo-join-code', 'ZZZZ'); await page.click('#demo-join-btn'); await sleep(800);
      const err = (await page.locator('#demo-error').innerText()).trim();
      ok('demo: yanlış kodda hata mesajı', err.length > 0, err);
      // ana menü
      await page.click('#demo-home'); await page.waitForURL((u) => u.pathname === '/', { timeout: 5000 }).catch(() => {});
      ok('demo: #demo-home ana menüye döner', new URL(page.url()).pathname === '/', page.url());
      await ctx.close();
      // dar demo: 1366x768
      const ctx2 = await b.newContext({ viewport: { width: 1366, height: 768 } }); const p2 = await ctx2.newPage();
      await p2.goto(server.url + '/demo.html'); await p2.click('#demo-empty-start'); await sleep(5000);
      await L.shot({ page: p2 }, 'demo-1366-grid'); await p2.click('button[data-layout="director"]'); await sleep(500); await L.shot({ page: p2 }, 'demo-1366-director');
      await ctx2.close();
    } finally { L.stopServer(server); }
  });
};
