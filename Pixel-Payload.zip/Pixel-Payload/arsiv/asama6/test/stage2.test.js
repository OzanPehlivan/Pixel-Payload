'use strict';
// Aşama 2 birim testleri: parça işlemleri + görünüm ekleri. SAHTE physics kullanır (Modül D'ye bağımlı değil).
// Çalıştır: node --test test/stage2.test.js

const test = require('node:test');
const assert = require('node:assert');

const { ROLE_NAMES, GameError } = require('../server/constants');
const { createRoomManager } = require('../server/rooms');
const { viewFor } = require('../server/filter');

const NUM_FIELDS = ['massKg', 'cost', 'thrustKN', 'isp', 'powerGenW', 'powerUseW', 'heat', 'heatShield',
  'fuelKg', 'ispMult', 'max', 'requires'];

// Ayırt edici sayılarla sahte katalog
function mk(id, role, category, name, icon, extra = {}) {
  return {
    id, role, category, name, icon, desc: `${name} açıklaması`,
    massKg: 7331, cost: 4447, powerGenW: 0, powerUseW: 0, thrustKN: 0, isp: 0, heat: 0, heatShield: 0,
    fuelKg: 0, ispMult: 1, max: 2, requires: [], ...extra,
  };
}
const PARTS = [
  mk('eng', 'rocket', 'engine', 'Sahte Motor', 'E', { thrustKN: 8123, isp: 3119, requires: ['tank'] }),
  mk('tank', 'rocket', 'tank', 'Sahte Tank', 'T', { fuelKg: 5557 }),
  mk('strut', 'rocket', 'structure', 'Sahte Destek', 'S', { max: 999 }),
  mk('panel', 'spacecraft', 'solar', 'Sahte Panel', 'P', { powerGenW: 6661 }),
  mk('cam', 'payload', 'instrument', 'Sahte Kamera', 'C', { powerUseW: 2221, max: 1 }),
];
const ROLES3 = ['rocket', 'spacecraft', 'payload'];

const MISSION = {
  id: 'gizli-gorev-xyz', title: 'GIZLI-BASLIK', target: 'GIZLI-HEDEF', requiredDeltaV: 4321,
  requiredInstruments: ['cam'], budget: 9991, durationSec: 300, nasaFact: 'GIZLI-FACT', nasaReal: 'GIZLI-REAL',
};

function fakePhysics() {
  const calls = { computeTelemetry: 0 };
  const byId = new Map(PARTS.map((p) => [p.id, p]));
  const physics = {
    calls,
    getPart: (id) => byId.get(id),
    fullCatalog: () => {
      const out = { rocket: [], spacecraft: [], payload: [] };
      for (const p of PARTS) out[p.role].push(structuredClone(p));
      return out;
    },
    // Kasıtlı olarak fazladan (sayısal) alanlar döndürür: filtre beyaz liste uygulamalı
    publicCatalog: (role) => PARTS.filter((p) => p.role === role).map((p) => ({ ...p, secret: 'SIZINTI' })),
    canAdd: (build, role, partId) => {
      const p = byId.get(partId);
      if (!p) return { ok: false, error: 'INVALID_PART' };
      if (p.role !== role) return { ok: false, error: 'NOT_ALLOWED' };
      if (build[role].filter((it) => it.partId === partId).length >= p.max) return { ok: false, error: 'PART_LIMIT' };
      return { ok: true };
    },
    computeTelemetry: (build, mission) => {
      calls.computeTelemetry++;
      const n = ROLES3.reduce((s, r) => s + build[r].length, 0);
      return {
        massKg: 1000 + n, dryMassKg: 0, fuelKg: 0, thrustKN: 0, isp: 0, twr: 0, deltaV: mission ? 9876 : 0,
        powerGenW: 0, powerUseW: 0, heat: 0, heatShield: 0, spent: 0,
        checks: { twr: false, deltaV: false, power: false, payload: false, heat: false },
        missing: [], overBudget: false, ready: false, parts: n,
      };
    },
    // motor tanksızsa kırmızı, diğerleri yeşil
    partStatuses: (build, role) => {
      const out = {};
      const hasTank = build[role].some((it) => it.partId === 'tank');
      for (const it of build[role]) out[it.uid] = it.partId === 'eng' && !hasTank ? 'red' : 'green';
      return out;
    },
  };
  return physics;
}

// Sahte fırlatma/puan (Aşama 3 arayüzü)
const resolveLaunch = () => ({ success: false, outcome: 'no-liftoff', title: 'x', reasonText: 'x', failedChecks: ['twr'] });
const computeScore = () => ({ total: 0, stars: 0, breakdown: [] });
// Aşama 4: olaysız, gecikmesiz, sabit saat
const config = { events: [], telemetryDelayMs: 0 };
const now = () => 10_000_000;

// Sahte layout (Aşama 5 arayüzü): her kategoriyi kabul eden 30 yuvalı tek gövde; physics.canAdd'i de uygular
const LETTERS = 'abcdefghijklmnopqrstuvwxyz';
const SLOT_IDS = Array.from({ length: 30 }, (_, i) => `yuva-${LETTERS[Math.floor(i / 26)]}${LETTERS[i % 26]}`);
const FRAME_ID = 'govde-deneme';
const slotTaken = (build, slotId) => ['rocket', 'spacecraft', 'payload'].some((r) => build[r].some((it) => it.slotId === slotId));
function fakeLayout(physics) {
  const frame = {
    id: FRAME_ID, name: 'Deneme Gövdesi', desc: 'Deneme gövdesi açıklaması', massKg: 0, cost: 0,
    shape: { segments: [], fins: 0, boosters: 0 },
    slots: SLOT_IDS.map((id) => ({
      id, name: `Yuva ${id.slice(5).toUpperCase()}`, zone: 'bolme', segment: 'kademe', face: 'C', kind: 'internal',
      accepts: ['engine', 'tank', 'structure', 'solar', 'computer', 'instrument'], pos: [0, 0, 0], normal: [0, 1, 0], neighbors: [],
    })),
  };
  const canPlace = (build, frameId, role, partId, slotId) => {
    const c = physics.canAdd(build, role, partId);
    if (!c || !c.ok) return { ok: false, error: c.error, reason: 'Sahte gerekçe' };
    if (frameId !== FRAME_ID || !SLOT_IDS.includes(slotId)) return { ok: false, error: 'INVALID_SLOT', reason: 'Yuva yok' };
    if (slotTaken(build, slotId)) return { ok: false, error: 'SLOT_TAKEN', reason: 'Yuva dolu' };
    return { ok: true };
  };
  return {
    listFrames: () => [structuredClone(frame)],
    getFrame: (id) => (id === FRAME_ID ? frame : undefined),
    publicFrame: (id) => (id === FRAME_ID ? structuredClone(frame) : undefined),
    publicFrameOptions: () => [{ id: frame.id, name: frame.name, desc: frame.desc, shape: structuredClone(frame.shape) }],
    canPlace,
    slotOptions: (build, frameId, role, partId) => SLOT_IDS.map((slotId) => ({ slotId, ...canPlace(build, frameId, role, partId, slotId) })),
    slotName: (frameId, slotId) => (frame.slots.find((s) => s.id === slotId) || {}).name,
  };
}
// İlk boş yuva (oda yoksa ilk yuva)
function free(m, code) {
  const room = m.getRoom(code);
  return SLOT_IDS.find((id) => !room || !slotTaken(room.build, id));
}
function deps() {
  const physics = fakePhysics();
  return { physics, layout: fakeLayout(physics) };
}

const VL = fakeLayout(fakePhysics()); // görünüm için (sahte layout durumsuz)

function throwsCode(fn, code) {
  assert.throws(fn, (err) => err instanceof GameError && err.code === code && typeof err.message === 'string' && err.message.length > 0,
    `beklenen hata: ${code}`);
}

// 4 rolü dolu, başlamış oda. p[0]=director, p[1]=rocket, p[2]=spacecraft, p[3]=payload
function started({ frame = true } = {}) {
  const physics = fakePhysics();
  const m = createRoomManager({ missions: [MISSION], physics, layout: fakeLayout(physics), resolveLaunch, computeScore, now, config, rng: () => 0 });
  const { room, player: p0 } = m.createRoom('Ayşe');
  const p = [p0, m.joinRoom(room.code, 'Bora').player, m.joinRoom(room.code, 'Cem').player, m.joinRoom(room.code, 'Deniz').player];
  ['director', 'rocket', 'spacecraft', 'payload'].forEach((r, i) => m.selectRole(room.code, p[i].id, r));
  if (frame) m.selectFrame(room.code, p[0].id, FRAME_ID); // Aşama 5: setup → building
  return { m, room, p, physics, code: room.code };
}

test('ROLE_NAMES', () => {
  assert.deepStrictEqual(ROLE_NAMES, {
    director: 'Yönetici', rocket: 'Roket & Yakıt', spacecraft: 'Uzay Aracı', payload: 'Faydalı Yük',
  });
});

test('physics zorunlu', () => {
  assert.throws(() => createRoomManager({ missions: [MISSION], resolveLaunch, computeScore }));
});

test('oyun başlarken telemetri hesaplanır ve log kind=system', () => {
  const { room, physics } = started();
  assert.strictEqual(physics.calls.computeTelemetry, 1);
  assert.strictEqual(room.telemetry.deltaV, 9876);
  assert.strictEqual(room.telemetry.parts, 0);
  const first = room.log[0];
  assert.strictEqual(first.kind, 'system');
  assert.strictEqual(first.text, 'Oyun başladı');
  assert.strictEqual(first.role, null);
});

test('addPart / removePart başarı, telemetri yenilenir, log biçimi', () => {
  const { m, room, p, physics, code } = started();
  assert.strictEqual(m.addPart(code, p[1].id, 'eng', free(m, code)), room);
  assert.strictEqual(room.build.rocket.length, 1);
  const item = room.build.rocket[0];
  assert.deepStrictEqual(Object.keys(item).sort(), ['partId', 'slotId', 'uid']);
  assert.strictEqual(item.slotId, 'yuva-aa');
  assert.strictEqual(item.partId, 'eng');
  assert.ok(typeof item.uid === 'string' && item.uid.length > 0);
  assert.strictEqual(room.telemetry.parts, 1);
  assert.strictEqual(physics.calls.computeTelemetry, 2);

  let last = room.log[room.log.length - 1];
  assert.strictEqual(last.kind, 'part');
  assert.strictEqual(last.role, 'rocket');
  assert.strictEqual(last.playerId, p[1].id);
  assert.strictEqual(last.text, 'Roket & Yakıt: Sahte Motor → Yuva AA');
  assert.strictEqual(last.cost, 4447); // yalnız sunucu logunda
  assert.ok(typeof last.t === 'number');

  m.addPart(code, p[1].id, 'eng', free(m, code));
  m.addPart(code, p[2].id, 'panel', free(m, code));
  m.addPart(code, p[3].id, 'cam', free(m, code));
  const uids = [...room.build.rocket, ...room.build.spacecraft, ...room.build.payload].map((it) => it.uid);
  assert.strictEqual(new Set(uids).size, uids.length, 'uid benzersiz olmalı');
  assert.strictEqual(room.log[room.log.length - 1].text, 'Faydalı Yük: Sahte Kamera → Yuva AD');
  assert.strictEqual(room.log[room.log.length - 2].text, 'Uzay Aracı: Sahte Panel → Yuva AC');

  assert.strictEqual(m.removePart(code, p[1].id, item.uid), room);
  assert.strictEqual(room.build.rocket.length, 1);
  assert.ok(!room.build.rocket.some((it) => it.uid === item.uid));
  assert.strictEqual(room.telemetry.parts, 3);
  last = room.log[room.log.length - 1];
  assert.strictEqual(last.kind, 'part');
  assert.strictEqual(last.text, 'Roket & Yakıt: Sahte Motor çıkardı (Yuva AA)');
  assert.strictEqual(last.cost, -4447);
  for (const e of room.log) assert.ok(!/\d/.test(e.text), `log metninde sayı var: ${e.text}`);
});

test('addPart / removePart hata kodları', () => {
  const { m, room, p, code } = started();
  // NOT_IN_ROOM
  throwsCode(() => m.addPart(code, 'yabanci', 'eng', free(m, code)), 'NOT_IN_ROOM');
  throwsCode(() => m.removePart(code, 'yabanci', 'x'), 'NOT_IN_ROOM');
  // ROOM_NOT_FOUND
  const other = code === 'ZZZZ' ? 'YYYY' : 'ZZZZ';
  throwsCode(() => m.addPart(other, p[1].id, 'eng', free(m, other)), 'ROOM_NOT_FOUND');
  // yönetici hiçbir parçaya dokunamaz
  throwsCode(() => m.addPart(code, p[0].id, 'eng', free(m, code)), 'NOT_ALLOWED');
  // başka rolün parçası (physics.canAdd -> NOT_ALLOWED)
  throwsCode(() => m.addPart(code, p[1].id, 'panel', free(m, code)), 'NOT_ALLOWED');
  // INVALID_PART
  throwsCode(() => m.addPart(code, p[1].id, 'yok-boyle', free(m, code)), 'INVALID_PART');
  throwsCode(() => m.addPart(code, p[1].id, undefined), 'INVALID_PART');
  throwsCode(() => m.addPart(code, p[1].id, { x: 1 }), 'INVALID_PART');
  // PART_LIMIT
  m.addPart(code, p[3].id, 'cam', free(m, code));
  throwsCode(() => m.addPart(code, p[3].id, 'cam', free(m, code)), 'PART_LIMIT');
  // PART_NOT_FOUND
  throwsCode(() => m.removePart(code, p[1].id, 'olmayan-uid'), 'PART_NOT_FOUND');
  throwsCode(() => m.removePart(code, p[1].id, undefined), 'PART_NOT_FOUND');
  // başka rolün uid'si -> NOT_ALLOWED; yönetici çıkaramaz
  const camUid = room.build.payload[0].uid;
  throwsCode(() => m.removePart(code, p[1].id, camUid), 'NOT_ALLOWED');
  throwsCode(() => m.removePart(code, p[0].id, camUid), 'NOT_ALLOWED');
  assert.strictEqual(room.build.payload.length, 1);
  // rolsüz oyuncu (normalde olmaz)
  room.players[p[2].id].role = null;
  throwsCode(() => m.addPart(code, p[2].id, 'panel', free(m, code)), 'NOT_ALLOWED');
});

test('WRONG_PHASE: lobide parça takılamaz', () => {
  const physics = fakePhysics();
  const m = createRoomManager({ missions: [MISSION], physics, layout: fakeLayout(physics), resolveLaunch, computeScore, now, config });
  const { room, player } = m.createRoom('A');
  m.selectRole(room.code, player.id, 'rocket');
  throwsCode(() => m.addPart(room.code, player.id, 'eng', free(m, room.code)), 'WRONG_PHASE');
  throwsCode(() => m.removePart(room.code, player.id, 'x'), 'WRONG_PHASE');
});

test('log en fazla 200 girdi tutar', () => {
  const { m, room, p, code } = started();
  for (let i = 0; i < 120; i++) {
    m.addPart(code, p[1].id, 'strut', free(m, code));
    m.removePart(code, p[1].id, room.build.rocket[0].uid);
  }
  assert.strictEqual(room.log.length, 200);
  assert.strictEqual(room.log[room.log.length - 1].text, 'Roket & Yakıt: Sahte Destek çıkardı (Yuva AA)');
});

test('yönetici görünümü: tam katalog, build name/icon, log kind', () => {
  const { m, room, p, physics, code } = started();
  m.addPart(code, p[1].id, 'eng', free(m, code));
  m.addPart(code, p[3].id, 'cam', free(m, code));
  const v = viewFor(room, p[0].id, physics, VL);
  assert.deepStrictEqual(v.mission, MISSION);
  assert.deepStrictEqual(v.telemetry, room.telemetry);
  assert.notStrictEqual(v.telemetry, room.telemetry);
  assert.deepStrictEqual(v.catalog, physics.fullCatalog());
  assert.strictEqual(v.catalog.rocket[0].massKg, 7331);
  assert.deepStrictEqual(v.build.rocket, [{ uid: room.build.rocket[0].uid, partId: 'eng', name: 'Sahte Motor', icon: 'E', slotId: 'yuva-aa', slotName: 'Yuva AA', cost: 4447 }]);
  assert.deepStrictEqual(v.build.spacecraft, []);
  assert.deepStrictEqual(v.build.payload, [{ uid: room.build.payload[0].uid, partId: 'cam', name: 'Sahte Kamera', icon: 'C', slotId: 'yuva-ab', slotName: 'Yuva AB', cost: 4447 }]);
  assert.strictEqual(v.log.length, room.log.length);
  // parça hareketlerinde ± cost (yalnız yöneticide), diğerlerinde yok
  for (const e of v.log) {
    assert.deepStrictEqual(Object.keys(e).sort(), e.kind === 'part' ? ['cost', 'kind', 'role', 't', 'text'] : ['kind', 'role', 't', 'text']);
  }
  assert.strictEqual(v.log[1].text, 'Yönetici gövdeyi seçti: Deneme Gövdesi');
  assert.strictEqual(v.log[2].kind, 'part');
  assert.strictEqual(v.log[2].cost, 4447);
  assert.strictEqual(v.undoLeft, 3);
  for (const k of ['missionLabel', 'myParts', 'others', 'feed']) assert.ok(!(k in v), k);
  const json = JSON.stringify(v);
  for (const o of p.slice(1)) assert.ok(!json.includes(o.id), 'başka oyuncunun playerId sızdı');
});

test('çalışan görünümü: sayısız katalog, myParts status, others, feed', () => {
  const { m, room, p, physics, code } = started();
  m.addPart(code, p[1].id, 'eng', free(m, code));          // tanksız motor -> red
  m.addPart(code, p[2].id, 'panel', free(m, code));
  m.addPart(code, p[3].id, 'cam', free(m, code));
  const v = viewFor(room, p[1].id, physics, VL);

  assert.strictEqual(v.missionLabel, 'GİZLİ');
  assert.deepStrictEqual(v.catalog.map(({ slots, ...c }) => c), [
    { id: 'eng', name: 'Sahte Motor', icon: 'E', desc: 'Sahte Motor açıklaması', category: 'engine', model: '', locked: false },
    { id: 'tank', name: 'Sahte Tank', icon: 'T', desc: 'Sahte Tank açıklaması', category: 'tank', model: '', locked: false },
    { id: 'strut', name: 'Sahte Destek', icon: 'S', desc: 'Sahte Destek açıklaması', category: 'structure', model: '', locked: false },
  ]);
  // yuva seçenekleri: dolu 3 yuva engelli, error kodu yok
  const engSlots = v.catalog[0].slots;
  assert.strictEqual(engSlots.length, SLOT_IDS.length);
  assert.deepStrictEqual(engSlots[0], { slotId: 'yuva-aa', ok: false, reason: 'Yuva dolu' });
  assert.deepStrictEqual(engSlots[3], { slotId: 'yuva-ad', ok: true });
  assert.strictEqual(engSlots.filter((x) => !x.ok).length, 3);
  const engUid = room.build.rocket[0].uid;
  assert.deepStrictEqual(v.myParts, [{ uid: engUid, partId: 'eng', name: 'Sahte Motor', icon: 'E', status: 'red', slotId: 'yuva-aa', slotName: 'Yuva AA' }]);
  assert.deepStrictEqual(v.others, {
    spacecraft: [{ name: 'Sahte Panel', icon: 'P' }],
    payload: [{ name: 'Sahte Kamera', icon: 'C' }],
  });

  m.addPart(code, p[1].id, 'tank', free(m, code));
  const v2 = viewFor(room, p[1].id, physics, VL);
  assert.ok(v2.myParts.every((x) => x.status === 'green'));

  // feed: yalnızca kind==='part', son 12, { t, role, text }
  assert.ok(v2.feed.every((e) => Object.keys(e).sort().join() === 'role,t,text'));
  assert.ok(!v2.feed.some((e) => e.text === 'Oyun başladı'));
  assert.strictEqual(v2.feed.length, 4);
  for (let i = 0; i < 15; i++) m.addPart(code, p[1].id, 'strut', free(m, code));
  const v3 = viewFor(room, p[1].id, physics, VL);
  assert.strictEqual(v3.feed.length, 12);
  assert.strictEqual(v3.feed[11].text, 'Roket & Yakıt: Sahte Destek → Yuva AS');
  const partLog = room.log.filter((e) => e.kind === 'part').slice(-12);
  assert.deepStrictEqual(v3.feed.map((e) => e.t), partLog.map((e) => e.t));
});

test('GÜVENLİK: çalışan JSON çıktısında görev/sayı/playerId/uid sızıntısı yok', () => {
  const { m, room, p, physics, code } = started();
  m.addPart(code, p[1].id, 'eng', free(m, code));
  m.addPart(code, p[1].id, 'tank', free(m, code));
  m.addPart(code, p[2].id, 'panel', free(m, code));
  m.addPart(code, p[3].id, 'cam', free(m, code));
  const otherUids = (role) => room.build[role].map((it) => it.uid);

  for (const me of p.slice(1)) {
    const v = viewFor(room, me.id, physics, VL);
    for (const k of ['mission', 'telemetry', 'log', 'undoLeft', 'build']) assert.ok(!(k in v), `${k} anahtarı var`);
    let json = JSON.stringify(v).split(me.id).join('<ME>');
    // kendi uid'lerini maskele (hex içinde rastgele rakam eşleşmesi olmasın)
    for (const uid of otherUids(me.role)) json = json.split(uid).join('<UID>');
    for (const f of NUM_FIELDS) assert.ok(!json.includes(`"${f}"`), `${f} alanı sızdı`);
    for (const n of ['7331', '4447', '8123', '3119', '5557', '6661', '2221', '9876', '4321', '9991']) {
      assert.ok(!json.includes(n), `sayı sızdı: ${n}`);
    }
    for (const s of ['SIZINTI', MISSION.id, MISSION.title, MISSION.target, 'GIZLI-FACT', 'GIZLI-REAL', 'requiredDeltaV', 'budget', 'checks']) {
      assert.ok(!json.includes(s), `sızdı: ${s}`);
    }
    for (const o of p) if (o.id !== me.id) assert.ok(!json.includes(o.id), 'başka oyuncunun playerId sızdı');
    // others içinde uid/partId yok; başka rollerin uid'leri hiç görünmez
    for (const list of Object.values(v.others)) for (const x of list) assert.deepStrictEqual(Object.keys(x).sort(), ['icon', 'name']);
    for (const r of ['rocket', 'spacecraft', 'payload']) {
      if (r !== me.role) for (const uid of otherUids(r)) assert.ok(!json.includes(uid), 'başka rolün uid sızdı');
    }
  }
});

test('GÜVENLİK: rolsüz oyuncu ve physics yokluğu çökertmez', () => {
  const { room, p, physics } = started();
  room.players[p[3].id].role = null;
  const v = viewFor(room, p[3].id, physics, VL);
  assert.strictEqual(v.missionLabel, 'GİZLİ');
  for (const k of ['mission', 'telemetry', 'log', 'undoLeft', 'build', 'catalog']) assert.ok(!(k in v), k);
  // physics verilmezse de çökmez
  const w = viewFor(room, p[1].id);
  assert.deepStrictEqual(w.catalog, []);
  assert.ok(viewFor(room, p[0].id).catalog);
});

test('lobide yeni alanlar gönderilmez', () => {
  const physics = fakePhysics();
  const m = createRoomManager({ missions: [MISSION], physics, layout: fakeLayout(physics), resolveLaunch, computeScore, now, config });
  const { room, player } = m.createRoom('A');
  m.selectRole(room.code, player.id, 'director');
  const v = viewFor(room, player.id, physics, VL);
  assert.deepStrictEqual(Object.keys(v).sort(), ['code', 'phase', 'players', 'roles', 'you']);
});
