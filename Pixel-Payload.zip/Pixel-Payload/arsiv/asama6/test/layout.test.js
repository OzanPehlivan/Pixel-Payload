'use strict';
// Modül Q birim testleri: node --test test/layout.test.js
const test = require('node:test');
const assert = require('node:assert/strict');
const catalog = require('../data/parts.json');
const framesData = require('../data/frames.json');
const { createPhysics } = require('../server/physics.js');
const { createLayout } = require('../server/layout.js');

const phys = createPhysics(catalog);
const layout = createLayout({ framesData, physics: phys });
const CATEGORIES = new Set(catalog.parts.map((p) => p.category));
const ROLE_OF_CAT = Object.fromEntries(catalog.parts.map((p) => [p.category, p.role]));
const TAGS = new Set(catalog.parts.flatMap((p) => p.tags));
const MODELS = ['engine', 'tank', 'fuel', 'panel', 'battery', 'shield', 'dish', 'box', 'frame', 'camera', 'spectrometer', 'radar', 'rover', 'drill', 'capsule'];
const DIR = { N: [0, 0, 1], E: [1, 0, 0], S: [0, 0, -1], W: [-1, 0, 0] };
const empty = () => ({ rocket: [], spacecraft: [], payload: [] });
const part = (id) => phys.getPart(id);
let uidN = 0;
function put(build, role, partId, slotId) {
  build[role].push({ uid: 'x' + uidN++, partId, slotId });
  return build;
}

// ---------- şema ----------

test('parts.json: her parçada tags dizisi ve geçerli model', () => {
  for (const p of catalog.parts) {
    assert.ok(Array.isArray(p.tags), p.id);
    for (const t of p.tags) assert.equal(typeof t, 'string');
    assert.ok(MODELS.includes(p.model), p.id + ' model');
  }
});

test('frames.json şeması: en az üç gövde, benzersiz id, sayısal alanlar', () => {
  const frames = framesData.frames;
  assert.ok(frames.length >= 3);
  assert.equal(new Set(frames.map((f) => f.id)).size, frames.length);
  for (const f of frames) {
    assert.ok(Number.isFinite(f.massKg) && f.massKg > 0, f.id);
    assert.ok(Number.isFinite(f.cost) && f.cost > 0, f.id);
    assert.ok(typeof f.name === 'string' && typeof f.desc === 'string');
    assert.ok(!/\d/.test(f.name) && !/\d/.test(f.desc), f.id + ' ad/açıklama sayısız');
    const sh = f.shape;
    assert.ok(Array.isArray(sh.segments) && sh.segments.length > 0);
    for (const s of sh.segments) {
      assert.ok(Number.isFinite(s.y0) && Number.isFinite(s.y1) && s.y1 > s.y0 && s.radius > 0, f.id + ' ' + s.id);
      assert.ok(!/\d/.test(s.name));
    }
    assert.ok(Number.isFinite(sh.nose.y0) && sh.nose.y1 > sh.nose.y0 && sh.nose.radius > 0);
    assert.ok(Number.isInteger(sh.fins) && Number.isInteger(sh.boosters));
    assert.ok(f.slots.length >= 14 && f.slots.length <= 24, f.id + ' yuva sayısı ' + f.slots.length);
  }
  // gövdeler belirgin farklı: kütle, maliyet ve yuva sayıları ayrı
  assert.equal(new Set(frames.map((f) => f.massKg)).size, frames.length);
  assert.equal(new Set(frames.map((f) => f.cost)).size, frames.length);
});

test('yuvalar: benzersiz id, geçerli alanlar, simetrik komşuluk, şekille tutarlı konum', () => {
  for (const f of framesData.frames) {
    const ids = f.slots.map((s) => s.id);
    assert.equal(new Set(ids).size, ids.length, f.id + ' yuva id benzersiz');
    const byId = Object.fromEntries(f.slots.map((s) => [s.id, s]));
    const segs = Object.fromEntries(f.shape.segments.map((s) => [s.id, s]));
    segs.nose = f.shape.nose;
    assert.equal(f.slots.filter((s) => s.zone === 'fuel-line').length, 1, f.id + ' tek yakıt hattı');
    for (const s of f.slots) {
      const at = f.id + '/' + s.id;
      assert.ok(['mount', 'internal', 'surface'].includes(s.kind), at);
      assert.ok(['N', 'E', 'S', 'W', 'C'].includes(s.face), at);
      assert.ok(segs[s.segment], at + ' segment');
      assert.ok(typeof s.name === 'string' && !/\d/.test(s.name), at + ' ad');
      assert.ok(typeof s.zone === 'string');
      assert.ok(Array.isArray(s.accepts) && s.accepts.length > 0, at);
      for (const c of s.accepts) assert.ok(CATEGORIES.has(c), at + ' kategori ' + c);
      if (s.acceptsTags) {
        for (const [c, tags] of Object.entries(s.acceptsTags)) {
          assert.ok(s.accepts.includes(c), at + ' acceptsTags kategorisi');
          for (const t of tags) assert.ok(TAGS.has(t), at + ' etiket ' + t);
        }
      }
      for (const k of ['pos', 'normal']) {
        assert.ok(Array.isArray(s[k]) && s[k].length === 3 && s[k].every(Number.isFinite), at + ' ' + k);
      }
      // komşular: var, kendisi değil, simetrik
      assert.ok(Array.isArray(s.neighbors), at);
      for (const n of s.neighbors) {
        assert.ok(byId[n], at + ' -> ' + n);
        assert.notEqual(n, s.id);
        assert.ok(byId[n].neighbors.includes(s.id), `${at} <-> ${n} simetrik değil`);
      }
      // şekil tutarlılığı
      if (s.kind === 'mount') {
        assert.equal(s.pos[1], 0, at + ' motor tabanda');
        assert.deepEqual(s.normal, [0, -1, 0]);
        assert.deepEqual(s.accepts, ['engine']);
      }
      if (s.kind === 'surface') {
        assert.notEqual(s.face, 'C');
        assert.deepEqual(s.normal, DIR[s.face], at + ' normal yüz yönünde');
        const seg = segs[s.segment];
        const r = Math.hypot(s.pos[0], s.pos[2]);
        assert.ok(Math.abs(r - seg.radius) < 0.01, at + ' yüzey gövde yarıçapında');
        assert.ok(s.pos[1] >= seg.y0 && s.pos[1] <= seg.y1, at + ' segment yüksekliğinde');
        const d = DIR[s.face];
        assert.ok(s.pos[0] * d[0] + s.pos[2] * d[2] > 0, at + ' yüz yönünde');
      }
      if (s.kind === 'internal' && s.face === 'C') {
        const seg = segs[s.segment];
        assert.ok(s.pos[1] >= seg.y0 && s.pos[1] <= seg.y1, at + ' segment içinde');
      }
    }
  }
});

test('yuva konumları: aynı gövdede merkezler arası asgari mesafe, yüzey/iç bölme y çakışması yok', () => {
  const MIN = 0.6;
  for (const f of framesData.frames) {
    for (let i = 0; i < f.slots.length; i++) {
      for (let j = i + 1; j < f.slots.length; j++) {
        const a = f.slots[i], b = f.slots[j];
        const d = Math.hypot(a.pos[0] - b.pos[0], a.pos[1] - b.pos[1], a.pos[2] - b.pos[2]);
        assert.ok(d >= MIN, `${f.id}: ${a.id} ile ${b.id} arası ${d.toFixed(2)} < ${MIN}`);
        // aynı segmentteki yüzey yuvası ile iç bölme aynı yükseklikte olmasın (3B'de izdüşümleri çakışır)
        const pair = [a.kind, b.kind].sort().join('/');
        if (pair === 'internal/surface' && a.segment === b.segment) {
          assert.ok(Math.abs(a.pos[1] - b.pos[1]) >= 0.3, `${f.id}: ${a.id} ile ${b.id} aynı yükseklikte`);
        }
      }
    }
  }
});

test('unfitParts: gövdede hiçbir yuvaya sığmayan parçalar', () => {
  const all = catalog.parts.map((p) => p.id);
  assert.deepEqual(layout.unfitParts('frame-swift', ['rover', 'sample-capsule', 'camera', 'drill', 'radar']), ['rover', 'sample-capsule']);
  assert.deepEqual(layout.unfitParts('frame-cargo', all), []);
  assert.deepEqual(layout.unfitParts('frame-heavy', all), []);
  // Kırlangıç'ta yalnız bulky aletler sığmaz
  assert.deepEqual(layout.unfitParts('frame-swift', all), catalog.parts.filter((p) => p.tags.includes('bulky')).map((p) => p.id));
  // geçersiz gövde → hepsi; bilinmeyen parça listede; sıra korunur
  assert.deepEqual(layout.unfitParts('yok', ['camera', 'rover']), ['camera', 'rover']);
  assert.deepEqual(layout.unfitParts(undefined, ['camera']), ['camera']);
  assert.deepEqual(layout.unfitParts('frame-cargo', ['camera', 'yok', 'rover']), ['yok']);
  assert.deepEqual(layout.unfitParts('frame-cargo', []), []);
  assert.deepEqual(layout.unfitParts('frame-cargo', undefined), []);
  // kurallar/limitler hesaba katılmaz: aynı parça iki kez → ikisi de sığar
  assert.deepEqual(layout.unfitParts('frame-swift', ['camera', 'camera']), []);
});

test('paylaşılan yuvalar (kaos mekaniği) her gövdede var', () => {
  for (const f of framesData.frames) {
    const roles = (s) => new Set(s.accepts.map((c) => ROLE_OF_CAT[c]));
    // iç bölme: uzay aracı + faydalı yük
    assert.ok(f.slots.some((s) => s.kind === 'internal' && roles(s).has('spacecraft') && roles(s).has('payload')), f.id + ' iç paylaşım');
    // dış yüzey: panel + kalkan + anten + (dışarı bakan) alet
    assert.ok(f.slots.some((s) => s.kind === 'surface' && ['solar', 'shield', 'antenna', 'instrument'].every((c) => s.accepts.includes(c))), f.id + ' yüzey paylaşımı');
    // tank + batarya
    assert.ok(f.slots.some((s) => s.accepts.includes('tank') && s.accepts.includes('battery')), f.id + ' tank/batarya');
    // dış yüzeye kamera ve radar takılabilir, rover takılamaz
    const surf = f.slots.filter((s) => s.kind === 'surface');
    for (const id of ['camera', 'radar']) assert.ok(layout.slotOptions(empty(), f.id, 'payload', id).some((o) => surf.some((s) => s.id === o.slotId)), f.id + ' ' + id);
    assert.ok(!layout.slotOptions(empty(), f.id, 'payload', 'rover').some((o) => surf.some((s) => s.id === o.slotId)), f.id + ' rover yüzeyde değil');
  }
});

test('kurallar: en az beş, geçerli seçiciler, sayısız gerekçe', () => {
  const rules = framesData.rules;
  assert.ok(rules.length >= 5);
  assert.equal(new Set(rules.map((r) => r.id)).size, rules.length);
  const matchesAny = (sel) => catalog.parts.some((p) => (sel.tag && p.tags.includes(sel.tag)) || (sel.category && p.category === sel.category) || (sel.partId && p.id === sel.partId));
  for (const r of rules) {
    assert.ok(['same-face', 'neighbors', 'same-segment'].includes(r.scope), r.id);
    assert.ok(matchesAny(r.a) && matchesAny(r.b), r.id + ' seçici bir parçaya uyar');
    assert.ok(typeof r.reason === 'string' && r.reason.length > 20, r.id);
    assert.ok(!/\d/.test(r.reason), r.id + ' gerekçede rakam var');
  }
});

// ---------- arayüz ----------

test('listFrames / getFrame / publicFrame / publicFrameOptions / slotName', () => {
  const full = layout.listFrames();
  assert.equal(full.length, framesData.frames.length);
  assert.ok(full.every((f) => Number.isFinite(f.massKg) && Number.isFinite(f.cost)));
  full[0].massKg = -1; // kopya döner
  assert.notEqual(layout.listFrames()[0].massKg, -1);
  assert.equal(layout.getFrame('yok'), undefined);
  assert.equal(layout.getFrame('frame-swift').id, 'frame-swift');
  assert.equal(layout.publicFrame('yok'), undefined);
  for (const f of framesData.frames) {
    const pub = layout.publicFrame(f.id);
    assert.deepEqual(Object.keys(pub).sort(), ['desc', 'id', 'name', 'shape', 'slots']);
    assert.equal(pub.slots.length, f.slots.length);
    for (const s of pub.slots) {
      assert.deepEqual(Object.keys(s).sort(), ['accepts', 'face', 'id', 'kind', 'name', 'normal', 'pos', 'segment', 'zone']);
    }
    const json = JSON.stringify(pub);
    assert.ok(!json.includes('"massKg"') && !json.includes('"cost"'), f.id);
    assert.equal(layout.slotName(f.id, f.slots[0].id), f.slots[0].name);
  }
  const opts = layout.publicFrameOptions();
  assert.equal(opts.length, framesData.frames.length);
  for (const o of opts) {
    assert.deepEqual(Object.keys(o).sort(), ['desc', 'id', 'name', 'shape']);
    assert.ok(!JSON.stringify(o).includes('"massKg"') && !JSON.stringify(o).includes('"cost"'));
  }
  assert.equal(layout.slotName('frame-swift', 'yok'), '');
  assert.equal(layout.slotName('yok', 'eng-1'), '');
  assert.throws(() => createLayout({ framesData }), TypeError);
});

function expectErr(r, code) {
  assert.equal(r.ok, false);
  assert.equal(r.error, code);
  assert.ok(typeof r.reason === 'string' && r.reason.length > 0 && !/\d/.test(r.reason), code + ': ' + r.reason);
}

test('canPlace: tüm hata kodları', () => {
  const F = 'frame-swift';
  assert.deepEqual(layout.canPlace(empty(), F, 'rocket', 'engine-kestrel', 'eng-1'), { ok: true });
  expectErr(layout.canPlace(empty(), F, 'rocket', 'yok', 'eng-1'), 'INVALID_PART');
  expectErr(layout.canPlace(empty(), F, 'spacecraft', 'engine-kestrel', 'eng-1'), 'NOT_ALLOWED');
  expectErr(layout.canPlace(empty(), F, 'director', 'engine-kestrel', 'eng-1'), 'NOT_ALLOWED');
  const fuel = put(empty(), 'rocket', 'fuel-kerosene', 'fuel');
  expectErr(layout.canPlace(fuel, F, 'rocket', 'fuel-methalox', 'fuel'), 'PART_LIMIT');
  expectErr(layout.canPlace(empty(), F, 'rocket', 'engine-kestrel', 'yok'), 'INVALID_SLOT');
  expectErr(layout.canPlace(empty(), 'yok', 'rocket', 'engine-kestrel', 'eng-1'), 'INVALID_SLOT');
  expectErr(layout.canPlace(empty(), F, 'rocket', 'engine-kestrel', undefined), 'INVALID_SLOT');
  // dolu yuva — başka rolün parçası da yuvayı doldurur
  const b = put(empty(), 'rocket', 'tank-small', 'tank-2');
  expectErr(layout.canPlace(b, F, 'spacecraft', 'battery', 'tank-2'), 'SLOT_TAKEN');
  expectErr(layout.canPlace(b, F, 'rocket', 'tank-large', 'tank-2'), 'SLOT_TAKEN');
  // kategori uyumu
  expectErr(layout.canPlace(empty(), F, 'rocket', 'tank-small', 'eng-1'), 'SLOT_MISMATCH');
  expectErr(layout.canPlace(empty(), F, 'payload', 'rover', 'pl-1'), 'SLOT_MISMATCH'); // dar bölmeye rover sığmaz
  expectErr(layout.canPlace(empty(), F, 'payload', 'camera', 'pl-1'), 'SLOT_MISMATCH'); // kamera dışarı bakmalı
  // kural
  const sun = put(empty(), 'spacecraft', 'solar-small', 's2-e1');
  const c = layout.canPlace(sun, F, 'spacecraft', 'shield-light', 's2-e2');
  expectErr(c, 'PART_CONFLICT');
  assert.equal(c.reason, framesData.rules.find((r) => r.id === 'shield-vs-solar').reason);
  // sıra: limit, yuva kontrollerinden önce gelir
  expectErr(layout.canPlace(fuel, F, 'rocket', 'fuel-methalox', 'yok'), 'PART_LIMIT');
  // yuvasız / geçersiz build girdileri yuva doldurmaz
  const loose = { rocket: [{ uid: 'a', partId: 'engine-kestrel' }, null, { uid: 'b', partId: 'yok', slotId: 'eng-2' }] };
  assert.deepEqual(layout.canPlace(loose, F, 'rocket', 'engine-kestrel', 'eng-2'), { ok: true });
  assert.deepEqual(layout.canPlace({}, F, 'payload', 'camera', 's2-e1'), { ok: true });
});

// Kural için kapsamda olan bir yuva çifti ve uygun iki parça bulur (otomatik, her gövdede dener).
function findRuleSetup(rule) {
  const sel = (s) => catalog.parts.filter((p) => (s.tag && p.tags.includes(s.tag)) || (s.category && p.category === s.category) || (s.partId && p.id === s.partId));
  for (const f of framesData.frames) {
    for (const pa of sel(rule.a)) for (const pb of sel(rule.b)) {
      if (pa.id === pb.id && pa.max < 2) continue;
      const oa = layout.slotOptions(empty(), f.id, pa.role, pa.id).filter((o) => o.ok);
      const ob = layout.slotOptions(empty(), f.id, pb.role, pb.id).filter((o) => o.ok);
      for (const x of oa) for (const y of ob) {
        if (x.slotId === y.slotId) continue;
        const sx = f.slots.find((s) => s.id === x.slotId), sy = f.slots.find((s) => s.id === y.slotId);
        const inScope = rule.scope === 'same-face' ? sx.segment === sy.segment && sx.face === sy.face
          : rule.scope === 'same-segment' ? sx.segment === sy.segment : sx.neighbors.includes(sy.id);
        if (inScope) return { f, pa, pb, sa: sx.id, sb: sy.id };
      }
    }
  }
  return null;
}

for (const rule of framesData.rules) {
  test(`kural ${rule.id}: iki yönde de çalışır`, () => {
    const st = findRuleSetup(rule);
    assert.ok(st, 'kuralın tetiklenebileceği bir yerleşim olmalı');
    // a takılıyken b
    const b1 = put(empty(), st.pa.role, st.pa.id, st.sa);
    const r1 = layout.canPlace(b1, st.f.id, st.pb.role, st.pb.id, st.sb);
    expectErr(r1, 'PART_CONFLICT');
    assert.equal(r1.reason, rule.reason);
    // b takılıyken a
    const b2 = put(empty(), st.pb.role, st.pb.id, st.sb);
    const r2 = layout.canPlace(b2, st.f.id, st.pa.role, st.pa.id, st.sa);
    expectErr(r2, 'PART_CONFLICT');
    assert.equal(r2.reason, rule.reason);
    // kapsam dışında aynı ikili sorunsuz: a'yı kapsam dışı bir yuvaya koyabiliyorsak çakışma yok
    const far = layout.slotOptions(b2, st.f.id, st.pa.role, st.pa.id).filter((o) => o.ok);
    for (const o of far) assert.deepEqual(layout.canPlace(b2, st.f.id, st.pa.role, st.pa.id, o.slotId), { ok: true });
  });
}

test('kural örnekleri: gerçek senaryolar', () => {
  // hidrojen yakıt hattının yanına batarya (ısı kaynağı) konamaz
  const b = put(empty(), 'rocket', 'fuel-hydrolox', 'fuel');
  expectErr(layout.canPlace(b, 'frame-swift', 'spacecraft', 'battery', 'tank-2'), 'PART_CONFLICT');
  assert.deepEqual(layout.canPlace(b, 'frame-swift', 'spacecraft', 'battery', 'pl-1'), { ok: true });
  // motor yanındaki alt yüzeye kamera konamaz (motor varken)
  const e = put(empty(), 'rocket', 'engine-kestrel', 'eng-1');
  expectErr(layout.canPlace(e, 'frame-swift', 'payload', 'camera', 's1-n'), 'PART_CONFLICT');
  assert.deepEqual(layout.canPlace(empty(), 'frame-swift', 'payload', 'camera', 's1-n'), { ok: true });
  // matkap ile kamera aynı bölümde olamaz
  const d = put(empty(), 'payload', 'drill', 'pl-1');
  expectErr(layout.canPlace(d, 'frame-cargo', 'payload', 'camera', 'p-n1'), 'PART_CONFLICT');
  assert.deepEqual(layout.canPlace(d, 'frame-cargo', 'payload', 'camera', 's1-e'), { ok: true });
});

test('slotOptions: yalnız kabul eden yuvalar, durumlarıyla', () => {
  const F = 'frame-swift';
  const frame = framesData.frames.find((f) => f.id === F);
  const opts = layout.slotOptions(empty(), F, 'rocket', 'engine-kestrel');
  assert.deepEqual(opts.map((o) => o.slotId), frame.slots.filter((s) => s.accepts.includes('engine')).map((s) => s.id));
  assert.ok(opts.every((o) => o.ok === true && !('error' in o)));
  // bir yuva dolunca SLOT_TAKEN gerekçesiyle görünür
  const b = put(empty(), 'rocket', 'engine-titan', 'eng-1');
  const o2 = layout.slotOptions(b, F, 'rocket', 'engine-kestrel');
  assert.equal(o2.find((o) => o.slotId === 'eng-1').error, 'SLOT_TAKEN');
  assert.equal(o2.find((o) => o.slotId === 'eng-2').ok, true);
  // paylaşılan yuva: batarya tank bölmesinde de görünür
  assert.ok(layout.slotOptions(empty(), F, 'spacecraft', 'battery').some((o) => o.slotId === 'tank-2'));
  // kural engeli gerekçeyle
  const sun = put(empty(), 'spacecraft', 'solar-small', 's2-e1');
  const sh = layout.slotOptions(sun, F, 'spacecraft', 'shield-light').find((o) => o.slotId === 's2-e2');
  assert.equal(sh.ok, false);
  assert.equal(sh.error, 'PART_CONFLICT');
  assert.ok(sh.reason && !/\d/.test(sh.reason));
  // geçersiz girdiler
  assert.deepEqual(layout.slotOptions(empty(), 'yok', 'rocket', 'engine-kestrel'), []);
  assert.deepEqual(layout.slotOptions(empty(), F, 'rocket', 'yok'), []);
  // yanlış rol: yuvalar yine listelenir ama NOT_ALLOWED
  const wrong = layout.slotOptions(empty(), F, 'payload', 'engine-kestrel');
  assert.ok(wrong.length > 0 && wrong.every((o) => o.error === 'NOT_ALLOWED'));
  // her parça her gövdede en az bir yuva bulur (rover/kapsül hariç Kırlangıç'ta)
  for (const f of framesData.frames) {
    for (const p of catalog.parts) {
      const n = layout.slotOptions(empty(), f.id, p.role, p.id).length;
      if (f.id === 'frame-swift' && p.tags.includes('bulky')) assert.equal(n, 0, p.id);
      else assert.ok(n > 0, f.id + ' ' + p.id);
    }
  }
});
