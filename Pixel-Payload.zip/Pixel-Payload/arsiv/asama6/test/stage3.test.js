'use strict';
// Aşama 3 birim testleri: GO/NO-GO anketi, sonuç, yeniden başlatma + görünümler.
// SAHTE physics / resolveLaunch / computeScore kullanır (Modül D/H'ye bağımlı değil).
// Çalıştır: node --test test/stage3.test.js

const test = require('node:test');
const assert = require('node:assert');

const { PHASES, GameError } = require('../server/constants');
const { createRoomManager } = require('../server/rooms');
const { viewFor } = require('../server/filter');

const NUM_FIELDS = ['massKg', 'cost', 'thrustKN', 'isp', 'powerGenW', 'powerUseW', 'heat', 'heatShield',
  'fuelKg', 'ispMult', 'max', 'requires'];
const SECRET_NUMS = ['7331', '4447', '8123', '9876', '4321', '9991', '5432'];

function mk(id, role, category, name, icon, extra = {}) {
  return {
    id, role, category, name, icon, desc: `${name} açıklaması`,
    massKg: 7331, cost: 4447, powerGenW: 0, powerUseW: 0, thrustKN: 0, isp: 0, heat: 0, heatShield: 0,
    fuelKg: 0, ispMult: 1, max: 3, requires: [], ...extra,
  };
}
const PARTS = [
  mk('eng', 'rocket', 'engine', 'Sahte Motor', 'E', { thrustKN: 8123 }),
  mk('panel', 'spacecraft', 'solar', 'Sahte Panel', 'P'),
  mk('cam', 'payload', 'instrument', 'Sahte Kamera', 'C'),
];

const MISSIONS = [
  { id: 'gorev-a', title: 'GIZLI-BASLIK-A', target: 'GIZLI-HEDEF-A', requiredDeltaV: 4321, requiredInstruments: ['cam'],
    budget: 9991, durationSec: 300, nasaFact: 'GIZLI-FACT-A', nasaReal: 'GIZLI-REAL-A', parMassKg: 5432 },
  { id: 'gorev-b', title: 'GIZLI-BASLIK-B', target: 'GIZLI-HEDEF-B', requiredDeltaV: 4321, requiredInstruments: ['cam'],
    budget: 9991, durationSec: 300, nasaFact: 'GIZLI-FACT-B', nasaReal: 'GIZLI-REAL-B', parMassKg: 5432 },
];

function fakePhysics() {
  const byId = new Map(PARTS.map((p) => [p.id, p]));
  return {
    getPart: (id) => byId.get(id),
    fullCatalog: () => {
      const out = { rocket: [], spacecraft: [], payload: [] };
      for (const p of PARTS) out[p.role].push(structuredClone(p));
      return out;
    },
    publicCatalog: (role) => PARTS.filter((p) => p.role === role)
      .map((p) => ({ id: p.id, name: p.name, icon: p.icon, desc: p.desc, category: p.category })),
    canAdd: (build, role, partId) => {
      const p = byId.get(partId);
      if (!p) return { ok: false, error: 'INVALID_PART' };
      if (p.role !== role) return { ok: false, error: 'NOT_ALLOWED' };
      return { ok: true };
    },
    computeTelemetry: (build, mission) => {
      const n = build.rocket.length + build.spacecraft.length + build.payload.length;
      return {
        massKg: 7331 + n, dryMassKg: 0, fuelKg: 0, thrustKN: 0, isp: 0, twr: 0, deltaV: mission ? 9876 : 0,
        powerGenW: 0, powerUseW: 0, heat: 0, heatShield: 0, spent: 0,
        checks: { twr: n > 0, deltaV: true, power: true, payload: true, heat: true },
        missing: [], overBudget: false, ready: n > 0,
      };
    },
    partStatuses: () => ({}),
  };
}

// Sahte fırlatma: telemetry.checks'e bakar; çağrıları kaydeder
function fakeLaunch() {
  const calls = [];
  const fn = (telemetry, mission) => {
    calls.push({ telemetry, mission });
    const failed = Object.keys(telemetry.checks).filter((k) => !telemetry.checks[k]);
    const success = failed.length === 0;
    return {
      success, outcome: success ? 'success' : 'no-liftoff',
      title: success ? 'Görev başarılı' : 'Roket rampadan kalkamadı',
      reasonText: success ? 'Her şey yolunda' : 'İtki yetersiz', failedChecks: failed, extra: 'GEREKSIZ',
    };
  };
  fn.calls = calls;
  return fn;
}
function fakeScore() {
  const calls = [];
  const fn = (args) => {
    calls.push(args);
    const pts = args.success ? 100 : 0;
    return {
      total: pts * 2, stars: args.success ? 3 : 0, junk: 'GEREKSIZ',
      breakdown: ['base', 'time', 'budget', 'mass', 'undo'].map((key) => ({ key, label: `L-${key}`, points: key === 'base' ? pts * 2 : 0, x: 1 })),
    };
  };
  fn.calls = calls;
  return fn;
}

// Aşama 4: olaysız, gecikmesiz, sabit saat
const config = { events: [], telemetryDelayMs: 0 };
const now = () => 10_000_000;

// Sahte layout (Aşama 5 arayüzü): her kategoriyi kabul eden 30 yuvalı tek gövde; physics.canAdd'i de uygular
const LETTERS = 'abcdefghijklmnopqrstuvwxyz';
const SLOT_IDS = Array.from({ length: 30 }, (_, i) => `yuva-${LETTERS[Math.floor(i / 26)]}${LETTERS[i % 26]}`);
const FRAME_ID = 'govde-deneme';
const slotTaken = (build, slotId) => ['rocket', 'spacecraft', 'payload'].some((r) => build[r].some((it) => it.slotId === slotId));
function fakeLayout(physics) {
  const frame = {
    id: FRAME_ID, name: 'Deneme Gövdesi', desc: 'Deneme gövdesi açıklaması', massKg: 0, cost: 0,
    shape: { segments: [], fins: 0, boosters: 0 },
    slots: SLOT_IDS.map((id) => ({
      id, name: `Yuva ${id.slice(5).toUpperCase()}`, zone: 'bolme', segment: 'kademe', face: 'C', kind: 'internal',
      accepts: ['engine', 'tank', 'structure', 'solar', 'computer', 'instrument'], pos: [0, 0, 0], normal: [0, 1, 0], neighbors: [],
    })),
  };
  const canPlace = (build, frameId, role, partId, slotId) => {
    const c = physics.canAdd(build, role, partId);
    if (!c || !c.ok) return { ok: false, error: c.error, reason: 'Sahte gerekçe' };
    if (frameId !== FRAME_ID || !SLOT_IDS.includes(slotId)) return { ok: false, error: 'INVALID_SLOT', reason: 'Yuva yok' };
    if (slotTaken(build, slotId)) return { ok: false, error: 'SLOT_TAKEN', reason: 'Yuva dolu' };
    return { ok: true };
  };
  return {
    listFrames: () => [structuredClone(frame)],
    getFrame: (id) => (id === FRAME_ID ? frame : undefined),
    publicFrame: (id) => (id === FRAME_ID ? structuredClone(frame) : undefined),
    publicFrameOptions: () => [{ id: frame.id, name: frame.name, desc: frame.desc, shape: structuredClone(frame.shape) }],
    canPlace,
    slotOptions: (build, frameId, role, partId) => SLOT_IDS.map((slotId) => ({ slotId, ...canPlace(build, frameId, role, partId, slotId) })),
    slotName: (frameId, slotId) => (frame.slots.find((s) => s.id === slotId) || {}).name,
  };
}
// İlk boş yuva (oda yoksa ilk yuva)
function free(m, code) {
  const room = m.getRoom(code);
  return SLOT_IDS.find((id) => !room || !slotTaken(room.build, id));
}
function deps() {
  const physics = fakePhysics();
  return { physics, layout: fakeLayout(physics) };
}

const VL = fakeLayout(fakePhysics()); // görünüm için (sahte layout durumsuz)

function throwsCode(fn, code) {
  assert.throws(fn, (err) => err instanceof GameError && err.code === code && err.message.length > 0, `beklenen hata: ${code}`);
}

// p[0]=director, p[1]=rocket, p[2]=spacecraft, p[3]=payload
function started({ missions = MISSIONS, rng = () => 0, frame = true } = {}) {
  const physics = fakePhysics();
  const resolveLaunch = fakeLaunch();
  const computeScore = fakeScore();
  const m = createRoomManager({ missions, physics, layout: fakeLayout(physics), resolveLaunch, computeScore, rng, now, config });
  const { room, player: p0 } = m.createRoom('Ayşe');
  const p = [p0, m.joinRoom(room.code, 'Bora').player, m.joinRoom(room.code, 'Cem').player, m.joinRoom(room.code, 'Deniz').player];
  ['director', 'rocket', 'spacecraft', 'payload'].forEach((r, i) => m.selectRole(room.code, p[i].id, r));
  if (frame) m.selectFrame(room.code, p[0].id, FRAME_ID); // Aşama 5: setup → building
  return { m, room, p, physics, layout: fakeLayout(physics), resolveLaunch, computeScore, code: room.code };
}
const lastLog = (room) => room.log[room.log.length - 1];

function allGo(s) {
  s.m.vote(s.code, s.p[1].id, 'go');
  s.m.vote(s.code, s.p[2].id, 'go');
  return s.m.vote(s.code, s.p[3].id, 'go');
}

test('zorunlu bağımlılıklar ve yeni oda alanları', () => {
  const physics = fakePhysics();
  assert.throws(() => createRoomManager({ missions: MISSIONS, physics }), TypeError);
  assert.throws(() => createRoomManager({ missions: MISSIONS, physics, layout: fakeLayout(physics), resolveLaunch: () => ({}) }), TypeError);
  const m = createRoomManager({ missions: MISSIONS, physics, layout: fakeLayout(physics), resolveLaunch: fakeLaunch(), computeScore: fakeScore(), now, config });
  const { room } = m.createRoom('A');
  assert.strictEqual(room.poll, null);
  assert.strictEqual(room.result, null);
  assert.strictEqual(room.undoUsed, 0);
  assert.strictEqual(PHASES.POLL, 'poll');
  assert.strictEqual(PHASES.RESULT, 'result');
});

test('startPoll / cancelPoll akışı ve log', () => {
  const { m, room, p, code } = started();
  assert.strictEqual(m.startPoll(code, p[0].id), room);
  assert.strictEqual(room.phase, 'poll');
  assert.deepStrictEqual(room.poll.votes, { rocket: null, spacecraft: null, payload: null });
  assert.strictEqual(typeof room.poll.startedAt, 'number');
  assert.strictEqual(lastLog(room).kind, 'poll');
  assert.strictEqual(lastLog(room).text, 'Yönetici GO/NO-GO anketini başlattı');
  assert.strictEqual(lastLog(room).role, 'director');

  assert.strictEqual(m.cancelPoll(code, p[0].id), room);
  assert.strictEqual(room.phase, 'building');
  assert.strictEqual(room.poll, null);
  assert.strictEqual(lastLog(room).kind, 'poll');
  assert.strictEqual(lastLog(room).text, 'Yönetici anketi iptal etti');
});

test('yetki ve faz hataları', () => {
  const { m, room, p, code } = started();
  // building fazı
  throwsCode(() => m.startPoll(code, p[1].id), 'NOT_ALLOWED');
  throwsCode(() => m.startPoll(code, 'yabanci'), 'NOT_IN_ROOM');
  throwsCode(() => m.cancelPoll(code, p[0].id), 'WRONG_PHASE');
  throwsCode(() => m.vote(code, p[1].id, 'go'), 'WRONG_PHASE');
  throwsCode(() => m.restart(code, p[0].id), 'WRONG_PHASE');
  // poll fazı
  m.startPoll(code, p[0].id);
  throwsCode(() => m.startPoll(code, p[0].id), 'WRONG_PHASE');
  throwsCode(() => m.cancelPoll(code, p[1].id), 'NOT_ALLOWED');
  throwsCode(() => m.vote(code, p[0].id, 'go'), 'NOT_ALLOWED');
  throwsCode(() => m.vote(code, 'yabanci', 'go'), 'NOT_IN_ROOM');
  for (const bad of [undefined, null, 'GO', 'evet', 1, {}]) throwsCode(() => m.vote(code, p[1].id, bad), 'BAD_REQUEST');
  throwsCode(() => m.restart(code, p[0].id), 'WRONG_PHASE');
  // lobi
  const m2 = createRoomManager({ missions: MISSIONS, ...deps(), resolveLaunch: fakeLaunch(), computeScore: fakeScore(), now, config });
  const { room: r2, player } = m2.createRoom('X');
  m2.selectRole(r2.code, player.id, 'director');
  throwsCode(() => m2.startPoll(r2.code, player.id), 'WRONG_PHASE');
  assert.strictEqual(room.phase, 'poll');
});

test('poll fazında parça kilidi (WRONG_PHASE)', () => {
  const { m, room, p, code } = started();
  m.addPart(code, p[1].id, 'eng', free(m, code));
  const uid = room.build.rocket[0].uid;
  m.startPoll(code, p[0].id);
  throwsCode(() => m.addPart(code, p[1].id, 'eng', free(m, code)), 'WRONG_PHASE');
  throwsCode(() => m.removePart(code, p[1].id, uid), 'WRONG_PHASE');
  assert.strictEqual(room.build.rocket.length, 1);
  m.cancelPoll(code, p[0].id);
  m.addPart(code, p[1].id, 'eng', free(m, code));
  assert.strictEqual(room.build.rocket.length, 2);
});

test('oy değiştirilebilir; GO logu; NO-GO anketi bitirir', () => {
  const { m, room, p, code } = started();
  m.startPoll(code, p[0].id);
  m.vote(code, p[1].id, 'go');
  assert.strictEqual(room.poll.votes.rocket, 'go');
  assert.strictEqual(lastLog(room).text, 'Roket & Yakıt GO dedi');
  assert.strictEqual(lastLog(room).kind, 'poll');
  const n = room.log.length;
  m.vote(code, p[1].id, 'go'); // aynı oy tekrar: log şişmez
  assert.strictEqual(room.log.length, n);
  m.vote(code, p[2].id, 'go');
  assert.strictEqual(room.phase, 'poll');
  m.vote(code, p[3].id, 'nogo');
  assert.strictEqual(room.phase, 'building');
  assert.strictEqual(room.poll, null);
  assert.strictEqual(room.result, null);
  assert.strictEqual(lastLog(room).text, 'Faydalı Yük NO-GO dedi — anket iptal');
  assert.strictEqual(lastLog(room).kind, 'poll');
  assert.strictEqual(lastLog(room).role, 'payload');
});

test('bağlantısı kopuk çalışan oy veremez; anket bekler, yönetici iptal edebilir', () => {
  const { m, room, p, code } = started();
  m.startPoll(code, p[0].id);
  m.vote(code, p[1].id, 'go');
  m.vote(code, p[2].id, 'go');
  m.setConnected(code, p[3].id, false);
  throwsCode(() => m.vote(code, p[3].id, 'go'), 'NOT_ALLOWED');
  assert.strictEqual(room.phase, 'poll');
  assert.strictEqual(room.poll.votes.payload, null);
  m.cancelPoll(code, p[0].id);
  assert.strictEqual(room.phase, 'building');
});

test('3 GO -> result; resolveLaunch/computeScore doğru çağrılır', () => {
  const s = started();
  const { m, room, p, code, resolveLaunch, computeScore } = s;
  m.addPart(code, p[1].id, 'eng', free(m, code));
  m.addPart(code, p[2].id, 'panel', free(m, code));
  m.addPart(code, p[3].id, 'cam', free(m, code));
  m.startPoll(code, p[0].id);
  m.vote(code, p[1].id, 'nogo'); // önce nogo -> building
  m.startPoll(code, p[0].id);
  m.vote(code, p[1].id, 'go');
  m.vote(code, p[2].id, 'go');
  assert.strictEqual(resolveLaunch.calls.length, 0);
  assert.strictEqual(m.vote(code, p[3].id, 'go'), room);

  assert.strictEqual(room.phase, 'result');
  assert.strictEqual(room.poll, null);
  assert.strictEqual(resolveLaunch.calls.length, 1);
  assert.deepStrictEqual(resolveLaunch.calls[0].mission, room.mission);
  assert.strictEqual(computeScore.calls.length, 1);
  const args = computeScore.calls[0];
  assert.deepStrictEqual(Object.keys(args).sort(), ['mission', 'success', 'telemetry', 'timeLeftSec', 'undoUsed']);
  assert.strictEqual(args.success, true);
  assert.strictEqual(args.undoUsed, 0);
  assert.strictEqual(args.timeLeftSec, 300); // Aşama 4: sabit saatte 1. pencerenin tamamı kaldı

  const r = room.result;
  assert.strictEqual(r.success, true);
  assert.strictEqual(r.outcome, 'success');
  assert.strictEqual(r.title, 'Görev başarılı');
  assert.deepStrictEqual(r.failedChecks, []);
  assert.strictEqual(r.score.total, 200);
  assert.strictEqual(r.score.stars, 3);
  assert.deepStrictEqual(r.score.breakdown.map((b) => b.key), ['base', 'time', 'budget', 'mass', 'undo']);
  assert.ok(!('extra' in r) && !('junk' in r.score));
  // derin kopyalar
  assert.deepStrictEqual(r.mission, room.mission);
  assert.notStrictEqual(r.mission, room.mission);
  assert.deepStrictEqual(r.telemetry, room.telemetry);
  assert.notStrictEqual(r.telemetry, room.telemetry);
  assert.deepStrictEqual(r.build, {
    rocket: [{ name: 'Sahte Motor', icon: 'E', slotName: 'Yuva AA' }], spacecraft: [{ name: 'Sahte Panel', icon: 'P', slotName: 'Yuva AB' }],
    payload: [{ name: 'Sahte Kamera', icon: 'C', slotName: 'Yuva AC' }],
  });
  assert.deepStrictEqual(r.frame, { name: 'Deneme Gövdesi' });
  assert.strictEqual(typeof r.endedAt, 'number');
  assert.strictEqual(lastLog(room).kind, 'poll');
  assert.strictEqual(lastLog(room).text, 'Fırlatma: Görev başarılı');

  // result fazında her şey kilitli
  throwsCode(() => m.addPart(code, p[1].id, 'eng', free(m, code)), 'WRONG_PHASE');
  throwsCode(() => m.vote(code, p[1].id, 'go'), 'WRONG_PHASE');
  throwsCode(() => m.startPoll(code, p[0].id), 'WRONG_PHASE');
  throwsCode(() => m.restart(code, p[1].id), 'NOT_ALLOWED');
});

test('başarısız fırlatma: göstergeler yeşil değilken de anket başlatılabilir', () => {
  const s = started();
  s.m.startPoll(s.code, s.p[0].id);
  allGo(s);
  assert.strictEqual(s.room.phase, 'result');
  assert.strictEqual(s.room.result.success, false);
  assert.strictEqual(s.room.result.outcome, 'no-liftoff');
  assert.deepStrictEqual(s.room.result.failedChecks, ['twr']);
  assert.strictEqual(s.room.result.score.total, 0);
  assert.strictEqual(s.computeScore.calls[0].success, false);
});

test('restart: temiz durum, farklı görev, roller korunur', () => {
  const s = started();
  const { m, room, p, code } = s;
  m.addPart(code, p[1].id, 'eng', free(m, code));
  room.undoLeft = 1;
  room.undoUsed = 2;
  m.startPoll(code, p[0].id);
  allGo(s);
  const prevId = room.mission.id;
  assert.strictEqual(m.restart(code, p[0].id), room);
  assert.strictEqual(room.phase, 'setup'); // Aşama 5: yeni turda gövde yeniden seçilir
  assert.strictEqual(room.frameId, null);
  assert.strictEqual(room.timer, null);
  assert.deepStrictEqual(room.build, { rocket: [], spacecraft: [], payload: [] });
  assert.strictEqual(room.poll, null);
  assert.strictEqual(room.result, null);
  assert.strictEqual(room.undoLeft, 3);
  assert.strictEqual(room.undoUsed, 0);
  assert.notStrictEqual(room.mission.id, prevId);
  assert.strictEqual(room.log.length, 1);
  assert.strictEqual(room.log[0].text, 'Yeni tur başladı');
  assert.strictEqual(room.log[0].kind, 'system');
  m.selectFrame(code, p[0].id, FRAME_ID);
  assert.strictEqual(room.phase, 'building');
  assert.strictEqual(room.telemetry.ready, false); // yeniden hesaplandı (boş build)
  assert.deepStrictEqual(['director', 'rocket', 'spacecraft', 'payload'], p.map((x) => room.players[x.id].role));
  // ikinci tur oynanabilir
  m.addPart(code, p[1].id, 'eng', free(m, code));
  m.startPoll(code, p[0].id);
  assert.strictEqual(room.phase, 'poll');
});

test('restart: tek görev varsa aynısı atanır', () => {
  const s = started({ missions: [MISSIONS[0]] });
  s.m.startPoll(s.code, s.p[0].id);
  allGo(s);
  s.m.restart(s.code, s.p[0].id);
  assert.strictEqual(s.room.mission.id, 'gorev-a');
  assert.strictEqual(s.room.phase, 'setup');
});

test('görünüm poll: yönetici ve çalışan; feed poll girdileri içerir', () => {
  const { m, room, p, physics, code } = started();
  m.addPart(code, p[1].id, 'eng', free(m, code));
  m.startPoll(code, p[0].id);
  m.vote(code, p[2].id, 'go');

  const d = viewFor(room, p[0].id, physics, VL);
  assert.strictEqual(d.phase, 'poll');
  assert.deepStrictEqual(d.poll, { votes: { rocket: null, spacecraft: 'go', payload: null } });
  for (const k of ['mission', 'telemetry', 'build', 'catalog', 'log', 'undoLeft']) assert.ok(k in d, k);
  assert.ok(!('result' in d));

  const w = viewFor(room, p[2].id, physics, VL);
  assert.deepStrictEqual(w.poll, { votes: { rocket: null, spacecraft: 'go', payload: null }, myVote: 'go' });
  assert.strictEqual(viewFor(room, p[1].id, physics, VL).poll.myVote, null);
  assert.strictEqual(w.missionLabel, 'GİZLİ');
  for (const k of ['catalog', 'myParts', 'others', 'feed']) assert.ok(k in w, k);
  const texts = w.feed.map((e) => e.text);
  assert.ok(texts.includes('Yönetici GO/NO-GO anketini başlattı'));
  assert.ok(texts.includes('Uzay Aracı GO dedi'));
  assert.ok(texts.includes('Roket & Yakıt: Sahte Motor → Yuva AA'));
  assert.ok(!texts.some((x) => /gövdeyi seçti/.test(x))); // system logu feed'e girmez
  assert.ok(!texts.includes('Oyun başladı'));
  // building'de poll anahtarı yok
  m.cancelPoll(code, p[0].id);
  assert.ok(!('poll' in viewFor(room, p[1].id, physics, VL)));
  assert.ok(!('poll' in viewFor(room, p[0].id, physics, VL)));
  assert.ok(viewFor(room, p[1].id, physics, VL).feed.some((e) => e.text === 'Yönetici anketi iptal etti'));
});

// Çalışanın JSON'unda görev/sayı/başka playerId olmadığını doğrula
function assertWorkerClean(room, me, players, physics) {
  const v = viewFor(room, me.id, physics, VL);
  for (const k of ['mission', 'telemetry', 'log', 'undoLeft', 'build', 'result']) assert.ok(!(k in v), `${k} anahtarı var`);
  let json = JSON.stringify(v).split(me.id).join('<ME>');
  for (const uid of room.build[me.role].map((it) => it.uid)) json = json.split(uid).join('<UID>');
  for (const f of NUM_FIELDS) assert.ok(!json.includes(`"${f}"`), `${f} alanı sızdı`);
  for (const n of SECRET_NUMS) assert.ok(!json.includes(n), `sayı sızdı: ${n}`);
  for (const s of ['GIZLI', 'gorev-a', 'gorev-b', 'requiredDeltaV', 'budget', 'checks', 'parMassKg']) assert.ok(!json.includes(s), `sızdı: ${s}`);
  for (const o of players) if (o.id !== me.id) assert.ok(!json.includes(o.id), 'başka oyuncunun playerId sızdı');
  if (v.poll) assert.deepStrictEqual(Object.keys(v.poll).sort(), ['myVote', 'votes']);
  return v;
}

test('GÜVENLİK: building ve poll fazlarında çalışana görev/sayı sızmaz', () => {
  const { m, room, p, physics, code } = started();
  m.addPart(code, p[1].id, 'eng', free(m, code));
  m.addPart(code, p[2].id, 'panel', free(m, code));
  for (const me of p.slice(1)) assertWorkerClean(room, me, p, physics);
  m.startPoll(code, p[0].id);
  m.vote(code, p[1].id, 'go');
  for (const me of p.slice(1)) assertWorkerClean(room, me, p, physics);
  // yönetici: başka playerId yok
  const dj = JSON.stringify(viewFor(room, p[0].id, physics, VL));
  for (const o of p.slice(1)) assert.ok(!dj.includes(o.id));
});

test('görünüm result: herkese aynı result, diğer alanlar yok, sayılar açık', () => {
  const s = started();
  const { m, room, p, physics, code } = s;
  m.addPart(code, p[1].id, 'eng', free(m, code));
  m.startPoll(code, p[0].id);
  allGo(s);

  const views = p.map((x) => viewFor(room, x.id, physics, VL));
  for (const [i, v] of views.entries()) {
    assert.deepStrictEqual(Object.keys(v).sort(), ['code', 'phase', 'players', 'result', 'roles', 'you']);
    assert.strictEqual(v.phase, 'result');
    assert.deepStrictEqual(v.result, views[0].result);
    assert.notStrictEqual(v.result, room.result);
    assert.notStrictEqual(v.result.mission, room.result.mission);
    assert.deepStrictEqual(Object.keys(v.result).sort(),
      ['build', 'endedAt', 'events', 'failedChecks', 'frame', 'mission', 'outcome', 'reasonText', 'score', 'success', 'telemetry',
        'timeLeftSec', 'title', 'undoUsed', 'window']);
    for (const b of v.result.score.breakdown) assert.deepStrictEqual(Object.keys(b).sort(), ['key', 'label', 'points']);
    const json = JSON.stringify(v).split(p[i].id).join('<ME>');
    // sonuçta görev ve sayılar açık
    for (const sx of ['GIZLI-BASLIK-A', 'GIZLI-REAL-A', 'requiredDeltaV', '9876', '7332']) assert.ok(json.includes(sx), `eksik: ${sx}`);
    // yine de başka playerId ve parça kimliği/uid yok
    for (const o of p) if (o.id !== p[i].id) assert.ok(!json.includes(o.id), 'başka oyuncunun playerId sızdı');
    assert.ok(!json.includes('"uid"') && !json.includes('"partId"'));
    assert.ok(!json.includes('GEREKSIZ'));
  }
  assert.deepStrictEqual(views[0].result.build.rocket, [{ name: 'Sahte Motor', icon: 'E', slotName: 'Yuva AA' }]);
  assert.deepStrictEqual(views[0].result.frame, { name: 'Deneme Gövdesi' });
});

test('restart sonrası çalışan görünümü yeniden gizli', () => {
  const s = started();
  const { m, room, p, physics, code } = s;
  m.startPoll(code, p[0].id);
  allGo(s);
  m.restart(code, p[0].id);
  // setup: yalnız gövde seçenekleri + etiket
  for (const me of p.slice(1)) {
    const v = assertWorkerClean(room, me, p, physics);
    assert.deepStrictEqual(Object.keys(v).sort(), ['code', 'frameOptions', 'missionLabel', 'phase', 'players', 'roles', 'you']);
  }
  assert.strictEqual(viewFor(room, p[0].id, physics, VL).mission.id, 'gorev-b');
  m.selectFrame(code, p[0].id, FRAME_ID);
  for (const me of p.slice(1)) {
    const v = assertWorkerClean(room, me, p, physics);
    assert.strictEqual(v.missionLabel, 'GİZLİ');
    assert.deepStrictEqual(v.myParts, []);
    assert.ok(!('poll' in v));
    assert.ok(!v.feed.some((e) => /Fırlatma/.test(e.text)));
  }
  const d = viewFor(room, p[0].id, physics, VL);
  assert.strictEqual(d.mission.id, 'gorev-b');
  assert.ok(!('result' in d));
  assert.strictEqual(d.log.length, 2); // 'Yeni tur başladı' + gövde seçimi
});
