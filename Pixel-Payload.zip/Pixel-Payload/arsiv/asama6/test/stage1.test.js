'use strict';
// Aşama 1 birim testleri: rooms + filter. Çalıştır: node --test test/

const test = require('node:test');
const assert = require('node:assert');
const path = require('path');

const { ROLES, WORKER_ROLES, PHASES, MAX_PLAYERS, GameError } = require('../server/constants');
const { createRoomManager } = require('../server/rooms');
const { viewFor } = require('../server/filter');
const missions = require(path.join(__dirname, '..', 'data', 'missions.json'));

// Sahte physics (Aşama 2 arayüzü): parçasız, sabit telemetri — Modül D'ye bağımlı değil
const physics = {
  getPart: () => undefined,
  fullCatalog: () => ({ rocket: [], spacecraft: [], payload: [] }),
  publicCatalog: () => [],
  canAdd: () => ({ ok: false, error: 'INVALID_PART' }),
  computeTelemetry: () => ({ massKg: 0, twr: 0, deltaV: 0, powerGenW: 0, powerUseW: 0, heat: 0, spent: 0 }),
  partStatuses: () => ({}),
};
// Sahte fırlatma/puan (Aşama 3 arayüzü; Modül H'ye bağımlı değil)
const resolveLaunch = () => ({ success: false, outcome: 'no-liftoff', title: 'x', reasonText: 'x', failedChecks: ['twr'] });
const computeScore = () => ({ total: 0, stars: 0, breakdown: [] });
// Aşama 4: olaysız, gecikmesiz, sabit saat (rakam sızıntı testlerini rastgele zaman damgası bozmasın)
const config = { events: [], telemetryDelayMs: 0 };
const now = () => 10_000_000;

// Sahte layout (Aşama 5 arayüzü): her kategoriyi kabul eden 30 yuvalı tek gövde; physics.canAdd'i de uygular
const LETTERS = 'abcdefghijklmnopqrstuvwxyz';
const SLOT_IDS = Array.from({ length: 30 }, (_, i) => `yuva-${LETTERS[Math.floor(i / 26)]}${LETTERS[i % 26]}`);
const FRAME_ID = 'govde-deneme';
const slotTaken = (build, slotId) => ['rocket', 'spacecraft', 'payload'].some((r) => build[r].some((it) => it.slotId === slotId));
function fakeLayout(physics) {
  const frame = {
    id: FRAME_ID, name: 'Deneme Gövdesi', desc: 'Deneme gövdesi açıklaması', massKg: 0, cost: 0,
    shape: { segments: [], fins: 0, boosters: 0 },
    slots: SLOT_IDS.map((id) => ({
      id, name: `Yuva ${id.slice(5).toUpperCase()}`, zone: 'bolme', segment: 'kademe', face: 'C', kind: 'internal',
      accepts: ['engine', 'tank', 'structure', 'solar', 'computer', 'instrument'], pos: [0, 0, 0], normal: [0, 1, 0], neighbors: [],
    })),
  };
  const canPlace = (build, frameId, role, partId, slotId) => {
    const c = physics.canAdd(build, role, partId);
    if (!c || !c.ok) return { ok: false, error: c.error, reason: 'Sahte gerekçe' };
    if (frameId !== FRAME_ID || !SLOT_IDS.includes(slotId)) return { ok: false, error: 'INVALID_SLOT', reason: 'Yuva yok' };
    if (slotTaken(build, slotId)) return { ok: false, error: 'SLOT_TAKEN', reason: 'Yuva dolu' };
    return { ok: true };
  };
  return {
    listFrames: () => [structuredClone(frame)],
    getFrame: (id) => (id === FRAME_ID ? frame : undefined),
    publicFrame: (id) => (id === FRAME_ID ? structuredClone(frame) : undefined),
    publicFrameOptions: () => [{ id: frame.id, name: frame.name, desc: frame.desc, shape: structuredClone(frame.shape) }],
    canPlace,
    slotOptions: (build, frameId, role, partId) => SLOT_IDS.map((slotId) => ({ slotId, ...canPlace(build, frameId, role, partId, slotId) })),
    slotName: (frameId, slotId) => (frame.slots.find((s) => s.id === slotId) || {}).name,
  };
}
// İlk boş yuva (oda yoksa ilk yuva)
function free(m, code) {
  const room = m.getRoom(code);
  return SLOT_IDS.find((id) => !room || !slotTaken(room.build, id));
}

const VL = fakeLayout(physics); // görünüm için

function throwsCode(fn, code) {
  assert.throws(fn, (err) => err instanceof GameError && err.code === code);
}

// 4 oyunculu, 4 rolü dolu (başlamış) oda kur
function startedRoom(rng, frame = true) {
  const m = createRoomManager({ missions, physics, layout: fakeLayout(physics), resolveLaunch, computeScore, now, config, rng });
  const { room, player: p0 } = m.createRoom('Ayşe');
  const p1 = m.joinRoom(room.code, 'Bora').player;
  const p2 = m.joinRoom(room.code, 'Cem').player;
  const p3 = m.joinRoom(room.code, 'Deniz').player;
  m.selectRole(room.code, p0.id, 'director');
  m.selectRole(room.code, p1.id, 'rocket');
  m.selectRole(room.code, p2.id, 'spacecraft');
  m.selectRole(room.code, p3.id, 'payload');
  if (frame) m.selectFrame(room.code, p0.id, FRAME_ID); // Aşama 5: setup → building
  return { m, room, players: [p0, p1, p2, p3] };
}

test('sabitler', () => {
  assert.deepStrictEqual(ROLES, ['director', 'rocket', 'spacecraft', 'payload']);
  assert.deepStrictEqual(WORKER_ROLES, ['rocket', 'spacecraft', 'payload']);
  assert.deepStrictEqual(PHASES, { LOBBY: 'lobby', SETUP: 'setup', BUILDING: 'building', POLL: 'poll', RESULT: 'result' });
  assert.strictEqual(MAX_PLAYERS, 4);
  const e = new GameError('ROOM_FULL', 'Oda dolu');
  assert.ok(e instanceof Error);
  assert.strictEqual(e.code, 'ROOM_FULL');
  assert.strictEqual(e.message, 'Oda dolu');
});

test('görev kartları biçimi', () => {
  assert.ok(Array.isArray(missions) && missions.length >= 3);
  for (const c of missions) {
    for (const k of ['id', 'title', 'target', 'nasaFact', 'nasaReal']) assert.strictEqual(typeof c[k], 'string', k);
    for (const k of ['requiredDeltaV', 'budget', 'durationSec']) assert.strictEqual(typeof c[k], 'number', k);
    assert.ok(Array.isArray(c.requiredInstruments) && c.requiredInstruments.length > 0);
  }
});

test('oda oluşturma: kod biçimi ve oda yapısı', () => {
  const m = createRoomManager({ missions, physics, layout: fakeLayout(physics), resolveLaunch, computeScore, now, config });
  for (let i = 0; i < 50; i++) {
    const { room, player } = m.createRoom('  Ali  ');
    assert.match(room.code, /^[A-HJ-NP-Z]{4}$/);
    assert.strictEqual(player.name, 'Ali');
    assert.strictEqual(player.role, null);
    assert.strictEqual(player.connected, true);
    assert.match(player.id, /^[0-9a-f-]{36}$/);
    assert.strictEqual(room.phase, 'lobby');
    assert.strictEqual(room.mission, null);
    assert.deepStrictEqual(room.build, { rocket: [], spacecraft: [], payload: [] });
    assert.strictEqual(room.undoLeft, 3);
    assert.strictEqual(m.getRoom(room.code), room);
    assert.strictEqual(m.getPlayer(room.code, player.id), player);
  }
});

test('isim doğrulama', () => {
  const m = createRoomManager({ missions, physics, layout: fakeLayout(physics), resolveLaunch, computeScore, now, config });
  throwsCode(() => m.createRoom(''), 'NAME_REQUIRED');
  throwsCode(() => m.createRoom('   '), 'NAME_REQUIRED');
  throwsCode(() => m.createRoom('x'.repeat(17)), 'NAME_REQUIRED');
  throwsCode(() => m.createRoom(undefined), 'NAME_REQUIRED');
  assert.ok(m.createRoom('x'.repeat(16)));
});

test('katılma: büyük/küçük harf, bulunamayan oda, dolu oda', () => {
  const m = createRoomManager({ missions, physics, layout: fakeLayout(physics), resolveLaunch, computeScore, now, config });
  const { room } = m.createRoom('A');
  const { player } = m.joinRoom(` ${room.code.toLowerCase()} `, 'B');
  assert.ok(room.players[player.id]);
  m.joinRoom(room.code, 'C');
  m.joinRoom(room.code, 'D');
  throwsCode(() => m.joinRoom(room.code, 'E'), 'ROOM_FULL');
  throwsCode(() => m.joinRoom('ZZZZ' === room.code ? 'YYYY' : 'ZZZZ', 'E'), 'ROOM_NOT_FOUND');
  throwsCode(() => m.joinRoom(room.code, ''), 'NAME_REQUIRED');
  assert.strictEqual(m.playerIds(room.code).length, 4);
});

test('rol seçme: çakışma, geçersiz rol, bırakma', () => {
  const m = createRoomManager({ missions, physics, layout: fakeLayout(physics), resolveLaunch, computeScore, now, config });
  const { room, player: a } = m.createRoom('A');
  const b = m.joinRoom(room.code, 'B').player;
  m.selectRole(room.code, a.id, 'rocket');
  throwsCode(() => m.selectRole(room.code, b.id, 'rocket'), 'ROLE_TAKEN');
  throwsCode(() => m.selectRole(room.code, b.id, 'kaptan'), 'INVALID_ROLE');
  throwsCode(() => m.selectRole(room.code, 'yok-boyle-biri', 'payload'), 'NOT_IN_ROOM');
  throwsCode(() => m.selectRole('QQQQ' === room.code ? 'WWWW' : 'QQQQ', a.id, 'payload'), 'ROOM_NOT_FOUND');
  m.selectRole(room.code, a.id, 'rocket'); // kendi rolünü tekrar seçmek hata değil
  m.selectRole(room.code, a.id, null);
  assert.strictEqual(a.role, null);
  m.selectRole(room.code, b.id, 'rocket');
  assert.strictEqual(b.role, 'rocket');
  m.selectRole(room.code, b.id, 'director'); // rol değiştirme
  assert.strictEqual(b.role, 'director');
  assert.strictEqual(room.phase, 'lobby');
});

test('4 rol dolunca otomatik başlama', () => {
  const { m, room, players } = startedRoom(() => 0, false);
  assert.strictEqual(room.phase, 'setup'); // Aşama 5: önce gövde seçimi
  assert.strictEqual(room.frameId, null);
  assert.deepStrictEqual(room.mission, missions[0]);
  assert.notStrictEqual(room.mission, missions[0]); // kopya olmalı
  assert.ok(room.log.some((e) => e.text === 'Oyun başladı'));
  throwsCode(() => m.selectRole(room.code, players[1].id, null), 'GAME_STARTED');
  throwsCode(() => m.joinRoom(room.code, 'Geç'), 'GAME_STARTED');
  m.selectFrame(room.code, players[0].id, FRAME_ID);
  assert.strictEqual(room.phase, 'building');
  assert.strictEqual(room.frameId, FRAME_ID);
});

test('bağlantı/ayrılma: lobide silinir, oyunda koltuk korunur', () => {
  const m = createRoomManager({ missions, physics, layout: fakeLayout(physics), resolveLaunch, computeScore, now, config });
  const { room, player: a } = m.createRoom('A');
  const b = m.joinRoom(room.code, 'B').player;
  m.selectRole(room.code, b.id, 'payload');
  assert.strictEqual(m.setConnected(room.code, b.id, false), room);
  assert.strictEqual(m.getPlayer(room.code, b.id), undefined);
  assert.strictEqual(m.removePlayer(room.code, a.id), undefined); // oda boşaldı -> silindi
  assert.strictEqual(m.getRoom(room.code), undefined);
  assert.deepStrictEqual(m.playerIds(room.code), []);

  const s = startedRoom();
  const p = s.players[2];
  assert.strictEqual(s.m.setConnected(s.room.code, p.id, false), s.room);
  assert.strictEqual(p.connected, false);
  assert.strictEqual(p.role, 'spacecraft');
  s.m.setConnected(s.room.code, p.id, true);
  assert.strictEqual(p.connected, true);
  assert.strictEqual(s.m.removePlayer(s.room.code, p.id), s.room);
  assert.strictEqual(p.connected, false);
  assert.strictEqual(s.m.playerIds(s.room.code).length, 4);
  s.m.deleteRoom(s.room.code);
  assert.strictEqual(s.m.getRoom(s.room.code), undefined);
});

test('viewFor: odada olmayan oyuncu -> null', () => {
  const { room } = startedRoom();
  assert.strictEqual(viewFor(room, 'yabanci', physics, VL), null);
  assert.strictEqual(viewFor(room, undefined, physics, VL), null);
});

test('viewFor: lobide kimseye görev/telemetri yok, seat ve roles doğru', () => {
  const m = createRoomManager({ missions, physics, layout: fakeLayout(physics), resolveLaunch, computeScore, now, config });
  const { room, player: a } = m.createRoom('A');
  const b = m.joinRoom(room.code, 'B').player;
  m.selectRole(room.code, a.id, 'director');
  m.selectRole(room.code, b.id, 'rocket');
  const v = viewFor(room, a.id, physics, VL);
  assert.deepStrictEqual(Object.keys(v).sort(), ['code', 'phase', 'players', 'roles', 'you']);
  assert.deepStrictEqual(v.you, { id: a.id, name: 'A', role: 'director' });
  assert.deepStrictEqual(v.players, [
    { seat: 0, name: 'A', role: 'director', connected: true, isYou: true },
    { seat: 1, name: 'B', role: 'rocket', connected: true, isYou: false },
  ]);
  assert.deepStrictEqual(v.roles, { director: 0, rocket: 1, spacecraft: null, payload: null });
  assert.ok(!JSON.stringify(v).includes(b.id));
});

test('viewFor: yönetici görünümü tam bilgi içerir', () => {
  const { room, players } = startedRoom(() => 0);
  const v = viewFor(room, players[0].id, physics, VL);
  assert.deepStrictEqual(v.mission, room.mission);
  assert.deepStrictEqual(v.telemetry, room.telemetry);
  assert.deepStrictEqual(v.build, room.build);
  assert.ok(Array.isArray(v.log) && v.log.length > 0);
  assert.strictEqual(v.undoLeft, 3);
  assert.ok(!('missionLabel' in v));
  // yönetici görünümü de room'a referans tutmamalı
  v.mission.title = 'değişti';
  assert.notStrictEqual(room.mission.title, 'değişti');
  const json = JSON.stringify(v);
  for (const p of players.slice(1)) assert.ok(!json.includes(p.id), 'başka oyuncunun playerId sızdı');
});

test('GÜVENLİK: çalışan görünümünde görev/sayı/başka playerId yok', () => {
  for (let i = 0; i < missions.length; i++) {
    const rng = () => i / missions.length + 0.0001;
    const { room, players } = startedRoom(rng);
    room.telemetry.deltaV = 9876; // ayırt edici değer
    room.log.push({ t: Date.now(), playerId: players[1].id, role: 'rocket', text: 'gizli-log-satiri' });
    const mission = room.mission;

    for (const me of players.slice(1)) {
      const v = viewFor(room, me.id, physics, VL);
      for (const k of ['mission', 'telemetry', 'log', 'undoLeft', 'build']) {
        assert.ok(!(k in v), `çalışan görünümünde ${k} anahtarı var`);
      }
      assert.strictEqual(v.missionLabel, 'GİZLİ');
      assert.strictEqual(v.you.id, me.id);
      // kendi UUID'sini çıkar: rastgele hex içinde sayı eşleşmesi testi oynatmasın
      const json = JSON.stringify(v).split(me.id).join('<ME>');
      assert.ok(!json.includes(mission.title), 'görev başlığı sızdı');
      assert.ok(!json.includes(mission.id), 'görev id sızdı');
      assert.ok(!json.includes(mission.target), 'görev hedefi sızdı');
      assert.ok(!json.includes('requiredDeltaV'), 'requiredDeltaV sızdı');
      assert.ok(!json.includes(String(mission.requiredDeltaV)), 'deltaV değeri sızdı');
      assert.ok(!json.includes('telemetry'), 'telemetry sızdı');
      assert.ok(!json.includes('9876'), 'telemetri değeri sızdı');
      assert.ok(!json.includes('gizli-log-satiri'), 'log sızdı');
      for (const other of players) {
        if (other.id !== me.id) assert.ok(!json.includes(other.id), 'başka oyuncunun playerId sızdı');
      }
    }
  }
});

test('GÜVENLİK: rolsüz oyuncu da çalışan görünümü alır', () => {
  const { room, players } = startedRoom();
  // Rolsüz oyuncu senaryosu (normalde olmaz ama filtre yine güvenli olmalı)
  room.players[players[3].id].role = null;
  const v = viewFor(room, players[3].id, physics, VL);
  assert.ok(!('mission' in v) && !('telemetry' in v));
  assert.strictEqual(v.missionLabel, 'GİZLİ');
});
