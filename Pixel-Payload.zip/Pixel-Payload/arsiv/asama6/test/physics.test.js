'use strict';
// Modül D birim testleri: node --test test/physics.test.js
const test = require('node:test');
const assert = require('node:assert/strict');
const catalog = require('../data/parts.json');
const missions = require('../data/missions.json');
const { createPhysics } = require('../server/physics.js');
const { createLayout } = require('../server/layout.js');
const framesData = require('../data/frames.json');

const phys = createPhysics(catalog);
const layout = createLayout({ framesData, physics: phys });
const frameOf = (id) => framesData.frames.find((f) => f.id === id);
const G0 = catalog.constants.g0;
const NUMERIC = ['massKg', 'cost', 'powerGenW', 'powerUseW', 'thrustKN', 'isp', 'heat', 'heatShield', 'fuelKg', 'ispMult', 'max'];
const mission = (id) => missions.find((m) => m.id === id);

// Parça id listelerinden build kurar (uid'ler benzersiz).
function mk({ rocket = [], spacecraft = [], payload = [] } = {}) {
  let n = 0;
  const m = (a) => a.map((partId) => ({ uid: 'u' + n++, partId }));
  return { rocket: m(rocket), spacecraft: m(spacecraft), payload: m(payload) };
}
const empty = () => mk();
const near = (a, b, tol = 1) => assert.ok(Math.abs(a - b) <= tol, `${a} ~ ${b}`);

test('katalog yapısı: rol başına 6-8 parça, tüm sayısal alanlar mevcut', () => {
  const full = phys.fullCatalog();
  for (const role of ['rocket', 'spacecraft', 'payload']) {
    assert.ok(full[role].length >= 6 && full[role].length <= 8, role);
    for (const p of full[role]) {
      for (const k of NUMERIC) assert.ok(Number.isFinite(p[k]), `${p.id}.${k}`);
      assert.ok(Array.isArray(p.requires));
      assert.equal(p.role, role);
    }
  }
  const ids = catalog.parts.map((p) => p.id);
  assert.equal(new Set(ids).size, ids.length, 'id benzersiz');
  assert.ok(catalog.parts.some((p) => p.category === 'computer'), 'yedek bilgisayar var');
});

test('name/desc içinde rakam yok', () => {
  for (const p of catalog.parts) {
    assert.ok(!/\d/.test(p.name), p.id + ' name');
    assert.ok(!/\d/.test(p.desc), p.id + ' desc');
  }
});

test('publicCatalog sayısal alan içermez', () => {
  for (const role of ['rocket', 'spacecraft', 'payload']) {
    const pub = phys.publicCatalog(role);
    assert.ok(pub.length > 0);
    for (const p of pub) {
      assert.deepEqual(Object.keys(p).sort(), ['category', 'desc', 'icon', 'id', 'model', 'name']);
      for (const v of Object.values(p)) assert.equal(typeof v, 'string');
    }
    const json = JSON.stringify(pub);
    for (const k of NUMERIC.concat(['requires'])) assert.ok(!json.includes(`"${k}"`), k);
  }
  assert.deepEqual(phys.publicCatalog('director'), []);
});

test('getPart', () => {
  assert.equal(phys.getPart('engine-kestrel').role, 'rocket');
  assert.equal(phys.getPart('yok'), undefined);
});

test('boş build: tüm sayılar sonlu ve 0, kontroller false', () => {
  for (const m of [null, mission('lunar-relay')]) {
    const t = phys.computeTelemetry(empty(), m);
    for (const k of ['massKg', 'dryMassKg', 'fuelKg', 'thrustKN', 'isp', 'twr', 'deltaV', 'powerGenW', 'powerUseW', 'heat', 'heatShield', 'spent']) {
      assert.ok(Number.isFinite(t[k]), k);
      assert.equal(t[k], 0, k);
    }
    assert.equal(t.checks.twr, false);
    assert.equal(t.checks.deltaV, false);
    assert.equal(t.checks.power, false);
    assert.equal(t.checks.payload, false);
    assert.equal(t.ready, false);
  }
  // bozuk girdi de çökmez
  const t = phys.computeTelemetry({ rocket: [{ uid: 'x', partId: 'yok' }] }, null);
  assert.equal(t.massKg, 0);
});

test('Tsiolkovsky, TWR, kütle', () => {
  const b = mk({ rocket: ['engine-kestrel', 'tank-large', 'fuel-kerosene'] });
  const t = phys.computeTelemetry(b, null);
  const dry = 1500 + 1200 + 0, wet = dry + 13000;
  assert.equal(t.dryMassKg, dry);
  assert.equal(t.massKg, wet);
  assert.equal(t.fuelKg, 13000);
  assert.equal(t.isp, 300);
  near(t.deltaV, 300 * G0 * Math.log(wet / dry));
  near(t.twr, (250 * 1000) / (wet * G0), 0.001);
  assert.equal(t.checks.deltaV, false, 'görev yoksa deltaV kontrolü false');
});

test('Isp: itkiye göre ağırlıklı ortalama × yakıt çarpanı; yakıt yoksa Δv 0', () => {
  const b = mk({ rocket: ['engine-kestrel', 'engine-heron', 'tank-small', 'fuel-methalox'] });
  const t = phys.computeTelemetry(b, null);
  near(t.isp, ((250 * 300 + 110 * 360) / 360) * 1.1, 0.1);
  assert.equal(t.thrustKN, 360);
  const noFuel = phys.computeTelemetry(mk({ rocket: ['engine-kestrel', 'tank-small'] }), null);
  assert.equal(noFuel.isp, 0);
  assert.equal(noFuel.deltaV, 0);
  assert.ok(noFuel.twr > 0);
});

test('büyük tank Δv artırır ama TWR düşürür', () => {
  const small = phys.computeTelemetry(mk({ rocket: ['engine-kestrel', 'tank-small', 'fuel-kerosene'] }), null);
  const big = phys.computeTelemetry(mk({ rocket: ['engine-kestrel', 'tank-large', 'fuel-kerosene'] }), null);
  assert.ok(big.deltaV > small.deltaV);
  assert.ok(big.twr < small.twr);
});

test('güç kontrolü', () => {
  const ok = phys.computeTelemetry(mk({ spacecraft: ['structure-frame', 'solar-small'], payload: ['camera'] }), null);
  assert.equal(ok.powerGenW, 120);
  assert.equal(ok.powerUseW, 40);
  assert.equal(ok.checks.power, true);
  const bad = phys.computeTelemetry(mk({ payload: ['relay-antenna'] }), null);
  assert.equal(bad.checks.power, false);
});

test('ısı kontrolü: motor ısı üretir, kalkan karşılar', () => {
  const hot = phys.computeTelemetry(mk({ rocket: ['engine-titan'] }), null);
  assert.equal(hot.heat, 45);
  assert.equal(hot.checks.heat, false);
  const cool = phys.computeTelemetry(mk({ rocket: ['engine-titan'], spacecraft: ['structure-frame', 'shield-light', 'shield-light'] }), null);
  assert.equal(cool.heatShield, 70);
  assert.equal(cool.checks.heat, true);
});

test('bütçe ve eksik alet', () => {
  const m = mission('mars-rover');
  const t = phys.computeTelemetry(mk({ payload: ['rover', 'camera'] }), m);
  assert.deepEqual(t.missing, ['drill']);
  assert.equal(t.checks.payload, false);
  assert.equal(t.overBudget, false);
  const full = phys.computeTelemetry(mk({ payload: ['rover', 'camera', 'drill'] }), m);
  assert.deepEqual(full.missing, []);
  assert.equal(full.checks.payload, true);
  const pricey = phys.computeTelemetry(mk({
    rocket: ['engine-titan', 'engine-titan', 'engine-titan', 'tank-large', 'tank-large', 'tank-large', 'tank-large', 'fuel-hydrolox'],
    spacecraft: ['structure-frame', 'solar-large', 'solar-large', 'shield-heavy', 'shield-heavy'],
    payload: ['rover', 'camera', 'drill'],
  }), m, frameOf('frame-heavy'));
  assert.ok(pricey.spent > m.budget);
  assert.equal(pricey.overBudget, true);
  assert.equal(pricey.checks.payload, false);
  assert.equal(phys.computeTelemetry(mk({ payload: ['rover', 'camera', 'drill'] }), null).checks.payload, false);
});

test('canAdd sınırları', () => {
  const b = mk();
  assert.deepEqual(phys.canAdd(b, 'rocket', 'yok'), { ok: false, error: 'INVALID_PART' });
  assert.deepEqual(phys.canAdd(b, 'spacecraft', 'engine-kestrel'), { ok: false, error: 'NOT_ALLOWED' });
  assert.deepEqual(phys.canAdd(b, 'director', 'engine-kestrel'), { ok: false, error: 'NOT_ALLOWED' });
  assert.deepEqual(phys.canAdd(b, 'rocket', 'engine-kestrel'), { ok: true });
  // max
  const four = mk({ rocket: ['engine-kestrel', 'engine-kestrel', 'engine-kestrel', 'engine-kestrel'] });
  assert.deepEqual(phys.canAdd(four, 'rocket', 'engine-kestrel'), { ok: false, error: 'PART_LIMIT' });
  assert.deepEqual(phys.canAdd(four, 'rocket', 'engine-heron'), { ok: true });
  const one = mk({ spacecraft: ['structure-frame'] });
  assert.deepEqual(phys.canAdd(one, 'spacecraft', 'structure-frame'), { ok: false, error: 'PART_LIMIT' });
  // tekil yakıt kategorisi (farklı yakıt da eklenemez)
  const fuel = mk({ rocket: ['fuel-kerosene'] });
  assert.deepEqual(phys.canAdd(fuel, 'rocket', 'fuel-hydrolox'), { ok: false, error: 'PART_LIMIT' });
  assert.deepEqual(phys.canAdd(fuel, 'rocket', 'fuel-kerosene'), { ok: false, error: 'PART_LIMIT' });
  // build eksik/bozuk olsa da çalışır
  assert.deepEqual(phys.canAdd({}, 'payload', 'camera'), { ok: true });
});

test('partStatuses kuralları', () => {
  const st = (build, role) => phys.partStatuses(build, role);
  // motor tanksız -> red; tank eklenince yakıt yok -> yellow; yakıtla -> green
  let b = mk({ rocket: ['engine-kestrel'] });
  assert.deepEqual(st(b, 'rocket'), { u0: 'red' });
  b = mk({ rocket: ['engine-kestrel', 'tank-small'] });
  assert.deepEqual(st(b, 'rocket'), { u0: 'yellow', u1: 'yellow' });
  b = mk({ rocket: ['engine-kestrel', 'tank-small', 'fuel-kerosene'] });
  assert.deepEqual(st(b, 'rocket'), { u0: 'green', u1: 'green', u2: 'green' });
  // motorsuz tank + yakıt -> yellow
  b = mk({ rocket: ['tank-small', 'fuel-kerosene'] });
  assert.deepEqual(st(b, 'rocket'), { u0: 'yellow', u1: 'yellow' });
  // yakıt tanksız -> red
  assert.deepEqual(st(mk({ rocket: ['fuel-kerosene'] }), 'rocket'), { u0: 'red' });
  // gövdesiz panel -> red; bataryasız panel -> yellow; bataryalı -> green
  assert.deepEqual(st(mk({ spacecraft: ['solar-small'] }), 'spacecraft'), { u0: 'red' });
  assert.deepEqual(st(mk({ spacecraft: ['structure-frame', 'solar-small'] }), 'spacecraft'), { u0: 'green', u1: 'yellow' });
  assert.deepEqual(st(mk({ spacecraft: ['structure-frame', 'solar-small', 'battery'] }), 'spacecraft'), { u0: 'green', u1: 'green', u2: 'green' });
  // anten/bilgisayar: uzay aracının kendi gücü yetmezse yellow
  assert.deepEqual(st(mk({ spacecraft: ['structure-frame', 'antenna-hga'] }), 'spacecraft'), { u0: 'green', u1: 'yellow' });
  // matkap rover'sız -> yellow
  assert.deepEqual(st(mk({ payload: ['drill'] }), 'payload'), { u0: 'yellow' });
  assert.deepEqual(st(mk({ payload: ['drill', 'rover'] }), 'payload'), { u0: 'green', u1: 'green' });
  // yalnızca kendi rolüne bakar
  b = mk({ rocket: ['engine-kestrel'], spacecraft: ['structure-frame'] });
  assert.deepEqual(Object.keys(st(b, 'spacecraft')), ['u1']);
  assert.deepEqual(st(empty(), 'payload'), {});
});

test('görevler: requiredInstruments gerçek payload parçaları', () => {
  assert.ok(missions.length >= 3);
  for (const m of missions) {
    for (const id of m.requiredInstruments) assert.equal(phys.getPart(id) && phys.getPart(id).role, 'payload', id);
    assert.ok(m.requiredDeltaV > 0 && m.budget > 0);
  }
});


// ---------- Aşama 5: gövde parametresi + yerleşimli sabit çözümler ----------

test('computeTelemetry: frame kütlesi kuru kütleye, maliyeti harcamaya eklenir', () => {
  const f = frameOf('frame-cargo');
  const b = mk({ rocket: ['engine-kestrel', 'tank-large', 'fuel-kerosene'] });
  const without = phys.computeTelemetry(b, null);
  const withF = phys.computeTelemetry(b, null, f);
  assert.equal(without.frameMassKg, 0);
  assert.equal(without.frameCost, 0);
  assert.equal(withF.frameMassKg, f.massKg);
  assert.equal(withF.frameCost, f.cost);
  assert.equal(withF.dryMassKg, without.dryMassKg + f.massKg);
  assert.equal(withF.massKg, without.massKg + f.massKg);
  assert.equal(withF.spent, without.spent + f.cost);
  assert.ok(withF.deltaV < without.deltaV, 'ölü kütle Δv düşürür');
  assert.ok(withF.twr < without.twr);
  // null/undefined -> eski davranış
  assert.deepEqual(phys.computeTelemetry(b, null, null), without);
  assert.deepEqual(phys.computeTelemetry(b, null, undefined), without);
  // boş build + gövde: sayılar sonlu, kontroller false
  const e = phys.computeTelemetry(empty(), mission('lunar-relay'), f);
  for (const k of ['massKg', 'dryMassKg', 'twr', 'deltaV', 'isp', 'spent']) assert.ok(Number.isFinite(e[k]), k);
  assert.equal(e.massKg, f.massKg);
  assert.equal(e.deltaV, 0);
  assert.equal(e.ready, false);
});

test('partStatuses ve canAdd, girdilerde slotId olsa da çalışır', () => {
  const b = { rocket: [{ uid: 'a', partId: 'engine-kestrel', slotId: 'eng-1' }, { uid: 'b', partId: 'tank-small', slotId: 'tank-1' },
    { uid: 'c', partId: 'fuel-kerosene', slotId: 'fuel' }], spacecraft: [], payload: [] };
  assert.deepEqual(phys.partStatuses(b, 'rocket'), { a: 'green', b: 'green', c: 'green' });
  assert.deepEqual(phys.canAdd(b, 'rocket', 'fuel-hydrolox'), { ok: false, error: 'PART_LIMIT' });
  assert.equal(phys.computeTelemetry(b, null, frameOf('frame-swift')).thrustKN, 250);
});

// Her görev için ≥2 yapısal olarak farklı çözüm (gövde + yuvalı yerleşim). Arama betiğiyle bulundu.
const R = (partId, slotId) => ({ role: 'rocket', partId, slotId });
const S = (partId, slotId) => ({ role: 'spacecraft', partId, slotId });
const Y = (partId, slotId) => ({ role: 'payload', partId, slotId });
const SOLUTIONS = {
  'lunar-relay': [
    { frameId: 'frame-swift', placements: [R('engine-kestrel', 'eng-1'), R('tank-large', 'tank-1'), R('fuel-methalox', 'fuel'),
      S('structure-frame', 'svc-1'), S('solar-small', 's2-e1'), S('solar-small', 's2-e2'), S('shield-light', 's1-s'), Y('relay-antenna', 's1-n')] },
    { frameId: 'frame-cargo', placements: [R('engine-kestrel', 'eng-c'), R('tank-large', 'tank-1'), R('fuel-hydrolox', 'fuel'),
      S('structure-frame', 'svc-1'), S('solar-small', 'p-n1'), S('solar-small', 'p-n2'), S('shield-light', 's1-w'), Y('relay-antenna', 's1-e')] },
  ],
  'mars-rover': [
    { frameId: 'frame-cargo', placements: [R('engine-heron', 'eng-c'), R('engine-kestrel', 'eng-e'), R('engine-kestrel', 'eng-w'),
      R('tank-large', 'tank-1'), R('tank-large', 'tank-2'), R('tank-large', 'tank-3'), R('fuel-hydrolox', 'fuel'),
      S('structure-frame', 'svc-1'), S('solar-large', 's1-w'), S('shield-heavy', 's1-e'),
      Y('rover', 'pl-1'), Y('drill', 'nose-1'), Y('camera', 'p-n1')] },
    { frameId: 'frame-heavy', placements: [R('engine-heron', 'eng-c'), R('engine-kestrel', 'eng-n'), R('engine-kestrel', 'bst-e-eng'),
      R('engine-kestrel', 'bst-w-eng'), R('tank-large', 'tank-1'), R('tank-large', 'tank-2'), R('tank-large', 'tank-3'),
      R('tank-large', 'bst-e-tank'), R('fuel-hydrolox', 'fuel'),
      S('structure-frame', 'svc-1'), S('solar-large', 's2-e'), S('shield-heavy', 's1-n'), S('shield-light', 's2-n'),
      Y('rover', 'pl-1'), Y('drill', 'svc-2'), Y('camera', 's1-s')] },
  ],
  'asteroid-sample': [
    { frameId: 'frame-cargo', placements: [R('engine-heron', 'eng-c'), R('engine-kestrel', 'eng-e'), R('tank-large', 'tank-1'),
      R('tank-small', 'tank-2'), R('tank-small', 'tank-3'), R('fuel-hydrolox', 'fuel'),
      S('structure-frame', 'svc-1'), S('solar-small', 'p-e'), S('shield-light', 's1-e'), S('shield-light', 'p-n1'),
      Y('sample-capsule', 'pl-1'), Y('camera', 's1-w'), Y('spectrometer', 'p-n2')] },
    { frameId: 'frame-heavy', placements: [R('engine-kestrel', 'eng-c'), R('engine-kestrel', 'eng-n'), R('tank-large', 'tank-1'),
      R('tank-large', 'tank-2'), R('tank-small', 'tank-3'), R('fuel-hydrolox', 'fuel'),
      S('structure-frame', 'svc-1'), S('solar-small', 's2-n'), S('shield-heavy', 's1-n'),
      Y('sample-capsule', 'pl-1'), Y('camera', 's1-s'), Y('spectrometer', 's2-e')] },
  ],
};

// Bilgisayar arızası (yedek bilgisayar zorunlu) altında her görev için bir çözüm.
const FAULT_SOLUTIONS = {
  'lunar-relay': { frameId: 'frame-swift', placements: [R('engine-kestrel', 'eng-1'), R('tank-large', 'tank-1'), R('fuel-methalox', 'fuel'),
    S('structure-frame', 'svc-1'), S('computer-backup', 'pl-1'), S('solar-small', 's2-e1'), S('solar-small', 's2-e2'), S('shield-light', 's1-s'),
    Y('relay-antenna', 's1-n')] },
  'mars-rover': { frameId: 'frame-cargo', placements: [R('engine-heron', 'eng-c'), R('engine-kestrel', 'eng-e'), R('engine-kestrel', 'eng-w'),
    R('tank-large', 'tank-1'), R('tank-large', 'tank-2'), R('tank-large', 'tank-3'), R('fuel-hydrolox', 'fuel'),
    S('structure-frame', 'svc-1'), S('computer-backup', 'pl-2'), S('solar-large', 's1-w'), S('shield-heavy', 's1-e'),
    Y('rover', 'pl-1'), Y('drill', 'nose-1'), Y('camera', 'p-n1')] },
  'asteroid-sample': { frameId: 'frame-cargo', placements: [R('engine-heron', 'eng-c'), R('engine-kestrel', 'eng-e'), R('tank-large', 'tank-1'),
    R('tank-small', 'tank-2'), R('tank-small', 'tank-3'), R('fuel-hydrolox', 'fuel'),
    S('structure-frame', 'svc-1'), S('computer-backup', 'pl-2'), S('solar-small', 'p-e'), S('solar-small', 'p-s1'),
    S('shield-light', 's1-e'), S('shield-light', 'p-n1'), Y('sample-capsule', 'pl-1'), Y('camera', 's1-w'), Y('spectrometer', 'p-n2')] },
};

// Yerleşimleri sırayla canPlace'ten geçirerek build kurar.
function placeAll(sol) {
  const build = { rocket: [], spacecraft: [], payload: [] };
  sol.placements.forEach((pl, i) => {
    const r = layout.canPlace(build, sol.frameId, pl.role, pl.partId, pl.slotId);
    assert.deepEqual(r, { ok: true }, `${sol.frameId} ${pl.partId}@${pl.slotId}: ${r.reason}`);
    build[pl.role].push({ uid: 'p' + i, partId: pl.partId, slotId: pl.slotId });
  });
  return build;
}
const sig = (sol) => sol.frameId + '|' + sol.placements.filter((p) => p.role === 'rocket').map((p) => p.partId).sort().join(',');

for (const m of missions) {
  test(`görev ${m.id}: yerleşimli sabit çözümler (canPlace + tüm kontroller yeşil)`, () => {
    const sols = SOLUTIONS[m.id];
    assert.ok(sols && sols.length >= 2, 'en az iki çözüm');
    assert.equal(new Set(sols.map(sig)).size, sols.length, 'çözümler yapısal olarak farklı');
    for (const sol of sols) {
      const build = placeAll(sol);
      const t = phys.computeTelemetry(build, m, frameOf(sol.frameId));
      assert.deepEqual(t.checks, { twr: true, deltaV: true, power: true, payload: true, heat: true }, sol.frameId + ' ' + JSON.stringify(t));
      assert.equal(t.ready, true);
      for (const role of ['rocket', 'spacecraft', 'payload']) {
        assert.ok(!Object.values(phys.partStatuses(build, role)).includes('red'), role);
      }
      assert.ok(phys.computeTelemetry(build, m).spent < t.spent, 'gövde maliyeti sayılıyor');
    }
  });

  test(`görev ${m.id}: bilgisayar arızasında da çözülebilir`, () => {
    const sol = FAULT_SOLUTIONS[m.id];
    const build = placeAll(sol);
    const t = phys.computeTelemetry(build, m, frameOf(sol.frameId));
    assert.ok(build.spacecraft.some((e) => phys.getPart(e.partId).category === 'computer'));
    assert.equal(t.ready, true, JSON.stringify(t));
  });

  test(`görev ${m.id}: açgözlü ve çok küçük build'ler geçmez`, () => {
    const all = { rocket: [], spacecraft: [], payload: [] };
    for (const p of catalog.parts) {
      if (p.category === 'fuel') continue;
      for (let k = 0; k < p.max; k++) all[p.role].push(p.id);
    }
    all.rocket.push('fuel-hydrolox');
    for (const f of framesData.frames) {
      const g = phys.computeTelemetry(mk(all), m, f);
      assert.equal(g.overBudget, true, f.id);
      assert.equal(g.ready, false);
    }
    assert.equal(phys.computeTelemetry(mk({ payload: m.requiredInstruments }), m, frameOf('frame-swift')).ready, false);
    const tiny = mk({ rocket: ['engine-kestrel', 'tank-small', 'fuel-hydrolox'],
      spacecraft: ['structure-frame', 'solar-large', 'shield-heavy'], payload: m.requiredInstruments });
    assert.equal(phys.computeTelemetry(tiny, m, frameOf('frame-swift')).checks.deltaV, false);
  });
}

test('her gövde en az bir görevi çözer', () => {
  const used = new Set(Object.values(SOLUTIONS).flat().map((s) => s.frameId));
  for (const f of framesData.frames) assert.ok(used.has(f.id), f.id);
});

// Fizik-yalnız kaba arama (yuvalar yok sayılır: burada imkânsızsa yuvalarla da imkânsız).
function physicsFeasible(m, frame) {
  const P = (id) => phys.getPart(id);
  const mounts = frame.slots.filter((s) => s.accepts.includes('engine')).length;
  const tanks = frame.slots.filter((s) => s.accepts.includes('tank')).length;
  const agg = (ids) => ids.reduce((a, id) => {
    const p = P(id);
    a.dry += p.massKg; a.fuel += p.fuelKg; a.thr += p.thrustKN; a.ti += p.thrustKN * p.isp;
    a.gen += p.powerGenW; a.use += p.powerUseW; a.heat += p.heat; a.hs += p.heatShield; a.cost += p.cost;
    return a;
  }, { dry: 0, fuel: 0, thr: 0, ti: 0, gen: 0, use: 0, heat: 0, hs: 0, cost: 0 });
  const range = (n) => Array.from({ length: n + 1 }, (_, i) => i);
  const rep = (id, n) => Array(n).fill(id);
  const rockets = [];
  for (const k of range(4)) for (const t of range(3)) for (const h of range(2)) for (const ts of range(4)) for (const tl of range(P('tank-large').max)) {
    if (k + t + h < 1 || k + t + h > mounts || ts + tl < 1 || ts + tl > tanks) continue;
    const base = [...rep('engine-kestrel', k), ...rep('engine-titan', t), ...rep('engine-heron', h), ...rep('tank-small', ts), ...rep('tank-large', tl)];
    for (const fu of ['fuel-kerosene', 'fuel-methalox', 'fuel-hydrolox']) rockets.push({ a: agg(base.concat(fu)), mult: P(fu).ispMult });
  }
  const scs = [];
  for (const a of range(4)) for (const b of range(2)) for (const c of range(3)) for (const d of range(2)) for (const e of range(2)) {
    scs.push(agg(['structure-frame', ...rep('solar-small', a), ...rep('solar-large', b), ...rep('battery', c), ...rep('shield-light', d), ...rep('shield-heavy', e)]));
  }
  const pl = agg(m.requiredInstruments);
  for (const { a: r, mult } of rockets) for (const s of scs) {
    if (r.cost + s.cost + pl.cost + frame.cost > m.budget) continue;
    if (s.gen < s.use + pl.use || s.hs < r.heat + s.heat + pl.heat) continue;
    const dry = r.dry + s.dry + pl.dry + frame.massKg, wet = dry + r.fuel;
    if ((r.thr * 1000) / (wet * G0) < catalog.constants.minTwr) continue;
    if ((r.ti / r.thr) * mult * G0 * Math.log(wet / dry) >= m.requiredDeltaV) return true;
  }
  return false;
}

test('gövde seçimi anlamlı: her görevi en az bir gövde imkânsız kılar', () => {
  // Dev (ağır, pahalı) ile Ay rölesi bütçeye sığmaz.
  assert.equal(physicsFeasible(mission('lunar-relay'), frameOf('frame-heavy')), false);
  assert.equal(physicsFeasible(mission('lunar-relay'), frameOf('frame-swift')), true);
  // Kargo'da yalnız üç tank yeri var: Mars için yakıt ancak en iyi seçimle yeter (zor ama mümkün).
  assert.equal(physicsFeasible(mission('mars-rover'), frameOf('frame-cargo')), true);
  // Kırlangıç'ın dar burnunda rover ve örnek kapsülü için yuva yok -> Mars ve asteroit imkânsız.
  for (const id of ['rover', 'sample-capsule']) {
    assert.deepEqual(layout.slotOptions(mk(), 'frame-swift', 'payload', id), [], id);
    assert.ok(layout.slotOptions(mk(), 'frame-cargo', 'payload', id).length > 0, id);
  }
});
