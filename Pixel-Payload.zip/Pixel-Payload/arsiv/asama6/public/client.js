// Pixel Payload — istemci (Aşama 6: sakin arayüz + 2B roket sahnesi).
// İstemci oyun kuralı hesaplamaz; yalnızca sunucudan gelen son `state`i çizer.
// Uygunluk (hangi yuvaya ne takılır) sunucudan `catalog[].slots` ile gelir. innerHTML kullanılmaz.
(function () {
  'use strict';

  var ROLE_NAMES = {
    director: 'Yönetici',
    rocket: 'Roket & Yakıt',
    spacecraft: 'Uzay Aracı',
    payload: 'Faydalı Yük'
  };
  var ROLE_INFO = {
    director: { icon: '🎧', kind: 'KOMUTA', desc: 'Görevi, bütçeyi ve bütün ölçümleri görür. Gövdeyi seçer, ekibi yönlendirir, anketi açar.' },
    rocket: { icon: '🔥', kind: 'MÜHENDİS', desc: 'Motorlar, tanklar ve yakıt. Roketi rampadan kaldıracak itkiyi kurar.' },
    spacecraft: { icon: '🛰️', kind: 'MÜHENDİS', desc: 'Güneş paneli, batarya, ısı kalkanı, anten, yapı ve bilgisayar.' },
    payload: { icon: '🔭', kind: 'MÜHENDİS', desc: 'Bilimsel aletler: kamera, spektrometre, radar, gezgin, sondaj.' }
  };
  var WORKER_ROLES = ['rocket', 'spacecraft', 'payload'];
  var PHASE_LABELS = { lobby: 'LOBİ', setup: 'GÖVDE SEÇİMİ', building: 'MONTAJ', poll: 'GO / NO-GO', result: 'SONUÇ' };
  var CATEGORY_NAMES = {
    engine: 'Motor', tank: 'Yakıt tankı', fuel: 'Yakıt tipi', solar: 'Güneş paneli', battery: 'Batarya',
    shield: 'Isı kalkanı', antenna: 'Anten', structure: 'Yapı', computer: 'Bilgisayar', instrument: 'Bilimsel alet'
  };
  var KIND_NAMES = { mount: 'motor bağlantısı', internal: 'iç bölme', surface: 'dış yüzey' };
  var FACE_NAMES = { N: 'ön yüz', E: 'sağ yüz', S: 'arka yüz', W: 'sol yüz', C: 'eksen' };
  var STATUS_TEXT = { green: 'TAMAM', yellow: 'UYARI', red: 'EKSİK' };
  var KIND_LABELS = { part: 'PARÇA', event: 'OLAY', poll: 'ANKET', undo: 'GERİ ALMA', system: 'SİSTEM' };

  // ---- URL parametreleri (demo modu; hiçbiri yoksa davranış değişmez) ----
  var params = new URLSearchParams(location.search);
  function safeParam(name, re) {
    var v = params.get(name);
    return v !== null && re.test(v) ? v : null;
  }
  var SLOT = safeParam('slot', /^[A-Za-z0-9_-]{1,32}$/);         // ayrı oturum anahtarı
  var AUTO_MODE = safeParam('auto', /^(create|join)$/);          // otomatik giriş
  var AUTO_NAME = (params.get('name') || '').slice(0, 16);
  var AUTO_ROLE = safeParam('role', /^(director|rocket|spacecraft|payload)$/);
  var AUTO_CODE = (params.get('code') || '').trim().toUpperCase();
  var EMBED = params.get('embed') === '1';
  var IN_FRAME = window.parent !== window;
  var ROOT = document.documentElement;
  if (EMBED) ROOT.setAttribute('data-embed', '1');
  if (params.get('debug') === '1') ROOT.setAttribute('data-debug', '1');

  var STORAGE_KEY = SLOT ? 'pixelPayloadSession:' + SLOT : 'pixelPayloadSession';

  function $(sel) { return document.querySelector(sel); }

  var el = {
    error: $('#error-msg'), errorWrap: $('#error-wrap'), errorClose: $('#error-close'),
    connStatus: $('#conn-status'), connText: $('#conn-text'),
    headCode: $('#head-code'), headRole: $('#head-role'), footPhase: $('#foot-phase'), footCrew: $('#foot-crew'),
    head: $('#app-head'), foot: $('#app-foot'),
    helpBtn: $('#help-btn'), helpPanel: $('#help-panel'), helpClose: $('#help-close'),
    // giriş
    name: $('#name-input'), code: $('#code-input'), createBtn: $('#create-btn'), joinBtn: $('#join-btn'),
    cardCreate: $('#card-create'), cardJoin: $('#card-join'), entryForm: $('#entry-form'),
    formCreate: $('#form-create'), formJoin: $('#form-join'), heroInner: $('.hero-inner'),
    leaveBtn: $('#leave-btn'),
    entry: $('#screen-entry'), lobby: $('#screen-lobby'), setup: $('#screen-setup'), game: $('#screen-game'),
    roomInfo: $('#room-info'), roomCode: $('#room-code'), playerList: $('#player-list'), lobbyNote: $('#lobby-note'),
    roleBtns: document.querySelectorAll('#screen-lobby [data-role]'),
    // kurulum
    setupDirector: $('#setup-director'), setupWorker: $('#setup-worker'), setupMission: $('#setup-mission'),
    frameSelect: $('#frame-select'), frameOptions: $('#frame-options'),
    // şerit
    strip: $('#gauge-strip'), roleName: $('#role-name'), roleCell: $('#role-cell'), missionLabel: $('#mission-label'),
    frameName: $('#g-frame-name'), phaseValue: $('#phase-value'), centerTimerHost: $('#center-timer-host'),
    budgetBox: $('#budget-box'), budgetSpent: $('#budget-spent'), budgetTotal: $('#budget-total'),
    budgetBar: $('#budget-bar'), budgetLeft: $('#budget-left'),
    // çalışan
    catalog: $('#catalog'), catalogNote: $('#catalog-note'), slotList: $('#slot-list'), slotHint: $('#slot-hint'),
    slotMsg: $('#slot-msg'), slotNote: $('#slot-note'), slotPanel: $('#slot-panel'),
    myParts: $('#my-parts'), others: $('#others'), feed: $('#feed'),
    // yönetici
    gauges: $('#gauges'), readyLine: $('#ready-line'), telemetryBox: $('#telemetry-box'),
    buildBox: $('#build-box'), directorCatalog: $('#director-catalog'), missionBox: $('#mission-box'),
    frameBox: $('#frame-box'), logBox: $('#log-box'), delayNote: $('#telemetry-delay-note'), lastLog: $('#last-log'),
    // sahne
    scenePanel: $('#scene-panel'), sceneHost: $('#scene-host'), scene3d: $('#scene3d'), sceneInfo: $('#scene-info'),
    sceneNote: $('#scene-note'), pickedBar: $('#picked-bar'), pickedText: $('#picked-text'), pickedSub: $('#picked-sub'),
    pickedIcon: $('#picked-icon'), unpickBtn: $('#unpick-btn'), gameBody: $('#game-body'),
    // çekmece
    drawer: $('#drawer'), drawerScrim: $('#drawer-scrim'), drawerTitle: $('#drawer-title'), drawerClose: $('#drawer-close'),
    // anket
    pollControls: $('#poll-controls'), pollStartWrap: $('#poll-start-wrap'), pollStartBtn: $('#poll-start-btn'),
    pollWarning: $('#poll-warning'), pollReadyNote: $('#poll-ready-note'), pollBox: $('#poll-box'), pollNote: $('#poll-note'),
    voteItems: document.querySelectorAll('[data-vote-role]'), voteBtns: $('#vote-btns'), myVote: $('#my-vote'),
    voteGoBtn: $('#vote-go-btn'), voteNogoBtn: $('#vote-nogo-btn'), pollCancelBtn: $('#poll-cancel-btn'),
    // sayaç / olay / geri alma
    timer: $('#timer'), timerLabel: $('#timer-label'), timerValue: $('#timer-value'), holdBanner: $('#hold-banner'),
    eventsBox: $('#events-box'), undoBox: $('#undo-box'), undoLeft: $('#undo-left'),
    undoBtns: document.querySelectorAll('button[data-undo]'),
    // sonuç
    result: $('#screen-result'), resultStage: $('#result-stage'), resultStageTitle: $('#result-stage-title'),
    resultSceneHost: $('#result-scene-host'), launchWrap: $('#launch-wrap'), launchSeq: $('#launch-sequence'),
    skipLaunchBtn: $('#skip-launch-btn'), resultPanel: $('#result-panel'), resultBadge: $('#result-badge'),
    resultTitle: $('#result-title'), resultReason: $('#result-reason'), resultScore: $('#result-score'),
    resultBreakdown: $('#result-breakdown'), resultMission: $('#result-mission'), resultTelemetry: $('#result-telemetry'),
    resultBuild: $('#result-build'), resultNasa: $('#result-nasa'), restartBtn: $('#restart-btn'), restartWait: $('#restart-wait'),
    resultTime: $('#result-time'), resultUndo: $('#result-undo'), resultEvents: $('#result-events'),
    resultFrame: $('#result-frame'), resultMore: $('#result-more'),
    debug: $('#debug-state')
  };

  var lastState = null;
  var justReconnected = false;
  var pendingBtns = []; // yanıtı beklenen istek düğmeleri (devre dışı)
  var lastCatalogIdx = {}; // partId -> parça (ad çevirisi için önbellek)

  function releasePending(btn) {
    var i = pendingBtns.indexOf(btn);
    if (i !== -1) pendingBtns.splice(i, 1);
    btn.disabled = false;
  }
  function clearPending() { pendingBtns.slice().forEach(releasePending); }

  // ---- sessionStorage (her sekme ayrı oturum) ----
  function loadSession() {
    try {
      var s = JSON.parse(sessionStorage.getItem(STORAGE_KEY));
      return s && s.code && s.playerId ? s : null;
    } catch (e) { return null; }
  }
  function saveSession(code, playerId) {
    try { sessionStorage.setItem(STORAGE_KEY, JSON.stringify({ code: code, playerId: playerId })); } catch (e) { /* yok say */ }
  }
  function clearSession() {
    try { sessionStorage.removeItem(STORAGE_KEY); } catch (e) { /* yok say */ }
  }

  // ---- DOM yardımcıları (innerHTML yok) ----
  function clear(node) { while (node.firstChild) node.removeChild(node.firstChild); }
  function h(tag, cls, text) {
    var n = document.createElement(tag);
    if (cls) n.className = cls;
    if (text !== undefined && text !== null) n.textContent = text;
    return n;
  }
  function add(parent, tag, cls, text) { var n = h(tag, cls, text); parent.appendChild(n); return n; }
  function kvList(parent, rows) {
    var dl = add(parent, 'dl', 'kv');
    rows.forEach(function (r) {
      var row = add(dl, 'div', 'kv-row' + (r[2] ? ' ' + r[2] : ''));
      add(row, 'dt', null, r[0]);
      var dd = add(row, 'dd', 'mono');
      if (r[1] instanceof Node) dd.appendChild(r[1]); else dd.textContent = r[1];
    });
    return dl;
  }

  function num(v) { return typeof v === 'number' && isFinite(v) ? v : 0; }
  function isNum(v) { return typeof v === 'number' && isFinite(v); }
  function int(v) { return String(Math.round(num(v))); }
  function fmtInt(v) { return Math.round(num(v)).toLocaleString('tr-TR'); }
  function fmtNum(v) {
    if (typeof v !== 'number' || !isFinite(v)) return v === undefined || v === null ? '-' : String(v);
    return Number.isInteger(v) ? String(v) : String(Math.round(v * 100) / 100);
  }
  function pad2(n) { return (n < 10 ? '0' : '') + n; }
  function timeStr(t) { return t ? new Date(t).toLocaleTimeString('tr-TR', { hour: '2-digit', minute: '2-digit' }) : ''; }
  function pct(x) { return Math.max(0, Math.min(100, x * 100)) + '%'; }
  function arr(v) { return Array.isArray(v) ? v : []; }
  function obj(v) { return v && typeof v === 'object' && !Array.isArray(v) ? v : {}; }
  function roleLabel(role) { return role ? (ROLE_NAMES[role] || role) : 'rol yok'; }

  function catalogIndex(catalog) {
    var idx = {};
    if (Array.isArray(catalog)) {
      catalog.forEach(function (p) { if (p && p.id) idx[p.id] = p; });
    } else if (catalog && typeof catalog === 'object') {
      Object.keys(catalog).forEach(function (r) {
        arr(catalog[r]).forEach(function (p) { if (p && p.id) idx[p.id] = p; });
      });
    }
    return idx;
  }
  function rememberCatalog(catalog) {
    var idx = catalogIndex(catalog);
    Object.keys(idx).forEach(function (k) { lastCatalogIdx[k] = idx[k]; });
    return idx;
  }
  function readableId(id) { return String(id).replace(/[-_]+/g, ' '); }
  function partName(idx, id) { return idx[id] && idx[id].name ? idx[id].name : (lastCatalogIdx[id] && lastCatalogIdx[id].name) || readableId(id); }

  // ---- Hata kutusu: girişte açık formun altında, odada alt bildirim ----
  function placeError() {
    var target = document.body;
    if (!el.entry.hidden) {
      var form = openForm || (el.error.textContent ? (el.code.value.trim() || AUTO_MODE === 'join' ? 'join' : 'create') : null);
      if (form && el.error.textContent && !openForm) setEntryForm(form);
      var slot = form ? document.querySelector('.err-slot[data-for="' + form + '"]') : null;
      if (slot) target = slot;
    }
    if (el.errorWrap.parentNode !== target) target.appendChild(el.errorWrap);
    el.errorWrap.classList.toggle('toast', target === document.body);
  }
  function showError(msg) {
    el.error.textContent = msg || '';
    el.errorWrap.hidden = !msg;
    if (msg) placeError();
  }

  // Gömülü görünümde faz/rol <html> özniteliği (demo sözleşmesi; yalnız CSS)
  function setEmbedAttrs(phase, role) {
    if (!EMBED) return;
    if (phase) ROOT.setAttribute('data-pp-phase', phase); else ROOT.removeAttribute('data-pp-phase');
    if (role) ROOT.setAttribute('data-pp-role', role); else ROOT.removeAttribute('data-pp-role');
  }
  function setRootPhase(phase, role) {
    if (phase) ROOT.setAttribute('data-phase', phase); else ROOT.removeAttribute('data-phase');
    if (role === undefined) ROOT.removeAttribute('data-rolekind');
    else ROOT.setAttribute('data-rolekind', role === 'director' ? 'director' : 'worker');
    if (role) ROOT.setAttribute('data-myrole', role); else ROOT.removeAttribute('data-myrole');
  }

  // ---- Düzen: wide (üç sütun) / split (iki sütun) / stack (telefon) ----
  var currentLayout = null;
  function computeLayout() {
    var w = window.innerWidth, hgt = window.innerHeight;
    var layout = w >= 1100 && hgt >= 560 ? 'wide' : (w >= 440 ? 'split' : 'stack');
    if (layout !== currentLayout) {
      currentLayout = layout;
      ROOT.setAttribute('data-layout', layout);
      placeEntryForm();
      placeTimer();
    }
    updateBars();
    resizeScene();
  }
  // Yapışkan şeridin yüksekliği CSS'e (roketin yapışma noktası)
  function updateBars() {
    var hgt = el.game.hidden ? 0 : el.strip.offsetHeight;
    ROOT.style.setProperty('--strip-h', hgt + 'px');
  }
  var resizeRaf = 0;
  window.addEventListener('resize', function () {
    if (resizeRaf) cancelAnimationFrame(resizeRaf);
    resizeRaf = requestAnimationFrame(function () { resizeRaf = 0; computeLayout(); });
  });

  // ---- Giriş: kartlar ve formlar ----
  var openForm = null; // 'create' | 'join' | null
  function setEntryForm(which) {
    openForm = which;
    el.cardCreate.setAttribute('aria-expanded', which === 'create' ? 'true' : 'false');
    el.cardJoin.setAttribute('aria-expanded', which === 'join' ? 'true' : 'false');
    el.formCreate.hidden = which !== 'create';
    el.formJoin.hidden = which !== 'join';
    el.entryForm.hidden = !which;
    el.entry.setAttribute('data-form', which || '');
    if (which) {
      // #name-input tek öğe: açık forma taşınır (etiketiyle birlikte)
      var slot = document.querySelector('.name-slot[data-for="' + which + '"]');
      var label = document.querySelector('label[for="name-input"]');
      if (slot && el.name.parentNode !== slot) { slot.appendChild(label); slot.appendChild(el.name); }
    }
    placeEntryForm();
    if (!el.errorWrap.hidden) placeError();
  }
  // Geniş ekranda form kahraman alanında, dar ekranda seçilen kartın altında
  function placeEntryForm() {
    var host = el.heroInner;
    if (currentLayout !== 'wide' && openForm) host = document.querySelector('.form-slot[data-for="' + openForm + '"]') || host;
    if (el.entryForm.parentNode !== host) host.appendChild(el.entryForm);
  }
  function focusForm(which) {
    var target = which === 'join' ? el.code : el.name;
    try { target.focus({ preventScroll: currentLayout !== 'stack' }); } catch (e) { target.focus(); }
  }
  el.cardCreate.addEventListener('click', function () {
    var next = openForm === 'create' ? null : 'create';
    setEntryForm(next);
    if (next) focusForm(next);
  });
  el.cardJoin.addEventListener('click', function () {
    var next = openForm === 'join' ? null : 'join';
    setEntryForm(next);
    if (next) focusForm(next);
  });

  // ---- Ekran geçişleri ----
  function showEntry() {
    setEmbedAttrs(null, null);
    setRootPhase(null);
    lastState = null;
    stopLaunch();
    picked = null;
    closeDrawer();
    ROOT.removeAttribute('data-picked');
    el.entry.hidden = false;
    el.lobby.hidden = true;
    el.setup.hidden = true;
    el.game.hidden = true;
    el.result.hidden = true;
    el.headCode.textContent = '—';
    el.headRole.textContent = '—';
    el.headRole.removeAttribute('data-r');
    el.footPhase.textContent = 'GİRİŞ';
    clear(el.footCrew);
    hideLiveBoxes();
    el.debug.textContent = '';
    if (!el.errorWrap.hidden) placeError();
  }

  function handleJoinAck(res) {
    if (!res || !res.ok) {
      showError(res && res.message ? res.message : 'Bilinmeyen hata.');
      return;
    }
    showError('');
    saveSession(res.code, res.playerId);
  }

  // ---- Alt durum satırı + ekip ----
  function renderFoot(state) {
    var role = state.you ? state.you.role : null;
    el.headCode.textContent = state.code || '—';
    el.headRole.textContent = role ? ROLE_NAMES[role] : 'seçilmedi';
    if (role) el.headRole.setAttribute('data-r', role); else el.headRole.removeAttribute('data-r');
    el.footPhase.textContent = PHASE_LABELS[state.phase] || state.phase || '';
    clear(el.footCrew);
    arr(state.players).slice().sort(function (a, b) { return a.seat - b.seat; }).forEach(function (p) {
      var d = add(el.footCrew, 'span', 'crew-dot');
      d.setAttribute('data-r', p.role || '');
      d.setAttribute('data-connected', p.connected === false ? 'false' : 'true');
      d.title = (p.name || '') + ' · ' + roleLabel(p.role) + (p.connected === false ? ' · bağlantı koptu' : '');
    });
  }

  function renderPlayers(state) {
    clear(el.playerList);
    arr(state.players).slice().sort(function (a, b) { return a.seat - b.seat; }).forEach(function (p) {
      var li = add(el.playerList, 'li');
      if (p.role) li.setAttribute('data-r', p.role);
      li.setAttribute('data-connected', p.connected === false ? 'false' : 'true');
      add(li, 'span', 'pl-dot').setAttribute('aria-hidden', 'true');
      add(li, 'span', 'pl-name', p.name + (p.isYou ? ' (sen)' : ''));
      add(li, 'span', 'pl-role', p.connected === false ? 'bağlantı koptu' : (p.role ? ROLE_NAMES[p.role] : 'rol seçmedi'));
    });
  }

  function seatName(state, seat) {
    var players = arr(state.players);
    for (var i = 0; i < players.length; i++) if (players[i].seat === seat) return players[i].name;
    return '?';
  }

  // ---- Lobi: rol kartları ----
  function renderRoleButtons(state) {
    var roles = obj(state.roles);
    var myRole = state.you ? state.you.role : null;
    var filled = 0;
    el.roleBtns.forEach(function (btn) {
      var role = btn.getAttribute('data-role');
      var seat = roles[role];
      var taken = seat !== null && seat !== undefined;
      if (taken) filled++;
      var mine = myRole === role;
      clear(btn);
      var top = add(btn, 'span', 'rc-top');
      add(top, 'span', 'rc-icon', ROLE_INFO[role].icon).setAttribute('aria-hidden', 'true');
      add(top, 'span', 'rc-kind', ROLE_INFO[role].kind);
      add(btn, 'span', 'rc-name', ROLE_NAMES[role].toUpperCase());
      add(btn, 'span', 'rc-desc', ROLE_INFO[role].desc);
      add(btn, 'span', 'rc-status', mine ? '[SENİN · BIRAKMAK İÇİN BAS]' : (taken ? '[DOLU · ' + seatName(state, seat) + ']' : '[BOŞ · SEÇ]'));
      btn.setAttribute('data-state', mine ? 'mine' : (taken ? 'taken' : 'free'));
      btn.setAttribute('aria-pressed', mine ? 'true' : 'false');
      btn.disabled = taken && !mine;
    });
    var left = 4 - filled;
    el.lobbyNote.textContent = left > 0
      ? 'Dört rol dolunca görev kendiliğinden başlar. Boş rol: ' + ['', 'bir', 'iki', 'üç', 'dört'][left] + '.'
      : 'Tüm roller dolu, görev başlıyor.';
  }

  // ---- Görev kartı (kurulum + oyun + sonuç) ----
  function renderMissionCard(box, mission, idx, missing) {
    clear(box);
    if (!mission) { add(box, 'p', 'hint', 'Görev bilgisi bekleniyor.'); return; }
    var head = add(box, 'div', 'mission-head');
    add(head, 'p', 'mission-title', mission.title || '');
    if (mission.target) add(head, 'p', 'mission-target', mission.target);
    var rows = [];
    if (mission.requiredDeltaV !== undefined) rows.push(['Gereken Δv', fmtInt(mission.requiredDeltaV) + ' m/s']);
    if (mission.budget !== undefined) rows.push(['Bütçe', fmtInt(mission.budget), 'kv-amber']);
    if (mission.durationSec !== undefined) rows.push(['Süre', Math.round(num(mission.durationSec) / 60) + ' dk']);
    if (mission.parMassKg !== undefined) rows.push(['Hedef kütle', '≤ ' + fmtInt(mission.parMassKg) + ' kg']);
    if (rows.length) kvList(box, rows);
    // Gereken aletler (yönetici görünümünde takılı/eksik durumu sunucunun `missing` listesinden)
    var ins = arr(mission.requiredInstruments);
    var names = arr(mission.requiredInstrumentNames);
    if (ins.length) {
      var wrap = add(box, 'div', 'mission-instr');
      add(wrap, 'p', 'eyebrow', 'GEREKEN ALETLER');
      var row = add(wrap, 'div', 'chip-row');
      var miss = arr(missing);
      ins.forEach(function (id, i) {
        var have = missing ? miss.indexOf(id) === -1 : null;
        var label = typeof names[i] === 'string' && names[i] ? names[i] : partName(idx, id);
        var c = add(row, 'span', 'chip', (have === true ? '✓ ' : (have === false ? '✕ ' : '')) + label);
        if (have !== null) c.setAttribute('data-have', have ? 'true' : 'false');
      });
    }
    if (mission.nasaFact) add(box, 'p', 'mission-fact', mission.nasaFact);
  }

  // ---- Gövde siluet çizimi (SVG, DOM API) ----
  var SVGNS = 'http://www.w3.org/2000/svg';
  function svgEl(tag, attrs, parent) {
    var n = document.createElementNS(SVGNS, tag);
    Object.keys(attrs).forEach(function (k) { n.setAttribute(k, attrs[k]); });
    if (parent) parent.appendChild(n);
    return n;
  }
  function silhouette(shape) {
    var W = 80, H = 150;
    var svg = svgEl('svg', { viewBox: '0 0 ' + W + ' ' + H, 'class': 'frame-sil', 'aria-hidden': 'true', focusable: 'false' });
    var s = obj(shape), segs = arr(s.segments), nose = s.nose && typeof s.nose === 'object' ? s.nose : null;
    var bst = s.booster && typeof s.booster === 'object' ? s.booster : null;
    var maxY = 1, maxR = 0.5;
    segs.forEach(function (g) { maxY = Math.max(maxY, num(g.y1)); maxR = Math.max(maxR, num(g.radius)); });
    if (nose) { maxY = Math.max(maxY, num(nose.y1)); maxR = Math.max(maxR, num(nose.radius)); }
    var boosters = !!bst || num(s.boosters) > 0;
    var widthNeed = bst ? Math.max(maxR, num(bst.offset) + num(bst.radius)) * 1.15 : maxR * (boosters ? 1.9 : 1.35);
    var sc = Math.min((H - 12) / maxY, (W / 2 - 4) / widthNeed);
    var cx = W / 2;
    function Y(y) { return H - 6 - y * sc; }
    svgEl('line', { x1: 4, y1: H - 5, x2: W - 4, y2: H - 5, 'class': 'sil-ground' }, svg);
    var base = segs[0];
    if (boosters && base) {
      var br = bst ? num(bst.radius) * sc : num(base.radius) * 0.38 * sc;
      var by0 = bst ? num(bst.y0) : num(base.y0);
      var by1 = bst ? num(bst.y1) : num(base.y0) + (num(base.y1) - num(base.y0)) * 0.85;
      [-1, 1].forEach(function (d) {
        var bx = cx + d * (bst ? num(bst.offset) * sc : num(base.radius) * sc + br + 1);
        svgEl('rect', { x: bx - br, y: Y(by1), width: br * 2, height: Math.max(1, (by1 - by0) * sc), 'class': 'sil-boost' }, svg);
        svgEl('path', { d: 'M' + (bx - br) + ',' + Y(by1) + ' L' + bx + ',' + (Y(by1) - br * 2.2) + ' L' + (bx + br) + ',' + Y(by1) + 'Z', 'class': 'sil-boost' }, svg);
      });
    }
    segs.forEach(function (g) {
      var r = num(g.radius) * sc;
      svgEl('rect', { x: cx - r, y: Y(num(g.y1)), width: r * 2, height: Math.max(1, (num(g.y1) - num(g.y0)) * sc), 'class': 'sil-body' }, svg);
    });
    if (nose) {
      var nr = num(nose.radius) * sc, y0 = Y(num(nose.y0)), y1 = Y(num(nose.y1));
      svgEl('path', { d: 'M' + (cx - nr) + ',' + y0 + ' C' + (cx - nr) + ',' + (y0 + (y1 - y0) * 0.6) + ' ' + (cx - nr * 0.3) + ',' + y1 + ' ' + cx + ',' + y1 +
        ' C' + (cx + nr * 0.3) + ',' + y1 + ' ' + (cx + nr) + ',' + (y0 + (y1 - y0) * 0.6) + ' ' + (cx + nr) + ',' + y0 + 'Z', 'class': 'sil-body' }, svg);
    }
    if (num(s.fins) > 0 && base) {
      var r0 = num(base.radius) * sc, fy0 = Y(num(base.y0)), fh = Math.min(30, (num(base.y1) - num(base.y0)) * sc * 0.45);
      [-1, 1].forEach(function (d) {
        svgEl('path', { d: 'M' + (cx + d * r0) + ',' + (fy0 - fh) + ' L' + (cx + d * (r0 + 9)) + ',' + fy0 + ' L' + (cx + d * r0) + ',' + fy0 + 'Z', 'class': 'sil-fin' }, svg);
      });
    }
    return svg;
  }

  function slotCounts(frame) {
    var c = { mount: 0, internal: 0, surface: 0 };
    arr(frame && frame.slots).forEach(function (s) { if (c[s.kind] !== undefined) c[s.kind]++; });
    return c;
  }

  // ---- Kurulum ekranı ----
  var frameInFlight = false;
  function renderSetup(state) {
    var isDirector = !!(state.you && state.you.role === 'director');
    el.setupDirector.hidden = !isDirector;
    el.setupWorker.hidden = isDirector;
    if (isDirector) {
      var idx = rememberCatalog(state.catalog);
      renderMissionCard(el.setupMission, state.mission, idx, null);
      clear(el.frameSelect);
      var frames = arr(state.frames).length ? arr(state.frames) : arr(state.frameOptions);
      frames.forEach(function (f, i) {
        var b = add(el.frameSelect, 'button', 'frame-card');
        b.type = 'button';
        b.setAttribute('data-frame', f.id);
        b.setAttribute('data-num', pad2(i + 1));
        // Görevin zorunlu aletlerinden bu gövdeye sığmayanlar (sunucudan; yoksa uyarı yok)
        var unfit = arr(f.unfit).filter(function (u) { return u && (u.name || u.partId); });
        b.setAttribute('data-unfit', unfit.length ? 'true' : 'false');
        b.disabled = frameInFlight;
        var art = add(b, 'span', 'fc-art');
        art.appendChild(silhouette(f.shape));
        var info = add(b, 'span', 'fc-info');
        add(info, 'span', 'fc-name', (f.name || f.id).toUpperCase());
        add(info, 'span', 'fc-desc', f.desc || '');
        var stats = add(info, 'span', 'fc-stats');
        var c = slotCounts(f);
        [['KÜTLE', fmtInt(f.massKg) + ' kg', ''], ['MALİYET', fmtInt(f.cost), 'fc-cost'],
          ['YUVA', String(arr(f.slots).length || (c.mount + c.internal + c.surface)), '']].forEach(function (r) {
          var st = add(stats, 'span', 'fc-stat ' + r[2]);
          add(st, 'span', 'fc-stat-l', r[0]);
          add(st, 'span', 'fc-stat-v mono', r[1]);
        });
        add(info, 'span', 'fc-slots', c.mount + ' motor · ' + c.internal + ' iç bölme · ' + c.surface + ' dış yüzey');
        if (unfit.length) {
          add(info, 'span', 'fc-unfit', 'Bu gövdede yer yok: ' + unfit.map(function (u) {
            return u.name || partName(idx, u.partId);
          }).join(', '));
        }
        add(info, 'span', 'fc-cta', unfit.length ? 'YİNE DE SEÇ' : 'BU GÖVDEYİ SEÇ');
      });
      if (!frames.length) add(el.frameSelect, 'p', 'hint', 'Gövde seçenekleri bekleniyor.');
    } else {
      clear(el.frameOptions);
      arr(state.frameOptions).forEach(function (f) {
        var d = add(el.frameOptions, 'div', 'frame-mini');
        add(d, 'span', 'fc-art').appendChild(silhouette(f.shape));
        var info = add(d, 'div', 'fc-info');
        add(info, 'p', 'fc-name', (f.name || f.id).toUpperCase());
        add(info, 'p', 'fc-desc', f.desc || '');
      });
    }
  }
  el.frameSelect.addEventListener('click', function (e) {
    var b = e.target.closest('button[data-frame]');
    if (!b || frameInFlight) return;
    frameInFlight = true;
    el.frameSelect.querySelectorAll('button[data-frame]').forEach(function (x) { x.disabled = true; });
    socket.emit('frame:select', { frameId: b.getAttribute('data-frame') }, function (res) {
      frameInFlight = false;
      if (!res || !res.ok) {
        partAck(res);
        if (lastState && lastState.phase === 'setup') renderSetup(lastState);
      } else showError('');
    });
  });

  // ---- Gövde/yuva bilgisi (çizim için; kural değil) ----
  function slotMeta(frame, slotId) {
    var f = obj(frame);
    var s = null;
    arr(f.slots).forEach(function (x) { if (x.id === slotId) s = x; });
    if (!s) return { name: slotId, meta: '', accepts: [] };
    var segName = '';
    if (s.segment === 'nose') segName = 'Burun';
    arr(obj(f.shape).segments).forEach(function (g) { if (g.id === s.segment) segName = g.name || ''; });
    var meta = [segName, KIND_NAMES[s.kind] || s.kind].filter(Boolean).join(' · ');
    return { name: s.name || slotId, meta: meta, accepts: arr(s.accepts) };
  }
  function acceptsText(list) { return list.map(function (c) { return CATEGORY_NAMES[c] || c; }).join(', '); }
  function occupantOf(state, slotId) {
    var o = null;
    arr(state.slots).forEach(function (s) { if (s.id === slotId) o = s.occupant || null; });
    return o;
  }

  // ---- Oyun: şerit ve sayaç yerleşimi ----
  // Yönetici geniş/iki sütun düzende sayacı roketin altında büyük görür; diğerlerinde şeritte.
  function placeTimer() {
    var role = lastState && lastState.you ? lastState.you.role : null;
    var host = role === 'director' && currentLayout !== 'stack' ? el.centerTimerHost : el.strip;
    if (el.timer.parentNode !== host) host.insertBefore(el.timer, host.firstChild);
    // Geniş düzende "Taktıklarım" sağ sütunda (yuva listesinin altında); diğerlerinde parçaların altında
    var mine = $('#mine-panel');
    var mineHost = currentLayout === 'wide' ? $('#col-c') : $('#col-a');
    if (mine.parentNode !== mineHost) mineHost.appendChild(mine);
  }
  function renderStrip(state) {
    var role = state.you ? state.you.role : null;
    el.phaseValue.textContent = PHASE_LABELS[state.phase] || state.phase;
    el.roleName.textContent = role ? ROLE_NAMES[role].toUpperCase() : 'ROL YOK';
    el.roleCell.setAttribute('data-r', role || '');
    el.missionLabel.textContent = state.missionLabel || 'GİZLİ';
    el.frameName.textContent = state.frame && state.frame.name ? state.frame.name : '—';
  }

  // ---- Çalışan ----
  var picked = null;        // seçili katalog parçası (partId)
  var addInFlight = false;  // part:add yanıtı bekleniyor

  function pickedPart(state) {
    if (!picked || !state) return null;
    var p = null;
    arr(state.catalog).forEach(function (x) { if (x && x.id === picked) p = x; });
    return p;
  }
  function validatePick(state) {
    var p = pickedPart(state);
    if (!p || p.locked === true || state.phase !== 'building') picked = null;
  }

  // Parça neden takılamıyor? (yalnız sunucunun gönderdiği `slots` + gerekçe metinlerinden; kural hesaplamaz)
  var LIMIT_RE = /daha fazla|sınır|limit|tekil|zaten bir/i;
  function slotAvailability(p) {
    if (!Array.isArray(p.slots)) return null;
    var list = p.slots.filter(Boolean);
    if (!list.length) return { tag: 'noslot', text: 'GÖVDEDE YER YOK', why: 'Bu gövdede bu parçayı alan yuva yok.' };
    if (list.some(function (s) { return s.ok; })) return null;
    var reasons = list.map(function (s) { return s.reason || ''; });
    if (reasons.every(function (r) { return LIMIT_RE.test(r); })) return { tag: 'limit', text: 'LİMİT DOLU', why: reasons[0] };
    return { tag: 'full', text: 'BOŞ YUVA YOK', why: reasons.filter(Boolean)[0] || '' };
  }

  function renderCatalog(state) {
    var inPoll = state.phase === 'poll';
    var placed = {};
    arr(state.myParts).forEach(function (m) { if (m && m.partId) placed[m.partId] = true; });
    clear(el.catalog);
    arr(state.catalog).forEach(function (p) {
      var li = add(el.catalog, 'li');
      var locked = p.locked === true;
      li.setAttribute('data-locked', locked ? 'true' : 'false');
      var b = add(li, 'button', 'pick');
      b.type = 'button';
      b.setAttribute('data-pick', p.id);
      b.setAttribute('aria-pressed', picked === p.id ? 'true' : 'false');
      b.disabled = locked || inPoll;
      var avail = locked ? null : slotAvailability(p);
      // Limit doluysa ve bu parça zaten bende takılıysa: "Takıldı" (A5: iki durumu ayır)
      if (avail && avail.tag === 'limit' && placed[p.id]) avail = { tag: 'placed', text: 'TAKILDI', why: avail.why };
      b.setAttribute('data-avail', locked ? 'locked' : (avail ? avail.tag : 'ok'));
      add(b, 'span', 'pi-icon', p.icon || '•').setAttribute('aria-hidden', 'true');
      var main = add(b, 'span', 'pi-main');
      add(main, 'span', 'pi-name', p.name || p.id);
      add(main, 'span', 'pi-cat', locked ? 'Tedarikte gecikme: şimdilik kilitli' : (avail ? avail.text.charAt(0) + avail.text.slice(1).toLocaleLowerCase('tr-TR') : (CATEGORY_NAMES[p.category] || p.category || '')));
      var tag = add(b, 'span', 'pi-light');
      tag.setAttribute('aria-hidden', 'true');
      if (avail && avail.why) b.title = avail.why;
    });
    if (!arr(state.catalog).length) add(el.catalog, 'li', 'hint', 'Katalog boş.');
    el.catalogNote.textContent = inPoll ? 'Ankette kilitli' : (picked ? '' : 'Birine dokun');
  }

  function renderSlotPanel(state) {
    var part = pickedPart(state);
    clear(el.slotList);
    el.slotHint.textContent = '';
    el.slotPanel.setAttribute('data-has-pick', part ? 'true' : 'false');
    if (!part) {
      el.slotNote.textContent = '';
      el.slotHint.textContent = state.phase === 'poll' ? 'Anket sürüyor; parçalar kilitli.' : 'Önce bir parça seç. Uygun yuvalar burada ve roketin üstünde görünür.';
      return;
    }
    el.slotNote.textContent = part.name || part.id;
    var opts = arr(part.slots).slice().sort(function (a, b) { return (b.ok ? 1 : 0) - (a.ok ? 1 : 0); });
    if (!opts.length) {
      el.slotHint.textContent = 'Bu gövdede bu parçayı alan yuva yok. Yöneticine söyle.';
      return;
    }
    var okCount = opts.filter(function (o) { return o.ok; }).length;
    el.slotHint.textContent = okCount ? (has2D() ? 'Bir yuvaya bas ya da roketteki yeşil yuvaya dokun.' : 'Takmak için bir yuvaya bas.') : 'Şu an uygun yuva yok. Nedenleri aşağıda.';
    opts.forEach(function (o) {
      var li = add(el.slotList, 'li');
      li.setAttribute('data-ok', o.ok ? 'true' : 'false');
      var m = slotMeta(state.frame, o.slotId);
      var b = add(li, 'button');
      b.type = 'button';
      b.setAttribute('data-slot', o.slotId);
      b.disabled = !o.ok || addInFlight || state.phase !== 'building';
      var main = add(b, 'span', 'sl-main');
      add(main, 'span', 'sl-name', m.name);
      if (m.meta) add(main, 'span', 'sl-meta', m.meta);
      add(b, 'span', 'sl-tag', o.ok ? 'TAK' : 'ENGELLİ');
      if (!o.ok && o.reason) add(li, 'p', 'sl-reason', o.reason);
    });
  }

  function renderPickedBar(state) {
    var part = pickedPart(state);
    el.pickedBar.hidden = !part;
    var was = ROOT.getAttribute('data-picked') === '1';
    if (part) ROOT.setAttribute('data-picked', '1'); else ROOT.removeAttribute('data-picked');
    if (was !== !!part) requestAnimationFrame(function () { updateBars(); resizeScene(); });
    if (part) {
      el.pickedIcon.textContent = part.icon || '•';
      el.pickedText.textContent = part.name || part.id;
      var none = arr(part.slots).length === 0;
      el.pickedSub.textContent = none ? 'Bu gövdede yeri yok' : (has2D() ? 'Yeşil yuvaya dokun ya da listeden seç' : 'Listeden bir yuva seç');
    }
  }

  function renderMyParts(state) {
    clear(el.myParts);
    var inPoll = state.phase === 'poll';
    var mine = arr(state.myParts);
    if (!mine.length) add(el.myParts, 'li', 'empty', 'Henüz parça takmadın.');
    mine.forEach(function (p) {
      var li = add(el.myParts, 'li');
      var status = STATUS_TEXT[p.status] ? p.status : 'green';
      li.setAttribute('data-st', status);
      var dot = add(li, 'span', 'status-dot');
      dot.setAttribute('data-status', status);
      dot.setAttribute('role', 'img');
      dot.setAttribute('aria-label', status === 'green' ? 'yeşil' : (status === 'yellow' ? 'sarı' : 'kırmızı'));
      var main = add(li, 'span', 'mp-main');
      add(main, 'span', 'mp-name', (p.icon ? p.icon + ' ' : '') + (p.name || p.partId || ''));
      add(main, 'span', 'mp-slot', p.slotName || '');
      add(li, 'span', 'mp-state', STATUS_TEXT[status]).setAttribute('data-status', status);
      var b = add(li, 'button', 'btn-line btn-small', 'ÇIKAR');
      b.type = 'button';
      b.setAttribute('data-remove', p.uid);
      b.setAttribute('aria-label', (p.name || 'Parça') + ' çıkar');
      b.disabled = inPoll;
    });
  }

  function renderOthers(state) {
    clear(el.others);
    var others = obj(state.others);
    WORKER_ROLES.forEach(function (r) {
      if (!(r in others)) return;
      var list = arr(others[r]);
      var div = add(el.others, 'div', 'other-team');
      div.setAttribute('data-other-role', r);
      add(div, 'p', 'eyebrow', ROLE_NAMES[r].toUpperCase());
      var row = add(div, 'div', 'chip-row');
      if (!list.length) add(row, 'span', 'chip-empty', 'henüz parça yok');
      list.forEach(function (p) { add(row, 'span', 'chip', (p.icon ? p.icon + ' ' : '') + (p.name || '')); });
    });
  }

  function renderTimeline(ul, entries, withCost) {
    clear(ul);
    entries.slice().reverse().forEach(function (f) {
      var li = add(ul, 'li');
      var kind = f.kind || (f.role == null ? 'system' : 'part');
      li.setAttribute('data-kind', kind);
      add(li, 'span', 't mono', timeStr(f.t));
      add(li, 'span', 'x', f.text || '');
      if (withCost && isNum(f.cost) && f.cost !== 0) {
        var c = add(li, 'span', 'c mono', (f.cost > 0 ? '+' : '−') + fmtInt(Math.abs(f.cost)));
        c.setAttribute('data-sign', f.cost > 0 ? 'plus' : 'minus');
      }
    });
    if (!entries.length) add(ul, 'li', 'hint', 'Henüz hareket yok.');
  }

  function renderWorker(state) {
    validatePick(state);
    renderCatalog(state);
    renderSlotPanel(state);
    renderPickedBar(state);
    renderMyParts(state);
    renderOthers(state);
    renderTimeline(el.feed, arr(state.feed), false);
  }

  // ---- Yönetici ----
  function setGauge(node, value, of, ok) {
    node.querySelector('.gv').textContent = value;
    node.querySelector('.g-of').textContent = of;
    node.setAttribute('data-ok', ok ? 'true' : 'false');
    node.querySelector('.gc-mark').textContent = ok ? '✓' : '✕';
  }
  function renderGauges(state, idx) {
    var tm = obj(state.telemetry), checks = obj(tm.checks), mission = obj(state.mission);
    var minTwr = isNum(tm.minTwr) ? tm.minTwr : 1.2;
    var missing = arr(tm.missing);
    setGauge($('#g-twr'), num(tm.twr).toFixed(2), ' / ≥ ' + minTwr, checks.twr === true);
    setGauge($('#g-deltav'), fmtInt(tm.deltaV), ' / ' + (mission.requiredDeltaV !== undefined ? fmtInt(mission.requiredDeltaV) : '-') + ' m/s', checks.deltaV === true);
    setGauge($('#g-power'), fmtInt(tm.powerGenW), ' / ' + fmtInt(tm.powerUseW) + ' W', checks.power === true);
    setGauge($('#g-heat'), fmtInt(tm.heat), ' / ' + fmtInt(tm.heatShield) + ' kalkan', checks.heat === true);
    setGauge($('#g-payload'),
      missing.length ? 'Eksik: ' + missing.map(function (id) { return partName(idx, id); }).join(', ') : 'Aletler tam',
      tm.overBudget ? ' · bütçe aşıldı' : '', checks.payload === true);
    // Yedek bilgisayar göstergesi yalnız arıza olayında var
    var comp = $('#g-computer');
    if (checks.computer !== undefined) {
      if (!comp) {
        comp = add(el.gauges, 'li');
        comp.id = 'g-computer';
        comp.setAttribute('data-check', 'computer');
        add(comp, 'span', 'gc-name', 'YEDEK BİLGİSAYAR');
        var v = add(comp, 'span', 'gc-val');
        add(v, 'span', 'gv'); add(v, 'span', 'g-of');
        add(comp, 'span', 'gc-mark').setAttribute('aria-hidden', 'true');
      }
      setGauge(comp, checks.computer === true ? 'Takılı' : 'Takılı değil', checks.computer === true ? '' : ' · uzay aracına takılmalı', checks.computer === true);
    } else if (comp) comp.parentNode.removeChild(comp);
    var ready = tm.ready === true;
    el.readyLine.textContent = ready ? 'KALKIŞA HAZIR' : 'HENÜZ HAZIR DEĞİL';
    el.readyLine.setAttribute('data-ready', ready ? 'true' : 'false');
  }

  function renderBudget(state) {
    var tm = obj(state.telemetry), mission = obj(state.mission);
    var b = state.budget && typeof state.budget === 'object' ? state.budget : null;
    var total = b ? num(b.total) : num(mission.budget);
    var spent = b ? num(b.spent) : num(tm.spent);
    var left = b && isNum(b.left) ? b.left : total - spent;
    var over = left < 0 || tm.overBudget === true;
    el.budgetSpent.textContent = fmtInt(spent);
    el.budgetTotal.textContent = fmtInt(total);
    el.budgetBar.style.width = pct(total > 0 ? spent / total : 0);
    el.budgetLeft.textContent = over ? 'AŞIM: ' + fmtInt(-left) : 'KALAN: ' + fmtInt(left);
    el.budgetBox.setAttribute('data-over', over ? 'true' : 'false');
  }

  function renderTelemetry(tm) {
    clear(el.telemetryBox);
    add(el.telemetryBox, 'p', 'eyebrow', 'ÖLÇÜMLER');
    var rows = [
      ['Toplam kütle', fmtInt(tm.massKg) + ' kg'], ['Kuru kütle', fmtInt(tm.dryMassKg) + ' kg'],
      ['Yakıt', fmtInt(tm.fuelKg) + ' kg'], ['İtki', fmtInt(tm.thrustKN) + ' kN'], ['Isp', fmtInt(tm.isp) + ' s']
    ];
    if (isNum(tm.frameMassKg)) rows.push(['Gövde kütlesi', fmtInt(tm.frameMassKg) + ' kg']);
    rows.push(['Harcanan', fmtInt(tm.spent), 'kv-amber']);
    kvList(el.telemetryBox, rows);
  }

  function renderFrameBox(state) {
    clear(el.frameBox);
    var fi = obj(state.frameInfo), fr = obj(state.frame);
    if (!fi.name && !fr.name) return;
    var wrap = add(el.frameBox, 'div', 'frame-line');
    add(wrap, 'span', 'fc-art').appendChild(silhouette(fr.shape));
    var info = add(wrap, 'div', 'fc-info');
    add(info, 'p', 'eyebrow', 'GÖVDE');
    add(info, 'p', 'fl-name', fi.name || fr.name);
    var used = arr(state.slots).filter(function (s) { return s && s.occupant; }).length;
    kvList(info, [
      ['Kütle', fmtInt(fi.massKg) + ' kg'], ['Maliyet', fmtInt(fi.cost), 'kv-amber'],
      ['Dolu yuva', used + ' / ' + arr(state.slots).length]
    ]);
  }

  function renderBuild(build) {
    clear(el.buildBox);
    var b = obj(build);
    WORKER_ROLES.forEach(function (r) {
      var list = arr(b[r]);
      var div = add(el.buildBox, 'div', 'build-role');
      div.setAttribute('data-build-role', r);
      var head = add(div, 'p', 'br-head');
      add(head, 'span', null, ROLE_NAMES[r].toUpperCase());
      add(head, 'span', 'mono', list.length + ' parça');
      var ul = add(div, 'ul', 'br-list');
      if (!list.length) add(ul, 'li', 'br-empty', 'boş');
      list.forEach(function (p) {
        var li = add(ul, 'li');
        li.setAttribute('data-slot-id', p.slotId || '');
        var main = add(li, 'span', 'br-main');
        add(main, 'span', 'br-name', (p.icon ? p.icon + ' ' : '') + (p.name || p.partId || ''));
        add(main, 'span', 'br-slot', p.slotName || '');
        add(li, 'span', 'br-cost mono', isNum(p.cost) ? fmtInt(p.cost) : '');
      });
    });
  }

  var CATALOG_COLUMNS = [
    ['category', 'Kategori'], ['cost', 'Fiyat'], ['massKg', 'Kütle kg'], ['powerGenW', 'Güç+ W'],
    ['powerUseW', 'Güç- W'], ['thrustKN', 'İtki kN'], ['isp', 'Isp s'], ['heat', 'Isı'],
    ['heatShield', 'Isı kalkanı'], ['fuelKg', 'Yakıt kg'], ['ispMult', 'Isp çarpanı'], ['max', 'Max'],
    ['requires', 'Gerekir'], ['tags', 'Etiket']
  ];
  var catalogKey = '';
  function renderDirectorCatalog(catalog, locks) {
    var key = JSON.stringify([catalog, locks]);
    if (key === catalogKey) return; // açık tablonun kaydırması korunsun
    catalogKey = key;
    clear(el.directorCatalog);
    var lk = obj(locks);
    if (!catalog || typeof catalog !== 'object') return;
    WORKER_ROLES.forEach(function (r) {
      var list = arr(catalog[r]);
      if (!list.length) return;
      add(el.directorCatalog, 'p', 'eyebrow', ROLE_NAMES[r].toUpperCase());
      var wrap = add(el.directorCatalog, 'div', 'table-scroll');
      var table = add(wrap, 'table');
      var head = add(table, 'tr');
      add(head, 'th', null, 'Parça');
      CATALOG_COLUMNS.forEach(function (c) { add(head, 'th', null, c[1]); });
      list.forEach(function (p) {
        var tr = add(table, 'tr');
        tr.setAttribute('data-part', p.id);
        var locked = lk[p.id] !== undefined && lk[p.id] !== null;
        tr.setAttribute('data-locked', locked ? 'true' : 'false');
        add(tr, 'td', null, (p.icon ? p.icon + ' ' : '') + (p.name || p.id) + (locked ? ' (KİLİTLİ)' : ''));
        CATALOG_COLUMNS.forEach(function (c) {
          var v = p[c[0]];
          add(tr, 'td', null, Array.isArray(v) ? (v.join(', ') || '-') : (c[0] === 'category' ? (CATEGORY_NAMES[v] || v) : fmtNum(v)));
        });
      });
    });
  }

  function renderDirector(state) {
    var idx = rememberCatalog(state.catalog);
    var tm = obj(state.telemetry);
    renderBudget(state);
    renderMissionCard(el.missionBox, state.mission, idx, tm.missing);
    renderFrameBox(state);
    renderTelemetry(tm);
    var logs = arr(state.log);
    renderTimeline(el.logBox.querySelector('ul') || add(el.logBox, 'ul', 'timeline'), logs, true);
    // Kapalı çekmece: son kayıt tek satır
    clear(el.lastLog);
    var last = logs[logs.length - 1];
    add(el.lastLog, 'span', 'll-label', 'SON KAYIT');
    add(el.lastLog, 'span', 'll-text', last ? last.text || '' : 'Henüz hareket yok');
    if (last && isNum(last.cost) && last.cost !== 0) {
      add(el.lastLog, 'span', 'll-cost mono', (last.cost > 0 ? '+' : '−') + fmtInt(Math.abs(last.cost))).setAttribute('data-sign', last.cost > 0 ? 'plus' : 'minus');
    }
    renderGauges(state, idx);
    renderBuild(state.build);
    renderDirectorCatalog(state.catalog, state.locks);
    var delay = num(state.telemetryDelayMs);
    el.delayNote.hidden = !(delay > 0);
    el.delayNote.textContent = delay > 0 ? 'Ölçümler ' + fmtNum(Math.round(delay / 100) / 10) + ' sn gecikmeli' : '';
  }

  function renderGame(state) {
    var role = state.you ? state.you.role : null;
    var isDirector = role === 'director';
    renderStrip(state);
    placeTimer();
    el.sceneNote.textContent = !has2D() ? '' : (isDirector ? 'Yuvaya dokun: bilgi' :
      (state.phase === 'poll' ? 'Anket sürüyor' : (picked ? '' : 'Parça seç, sonra yeşil yuvaya dokun')));
    if (isDirector) {
      clear(el.catalog); clear(el.myParts); clear(el.others); clear(el.feed); clear(el.slotList);
      picked = null;
      el.pickedBar.hidden = true;
      ROOT.removeAttribute('data-picked');
      renderDirector(state);
    } else {
      clear(el.missionBox); clear(el.telemetryBox); clear(el.logBox); clear(el.buildBox); clear(el.frameBox);
      renderWorker(state);
    }
  }

  // ---- Anket ----
  var VOTE_TEXT = { go: 'GO', nogo: 'NO-GO', pending: 'BEKLENİYOR' };
  function renderPoll(state) {
    var role = state.you ? state.you.role : null;
    var isDirector = role === 'director';
    var isWorker = WORKER_ROLES.indexOf(role) !== -1;
    var inPoll = state.phase === 'poll';
    el.pollControls.setAttribute('data-phase', state.phase || '');

    el.pollStartWrap.hidden = !(isDirector && state.phase === 'building');
    var ready = !!(state.telemetry && state.telemetry.ready === true);
    el.pollWarning.hidden = ready;
    el.pollReadyNote.hidden = !ready;
    el.pollStartBtn.setAttribute('data-ready', ready ? 'true' : 'false');
    updatePollStartBtn();

    el.pollBox.hidden = !inPoll;
    var poll = obj(state.poll);
    var votes = obj(poll.votes);
    el.voteItems.forEach(function (li) {
      var r = li.getAttribute('data-vote-role');
      var v = votes[r] === 'go' || votes[r] === 'nogo' ? votes[r] : 'pending';
      li.setAttribute('data-vote', v);
      clear(li);
      add(li, 'span', 'vt-role', ROLE_NAMES[r]);
      add(li, 'span', 'vt-state', VOTE_TEXT[v]);
    });
    el.pollNote.textContent = isDirector ? 'Herkes GO derse roket fırlatılır. Bir NO-GO anketi kapatır.' : 'Roket uçmaya hazır mı? Tek bir NO-GO anketi kapatır.';

    el.voteBtns.hidden = !(inPoll && isWorker);
    el.pollCancelBtn.hidden = !(inPoll && isDirector);
    var mv = poll.myVote === 'go' || poll.myVote === 'nogo' ? poll.myVote : null;
    el.myVote.textContent = mv ? 'Oyun: ' + VOTE_TEXT[mv] + '. Fikrini değiştirebilirsin.' : 'Henüz oy vermedin.';
    el.voteGoBtn.setAttribute('aria-pressed', mv === 'go' ? 'true' : 'false');
    el.voteNogoBtn.setAttribute('aria-pressed', mv === 'nogo' ? 'true' : 'false');
  }

  // ---- Sayaç, bekleme, olaylar, geri alma ----
  var clockOffset = 0;
  var tickTimer = null;
  var EVENT_NEW_MS = 5000;
  var EVENT_ICONS = { 'weather': '⛈', 'computer-fault': '💻', 'supplier-delay': '📦' };

  function serverNow() { return Date.now() + clockOffset; }
  function secsLeft(untilMs) { return isNum(untilMs) ? Math.max(0, Math.ceil((untilMs - serverNow()) / 1000)) : 0; }
  function liveState() {
    return lastState && (lastState.phase === 'building' || lastState.phase === 'poll') ? lastState : null;
  }
  function holdActive() {
    var s = liveState();
    return !!(s && isNum(s.holdUntil) && s.holdUntil > serverNow());
  }

  function updateTimer() {
    var s = liveState();
    var t = s && s.timer && typeof s.timer === 'object' ? s.timer : null;
    if (t) {
      var left = secsLeft(t.endsAt);
      var w = t.window === 2 ? 2 : 1;
      el.timer.setAttribute('data-window', String(w));
      el.timer.setAttribute('data-urgent', left <= 30 ? 'true' : 'false');
      el.timerLabel.textContent = w === 2 ? 'son pencere' : 'fırlatma penceresi';
      el.timerValue.textContent = pad2(Math.floor(left / 60)) + ':' + pad2(left % 60);
    } else {
      el.timerValue.textContent = '--:--';
      el.timerLabel.textContent = '';
    }
    var hold = holdActive();
    var wasHidden = el.holdBanner.hidden;
    el.holdBanner.hidden = !hold;
    el.holdBanner.textContent = hold ? 'FIRLATMA BEKLEMEDE · ' + secsLeft(s.holdUntil) + ' sn' : '';
    if (wasHidden !== el.holdBanner.hidden) updateBars();
  }

  function updatePollStartBtn() {
    if (pendingBtns.indexOf(el.pollStartBtn) !== -1) return;
    el.pollStartBtn.disabled = holdActive();
  }

  var eventsKey = '';
  function renderEvents() {
    var s = liveState();
    var list = s && Array.isArray(s.events) ? s.events.slice() : [];
    var now = serverNow();
    list.sort(function (a, b) { return num(b && b.t) - num(a && a.t); });
    // Her tikte DOM'u baştan kurmamak için değişmediyse atla
    var key = list.map(function (e) {
      return e ? [e.id, e.type, e.text, isNum(e.until) && e.until > now ? secsLeft(e.until) : '', isNum(e.t) && now - e.t < EVENT_NEW_MS].join('|') : '';
    }).join(';');
    if (key === eventsKey && !el.eventsBox.hidden === !!list.length) return;
    eventsKey = key;
    el.eventsBox.hidden = !list.length;
    clear(el.eventsBox);
    if (!list.length) return;
    var ul = add(el.eventsBox, 'ul');
    list.forEach(function (e) {
      if (!e || typeof e !== 'object') return;
      var li = add(ul, 'li');
      li.setAttribute('data-event-type', e.type || '');
      if (e.id !== undefined) li.setAttribute('data-event-id', String(e.id));
      li.setAttribute('data-new', isNum(e.t) && now - e.t < EVENT_NEW_MS ? 'true' : 'false');
      add(li, 'span', 'ev-icon', EVENT_ICONS[e.type] || '⚠').setAttribute('aria-hidden', 'true');
      add(li, 'span', 'ev-text', e.text || e.type || '');
      if (isNum(e.until) && e.until > now) add(li, 'span', 'ev-left mono', secsLeft(e.until) + ' sn');
    });
  }

  function renderUndo(state) {
    var isDirector = !!(state && state.you && state.you.role === 'director');
    var live = !!liveState();
    el.undoBox.hidden = !(isDirector && live && state.phase === 'building');
    if (el.undoBox.hidden) return;
    var u = obj(state.undo);
    var left = isNum(u.left) ? u.left : (isNum(state.undoLeft) ? state.undoLeft : 0);
    var avail = obj(u.available);
    el.undoLeft.textContent = left + ' / 3 hak';
    el.undoBtns.forEach(function (b) {
      if (pendingBtns.indexOf(b) !== -1) return;
      var r = b.getAttribute('data-undo');
      b.disabled = state.phase !== 'building' || left <= 0 || avail[r] !== true;
    });
  }

  function onTick() {
    updateTimer();
    renderEvents();
    updatePollStartBtn();
  }
  function startTicker() {
    if (!tickTimer) tickTimer = setInterval(onTick, 250);
    onTick();
  }
  function stopTicker() {
    if (tickTimer) clearInterval(tickTimer);
    tickTimer = null;
  }
  function hideLiveBoxes() {
    stopTicker();
    el.eventsBox.hidden = true;
    eventsKey = '';
    el.undoBox.hidden = true;
    el.holdBanner.hidden = true;
    el.pollBox.hidden = true;
  }

  // ---- 2B roket sahnesi (public/scene2d.js; yalnız PLAN arayüzü üzerinden) ----
  var scene = null;
  var sceneStatus = 'idle'; // idle | loading | ready | failed
  var sceneSync = { frameId: undefined, slotsKey: null, hlKey: null, role: null };
  var lastFrame = null, lastSlots = null;
  function has2D() { return sceneStatus !== 'failed'; } // sahne yoksa metinler yalnız listeye yönlendirir

  function ensureScene() {
    if (sceneStatus !== 'idle') return;
    sceneStatus = 'loading';
    import('/scene2d.js').then(function (mod) {
      if (!mod || mod.supported === false || typeof mod.createRocketScene !== 'function') throw new Error('sahne desteklenmiyor');
      scene = mod.createRocketScene(el.scene3d);
      if (!scene) throw new Error('sahne kurulamadı');
      if (typeof scene.onSlotClick === 'function') scene.onSlotClick(onSceneSlot);
      if (typeof scene.onPartClick === 'function') scene.onPartClick(onScenePart);
      sceneStatus = 'ready';
      ROOT.removeAttribute('data-scene');
      sceneSync = { frameId: undefined, slotsKey: null, hlKey: null, role: null };
      if (lastState) {
        if (liveState()) syncScene(lastState);
        else if (lastState.phase === 'result') enterResultScene();
      }
      resizeScene();
    }).catch(function (err) {
      sceneStatus = 'failed';
      scene = null;
      if (window.console) console.warn('Roket sahnesi yüklenemedi:', err && err.message ? err.message : err);
      showSceneFallback();
      if (lastState && lastState.phase === 'result') el.result.setAttribute('data-scene', 'none');
      if (liveState()) renderGame(lastState); // sahneye atıf yapan metinleri liste yönergesiyle değiştir
    });
  }
  function showSceneFallback() {
    clear(el.scene3d);
    el.scene3d.setAttribute('data-fallback', '1');
    ROOT.setAttribute('data-scene', 'none'); // CSS: roket alanı küçük not olarak kalır, listeler büyür
    var n = add(el.scene3d, 'div', 'scene-fallback');
    add(n, 'strong', null, 'ROKET ÇİZİMİ YÜKLENEMEDİ');
    add(n, 'span', null, 'Yuvaları listeden seç; takılı parçalar listelerde görünür.');
  }
  function resizeScene() {
    if (scene && typeof scene.resize === 'function') { try { scene.resize(); } catch (e) { /* yok say */ } }
  }
  function sceneCall(fn, arg) {
    if (!scene || typeof scene[fn] !== 'function') return;
    try { scene[fn](arg); } catch (e) { if (window.console) console.warn('Sahne:', fn, e && e.message); }
  }
  function highlightMap(state) {
    var part = pickedPart(state);
    if (!part || state.phase !== 'building') return null;
    var m = {};
    arr(part.slots).forEach(function (s) { if (s && s.slotId) m[s.slotId] = s.ok ? 'ok' : 'blocked'; });
    return m;
  }
  function syncScene(state) {
    if (state.frame) lastFrame = state.frame;
    if (Array.isArray(state.slots)) lastSlots = state.slots;
    if (!scene) return;
    var role = state.you ? state.you.role : null;
    if (sceneSync.role !== role) { sceneSync.role = role; sceneCall('setMyRole', role); }
    var frame = state.frame || null;
    var fid = frame ? frame.id : null;
    if (sceneSync.frameId !== fid) {
      sceneSync.frameId = fid;
      sceneSync.slotsKey = null;
      sceneSync.hlKey = null;
      sceneCall('setFrame', frame);
    }
    var sk = JSON.stringify(state.slots || []);
    if (sk !== sceneSync.slotsKey) { sceneSync.slotsKey = sk; sceneCall('setSlots', arr(state.slots)); }
    var hl = highlightMap(state);
    var hk = JSON.stringify(hl);
    if (hk !== sceneSync.hlKey) { sceneSync.hlKey = hk; sceneCall('setHighlights', hl); }
  }
  function moveSceneTo(host) {
    if (el.scene3d.parentNode !== host) {
      host.appendChild(el.scene3d);
      requestAnimationFrame(resizeScene);
    }
  }

  // Roket üstündeki bilgi kutusu
  function hideSceneInfo() { el.sceneInfo.hidden = true; clear(el.sceneInfo); }
  function showSceneInfo(kind, title, rows, reason, actions) {
    clear(el.sceneInfo);
    el.sceneInfo.hidden = false;
    el.sceneInfo.setAttribute('data-kind', kind);
    var x = add(el.sceneInfo, 'button', 'btn-x si-close', '×');
    x.type = 'button';
    x.setAttribute('aria-label', 'Kapat');
    x.addEventListener('click', hideSceneInfo);
    add(el.sceneInfo, 'p', 'si-title', title);
    (rows || []).forEach(function (r) {
      if (r instanceof Node) el.sceneInfo.appendChild(r); else if (r) add(el.sceneInfo, 'p', 'si-row', r);
    });
    if (reason) add(el.sceneInfo, 'p', 'si-reason', reason);
    if (actions && actions.length) {
      var row = add(el.sceneInfo, 'div', 'si-actions');
      actions.forEach(function (a) {
        var b = add(row, 'button', 'btn-line ' + (a.cls || ''), a.label);
        b.type = 'button';
        b.addEventListener('click', a.fn);
      });
    }
  }

  function onSceneSlot(slotId) {
    var s = liveState();
    if (!s) return;
    var m = slotMeta(s.frame, slotId);
    var isDirector = s.you && s.you.role === 'director';
    var occ = occupantOf(s, slotId);
    if (occ) { onScenePart(slotId); return; }
    if (isDirector) {
      showSceneInfo('info', m.name, [m.meta, 'Boş · Alır: ' + acceptsText(m.accepts)]);
      return;
    }
    var part = pickedPart(s);
    if (!part) {
      showSceneInfo('info', m.name, ['Boş · Alır: ' + acceptsText(m.accepts), 'Önce PARÇALARIM listesinden bir parça seç.']);
      return;
    }
    var opt = null;
    arr(part.slots).forEach(function (o) { if (o.slotId === slotId) opt = o; });
    if (opt && opt.ok) { addPart(slotId); return; }
    showSceneInfo('blocked', m.name + ' · ENGELLİ', [m.meta],
      opt && opt.reason ? opt.reason : (part.name || part.id) + ' bu yuvaya uymuyor.');
  }

  function onScenePart(slotId) {
    var s = liveState();
    if (!s) return;
    var occ = occupantOf(s, slotId);
    var m = slotMeta(s.frame, slotId);
    if (!occ) { onSceneSlot(slotId); return; }
    var title = (occ.icon ? occ.icon + ' ' : '') + (occ.name || '');
    var isDirector = s.you && s.you.role === 'director';
    if (isDirector) {
      var cost = null;
      arr(obj(s.build)[occ.role]).forEach(function (p) { if (p.slotId === slotId && isNum(p.cost)) cost = p.cost; });
      var rows = [ROLE_NAMES[occ.role] + ' · ' + m.name];
      if (cost !== null) { var pr = h('p', 'si-row'); pr.appendChild(document.createTextNode('Fiyat: ')); add(pr, 'span', 'si-price mono', fmtInt(cost)); rows.push(pr); }
      showSceneInfo('info', title, rows);
      return;
    }
    if (occ.mine) {
      var uid = null;
      arr(s.myParts).forEach(function (p) { if (p.slotId === slotId) uid = p.uid; });
      if (!uid || s.phase !== 'building') {
        showSceneInfo('info', title, ['Senin parçan · ' + m.name, s.phase === 'poll' ? 'Anket sürerken çıkarılamaz.' : '']);
        return;
      }
      showSceneInfo('confirm', title + ' çıkarılsın mı?', ['Senin parçan · ' + m.name], null, [
        { label: 'EVET, ÇIKAR', cls: 'btn-danger', fn: function () { hideSceneInfo(); removePart(uid); } },
        { label: 'VAZGEÇ', cls: '', fn: hideSceneInfo }
      ]);
      return;
    }
    showSceneInfo('info', title, [ROLE_NAMES[occ.role] + ' ekibinin parçası · ' + m.name, 'Bu yuva dolu.']);
  }

  // ---- Parça ekle / çıkar ----
  function partAck(res) {
    if (!res || !res.ok) showError(res && res.message ? res.message : 'Bilinmeyen hata.');
    else showError('');
  }
  function addPart(slotId) {
    var s = liveState();
    if (!s || !picked || addInFlight) return;
    addInFlight = true;
    el.slotMsg.hidden = true;
    renderSlotPanel(s);
    var partId = picked;
    socket.emit('part:add', { partId: partId, slotId: slotId }, function (res) {
      addInFlight = false;
      if (res && res.ok) {
        showError('');
        if (picked === partId) picked = null;
        hideSceneInfo();
      } else {
        var msg = res && res.message ? res.message : 'Bilinmeyen hata.';
        showError(msg);
        el.slotMsg.textContent = msg;
        el.slotMsg.hidden = false;
      }
      if (liveState()) { renderGame(lastState); syncScene(lastState); }
    });
  }
  function removePart(uid) {
    socket.emit('part:remove', { uid: uid }, partAck);
  }
  function setPicked(id) {
    picked = picked === id ? null : id;
    el.slotMsg.hidden = true;
    hideSceneInfo();
    var s = liveState();
    if (!s) return;
    renderGame(s);
    syncScene(s);
    if (picked && currentLayout === 'stack') requestAnimationFrame(alignSceneTop);
    else if (picked && currentLayout === 'split') {
      try { el.slotPanel.scrollIntoView({ block: 'nearest', behavior: 'smooth' }); } catch (e) { /* yok say */ }
    }
  }
  // Telefon: roket alanının üstünü yapışkan şeridin altına hizala; yuva listesi hemen altından akar.
  function alignSceneTop() {
    var top = el.gameBody.getBoundingClientRect().top + window.scrollY;
    var y = Math.max(0, top - el.strip.offsetHeight);
    try { window.scrollTo({ top: y, behavior: 'smooth' }); } catch (e) { window.scrollTo(0, y); }
  }

  // ---- Çekmece ----
  var DRAWER_TITLES = { log: 'KAYIT', parts: 'TAKILI PARÇALAR', catalog: 'TAM KATALOG' };
  var drawerOpener = null;
  function openDrawer(sec) {
    if (!DRAWER_TITLES[sec]) return;
    drawerOpener = document.activeElement;
    el.drawerTitle.textContent = sec === 'log' && lastState && lastState.you && lastState.you.role !== 'director' ? 'KAYIT VE EKİP' : DRAWER_TITLES[sec];
    el.drawer.querySelectorAll('[data-drawer-sec]').forEach(function (d) { d.hidden = d.getAttribute('data-drawer-sec') !== sec; });
    el.drawer.hidden = false;
    el.drawerScrim.hidden = false;
    el.drawer.setAttribute('data-sec', sec);
    ROOT.setAttribute('data-drawer', sec);
    try { el.drawerClose.focus({ preventScroll: true }); } catch (e) { /* yok say */ }
  }
  function closeDrawer() {
    if (el.drawer.hidden) return;
    el.drawer.hidden = true;
    el.drawerScrim.hidden = true;
    ROOT.removeAttribute('data-drawer');
    if (drawerOpener && document.contains(drawerOpener) && typeof drawerOpener.focus === 'function') {
      try { drawerOpener.focus({ preventScroll: true }); } catch (e) { /* yok say */ }
    }
    drawerOpener = null;
  }
  document.addEventListener('click', function (e) {
    var b = e.target.closest('[data-drawer]');
    if (b) openDrawer(b.getAttribute('data-drawer'));
  });
  el.drawerClose.addEventListener('click', closeDrawer);
  el.drawerScrim.addEventListener('click', closeDrawer);

  // ---- Nasıl oynanır ----
  function openHelp() {
    el.helpPanel.hidden = false;
    try { el.helpClose.focus({ preventScroll: true }); } catch (e) { /* yok say */ }
  }
  function closeHelp() {
    if (el.helpPanel.hidden) return;
    el.helpPanel.hidden = true;
    try { el.helpBtn.focus({ preventScroll: true }); } catch (e) { /* yok say */ }
  }
  el.helpBtn.addEventListener('click', openHelp);
  el.helpClose.addEventListener('click', closeHelp);
  el.helpPanel.addEventListener('click', function (e) { if (e.target === el.helpPanel) closeHelp(); });

  // ---- Fırlatma dizisi (2B animasyon + altyazı) ----
  var OUTCOME_LINES = {
    'success': ['Kalkış!', 'Kademeler ayrıldı', 'Yörüngeye ulaşıldı'],
    'no-liftoff': ['Motorlar çalışıyor', 'Roket kıpırdamıyor'],
    'out-of-fuel': ['Kalkış!', 'Yakıt bitti'],
    'power-loss': ['Kalkış!', 'Güç kesildi'],
    'overheat': ['Kalkış!', 'Aşırı ısınma'],
    'mission-failed': ['Kalkış!', 'Hedefe varıldı ama görev tamamlanamadı'],
    'computer-failure': ['Kalkış!', 'Uçuş bilgisayarı yanıt vermiyor']
  };
  var NO_SEQUENCE = { 'window-missed': true };
  var OUTCOME_TITLES = { 'computer-failure': 'Uçuş bilgisayarı arızalandı', 'window-missed': 'Fırlatma penceresi kaçırıldı' };
  var launchTimers = [];
  var launchToken = 0;
  var shownResultKey = null;

  function stopLaunch() {
    launchTimers.forEach(clearTimeout);
    launchTimers = [];
    launchToken++;
  }
  function finishLaunch() {
    stopLaunch();
    el.launchWrap.hidden = true;
    el.resultPanel.hidden = false;
    el.result.setAttribute('data-stage', 'panel');
    el.resultStageTitle.textContent = 'SONUÇ';
    requestAnimationFrame(resizeScene);
  }
  function wait(ms) { return new Promise(function (r) { launchTimers.push(setTimeout(r, ms)); }); }
  function playLaunch(outcome) {
    stopLaunch();
    var token = launchToken;
    clear(el.launchSeq);
    el.launchWrap.hidden = false;
    el.resultPanel.hidden = true;
    el.result.setAttribute('data-stage', 'launch');
    el.resultStageTitle.textContent = 'FIRLATMA';
    var lines = ['T-3', 'T-2', 'T-1', 'ATEŞLEME'].concat(OUTCOME_LINES[outcome] || ['Kalkış!']);
    var step = 3800 / lines.length;
    lines.forEach(function (text, i) {
      launchTimers.push(setTimeout(function () {
        clear(el.launchSeq);
        add(el.launchSeq, 'p', null, text);
      }, Math.round(i * step)));
    });
    var done = function () { if (token === launchToken) finishLaunch(); };
    if (scene && el.result.getAttribute('data-scene') === 'live' && typeof scene.playLaunch === 'function') {
      requestAnimationFrame(resizeScene);
      var anim;
      try { anim = Promise.resolve(scene.playLaunch(outcome)); } catch (e) { anim = Promise.resolve(); }
      Promise.race([
        Promise.all([anim.catch(function () {}), wait(4200)]),
        wait(16000)
      ]).then(done);
    } else {
      launchTimers.push(setTimeout(done, 4200));
    }
  }
  function enterResultScene() {
    var live = !!(scene && lastFrame);
    el.result.setAttribute('data-scene', live ? 'live' : 'none');
    if (!live) return;
    moveSceneTo(el.resultSceneHost);
    if (sceneSync.frameId !== lastFrame.id) {
      sceneSync.frameId = lastFrame.id;
      sceneCall('setFrame', lastFrame);
      if (lastSlots) sceneCall('setSlots', lastSlots);
    }
    sceneSync.hlKey = 'null';
    sceneCall('setHighlights', null);
  }

  // ---- Sonuç paneli ----
  var CHECK_LABELS = { twr: 'İtki/Ağırlık', deltaV: 'Δv', power: 'Güç', payload: 'Aletler + Bütçe', heat: 'Isı', computer: 'Yedek bilgisayar' };

  function renderResult(state) {
    var r = obj(state.result);
    var isDirector = !!(state.you && state.you.role === 'director');
    el.result.setAttribute('data-outcome', r.outcome || '');
    el.result.setAttribute('data-success', r.success === true ? 'true' : 'false');
    el.resultBadge.textContent = r.success === true ? 'GÖREV BAŞARILI' : 'GÖREV BAŞARISIZ';
    el.resultTitle.textContent = r.title || OUTCOME_TITLES[r.outcome] || (r.success ? 'Başarılı!' : 'Başarısız');
    el.resultReason.textContent = r.reasonText ||
      (r.outcome === 'window-missed' ? 'İki fırlatma penceresi de anket tamamlanmadan kapandı; roket rampada kaldı.' : '');

    var score = obj(r.score);
    var stars = Math.max(0, Math.min(3, Math.round(num(score.stars))));
    clear(el.resultScore);
    var tot = add(el.resultScore, 'span', 'rs-box');
    add(tot, 'span', 'rs-label', 'PUAN');
    add(tot, 'span', 'rs-total mono', int(score.total));
    add(el.resultScore, 'span', 'rs-stars', new Array(stars + 1).join('★') + new Array(3 - stars + 1).join('☆')).setAttribute('aria-label', stars + ' yıldız');

    clear(el.resultBreakdown);
    arr(score.breakdown).forEach(function (b) {
      var p = Math.round(num(b.points));
      var val = b.key === 'time' && (r.timeLeftSec === null || r.timeLeftSec === undefined) ? '—' : (p > 0 ? '+' : '') + p;
      var li = add(el.resultBreakdown, 'li');
      if (b.key) li.setAttribute('data-score-key', b.key);
      add(li, 'span', null, b.label || b.key || '');
      add(li, 'span', 'bd-val mono', val).setAttribute('data-sign', p > 0 ? 'plus' : (p < 0 ? 'minus' : 'zero'));
    });

    var tl = isNum(r.timeLeftSec) ? Math.max(0, Math.round(r.timeLeftSec)) : null;
    el.resultTime.textContent = tl === null ? '' :
      'Kalan süre ' + pad2(Math.floor(tl / 60)) + ':' + pad2(tl % 60) + (r.window === 2 ? ' (2. pencere)' : (r.window === 1 ? ' (1. pencere)' : ''));
    el.resultTime.hidden = tl === null;
    el.resultUndo.textContent = isNum(r.undoUsed) ? 'Geri alma: ' + r.undoUsed : '';
    el.resultUndo.hidden = !isNum(r.undoUsed);
    var fname = r.frame && r.frame.name ? r.frame.name : '';
    el.resultFrame.textContent = fname ? 'Gövde: ' + fname : '';
    el.resultFrame.hidden = !fname;

    clear(el.resultEvents);
    var evs = arr(r.events);
    var eul = add(el.resultEvents, 'ul', 'timeline');
    if (!evs.length) add(eul, 'li', 'hint', 'Olay yaşanmadı.');
    evs.forEach(function (e) {
      if (!e || typeof e !== 'object') return;
      var li = add(eul, 'li');
      li.setAttribute('data-kind', 'event');
      li.setAttribute('data-event-type', e.type || '');
      add(li, 'span', 't', EVENT_ICONS[e.type] || '⚠');
      add(li, 'span', 'x', e.text || e.type || '');
    });

    var mission = obj(r.mission);
    renderMissionCard(el.resultMission, r.mission ? mission : null, {}, null);
    var fact = el.resultMission.querySelector('.mission-fact'); // NASA bilgisi ayrı kutuda
    if (fact) fact.parentNode.removeChild(fact);

    var tm = obj(r.telemetry);
    clear(el.resultTelemetry);
    kvList(el.resultTelemetry, [
      ['Kütle', fmtInt(tm.massKg) + ' kg'], ['Kuru kütle', fmtInt(tm.dryMassKg) + ' kg'], ['Yakıt', fmtInt(tm.fuelKg) + ' kg'],
      ['İtki', fmtInt(tm.thrustKN) + ' kN'], ['Isp', fmtInt(tm.isp) + ' s'], ['İtki/Ağırlık', num(tm.twr).toFixed(2)],
      ['Δv', fmtInt(tm.deltaV) + ' m/s'], ['Güç', fmtInt(tm.powerGenW) + ' / ' + fmtInt(tm.powerUseW) + ' W'],
      ['Isı', fmtInt(tm.heat) + ' / ' + fmtInt(tm.heatShield)], ['Harcanan', fmtInt(tm.spent), 'kv-amber']
    ]);
    var checks = obj(tm.checks);
    var cl = add(el.resultTelemetry, 'ul', 'check-grid');
    Object.keys(CHECK_LABELS).forEach(function (k) {
      if (k === 'computer' && checks.computer === undefined) return;
      var ok = checks[k] === true;
      var li = add(cl, 'li', null, (ok ? '✓ ' : '✕ ') + CHECK_LABELS[k]);
      li.setAttribute('data-check', k);
      li.setAttribute('data-ok', ok ? 'true' : 'false');
    });
    var insIdx = {};
    var insIds = arr(mission.requiredInstruments), insNames = arr(mission.requiredInstrumentNames);
    insIds.forEach(function (id, i) { if (typeof insNames[i] === 'string' && insNames[i]) insIdx[id] = { name: insNames[i] }; });
    if (arr(tm.missing).length) add(el.resultTelemetry, 'p', 'missing-line', 'Eksik aletler: ' + tm.missing.map(function (id) { return partName(insIdx, id); }).join(', '));

    var b = obj(r.build);
    clear(el.resultBuild);
    WORKER_ROLES.forEach(function (role) {
      var list = arr(b[role]);
      var div = add(el.resultBuild, 'div', 'build-role');
      div.setAttribute('data-build-role', role);
      add(div, 'p', 'br-head', ROLE_NAMES[role].toUpperCase());
      var ul = add(div, 'ul', 'br-list');
      if (!list.length) add(ul, 'li', 'br-empty', 'boş');
      list.forEach(function (p) {
        var li = add(ul, 'li');
        var main = add(li, 'span', 'br-main');
        add(main, 'span', 'br-name', (p.icon ? p.icon + ' ' : '') + (p.name || ''));
        add(main, 'span', 'br-slot', p.slotName || '');
      });
    });

    clear(el.resultNasa);
    if (mission.nasaReal) add(el.resultNasa, 'p', null, mission.nasaReal);
    if (mission.nasaFact) add(el.resultNasa, 'p', 'nasa-fact', 'Biliyor muydun? ' + mission.nasaFact);
    if (!mission.nasaReal && !mission.nasaFact) add(el.resultNasa, 'p', 'hint', 'Bilgi yok.');

    el.restartBtn.hidden = !isDirector;
    el.restartWait.hidden = isDirector;
  }

  // ---- Ana çizim ----
  function render(state) {
    var prevPhase = lastState && !justReconnected ? lastState.phase : null;
    var phaseChanged = !lastState || !state || lastState.phase !== state.phase;
    justReconnected = false;
    if (phaseChanged) {
      if (state && lastState) showError('');
      clearPending();
      hideSceneInfo();
      closeDrawer();
      el.slotMsg.hidden = true;
      if (lastState && state) window.scrollTo(0, 0); // yeni faz: ekranın başından
    }
    lastState = state;
    el.debug.textContent = JSON.stringify(state, null, 2);
    if (!state) { showEntry(); return; }
    if (state.timer && isNum(state.timer.now)) clockOffset = state.timer.now - Date.now();

    var role = state.you ? state.you.role : null;
    setEmbedAttrs(state.phase, role);
    setRootPhase(state.phase, role);
    renderFoot(state);
    el.entry.hidden = true;
    el.roomCode.textContent = state.code || '';
    renderPlayers(state);

    var phase = state.phase;
    var inLobby = phase === 'lobby', inSetup = phase === 'setup', inResult = phase === 'result';
    var inGame = phase === 'building' || phase === 'poll';
    el.lobby.hidden = !inLobby;
    el.setup.hidden = !inSetup;
    el.game.hidden = !inGame;
    el.result.hidden = !inResult;
    if (!inGame) { ROOT.removeAttribute('data-picked'); closeDrawer(); }

    if (!inResult) {
      stopLaunch();
      shownResultKey = null;
      el.launchWrap.hidden = true;
      el.resultPanel.hidden = true;
      if (el.scene3d.parentNode !== el.sceneHost) moveSceneTo(el.sceneHost);
    }
    if (inLobby || inSetup) {
      // yeni tur: gövde sıfırlandı
      lastFrame = null; lastSlots = null; picked = null;
      if (scene && sceneSync.frameId !== null) { sceneSync.frameId = null; sceneSync.slotsKey = null; sceneCall('setFrame', null); }
    }

    if (inLobby) {
      hideLiveBoxes();
      renderRoleButtons(state);
    } else if (inSetup) {
      hideLiveBoxes();
      renderSetup(state);
    } else if (inResult) {
      hideLiveBoxes();
      if (lastFrame) ensureScene();
      enterResultScene();
      renderResult(state);
      var r = obj(state.result);
      var key = String(r.endedAt || '') + '|' + (r.outcome || '');
      if (shownResultKey !== key) {
        shownResultKey = key;
        if (el.resultMore) el.resultMore.open = false;
        if (prevPhase === 'poll' && !NO_SEQUENCE[r.outcome]) playLaunch(r.outcome);
        else finishLaunch();
      }
    } else {
      renderGame(state);
      renderPoll(state);
      renderUndo(state);
      startTicker();
      ensureScene();
      syncScene(state);
    }
    computeLayout();
  }

  // ---- Socket ----
  if (typeof io !== 'function') {
    showError('Sunucuya bağlanılamadı (socket.io yüklenemedi).');
    return;
  }
  var socket = io();

  // ---- Demo: otomatik giriş (yalnızca ilk bağlantıda bir kez) ----
  var autoPending = !!AUTO_MODE;
  var autoRoleTried = !AUTO_ROLE;

  function notifyParentError(res) {
    if (!IN_FRAME) return;
    try {
      window.parent.postMessage({
        type: 'pp-error',
        slot: SLOT,
        error: res && typeof res.error === 'string' ? res.error : 'UNKNOWN',
        message: res && typeof res.message === 'string' ? res.message : 'Bilinmeyen hata.'
      }, location.origin);
    } catch (e) { /* yok say */ }
  }
  function autoJoinAck(res) {
    handleJoinAck(res);
    if (!res || !res.ok) notifyParentError(res);
  }
  function runAuto() {
    if (AUTO_NAME) el.name.value = AUTO_NAME;
    if (AUTO_MODE === 'create') {
      socket.emit('room:create', { name: AUTO_NAME }, autoJoinAck);
    } else {
      el.code.value = AUTO_CODE;
      if (!AUTO_CODE) {
        showError('Oda kodu gerekli.');
        notifyParentError({ error: 'BAD_REQUEST', message: 'Oda kodu gerekli.' });
        return;
      }
      socket.emit('room:join', { code: AUTO_CODE, name: AUTO_NAME }, autoJoinAck);
    }
  }
  function maybeAutoRole(state) {
    if (autoRoleTried || !state || state.phase !== 'lobby' || !state.you || state.you.role) return;
    autoRoleTried = true;
    socket.emit('role:select', { role: AUTO_ROLE }, function (res) {
      if (!res || !res.ok) {
        showError(res && res.message ? res.message : 'Bilinmeyen hata.');
        notifyParentError(res);
      }
    });
  }
  // İframe içindeyse üst pencereye özet bildir (görev/sayı YOK)
  function notifyParent(state) {
    if (!IN_FRAME) return;
    try {
      window.parent.postMessage({
        type: 'pp-state',
        slot: SLOT,
        code: state && state.code ? state.code : null,
        phase: state && state.phase ? state.phase : null,
        role: state && state.you ? state.you.role || null : null,
        name: state && state.you ? state.you.name || null : null
      }, location.origin);
    } catch (e) { /* yok say */ }
  }

  function setConn(kind, text) {
    el.connStatus.setAttribute('data-conn', kind);
    el.connText.textContent = text;
  }

  socket.on('connect', function () {
    setConn('ok', 'BAĞLI');
    var s = loadSession();
    var firstAuto = autoPending;
    autoPending = false;
    if (!s) {
      if (firstAuto) runAuto();
      return;
    }
    socket.emit('room:rejoin', { code: s.code, playerId: s.playerId }, function (res) {
      if (res && res.ok) {
        showError('');
        saveSession(res.code, res.playerId);
      } else {
        clearSession();
        showEntry();
        if (res && res.message) showError(res.message);
        notifyParent(null);
        if (firstAuto) runAuto();
      }
    });
  });
  socket.on('disconnect', function () {
    justReconnected = true;
    setConn('lost', 'BAĞLANTI YOK');
    showError('Bağlantı koptu, yeniden bağlanılıyor...');
  });
  socket.on('state', function (state) {
    if (el.error.textContent.indexOf('Bağlantı koptu') === 0) showError('');
    render(state);
    maybeAutoRole(state);
    notifyParent(state);
  });
  socket.on('room:closed', function (payload) {
    clearSession();
    showEntry();
    showError('Oda kapandı' + (payload && payload.reason ? ': ' + payload.reason : '.'));
    notifyParent(null);
  });

  // ---- Düğmeler ----
  el.errorClose.addEventListener('click', function () { showError(''); });
  el.code.addEventListener('input', function () { el.code.value = el.code.value.toUpperCase(); });
  el.code.addEventListener('keydown', function (e) { if (e.key === 'Enter') el.joinBtn.click(); });
  el.name.addEventListener('keydown', function (e) { if (e.key === 'Enter') (openForm === 'join' ? el.joinBtn : el.createBtn).click(); });
  el.createBtn.addEventListener('click', function () {
    socket.emit('room:create', { name: el.name.value }, handleJoinAck);
  });
  el.joinBtn.addEventListener('click', function () {
    socket.emit('room:join', { code: el.code.value.trim().toUpperCase(), name: el.name.value }, handleJoinAck);
  });
  el.roleBtns.forEach(function (btn) {
    btn.addEventListener('click', function () {
      var role = btn.getAttribute('data-role');
      var mine = lastState && lastState.you && lastState.you.role === role;
      socket.emit('role:select', { role: mine ? null : role }, function (res) {
        if (!res || !res.ok) showError(res && res.message ? res.message : 'Bilinmeyen hata.');
        else showError('');
      });
    });
  });

  // Parça seç → yuva seç (olay devri: listeler yeniden kurulur)
  el.catalog.addEventListener('click', function (e) {
    var b = e.target.closest('button[data-pick]');
    if (b && !b.disabled) setPicked(b.getAttribute('data-pick'));
  });
  el.slotList.addEventListener('click', function (e) {
    var b = e.target.closest('button[data-slot]');
    if (b && !b.disabled) addPart(b.getAttribute('data-slot'));
  });
  // Listede bir yuvanın üstüne gelince/odaklanınca roketteki yerini göster
  function focusFromList(e) {
    var b = e.target.closest && e.target.closest('button[data-slot]');
    if (b) sceneCall('focusSlot', b.getAttribute('data-slot'));
  }
  el.slotList.addEventListener('pointerover', focusFromList);
  el.slotList.addEventListener('focusin', focusFromList);
  el.unpickBtn.addEventListener('click', function () { if (picked) setPicked(picked); });
  document.addEventListener('keydown', function (e) {
    if (e.key !== 'Escape') return;
    if (!el.helpPanel.hidden) closeHelp();
    else if (!el.drawer.hidden) closeDrawer();
    else if (!el.sceneInfo.hidden) hideSceneInfo();
    else if (picked) setPicked(picked);
  });
  el.myParts.addEventListener('click', function (e) {
    var b = e.target.closest('button[data-remove]');
    if (b && !b.disabled) removePart(b.getAttribute('data-remove'));
  });

  // İstek sürerken düğme devre dışı (çift tık koruması); ack gelince açılır
  var sentPhase = {};
  function guarded(btn, event, payload) {
    btn.addEventListener('click', function () {
      if (pendingBtns.indexOf(btn) !== -1) return;
      pendingBtns.push(btn);
      btn.disabled = true;
      socket.emit(event, payload, function (res) {
        releasePending(btn);
        refreshControls();
        if (res && !res.ok && res.error === 'WRONG_PHASE' && lastState && lastState.phase !== sentPhase[event]) return;
        partAck(res);
      });
      sentPhase[event] = lastState ? lastState.phase : null;
    });
  }
  guarded(el.pollStartBtn, 'poll:start', {});
  guarded(el.pollCancelBtn, 'poll:cancel', {});
  guarded(el.voteGoBtn, 'poll:vote', { vote: 'go' });
  guarded(el.voteNogoBtn, 'poll:vote', { vote: 'nogo' });
  guarded(el.restartBtn, 'game:restart', {});
  el.undoBtns.forEach(function (b) { guarded(b, 'undo:use', { role: b.getAttribute('data-undo') }); });
  function refreshControls() {
    if (!liveState()) return;
    updatePollStartBtn();
    renderUndo(lastState);
  }
  el.skipLaunchBtn.addEventListener('click', finishLaunch);

  el.leaveBtn.addEventListener('click', function () {
    socket.emit('room:leave', {}, function () { /* sonuç ne olursa olsun yerelde çık */ });
    clearSession();
    showEntry();
    showError('');
    notifyParent(null);
  });

  if (window.ResizeObserver) {
    new ResizeObserver(updateBars).observe(el.strip);
    new ResizeObserver(function () { resizeScene(); }).observe(el.scene3d);
  }
  showEntry();
  computeLayout();
})();
