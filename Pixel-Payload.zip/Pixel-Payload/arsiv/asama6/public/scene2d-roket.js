// Pixel Payload — 2B roket sahnesi (Modül V)
// Arayüz: PLAN.md > AŞAMA 6 > "2B roket sahnesi". Bağımlılıksız; her şey SVG ile çizilir.
//
// ÇİZİMLERİ DEĞİŞTİRMEK (ileride PNG):
//   - Parça simgeleri: PART_ART (model → vektör çizim). Aynı model için PART_IMAGES[model] = '/art/engine.png'
//     verilirse vektör yerine o resim 24×24 kutuya sığdırılarak çizilir.
//   - Gövde: drawHull(). FRAME_IMAGES[frameId] = '/art/frame-swift.png' verilirse vektör gövde yerine resim,
//     gövdenin dünya sınır kutusuna (genişlik × yükseklik) sığdırılarak çizilir.
//   Başka hiçbir yerde çizim kodu yok.

export const supported = true;

// ---------------------------------------------------------------- renkler (ortak tasarım dili)
const C = {
  text: '#e3ecf8', dim: '#7f93b0', frame: '#1b2a44', panel: '#0a1120', bg: '#05080f',
  cyan: '#4fd1ff', amber: '#ffb347', green: '#4dff9a', red: '#ff5a6a'
};
const ROLE_COLORS = { rocket: C.amber, spacecraft: C.cyan, payload: C.green, director: C.text };
const HULL = {
  fill: '#13213a', fillHot: '#5a1a0c', line: '#9fb3cf', lineHot: '#ff7a3a',
  seam: '#2c4166', fin: '#1d3050', booster: '#0f1b30', shine: '#24385a'
};

// ---------------------------------------------------------------- değiştirilebilir görseller
const PART_IMAGES = {};   // { [model]: url }  — boşsa vektör çizim kullanılır
const FRAME_IMAGES = {};  // { [frameId]: url } — boşsa vektör gövde kullanılır

// Kategori → boş yuvada gösterilecek ipucu simgesi (model adı)
const CATEGORY_HINT = {
  engine: 'engine', tank: 'tank', fuel: 'fuel', battery: 'battery', solar: 'panel', shield: 'shield',
  antenna: 'dish', instrument: 'camera', computer: 'box', structure: 'frame'
};

// Parça simgeleri: 24×24 kutuda, c = rol rengi. Düz dolgu + kalın hat (piksel-art'a yakın sade stil).
const F = (c, o = 0.25) => ({ fill: c, 'fill-opacity': o, stroke: c });
const PART_ART = {
  engine(g, c) { // yanma odası + çan
    svg('rect', { x: 9, y: 2, width: 6, height: 6, ...F(c, 0.45) }, g);
    svg('path', { d: 'M9 8 H15 L20 21 H4 Z', ...F(c) }, g);
    svg('path', { d: 'M6.5 15 H17.5', stroke: c }, g);
  },
  tank(g, c) { // dikey kapsül tank, iki bant
    svg('rect', { x: 6, y: 2, width: 12, height: 20, rx: 6, ...F(c) }, g);
    svg('path', { d: 'M6 9 H18 M6 15 H18', stroke: c }, g);
  },
  fuel(g, c) { // damla
    svg('path', { d: 'M12 2 C12 2 5 11 5 15 A7 7 0 0 0 19 15 C19 11 12 2 12 2 Z', ...F(c, 0.35) }, g);
    svg('path', { d: 'M9 15 A3 3 0 0 0 12 18', stroke: c }, g);
  },
  panel(g, c) { // güneş paneli: ızgara
    svg('rect', { x: 2, y: 5, width: 20, height: 14, ...F(c, 0.2) }, g);
    svg('path', { d: 'M8.7 5 V19 M15.3 5 V19 M2 12 H22', stroke: c }, g);
  },
  battery(g, c) { // pil + şimşek
    svg('rect', { x: 5, y: 5, width: 14, height: 17, ...F(c, 0.2) }, g);
    svg('rect', { x: 9, y: 2, width: 6, height: 3, fill: c, stroke: c }, g);
    svg('path', { d: 'M13 8 L9 14 H12 L11 19 L15 12 H12 Z', fill: c, stroke: 'none' }, g);
  },
  shield(g, c) { // kalkan
    svg('path', { d: 'M12 2 L20 5 V12 C20 17 16.5 20 12 22 C7.5 20 4 17 4 12 V5 Z', ...F(c, 0.3) }, g);
    svg('path', { d: 'M12 6 V18', stroke: c }, g);
  },
  dish(g, c) { // çanak anten: kase + besleyici + ayak
    svg('path', { d: 'M3 8 Q12 20 21 8 Z', ...F(c, 0.3) }, g);
    svg('path', { d: 'M12 14 V5 M12 14 V21 M8 21 H16', stroke: c }, g);
    svg('circle', { cx: 12, cy: 4, r: 1.8, fill: c, stroke: 'none' }, g);
  },
  box(g, c) { // uçuş bilgisayarı: yonga
    svg('rect', { x: 6, y: 6, width: 12, height: 12, ...F(c, 0.2) }, g);
    svg('rect', { x: 9.5, y: 9.5, width: 5, height: 5, fill: c, stroke: 'none' }, g);
    svg('path', { d: 'M9 2.5 V6 M15 2.5 V6 M9 18 V21.5 M15 18 V21.5 M2.5 9 H6 M2.5 15 H6 M18 9 H21.5 M18 15 H21.5', stroke: c }, g);
  },
  frame(g, c) { // yapı: kafes
    svg('rect', { x: 3, y: 3, width: 18, height: 18, ...F(c, 0.12) }, g);
    svg('path', { d: 'M3 3 L21 21 M21 3 L3 21 M12 3 V21', stroke: c }, g);
  },
  camera(g, c) { // gövde + mercek
    svg('path', { d: 'M8 7 L10 4 H14 L16 7', ...F(c, 0.4) }, g);
    svg('rect', { x: 3, y: 7, width: 18, height: 13, ...F(c, 0.2) }, g);
    svg('circle', { cx: 12, cy: 13.5, r: 4, fill: C.bg, stroke: c }, g);
    svg('circle', { cx: 12, cy: 13.5, r: 1.5, fill: c, stroke: 'none' }, g);
  },
  spectrometer(g, c) { // prizma + ayrışan ışınlar
    svg('path', { d: 'M1 13 H8', stroke: c }, g);
    svg('path', { d: 'M11 4 L19 18 H3 Z', ...F(c, 0.3) }, g);
    svg('path', { d: 'M15 10 L23 6 M16.5 13 L23 13 M15.5 16 L23 20', stroke: c }, g);
  },
  radar(g, c) { // yayılan dalgalar
    svg('circle', { cx: 5, cy: 19, r: 2.2, fill: c, stroke: 'none' }, g);
    svg('path', { d: 'M5 13 A6 6 0 0 1 11 19 M5 8 A11 11 0 0 1 16 19 M5 3 A16 16 0 0 1 21 19', stroke: c, fill: 'none' }, g);
  },
  rover(g, c) { // gövde + üç teker + direk
    svg('rect', { x: 3, y: 9, width: 18, height: 7, ...F(c, 0.3) }, g);
    svg('path', { d: 'M16 9 V3 H20', stroke: c }, g);
    for (const x of [6, 12, 18]) svg('circle', { cx: x, cy: 19, r: 2.6, fill: C.bg, stroke: c }, g);
  },
  drill(g, c) { // motor gövdesi + sivri uç + helezon
    svg('rect', { x: 7, y: 2, width: 10, height: 6, ...F(c, 0.4) }, g);
    svg('path', { d: 'M9.5 8 H14.5 V16 L12 22.5 L9.5 16 Z', ...F(c, 0.25) }, g);
    svg('path', { d: 'M9.5 10.5 L14.5 12.5 M9.5 14 L14.5 16', stroke: c }, g);
  },
  capsule(g, c) { // dönüş kapsülü + ısı kalkanı tabanı
    svg('path', { d: 'M9 3 H15 L20 17 H4 Z', ...F(c, 0.3) }, g);
    svg('path', { d: 'M3 17 Q12 23.5 21 17 Z', fill: c, stroke: c }, g);
    svg('rect', { x: 10, y: 8, width: 4, height: 3, fill: c, stroke: 'none' }, g);
  },
  unknown(g, c) { // bilinmeyen model
    svg('path', { d: 'M12 3 L21 12 L12 21 L3 12 Z', ...F(c, 0.25) }, g);
  }
};

// Simgeyi (resim ya da vektör) size×size kutuya, merkez (0,0) olacak şekilde çizer.
function drawArt(parent, model, color, size, opacity = 1) {
  const g = svg('g', {
    transform: `translate(${-size / 2} ${-size / 2}) scale(${size / 24})`,
    'stroke-width': 2, 'stroke-linejoin': 'miter', 'stroke-linecap': 'square', opacity
  }, parent);
  const url = PART_IMAGES[model];
  if (url) svg('image', { href: url, x: 0, y: 0, width: 24, height: 24, preserveAspectRatio: 'xMidYMid meet' }, g);
  else (PART_ART[model] || PART_ART.unknown)(g, color);
  return g;
}

// ---------------------------------------------------------------- yardımcılar
const NS = 'http://www.w3.org/2000/svg';
function svg(tag, attrs, parent) {
  const e = document.createElementNS(NS, tag);
  if (attrs) for (const k in attrs) if (attrs[k] != null) e.setAttribute(k, String(attrs[k]));
  if (parent) parent.appendChild(e);
  return e;
}
const num = (v, d) => (typeof v === 'number' && Number.isFinite(v) ? v : d);
const clamp = (v, a, b) => Math.max(a, Math.min(b, v));
const smooth = (a, b, x) => { const t = clamp((x - a) / (b - a), 0, 1); return t * t * (3 - 2 * t); };
const now = () => performance.now() / 1000;
const r1 = (v) => Math.round(v * 10) / 10;
function mixHex(a, b, t) {
  const pa = parseInt(a.slice(1), 16), pb = parseInt(b.slice(1), 16);
  const ch = (s) => Math.round(((pa >> s) & 255) * (1 - t) + ((pb >> s) & 255) * t);
  return '#' + ((ch(16) << 16) | (ch(8) << 8) | ch(0)).toString(16).padStart(6, '0');
}

// Macar algoritması (n ≤ m): cost[n][m] → her satıra benzersiz sütun (toplam en küçük).
function hungarian(cost) {
  const n = cost.length, m = cost[0].length, INF = 1e18;
  const u = new Float64Array(n + 1), v = new Float64Array(m + 1);
  const p = new Int32Array(m + 1), way = new Int32Array(m + 1);
  for (let i = 1; i <= n; i++) {
    p[0] = i;
    let j0 = 0;
    const minv = new Float64Array(m + 1).fill(INF);
    const used = new Uint8Array(m + 1);
    do {
      used[j0] = 1;
      const i0 = p[j0];
      let delta = INF, j1 = 0;
      for (let j = 1; j <= m; j++) {
        if (used[j]) continue;
        const cur = cost[i0 - 1][j - 1] - u[i0] - v[j];
        if (cur < minv[j]) { minv[j] = cur; way[j] = j0; }
        if (minv[j] < delta) { delta = minv[j]; j1 = j; }
      }
      for (let j = 0; j <= m; j++) {
        if (used[j]) { u[p[j]] += delta; v[j] -= delta; } else minv[j] -= delta;
      }
      j0 = j1;
    } while (p[j0] !== 0);
    do { const j1 = way[j0]; p[j0] = p[j1]; j0 = j1; } while (j0);
  }
  const ans = new Array(n);
  for (let j = 1; j <= m; j++) if (p[j]) ans[p[j] - 1] = j - 1;
  return ans;
}

// ---------------------------------------------------------------- gövde geometrisi (dünya birimi; y yukarı)
function shapeInfo(shape) {
  const segs = (Array.isArray(shape?.segments) ? shape.segments : [])
    .map((s) => ({ id: s.id, y0: num(s.y0, 0), y1: num(s.y1, 1), r: Math.max(0.1, num(s.radius, 1)) }))
    .sort((a, b) => a.y0 - b.y0);
  if (!segs.length) segs.push({ id: 'stage1', y0: 0, y1: 8, r: 1 });
  const last = segs[segs.length - 1];
  const nose = shape?.nose
    ? { y0: num(shape.nose.y0, last.y1), y1: num(shape.nose.y1, last.y1 + 2), r: Math.max(0.1, num(shape.nose.radius, last.r)) }
    : { y0: last.y1, y1: last.y1 + last.r * 2, r: last.r };
  const r0 = segs[0].r;
  const fins = Math.max(0, Math.round(num(shape?.fins, 0)));
  const nb = Math.max(0, Math.round(num(shape?.boosters, 0)));
  let booster = null;
  if (nb > 0) {
    const b = shape.booster || {};
    const rb = Math.max(0.1, num(b.radius, r0 * 0.36));
    booster = { r: rb, y0: num(b.y0, segs[0].y0), y1: num(b.y1, segs[0].y0 + (last.y1 - segs[0].y0) * 0.38), offset: num(b.offset, r0 + rb) };
  }
  const finSpan = r0 * (fins === 3 ? 0.65 : 0.8);
  const finH = Math.min((segs[0].y1 - segs[0].y0) * 0.45, 2.4);
  let halfW = Math.max(...segs.map((s) => s.r), nose.r);
  if (fins) halfW = Math.max(halfW, r0 + finSpan);
  if (booster) halfW = Math.max(halfW, booster.offset + booster.r);
  const top = Math.max(nose.y1, last.y1, booster ? booster.y1 + booster.r * 2.2 : 0);
  return { segs, nose, r0, fins, finSpan, finH, booster, halfW, top, bottom: segs[0].y0 };
}
// Gövdenin y yüksekliğindeki yarıçapı (burun parabolik)
function radiusAt(info, y) {
  const { segs, nose } = info;
  if (y >= nose.y0) { const t = clamp((y - nose.y0) / Math.max(0.01, nose.y1 - nose.y0), 0, 1); return nose.r * (1 - t * t); }
  for (const s of segs) if (y >= s.y0 && y <= s.y1) return s.r;
  return y < segs[0].y0 ? segs[0].r : segs[segs.length - 1].r;
}

// ---------------------------------------------------------------- yerleşim
// Roketi kaba sığdırır ve yuva işaretçilerini bir ızgaraya, gerçek konumlarına en yakın ve ÇAKIŞMASIZ olarak dağıtır.
function computeLayout(frame, W, H) {
  const info = shapeInfo(frame.shape);
  const slots = Array.isArray(frame.slots) ? frame.slots.filter((s) => s && s.id != null) : [];
  const n = slots.length;
  let g = Math.floor(clamp(Math.min(W * 0.9 / 7, H / 10), 42, 60)); // hücre = dokunma alanı (≥ 40px)
  for (;;) {
    const L = tryLayout(info, slots, W, H, g);
    if (L.cells.length >= n || g <= 24) return finishLayout(L, slots, info);
    g -= 2; // yer yetmiyorsa (çok küçük kap) işaretçiyi küçült
  }
}
function tryLayout(info, slots, W, H, g) {
  const topPad = Math.max(6, H * 0.03);
  const rowY0 = H - g / 2 - 2;            // en alt satır (motorlar) merkezi
  const baseY = rowY0 - g * 0.25;         // roket tabanı (dünya y = bottom)
  const worldH = info.top - info.bottom;
  const sH = (baseY - topPad) / worldH;
  const sW = (W / 2 - g * 1.15 - 6) / info.halfW;
  const s = Math.max(1, Math.min(sH, sW));
  // Yatay abartma (en çok 1.5×): işaretçiler gövdeyi tamamen örtmesin, siluet okunsun. Gövdeler arası oran korunur.
  const kx = clamp(sW / s, 1, 1.5);
  const axisX = W / 2;
  const cells = [];
  for (let j = 0; ; j++) {
    const cy = rowY0 - j * g;
    if (cy - g / 2 < 0) break;
    for (let k = -Math.floor(W / g); k <= Math.floor(W / g); k++) {
      const cx = axisX + k * g;
      if (cx - g / 2 >= 0 && cx + g / 2 <= W) cells.push({ cx, cy });
    }
  }
  return { W, H, g, m: g - 6, s, kx, axisX, baseY, rowY0, cells };
}
function finishLayout(L, slots, info) {
  const { s, kx, axisX, baseY, g } = L;
  const X = (wx) => axisX + wx * s * kx;
  const Y = (wy) => baseY - (wy - info.bottom) * s;
  const items = slots.map((slot) => {
    const pos = Array.isArray(slot.pos) ? slot.pos : [0, 0, 0];
    const px = num(pos[0], 0), py = num(pos[1], 0), pz = num(pos[2], 0);
    const face = slot.face || 'C';
    const kind = slot.kind || 'internal';
    const r = radiusAt(info, py);
    let ax, ay, rx, ry, side = 0; // side: -1 sol dışarıda olmalı, +1 sağ
    if (kind === 'mount') {
      ax = X(px - pz * 0.5); ay = Y(info.bottom); rx = ax; ry = L.rowY0;
      if (face === 'E') side = 1; else if (face === 'W') side = -1;
    } else if (face === 'E' || face === 'W') {
      const sign = face === 'E' ? 1 : -1;
      const onBooster = slot.zone === 'booster' || Math.abs(px) > r + 0.2;
      ay = Y(py); ry = ay;
      if (onBooster) { ax = X(px); rx = ax; side = sign; } // yan itici üstü
      else { ax = X(sign * r); rx = ax + sign * (g / 2 + 6); side = sign * 2; } // dış yüzey: gövdenin dışında
    } else if (face === 'N' || face === 'S') {
      const sign = face === 'N' ? -1 : 1; // N eksenin biraz solu, S biraz sağı
      ax = X(sign * r * 0.4); ay = Y(py); rx = ax + sign * g * 0.35; ry = ay;
    } else { ax = X(px); ay = Y(py); rx = ax; ry = ay; } // C: eksen / iç bölme
    return { slot, ax, ay, rx, ry, side, hw: r * s * kx, inner: kind !== 'surface' && kind !== 'mount' && !side };
  });
  // Maliyet: dinlenme noktasına uzaklık² + yan/yüzey kuralları
  const big = (g * 3) ** 2;
  const cost = items.map((it) => L.cells.map(({ cx, cy }) => {
    let c = (cx - it.rx) ** 2 + (cy - it.ry) ** 2;
    const dx = cx - axisX;
    if (it.side === 2 && dx < it.hw * 0.6) c += big;            // E yüzeyi: gövdenin sağında kalmalı
    if (it.side === -2 && dx > -it.hw * 0.6) c += big;          // W yüzeyi
    if (it.side === 1 && dx < 0) c += big;                       // sağ yan itici
    if (it.side === -1 && dx > 0) c += big;
    if (it.inner && Math.abs(dx) > it.hw + g * 0.5) c += g * g;  // iç bölme gövdeden çok uzaklaşmasın
    return c;
  }));
  const pick = items.length ? hungarian(cost) : [];
  items.forEach((it, i) => { const cell = L.cells[pick[i]]; it.cx = cell.cx; it.cy = cell.cy; });
  return { ...L, info, items, X, Y };
}

// ---------------------------------------------------------------- stiller (sıfır özgüllük; styles.css ezebilir)
let styleInjected = false;
function injectStyle() {
  if (styleInjected) return;
  styleInjected = true;
  const st = document.createElement('style');
  st.setAttribute('data-pp', 'scene2d');
  st.textContent = `
:where(.pp2d){position:absolute;inset:0;overflow:hidden;background:transparent}
:where(.pp2d-svg){display:block;width:100%;height:100%;touch-action:manipulation;user-select:none;-webkit-user-select:none;-webkit-tap-highlight-color:transparent}
:where(.pp2d-slot){cursor:pointer;outline:none}
:where(.pp2d-slot:focus-visible) .pp2d-hit{stroke:#e3ecf8;stroke-width:2;stroke-dasharray:3 3}
:where(.pp2d-svg[data-launch="1"]) :where(.pp2d-slot[data-empty="1"],.pp2d-leaders){display:none}
:where(.pp2d-svg[data-launch="1"]) .pp2d-slot{cursor:default}
:where(.pp2d-ring){animation:pp2d-pulse 1.4s ease-in-out infinite}
@keyframes pp2d-pulse{0%,100%{opacity:.25}50%{opacity:1}}
@media (prefers-reduced-motion:reduce){:where(.pp2d-ring){animation:none;opacity:.8}}
:where(.slot-label){position:absolute;left:0;top:0;z-index:5;pointer-events:none;white-space:nowrap;max-width:calc(100% - 8px);
overflow:hidden;text-overflow:ellipsis;font:600 14px/1.35 "Segoe UI",system-ui,sans-serif;color:#e3ecf8;background:rgba(10,17,32,.95);
border:1px solid #1b2a44;border-left:3px solid #4fd1ff;padding:6px 10px;box-sizing:border-box}
:where(.slot-label) .slot-label-part{display:block;font-size:13px;font-weight:400}
:where(.slot-label) .slot-label-empty{color:#7f93b0}`;
  document.head.appendChild(st);
}

// ---------------------------------------------------------------- sahne
const LAUNCH_DUR = {
  success: 3.4, 'mission-failed': 3.4, 'no-liftoff': 3.0, 'out-of-fuel': 3.8,
  'power-loss': 3.0, overheat: 3.4, 'computer-failure': 3.6
};

function createNoopScene() {
  const noop = () => {};
  return {
    setFrame: noop, setSlots: noop, setHighlights: noop, setMyRole: noop, onSlotClick: noop, onPartClick: noop,
    focusSlot: noop, resize: noop, dispose: noop, playLaunch: () => Promise.resolve()
  };
}

export function createRocketScene(container) {
  if (!container || typeof document === 'undefined') return createNoopScene();
  try { return buildScene(container); } catch (err) {
    console.warn('[scene2d] başlatılamadı:', err);
    return createNoopScene();
  }
}

function buildScene(container) {
  injectStyle();
  if (getComputedStyle(container).position === 'static') container.style.position = 'relative';

  // DOM: kap > .pp2d > svg (+ .slot-label)
  const wrap = document.createElement('div');
  wrap.className = 'pp2d';
  const root = svg('svg', { class: 'pp2d-svg', role: 'group', 'aria-label': 'Roket' });
  wrap.appendChild(root);
  const label = document.createElement('div');
  label.className = 'slot-label';
  label.hidden = true;
  wrap.appendChild(label);
  container.appendChild(wrap);

  // Katmanlar: world (kamera kayması) > ground, rocket (poz), smoke, fx
  const worldG = svg('g', { class: 'pp2d-world' }, root);
  const groundG = svg('g', { class: 'pp2d-ground' }, worldG);
  const rocketG = svg('g', { class: 'pp2d-rocket' }, worldG);
  const smokeG = svg('g', { class: 'pp2d-smoke', 'pointer-events': 'none' }, worldG);
  const fxG = svg('g', { class: 'pp2d-fx', 'pointer-events': 'none' }, worldG);

  let frame = null, frameSig = 'null', slotsSig = 'null', hlSig = 'null';
  let occ = new Map();          // slotId → occupant | null
  let highlights = null;
  let myRole = null;
  let slotCb = null, partCb = null;
  let disposed = false;
  let L = null;                 // geçerli yerleşim
  let size = { w: 0, h: 0 };
  let refs = { hull: [], flames: [], slots: new Map() };
  let pose = null;              // fırlatma pozu (null = rampada)
  let launch = null;
  let raf = 0, launchTimer = 0, labelTimer = 0, labelSlot = null;
  let smoke = [];
  let impact = null;

  // ---------------------------------------------------------- çizim
  // Kesirli gerçek boyut: viewBox = piksel boyutu → 1 birim = 1 CSS pikseli (dokunma alanı tam g px)
  function measure() {
    const r = wrap.getBoundingClientRect();
    const cw = wrap.clientWidth, ch = wrap.clientHeight;
    // ata öğede CSS transform (ölçek) varsa rect ölçeklidir → yerleşim boyutunu kullan
    const w = Math.abs(r.width - cw) > 1 ? cw : r.width, h = Math.abs(r.height - ch) > 1 ? ch : r.height;
    return { w: Math.round(w * 100) / 100, h: Math.round(h * 100) / 100 };
  }
  function render() {
    if (disposed) return;
    const { w: W, h: H } = measure();
    size = { w: W, h: H };
    const focusedId = document.activeElement && document.activeElement.closest &&
      root.contains(document.activeElement) ? document.activeElement.getAttribute('data-slot') : null;
    groundG.replaceChildren();
    rocketG.replaceChildren();
    refs = { hull: [], flames: [], slots: new Map() };
    L = null;
    if (!W || !H) return;
    root.setAttribute('viewBox', `0 0 ${W} ${H}`);
    if (!frame) { hideLabel(); return; }
    L = computeLayout(frame, W, H);
    drawGround();
    drawFlames();
    drawHull();
    drawSlots();
    applyPose();
    if (labelSlot) positionLabel();
    if (focusedId) { const r = refs.slots.get(focusedId); if (r) r.g.focus({ preventScroll: true }); }
  }

  function drawGround() {
    const { axisX, H, info, s, kx } = L;
    const w = info.halfW * s * kx * 2.6;
    // rampa: motorların altından başlar (fırlatmada kamera yukarı kayınca devamı görünür)
    const top = r1(L.rowY0 + L.m * 0.32);
    svg('rect', { x: r1(axisX - w / 2), y: top, width: r1(w), height: r1(H - top + L.g * 2), fill: C.panel }, groundG);
    svg('path', { d: `M${r1(axisX - w / 2)} ${top} H${r1(axisX + w / 2)}`, stroke: C.frame, 'stroke-width': 2 }, groundG);
  }

  function drawHull() {
    const { info, X, Y, s } = L;
    const lw = clamp(s * 0.08, 2, 4);
    const hullG = svg('g', { class: 'pp2d-hull', 'stroke-linejoin': 'miter' }, rocketG);
    const img = frame && FRAME_IMAGES[frame.id];
    if (img) { // kullanıcı çizimi: gövde sınır kutusuna sığdır
      svg('image', { href: img, x: r1(X(-info.halfW)), y: r1(Y(info.top)), width: r1(info.halfW * 2 * s), height: r1((info.top - info.bottom) * s), preserveAspectRatio: 'xMidYMax meet' }, hullG);
      return;
    }
    const fillAttrs = (fill) => ({ fill, stroke: HULL.line, 'stroke-width': lw });
    // yan iticiler (gövdenin arkasında)
    if (info.booster) {
      const b = info.booster;
      for (const sign of [-1, 1]) {
        const cx = sign * b.offset;
        const ch = b.r * 2.2;
        const pts = [];
        for (let i = 0; i <= 8; i++) { const t = i / 8; pts.push([b.r * (1 - t * t), b.y1 + ch * t]); }
        const right = pts.map(([x, y]) => `${r1(X(cx + x))} ${r1(Y(y))}`);
        const left = pts.slice().reverse().map(([x, y]) => `${r1(X(cx - x))} ${r1(Y(y))}`);
        const d = `M${r1(X(cx - b.r))} ${r1(Y(b.y0))} L${r1(X(cx + b.r))} ${r1(Y(b.y0))} L${right.join(' L')} L${left.join(' L')} Z`;
        refs.hull.push({ el: svg('path', { d, ...fillAttrs(HULL.booster) }, hullG), base: HULL.booster });
        svg('path', { d: `M${r1(X(cx - b.r * 0.75))} ${r1(Y(b.y0))} L${r1(X(cx - b.r * 0.55))} ${r1(Y(b.y0) + 0.3 * s)} H${r1(X(cx + b.r * 0.55))} L${r1(X(cx + b.r * 0.75))} ${r1(Y(b.y0))}`, fill: HULL.seam, stroke: HULL.line, 'stroke-width': lw * 0.7 }, hullG);
      }
    }
    // kanatlar (sağ + sol; 4 kanatta önden görünen ince orta kanat)
    if (info.fins) {
      const { r0, finSpan: sp, finH: fh, bottom: y0 } = info;
      const yb = y0 - 0.25;
      for (const sign of [-1, 1]) {
        const p = [[r0, y0 + fh], [r0 + sp, y0 + fh * 0.35], [r0 + sp, yb], [r0, y0 + 0.1]];
        const d = 'M' + p.map(([x, y]) => `${r1(X(sign * x))} ${r1(Y(y))}`).join(' L') + ' Z';
        refs.hull.push({ el: svg('path', { d, ...fillAttrs(HULL.fin) }, hullG), base: HULL.fin });
      }
    }
    // motor eteği
    {
      const r = info.r0;
      svg('path', { d: `M${r1(X(-r * 0.85))} ${r1(Y(info.bottom))} L${r1(X(-r * 0.65))} ${r1(Y(info.bottom) + 0.3 * s)} H${r1(X(r * 0.65))} L${r1(X(r * 0.85))} ${r1(Y(info.bottom))}`, fill: HULL.seam, stroke: HULL.line, 'stroke-width': lw * 0.8 }, hullG);
    }
    // ana gövde profili (sağ taraf yukarı, sol taraf aşağı)
    const prof = [];
    info.segs.forEach((sg, i) => {
      if (i === 0) prof.push([sg.r, sg.y0]);
      else {
        const pr = info.segs[i - 1].r;
        if (Math.abs(pr - sg.r) > 1e-3) { prof.push([pr, sg.y0]); prof.push([sg.r, sg.y0 + Math.min(0.5, (sg.y1 - sg.y0) * 0.25)]); }
        else prof.push([sg.r, sg.y0]);
      }
      prof.push([sg.r, sg.y1]);
    });
    const nz = info.nose;
    const lastR = info.segs[info.segs.length - 1].r;
    if (Math.abs(lastR - nz.r) > 1e-3) prof.push([nz.r, nz.y0]);
    for (let i = 0; i <= 14; i++) { const t = i / 14; prof.push([nz.r * (1 - t * t), nz.y0 + (nz.y1 - nz.y0) * t]); }
    const right = prof.map(([x, y]) => `${r1(X(x))} ${r1(Y(y))}`);
    const left = prof.slice(0, -1).reverse().map(([x, y]) => `${r1(X(-x))} ${r1(Y(y))}`);
    const hullD = `M${right.join(' L')} L${left.join(' L')} Z`;
    refs.hull.push({ el: svg('path', { d: hullD, ...fillAttrs(HULL.fill) }, hullG), base: HULL.fill });
    // parlama şeridi + kademe dikişleri
    const sx = -0.55;
    svg('path', { d: `M${r1(X(sx * info.r0))} ${r1(Y(info.bottom) - 4)} V${r1(Y(nz.y0))}`, stroke: HULL.shine, 'stroke-width': Math.max(2, s * 0.12), 'stroke-linecap': 'butt' }, hullG);
    for (let i = 1; i < info.segs.length; i++) {
      const y = info.segs[i].y0, r = Math.min(info.segs[i].r, info.segs[i - 1].r);
      svg('path', { d: `M${r1(X(-r))} ${r1(Y(y))} H${r1(X(r))}`, stroke: HULL.seam, 'stroke-width': Math.max(1.5, lw * 0.8) }, hullG);
    }
    svg('path', { d: `M${r1(X(-nz.r))} ${r1(Y(nz.y0))} H${r1(X(nz.r))}`, stroke: HULL.seam, 'stroke-width': Math.max(1.5, lw * 0.8) }, hullG);
    if (info.fins === 4) { // önden görünen kanat
      const w = info.finSpan * 0.14;
      const d = `M${r1(X(-w))} ${r1(Y(info.bottom + info.finH * 0.8))} H${r1(X(w))} V${r1(Y(info.bottom - 0.25))} H${r1(X(-w))} Z`;
      refs.hull.push({ el: svg('path', { d, ...fillAttrs(HULL.fin), 'stroke-width': lw * 0.7 }, hullG), base: HULL.fin });
    }
  }

  // Durum: 'empty' | 'occupied' | 'mine' | 'ok' | 'blocked' | 'dim'
  function stateOf(id) {
    if (highlights) {
      const h = highlights[id];
      if (h === 'ok' || h === 'blocked') return h;
      return 'dim';
    }
    const o = occ.get(id);
    return o ? (o.mine ? 'mine' : 'occupied') : 'empty';
  }

  function drawSlots() {
    const { g, m } = L;
    const leaders = svg('g', { class: 'pp2d-leaders', 'pointer-events': 'none' }, rocketG);
    const slotsG = svg('g', { class: 'pp2d-slots' }, rocketG);
    for (const it of L.items) {
      const id = String(it.slot.id);
      const o = occ.get(id) || null;
      const st = stateOf(id);
      // çizgi: işaretçi yuvanın gerçek yerinden uzaklaştırıldıysa
      const dist = Math.hypot(it.cx - it.ax, it.cy - it.ay);
      if (dist > g * 0.35) {
        const k = Math.max(0, (dist - m / 2) / dist);
        const ex = it.ax + (it.cx - it.ax) * k, ey = it.ay + (it.cy - it.ay) * k;
        const op = st === 'dim' ? 0.25 : 0.7;
        svg('path', { d: `M${r1(it.ax)} ${r1(it.ay)} L${r1(ex)} ${r1(ey)}`, stroke: C.dim, 'stroke-width': 1.5, opacity: op }, leaders);
        svg('circle', { cx: r1(it.ax), cy: r1(it.ay), r: 2.5, fill: C.dim, opacity: op }, leaders);
      }
      const name = String(it.slot.name ?? id);
      const grp = svg('g', {
        class: 'pp2d-slot', 'data-slot': id, 'data-state': st, 'data-empty': o ? null : '1', 'data-mine': o && o.mine ? '1' : null,
        role: 'button', tabindex: 0, 'aria-label': o ? `${name}: ${o.name || ''}` : `${name} (boş)`,
        transform: `translate(${r1(it.cx)} ${r1(it.cy)})`
      }, slotsG);
      // dokunma alanı: tüm hücre (g×g ≥ 40px); hücreler çakışmaz
      svg('rect', { class: 'pp2d-hit', x: -g / 2, y: -g / 2, width: g, height: g, fill: '#000', 'fill-opacity': 0, 'pointer-events': 'all' }, grp);
      drawMarker(grp, st, o, it.slot, m);
      refs.slots.set(id, { g: grp, it });
    }
  }

  function drawMarker(grp, st, o, slot, m) {
    const roleC = o ? (ROLE_COLORS[o.role] || C.text) : C.dim;
    const h = -m / 2;
    const box = (attrs) => svg('rect', { class: 'pp2d-frame', x: h, y: h, width: m, height: m, ...attrs }, grp);
    const hintModel = CATEGORY_HINT[(slot.accepts || [])[0]] || 'unknown';
    if (st === 'ok') {
      svg('rect', { class: 'pp2d-ring', x: h - 4, y: h - 4, width: m + 8, height: m + 8, fill: 'none', stroke: C.green, 'stroke-width': 2 }, grp);
      box({ fill: C.green, 'fill-opacity': 0.16, stroke: C.green, 'stroke-width': 2.5 });
      if (o) drawArt(grp, o.model, roleC, m * 0.74); else drawArt(grp, hintModel, C.green, m * 0.6, 0.9);
      return;
    }
    if (st === 'blocked') {
      box({ fill: C.red, 'fill-opacity': 0.08, stroke: C.red, 'stroke-width': 2, 'stroke-dasharray': '4 3', 'stroke-opacity': 0.8 });
      if (o) drawArt(grp, o.model, roleC, m * 0.74, 0.35); else drawArt(grp, hintModel, C.dim, m * 0.6, 0.35);
      const q = m * 0.26;
      svg('path', { d: `M${-q} ${-q} L${q} ${q} M${q} ${-q} L${-q} ${q}`, stroke: C.red, 'stroke-width': 3, 'stroke-linecap': 'square' }, grp);
      return;
    }
    if (st === 'dim') grp.setAttribute('opacity', '0.3');
    if (!o) { // boş yuva: soluk kesik çerçeve + kategori ipucu
      box({ fill: C.bg, 'fill-opacity': 0.55, stroke: C.dim, 'stroke-width': 1.5, 'stroke-dasharray': '4 3' });
      drawArt(grp, hintModel, C.dim, m * 0.56, 0.75);
      return;
    }
    if (o.mine) { // benim parçam: dolu çerçeve
      box({ fill: C.panel, stroke: 'none' });
      box({ fill: roleC, 'fill-opacity': 0.3, stroke: roleC, 'stroke-width': 3 });
    } else {
      box({ fill: C.panel, 'fill-opacity': 0.92, stroke: roleC, 'stroke-width': 2 });
    }
    drawArt(grp, o.model, roleC, m * 0.74);
  }

  // ---------------------------------------------------------- etiket
  function setLabelText(id) {
    const r = refs.slots.get(id);
    if (!r) return false;
    const o = occ.get(id);
    label.replaceChildren(document.createTextNode(String(r.it.slot.name ?? id)));
    const sp = document.createElement('span');
    if (o) {
      sp.className = 'slot-label-part';
      sp.textContent = `${o.icon ? o.icon + ' ' : ''}${o.name || ''}`;
      const c = ROLE_COLORS[o.role];
      if (c) sp.style.color = c;
    } else {
      sp.className = 'slot-label-part slot-label-empty';
      sp.textContent = '(boş)';
    }
    label.appendChild(sp);
    return true;
  }
  function showLabel(id, ms) {
    clearTimeout(labelTimer);
    if (launch || !setLabelText(id)) { hideLabel(); return; }
    labelSlot = id;
    label.hidden = false;
    positionLabel();
    if (ms) labelTimer = setTimeout(hideLabel, ms);
  }
  function hideLabel() { clearTimeout(labelTimer); labelSlot = null; label.hidden = true; }
  function positionLabel() {
    const r = labelSlot && refs.slots.get(labelSlot);
    if (!r) { hideLabel(); return; }
    const wr = wrap.getBoundingClientRect();
    const br = r.g.querySelector('.pp2d-frame')?.getBoundingClientRect() || r.g.getBoundingClientRect();
    const lw = label.offsetWidth, lh = label.offsetHeight;
    const cx = br.left + br.width / 2 - wr.left;
    let top = br.top - wr.top - lh - 6;
    if (top < 2) top = br.bottom - wr.top + 6; // üstte yer yoksa altına
    const left = clamp(cx - lw / 2, 4, Math.max(4, wr.width - lw - 4));
    label.style.transform = 'none';
    label.style.left = `${Math.round(left)}px`;
    label.style.top = `${Math.round(clamp(top, 2, Math.max(2, wr.height - lh - 2)))}px`;
  }

  // ---------------------------------------------------------- tıklama / üzerine gelme
  function fire(id) {
    const r = refs.slots.get(String(id));
    if (!r || launch) return false;
    const cb = occ.get(String(id)) ? partCb : slotCb;
    try { if (cb) cb(String(id)); } catch (e) { console.error('[scene2d] tıklama işleyicisi hatası:', e); }
    return true;
  }
  const slotFromEvent = (e) => {
    const t = e.target && e.target.closest ? e.target.closest('.pp2d-slot') : null;
    return t && root.contains(t) ? t.getAttribute('data-slot') : null;
  };
  let lastPointerType = 'mouse';
  const onDown = (e) => { lastPointerType = e.pointerType || 'mouse'; };
  const onClick = (e) => {
    const id = slotFromEvent(e);
    if (!id) { if (lastPointerType !== 'mouse') hideLabel(); return; }
    showLabel(id, lastPointerType === 'mouse' ? 0 : 2600);
    fire(id);
  };
  const onMove = (e) => {
    if (e.pointerType && e.pointerType !== 'mouse') return;
    const id = slotFromEvent(e);
    if (id) { if (id !== labelSlot) showLabel(id, 0); } else if (labelSlot) hideLabel();
  };
  const onLeave = (e) => { if (!e.pointerType || e.pointerType === 'mouse') hideLabel(); };
  const onKey = (e) => {
    if (e.key !== 'Enter' && e.key !== ' ') return;
    const id = slotFromEvent(e);
    if (!id) return;
    e.preventDefault();
    showLabel(id, 2600);
    fire(id);
  };
  const onFocusIn = (e) => { const id = slotFromEvent(e); if (id && e.target.matches(':focus-visible')) showLabel(id, 0); };
  const onFocusOut = () => { if (lastPointerType === 'mouse' && !root.matches(':hover')) hideLabel(); };
  root.addEventListener('pointerdown', onDown);
  root.addEventListener('click', onClick);
  root.addEventListener('pointermove', onMove);
  root.addEventListener('pointerleave', onLeave);
  root.addEventListener('keydown', onKey);
  root.addEventListener('focusin', onFocusIn);
  root.addEventListener('focusout', onFocusOut);

  // ---------------------------------------------------------- fırlatma
  function drawFlames() {
    const { items, m, g } = L;
    let mounts = items.filter((it) => it.slot.kind === 'mount');
    const withEngine = mounts.filter((it) => { const o = occ.get(String(it.slot.id)); return o && (o.model === 'engine' || !o.model); });
    if (withEngine.length) mounts = withEngine;
    const spots = mounts.length ? mounts.map((it) => ({ x: it.cx, y: it.cy + m * 0.32 })) : [{ x: L.axisX, y: L.baseY }];
    const fl = svg('g', { class: 'pp2d-flames', 'pointer-events': 'none' }, rocketG);
    refs.flames = spots.map((p) => ({
      ...p, w: g * 0.5,
      outer: svg('path', { fill: '#ff8a3a', opacity: 0.9 }, fl),
      inner: svg('path', { fill: '#ffe9a8' }, fl)
    }));
  }
  function flamePath(x, y, w, len) {
    return `M${r1(x - w / 2)} ${r1(y)} Q${r1(x - w * 0.6)} ${r1(y + len * 0.5)} ${r1(x)} ${r1(y + len)} Q${r1(x + w * 0.6)} ${r1(y + len * 0.5)} ${r1(x + w / 2)} ${r1(y)} Z`;
  }
  function restPose() { return { dx: 0, dy: 0, rot: 0, pivot: 'base', heat: 0, power: 1, flame: 0, cam: 0 }; }

  function applyPose() {
    const p = pose || restPose();
    if (!L) return;
    const pivotY = p.pivot === 'mid' ? L.baseY - (L.info.top - L.info.bottom) * L.s * 0.5 : L.baseY;
    rocketG.setAttribute('transform', `translate(${r1(p.dx)} ${r1(-p.dy)}) rotate(${r1(p.rot)} ${L.axisX} ${r1(pivotY)})`);
    worldG.setAttribute('transform', `translate(0 ${r1(-p.cam)})`);
    for (const h of refs.hull) {
      h.el.setAttribute('fill', p.heat > 0 ? mixHex(h.base, HULL.fillHot, p.heat) : h.base);
      h.el.setAttribute('stroke', p.heat > 0 ? mixHex(HULL.line, HULL.lineHot, p.heat) : HULL.line);
    }
    rocketG.style.filter = p.power < 0.999 ? `brightness(${r1(0.25 + 0.75 * p.power)}) saturate(${r1(p.power)})` : '';
    for (const f of refs.flames) {
      const len = p.flame > 0.01 ? L.g * (1.2 + 1.6 * p.flame) * (0.85 + Math.random() * 0.3) : 0;
      if (!len) { f.outer.setAttribute('d', ''); f.inner.setAttribute('d', ''); continue; }
      f.outer.setAttribute('d', flamePath(f.x, f.y, f.w * (0.7 + 0.3 * p.flame), len));
      f.inner.setAttribute('d', flamePath(f.x, f.y, f.w * 0.45, len * 0.55));
    }
  }

  function emitSmoke(n, x, y) {
    for (let i = 0; i < n && smoke.length < 50; i++) {
      const el = svg('circle', { fill: '#8a96a8', opacity: 0 }, smokeG);
      smoke.push({ el, x: x + (Math.random() - 0.5) * L.g * 0.6, y, vx: (Math.random() < 0.5 ? -1 : 1) * (20 + Math.random() * 70), vy: -Math.random() * 15, age: 0, life: 1.4 + Math.random() * 0.6 });
    }
  }
  function updateSmoke(dt) {
    const g = L ? L.g : 40;
    for (let i = smoke.length - 1; i >= 0; i--) {
      const p = smoke[i];
      p.age += dt;
      const k = p.age / p.life;
      if (k >= 1) { p.el.remove(); smoke.splice(i, 1); continue; }
      p.x += p.vx * dt; p.y += p.vy * dt;
      p.el.setAttribute('cx', r1(p.x)); p.el.setAttribute('cy', r1(p.y));
      p.el.setAttribute('r', r1(g * (0.2 + 0.9 * k)));
      p.el.setAttribute('opacity', r1(0.45 * (1 - k) * 100) / 100);
    }
  }
  function clearFx() {
    for (const p of smoke) p.el.remove();
    smoke = [];
    fxG.replaceChildren();
    impact = null;
  }

  function stepLaunch() {
    if (!launch || disposed) return;
    const t = now();
    const dt = Math.min(0.05, t - launch.last);
    launch.last = t;
    const e = t - launch.t0;
    const H = size.h || 400, W = size.w || 300, g = L ? L.g : 40;
    const R = L ? (L.info.top - L.info.bottom) * L.s : H;
    const p = restPose();
    const ign = smooth(0, 0.5, e);
    let shake = 0, smokeRate = 0;
    switch (launch.outcome) {
      case 'no-liftoff': {
        p.flame = e < 1.8 ? ign * 0.9 : e < 2.4 ? (Math.random() > 0.4 ? 0.7 : 0.1) : 0;
        shake = e < 2.4 ? 1 + 4 * smooth(0.5, 1.8, e) : 0;
        p.dy = 3 * smooth(0.6, 1.0, e) * (1 - smooth(1.8, 2.3, e));
        smokeRate = e < 2.4 ? 30 : 0;
        break;
      }
      case 'out-of-fuel': {
        const A = 0.4 * H / 1.96, v1 = 2 * A * 1.4, gk = (0.4 * H + 1.2 * v1) / 1.44;
        if (e < 0.6) { p.flame = ign; shake = 1.5; smokeRate = 30; }
        else if (e < 2.0) {
          const tt = e - 0.6;
          p.dy = A * tt * tt;
          p.flame = e > 1.7 ? (Math.random() > 0.5 ? 0.8 : 0.05) : 1;
          smokeRate = 20;
        } else {
          const tb = e - 2.0;
          if (tb < 1.2) { p.dy = Math.max(0, 0.4 * H + v1 * tb - gk * tb * tb); p.rot = -80 * smooth(0.1, 1.2, tb); }
          else {
            p.rot = -80;
            if (!impact && L) { // yere çarpma parlaması
              impact = { el: svg('circle', { cx: L.axisX, cy: L.baseY, r: 4, fill: '#ff7a3a', opacity: 0.8 }, fxG), t0: t };
              emitSmoke(12, L.axisX - R * 0.3, L.baseY);
            }
          }
        }
        break;
      }
      case 'power-loss': {
        if (e < 0.5) p.power = 1;
        else if (e < 2.2) p.power = Math.random() > (e - 0.5) / 1.7 ? 1 : 0.15;
        else p.power = 0.15 - 0.07 * smooth(2.2, 2.8, e);
        break;
      }
      case 'overheat': {
        p.flame = e < 2.8 ? ign * (0.8 + Math.random() * 0.2) : Math.max(0, 1 - (e - 2.8) * 3) * 0.6;
        p.dy = 0.12 * H * smooth(0.8, 2.0, e) * (1 - smooth(2.6, 3.3, e));
        p.heat = smooth(0.5, 2.0, e);
        shake = 1 + 3 * smooth(1.2, 2.8, e);
        smokeRate = 25;
        break;
      }
      case 'computer-failure': {
        p.flame = ign; smokeRate = 25; p.pivot = 'mid';
        if (e > 0.8) {
          const tt = e - 0.8, w = Math.max(0, tt - 0.7);
          p.dy = 0.18 * H * tt * tt;
          p.rot = 25 * Math.pow(w, 1.3) + 8 * Math.sin(w * 6) * Math.min(1, w);
          p.dx = 0.12 * W * w * w;
        } else shake = 1.5;
        break;
      }
      default: { // success, mission-failed: normal kalkış
        p.flame = ign; smokeRate = 35;
        if (e > 0.8) { const tt = e - 0.8; p.dy = (H + R) * tt * tt / 5.76; } else shake = 1.5;
      }
    }
    if (launch.outcome !== 'power-loss') p.cam = smooth(0, 0.5, e) * g * 1.4; // alevler görünsün diye kamera biraz yukarı
    if (shake) p.dx += (Math.random() - 0.5) * shake * 2;
    pose = p;
    applyPose();
    if (L && smokeRate && p.flame > 0.1 && p.dy < g * 3) emitSmoke(Math.round(smokeRate * dt + Math.random()), L.axisX + p.dx, L.H - 1);
    updateSmoke(dt);
    if (impact) {
      const k = clamp((t - impact.t0) / 0.7, 0, 1);
      impact.el.setAttribute('r', r1(4 + k * g * 1.6));
      impact.el.setAttribute('opacity', r1((1 - k) * 80) / 100);
    }
    if (e >= launch.dur) { finishLaunch(); return; }
    raf = requestAnimationFrame(stepLaunch);
  }
  function finishLaunch() {
    cancelAnimationFrame(raf);
    clearTimeout(launchTimer);
    if (!launch) return;
    const r = launch.resolve;
    launch = null;
    if (pose) { pose.flame = 0; applyPose(); }
    for (const p of smoke) p.el.remove();
    smoke = [];
    if (impact) { impact.el.remove(); impact = null; }
    // data-launch kalır: son pozda boş yuvalar gizli; setFrame (aynı gövde) rampaya sıfırlar
    r();
  }
  function resetLaunch() {
    if (launch) finishLaunch();
    pose = null;
    clearFx();
    root.removeAttribute('data-launch');
    applyPose();
  }
  function playLaunch(outcome) {
    if (disposed || outcome === 'window-missed' || !frame) return Promise.resolve();
    resetLaunch();
    hideLabel();
    root.setAttribute('data-launch', '1');
    return new Promise((resolve) => {
      const dur = LAUNCH_DUR[outcome] ?? 3.4;
      launch = { outcome: LAUNCH_DUR[outcome] ? outcome : 'success', dur, resolve, t0: now(), last: now() };
      pose = restPose();
      // sekme gizliyken rAF durur: güvenlik zamanlayıcısı
      launchTimer = setTimeout(finishLaunch, (dur + 1.5) * 1000);
      raf = requestAnimationFrame(stepLaunch);
    });
  }

  // ---------------------------------------------------------- boyut
  function onResize() {
    if (disposed) return;
    const { w: W, h: H } = measure();
    if (W === size.w && H === size.h) return;
    render();
  }
  let ro = null;
  if (typeof ResizeObserver !== 'undefined') { ro = new ResizeObserver(onResize); ro.observe(wrap); }
  else window.addEventListener('resize', onResize);

  // ---------------------------------------------------------- dış arayüz
  function setFrame(f) {
    if (disposed) return;
    const sig = f ? JSON.stringify(f) : 'null';
    const changed = sig !== frameSig;
    if (!changed && !pose && !launch) return;
    frameSig = sig;
    resetLaunch();
    if (changed) { frame = f || null; hideLabel(); }
    render();
  }
  function setSlots(slots) {
    if (disposed) return;
    const sig = JSON.stringify(slots ?? null);
    if (sig === slotsSig) return;
    slotsSig = sig;
    occ = new Map();
    if (Array.isArray(slots)) for (const s of slots) if (s && s.id != null) occ.set(String(s.id), s.occupant || null);
    render();
  }
  function setHighlights(map) {
    if (disposed) return;
    const m = map && typeof map === 'object' ? map : null;
    const sig = JSON.stringify(m);
    if (sig === hlSig) return;
    hlSig = sig;
    highlights = m;
    render();
  }
  function setMyRole(role) {
    myRole = role ?? null;
    if (myRole) wrap.setAttribute('data-my-role', myRole); else wrap.removeAttribute('data-my-role');
  }
  function focusSlot(id) {
    if (disposed || launch) return;
    const r = refs.slots.get(String(id));
    if (!r) return;
    // sakin vurgu: kısa süreli beyaz çerçeve + etiket (döndürme/yakınlaştırma yok)
    const m = L.m + 10;
    const ring = svg('rect', { x: -m / 2, y: -m / 2, width: m, height: m, fill: 'none', stroke: C.text, 'stroke-width': 2, 'pointer-events': 'none' }, r.g);
    setTimeout(() => ring.remove(), 1800);
    showLabel(String(id), 2500);
  }
  function dispose() {
    if (disposed) return;
    resetLaunch();
    disposed = true;
    clearTimeout(labelTimer);
    if (ro) ro.disconnect(); else window.removeEventListener('resize', onResize);
    root.removeEventListener('pointerdown', onDown);
    root.removeEventListener('click', onClick);
    root.removeEventListener('pointermove', onMove);
    root.removeEventListener('pointerleave', onLeave);
    root.removeEventListener('keydown', onKey);
    root.removeEventListener('focusin', onFocusIn);
    root.removeEventListener('focusout', onFocusOut);
    wrap.remove();
    delete container.dataset.sceneReady;
    if (window.__ppScene === hooks) delete window.__ppScene;
  }

  // Test kancaları
  const hooks = {
    slotScreenPos(id) {
      const r = !disposed && refs.slots.get(String(id));
      if (!r) return null;
      const b = r.g.querySelector('.pp2d-hit').getBoundingClientRect();
      const cr = wrap.getBoundingClientRect();
      const x = b.left + b.width / 2, y = b.top + b.height / 2;
      if (!b.width || x < cr.left || x > cr.right || y < cr.top || y > cr.bottom) return null;
      return { x, y };
    },
    clickSlot(id) { return fire(id); }
  };
  window.__ppScene = hooks;

  render();
  container.dataset.sceneReady = '1';

  return {
    setFrame, setSlots, setHighlights, setMyRole,
    onSlotClick(fn) { slotCb = typeof fn === 'function' ? fn : null; },
    onPartClick(fn) { partCb = typeof fn === 'function' ? fn : null; },
    focusSlot, resize: () => { size = { w: -1, h: -1 }; onResize(); }, dispose, playLaunch
  };
}
